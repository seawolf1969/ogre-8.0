<?php 
namespace App\Models;
use CodeIgniter\Model;
use CodeIgniter\I18n\Time;

class Game extends Model{
    var $gameid=0;
    var $msa_id=0;
    var $game_name='';
    var $game_subname='';
    var $game_abrev='';
    var $game_type='';
    var $game_typeid=0;
    var $game_orgtype='';
    var $game_orgtypeid=0;                
    var $game_affiliation='';
    var $game_affiliationid=0;
    var $game_man='';
    var $game_manid=0;                
    var $game_type_ids=''; 
    var $game_types=''; 
    var $game_desc='';
    var $min_players=0;
    var $max_players=0;  
    var $group_flag=0;
    var $website='';
		
			
    public function __construct(){
//       parent::__construct();
    }			
//---------------------------------------------------
//
//---------------------------------------------------
    public function init($gameid=0){   
        $this->gameid=0;
        $this->msa_id=0;
        $this->game_name='';
        $this->game_subname='';
        $this->game_abrev='';
        $this->game_type='';
        $this->game_typeid=0;
        $this->game_man='';
        $this->game_manid=0;                        
        $this->game_affiliation='';
        $this->game_affiliationid=0;
        $this->game_orgtype='';
        $this->game_orgtypeid=0;                      
        $this->game_type_ids=''; 
        $this->game_types=''; 
        $this->game_desc = '';
        $this->min_players=0;
        $this->max_players=0;  
        $this->group_flag=0;
        $this->website='';
        if($gameid != 0){
                $this->getGameData($gameid);
        }	 
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getGameData($gid){
        $ci = &get_instance();
        $qry = "SELECT * FROM ogre_games WHERE gn_game_id = " . $gid;
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $this->gameid = $row->gn_game_id;
                $this->msa_id = $row->gn_msa_game_id;
                $this->game_manid = $row->gn_gman_id;
                $this->game_man = $this->getPublisher($row->gn_gman_id);
                $this->game_name = $row->gn_game_name;
                $this->game_subname = $row->gn_game_subname;
                $this->game_abrev = $row->gn_abrev_name;
                $this->msa_id = $row->gn_msa_game_id; 
                $this->min_players = $row->gn_game_min_players;
                $this->max_players = $row->gn_game_max_players;	
                $this->group_flag = $row->gn_game_group_flag;
                $this->website = $row->gn_game_website;	
                $desc=  strip_tags($row->gn_game_description);
                $this->game_desc = html_entity_decode(ascii_to_entities($desc),ENT_QUOTES);

            }
        }		
        $qry =  'SELECT gd_descriptor, gd_id FROM ogre_games, ogre_games_descriptor, ogre_games_descriptor_xref, ogre_games_descriptor_type  ';
        $qry .= 'WHERE ogre_games.gn_game_id = ogre_games_descriptor_xref.gdx_gn_id ';
        $qry .= 'AND ogre_games_descriptor_xref.gdx_gd_id = ogre_games_descriptor.gd_id ';
        $qry .= 'AND ogre_games_descriptor_type.gdt_id = ogre_games_descriptor.gd_descriptor_type ';
        $qry .= 'AND gn_game_id = ' . $gid;
        $qry .= ' ORDER BY ogre_games_descriptor.gd_descriptor_type, ogre_games_descriptor_xref.gdx_id';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row)
            {
                $this->game_type_ids .= $row->gd_id . ',';
                $this->game_types .= $row->gd_descriptor . ',';
            }
        }
        $qry =  'SELECT gd_descriptor, gd_id FROM ogre_games, ogre_games_descriptor, ogre_games_descriptor_xref, ogre_games_descriptor_type  ';
        $qry .= 'WHERE ogre_games.gn_game_id = ogre_games_descriptor_xref.gdx_gn_id ';
        $qry .= 'AND ogre_games_descriptor_xref.gdx_gd_id = ogre_games_descriptor.gd_id ';
        $qry .= 'AND ogre_games_descriptor_type.gdt_id = ogre_games_descriptor.gd_descriptor_type ';
        $qry .= 'AND gn_game_id = ' . $gid . ' AND ogre_games_descriptor.gd_descriptor_type = 1 ';
        $qry .= ' ORDER BY ogre_games_descriptor.gd_descriptor_type, ogre_games_descriptor_xref.gdx_id';   
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row)
            {
                $this->game_type = $row->gd_descriptor;
                $this->game_typeid = $row->gd_id;
            }
        }   
        $qry =  'SELECT gd_descriptor, gd_id FROM ogre_games, ogre_games_descriptor, ogre_games_descriptor_xref, ogre_games_descriptor_type  ';
        $qry .= 'WHERE ogre_games.gn_game_id = ogre_games_descriptor_xref.gdx_gn_id ';
        $qry .= 'AND ogre_games_descriptor_xref.gdx_gd_id = ogre_games_descriptor.gd_id ';
        $qry .= 'AND ogre_games_descriptor_type.gdt_id = ogre_games_descriptor.gd_descriptor_type ';
        $qry .= 'AND gn_game_id = ' . $gid . ' AND ogre_games_descriptor.gd_descriptor_type = 5 ';
        $qry .= ' ORDER BY ogre_games_descriptor.gd_descriptor_type, ogre_games_descriptor_xref.gdx_id';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $this->game_affiliation = $row->gd_descriptor;
                $this->game_affiliationid = $row->gd_id;
            }
        }
        $qry =  'SELECT gd_descriptor, gd_id FROM ogre_games, ogre_games_descriptor, ogre_games_descriptor_xref, ogre_games_descriptor_type  ';
        $qry .= 'WHERE ogre_games.gn_game_id = ogre_games_descriptor_xref.gdx_gn_id ';
        $qry .= 'AND ogre_games_descriptor_xref.gdx_gd_id = ogre_games_descriptor.gd_id ';
        $qry .= 'AND ogre_games_descriptor_type.gdt_id = ogre_games_descriptor.gd_descriptor_type ';
        $qry .= 'AND gn_game_id = ' . $gid . ' AND ogre_games_descriptor.gd_descriptor_type = 3 ';
        $qry .= ' ORDER BY ogre_games_descriptor.gd_descriptor_type, ogre_games_descriptor_xref.gdx_id';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                    $this->game_orgtype = $row->gd_descriptor;
                    $this->game_orgtypeid = $row->gd_id;
            }
        }                        
    }
                
//---------------------------------------------------
//
//---------------------------------------------------               
    public function getPrimaryGameType($gid){
        $ci = &get_instance();
        $qry =  'SELECT gd_descriptor, gd_id FROM ogre_games, ogre_games_descriptor, ogre_games_descriptor_xref, ogre_games_descriptor_type  ';
        $qry .= 'WHERE ogre_games.gn_game_id = ogre_games_descriptor_xref.gdx_gn_id ';
        $qry .= 'AND ogre_games_descriptor_xref.gdx_gd_id = ogre_games_descriptor.gd_id ';
        $qry .= 'AND ogre_games_descriptor_type.gdt_id = ogre_games_descriptor.gd_descriptor_type ';
        $qry .= 'AND gn_game_id = ' . $gid . ' AND ogre_games_descriptor.gd_descriptor_type = 1 ';
        $qry .= ' ORDER BY ogre_games_descriptor.gd_descriptor_type, ogre_games_descriptor_xref.gdx_id';  
        $query = $ci->db->query($qry);

        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $this->game_type = $row->gd_descriptor;
                $this->game_typeid = $row->gd_id;
            }
        }
       return $this->game_typeid;
    }
    //---------------------------------------------------  
    //
    //---------------------------------------------------
    public function save_game( $p){
        $ret = (intval($p["gameid"]==0)) ? $this->save_new_game( $p) : $this->updateGame( $p);
        return $ret;
    }
    //---------------------------------------------------
    //
    //---------------------------------------------------
    private function save_new_game( $p){
        $ci = &get_instance();	
        $desc  = $p["game_descrption"]; 
        $ins = "INSERT ogre_games  ( ";
        $ins .= "gn_game_name,";
        $ins .= "gn_abrev_name,";
        $ins .= "gn_game_description,";
        $ins .= "gn_msa_game_id,";
        $ins .= "gn_game_min_players,";		
        $ins .= "gn_game_max_players,";
        $ins .= "gn_game_group_flag,";
        $ins .= "gn_game_website";
        $ins .= ") ";
        $ins .= "VALUES (" ;	 
        $ins .= '"' . $p['game_name'] . '", ';
        $ins .= '"' . $p['game_abrev'] . '", ';
        $ins .= '"' . $desc . '", ';
        $ins .=  $p['alt_id'] . ', ';
        $ins .=  $p['game_min_players'] . ', ';
        $ins .=  $p['game_max_players'] . ', ';
        $ins .=  $p['game_group'] . ', ';
        $ins .= '"' . $p['game_website'] . '" ';
        $ins .= ');';
        $ci->db->query($ins);
        if ($ci->db->affectedRows() > 0){
                $ret = "Failure: " . $ins;
        }
        else{  
                $ret = TRUE;
                $id = mysql_insert_id();  
        }
        if($ret===TRUE){
                $dsc[0] = $p["game_type"];
                $dsc[1] = $p["game_type1"];
                $dsc[2] = $p["game_type2"];
                $ret = $this->insertGameDescriptors($dsc,$id);
        }
        return $ret;  
    } 
    //---------------------------------------------------
    //
    //---------------------------------------------------
     public function createNewPublisher($pubname, $pubweb){
        $ci = &get_instance();
        $ins = "";
        $ins = "INSERT ogre_manufacturers  ( ";
        $ins .= "gman_name, ";
        $ins .= "gman_web";
        $ins .= ") ";
        $ins .= "VALUES (" ;	 
        $ins .= '"' . $pubname . '", ';
        $ins .= '"' . $pubweb . '" ';
        $ins .= ');';		
        $ci->db->query($ins);
        if ($ci->db->affectedRows() > 0){
            $ret= $ci->db->insertID();
        }
        return $ret;
     }                
                
//---------------------------------------------------
//
//---------------------------------------------------
    public function insertGameDescriptors($d,$gameid){
        $ci = &get_instance();
        for($i=0;$i<=count($d);$i++){
            if($d[$i]!='0'){
                $ins = 'INSERT ogre_games_descriptor_xref  ( ';
                $ins .= 'gdx_gn_id,';
                $ins .= 'gdx_gd_id';
                $ins .= ') ';
                $ins .= 'VALUES (' ;	 
                $ins .=  $gameid . ', ';
                $ins .=  $d[$i];
                $ins .= ');';	 
                $ci->db->query($ins);
                if ($this->db->affectedRows() > 0){
                    $ret = "Failure: " . $ins;
                }
                else{  
                    $ret = TRUE;
                }
            }
        }
        return $ret; 
    }
//---------------------------------------------------
//
//---------------------------------------------------
    private function updateGame( $p){
        $ci = &get_instance();
        $desc  = $p["game_descrption"];
        $qry = "UPDATE ogre_games ";
        $qry .= ' SET ';
        $qry .= ' gn_msa_game_id = ' . $p["alt_id"] . ',';
        $qry .= ' gn_game_name = "' . $p["game_name"] . '",';
        $qry .= ' gn_abrev_name = "' . $p["game_abrev"] . '",';
        $qry .= ' gn_game_description = "' . $desc . '",';
        $qry .= ' gn_game_min_players = ' . $p["game_min_players"] . ',';
        $qry .= ' gn_game_max_players = ' . $p["game_max_players"] . ',';
        $qry .= ' gn_game_group_flag = ' . $p["game_group"] . ',';
        $qry .= ' gn_game_website = "' . $p["game_website"] . '"';
        $qry .= ' WHERE gn_game_id =' . $this->gameid .';';
        $ci->db->query($qry);
        if ($ci->db->affectedRows() > 0){
                $dsc[0] = $p["game_type"];
                $dsc[1] = $p["game_type1"];
                $dsc[2] = $p["game_type2"];
                $ret = $this->deleteGameDescriptors($dsc);
                $ret = $this->insertGameDescriptors($dsc,$this->gameid);
        }
        return $ret;
    }
		
//---------------------------------------------------
//
//---------------------------------------------------
    public function deleteGameDescriptors($d){
        $ci = &get_instance();
        for($i=0;$i<=count($d);$i++){
            if($d[$i]!='0'){
                $del = 'DELETE FROM ogre_games_descriptor_xref  ';
                $del .= 'WHERE gdx_gn_id = '. $this->gameid;	 
                $del .= ' AND gdx_gd_id = ' . $d[$i];
                $ci->db->query($del);
                if ($ci->db->affectedRows() > 0){
                    $ret = "Failure: " . $del;
                }
                else{  
                    $ret = TRUE;
                }	   
            }
        }	  
        return $ret; 
    }		
//---------------------------------------------------
//
//---------------------------------------------------
    public function getDescriptorsView($delpage=''){
        $ci = &get_instance();
        $qry ='SELECT * FROM ogre_games, ogre_games_descriptor_xref, ogre_games_descriptor, ogre_games_descriptor_type ';
        $qry .= 'WHERE ogre_games.gn_game_id = ogre_games_descriptor_xref.gdx_gn_id ';
        $qry .= 'AND ogre_games_descriptor_xref.gdx_gd_id = ogre_games_descriptor.gd_id ';
        $qry .= 'AND ogre_games_descriptor_type.gdt_id = ogre_games_descriptor.gd_descriptor_type ';
        $qry .= 'AND ogre_games.gn_game_id= ' . $this->gameid . ' ' ;
        $qry .= 'AND ogre_games_descriptor.gd_descriptor_type <> 1 ';
        $qry .= 'ORDER BY gn_game_name';
        $query = $ci->db->query($qry);
        $i = 1;
        $ret = '';
        $ret = '<table cellpadding="3" cellspacing="0" border="0" align="center">';
        $ret .= '<tr>';
        $ret .= '<th>';		  
        $ret .= 'Descriptor';
        $ret .= '</th>';	  
        $ret .= '<th>';
        $ret .= '&nbsp;';
        $ret .= '</th>';  
        $ret .= '</tr>';
        if ($ci->db->affectedRows() > 0){
            foreach ($query->getResult() as $row){ 
                if($i%2==1){
                        $ret .= '<tr bgcolor="#999999">';
                }else{
                        $ret .= '<tr>';  
                }
                $ret .= '<td>' . $row->gd_descriptor . '</td>';  
                $i++;
                $ret .= '<td  align="right">';	      
                $ret .= '<input name="delg" id="delg" type="button"  class="btn btn-secondary" value=" Del " onclick="self.location='. "'". $delpage . '&gid=' . $row->gn_game_id . '&did=' . $row->gd_id . "'" . '" />';		  
                $ret .= '</td>';
                $ret .= '</tr>';
            }
        }
        $ret .= '</table>';	
        return $ret;	

    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getDescriptor($id){
        $ci = &get_instance();
        $ret = 0;
        $qry ='SELECT * FROM ogre_games_descriptor WHERE ogre_games_descriptor.gd_id = ' . $id;
        $query = $ci->db->query($qry);
        if ($ci->db->affectedRows() > 0){
            foreach ($query->getResult() as $row){
                    $ret = $row->gd_descriptor;
            }
        }
        return $ret;
    }
//--------------------------------------------------- 
//
//---------------------------------------------------
    public function getDescriptorID($name){
        $ci = &get_instance();
        $ret = 0;
        $qry ='SELECT * FROM ogre_games_descriptor WHERE ogre_games_descriptor.gd_descriptor = "' . $name . '"';
        $query = $ci->db->query($qry);
        if ($ci->db->affectedRows() > 0){
            foreach ($query->getResult() as $row){
                    $ret = $row->gd_id;
            }
        }
        return $ret;
    }               
//---------------------------------------------------
//
//---------------------------------------------------
    public function getPublisher($id){
        $ci = &get_instance();
        $ret=array();
        $qry ='SELECT * FROM ogre_manufacturers WHERE ogre_manufacturers.gman_id = ' . $id;

        $query = $ci->db->query($qry);

        if ($ci->db->affectedRows() > 0)
        {
            foreach ($query->getResult() as $row)
            {
                    $ret['name'] = $row->gman_name;
                    $ret['website'] = $row->gman_web;
            }
        }

        return $ret;
    }                        
//------------------------
//
//------------------------
    public function buildScenarioAffiliationDrop($aff='RPGA'){
        $ci = &get_instance();
        $i= 0;
        $qry='SELECT * FROM ogre_games_descriptor WHERE gd_descriptor_type = 5';

        $query = $ci->db->query($qry);

        if ($query->getNumRows() > 0){
            $ret = '<select name="affiliation">';
            $ret .= '<option value=" ">(Afilliation)</option>';
            foreach ($query->getResult() as $row){
                if ($aff == $row->gd_descriptor){
                    $ret .= '<option value="' . $row->gd_descriptor . '" selected="selected">' . $row->gd_descriptor . '</option>';
                }
                else{
                    $ret .= '<option value="' . $row->gd_descriptor . '" >' . $row->gd_descriptor . '</option>';
                }
            }
        }
        $ret .= '</select>';
        return $ret;
    }
//------------------------
//
//------------------------
    public function buildLevelRangeDropdown($val='0'){
        $ci = &get_instance();                
        $ret = '';
        $ret .= '<select name="levelrange" size="1">';
        $ret .=  '<option value="0">(4e Only)</option>';
        $lvlist = $ci->ogre_lib->getMiscContent(10);
        $lvlarray = explode(',', $lvlist['content']);
        foreach ($lvlarray as $lvlrange){
            if ($lvlrange == $val){
                $ret .=  '<option value="' . $lvlrange . '" selected="selected">' . $lvlrange . '</option>';
            }
            else{
                $ret .=  '<option value="' . $lvlrange . '">' . $lvlrange . '</option>';
            }
        }
        $ret .=  '</select>';
        return $ret;
    }
//***********************************
//
//***********************************
    public function getGameViewList($gtype=0, $edit='Yes', $editpage='', $kw=''){
        $ci = &get_instance();   
        $ret = '';
        $orgid = $ci->session->ogre_orgid;
        $conid = $ci->session->ogre_conid;
        $ci->convention->init($conid);
        $action = (trim($editpage)=='') ? site_url('ogrex/game','https') : $editpage;
        $saveaction=site_url('ogrex/gameIn','https');
        $lookupaction=site_url('ogrex/game_bgglookup','https');
        $lookupsaveaction=site_url('ogrex/game_bgglookup_in','https');
        $qry = 'SELECT ogre_games.*, ';
        $qry .= ' ogre_games_descriptor_xref.*, ';
        $qry .= ' ogre_games_descriptor.*, ';
        $qry .= ' ogre_games_descriptor_type.*';
        $qry .= ' FROM (ogre_games ';
        $qry .= ' INNER JOIN ogre_games_descriptor_xref ';
        $qry .= ' ON ogre_games.gn_game_id = ogre_games_descriptor_xref.gdx_gn_id)';
        $qry .= ' INNER JOIN (ogre_games_descriptor ';
        $qry .= ' INNER JOIN ogre_games_descriptor_type ';
        $qry .= ' ON ogre_games_descriptor.gd_descriptor_type = ogre_games_descriptor_type.gdt_id) ';
        $qry .= ' ON ogre_games_descriptor_xref.gdx_gd_id = ogre_games_descriptor.gd_id ';
        $qry .= ' WHERE ogre_games_descriptor.gd_descriptor_type = 1 ';
        $qry .= ' AND ogre_games_descriptor.gd_id = ' . $gtype;
        $qry .= ((trim($kw) !== '') ? ' AND ogre_games.gn_game_name LIKE "%'.$kw.'%"' : ''); 
        $qry .= ' ORDER BY ogre_games.gn_game_name, ogre_games_descriptor.gd_descriptor;';

        $gtypetitle = $this->getDescriptor($gtype);
        $query = $ci->db->query($qry);
        if ($edit=='Yes'){
               $ret .= '<div class="d-grid gap-2"><input name="add" type="button"  class="btn btn-secondary m-1" value="Add Game" onclick="gameAddEdit(0,'. "'". $action."','". $saveaction."','". $lookupaction."','". $lookupsaveaction."'".');" /></div>';
         }
        if ($gtype=='0'){
            $ret .= '<h3>Complete list of Games (Select Type)</h3>';
        }
        else{
            $ret .= '<h2>' . $gtypetitle . '</h2>';
        }
        $ret .= '<table id="gamelisttable" class="table table-striped">';
        $ret .= '<tr><th>';
        $ret .= 'Category';
        $ret .= '</th><th>';
        $ret .= 'Game Name';
        $ret .= '</th>';
        $ret .= '</tr>';
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
               $this->init($row->gn_game_id);
               $ret .= '<tr><td>';
               $ret .= $this->game_type;
               $ret .= '</td><td>';
               $ret .= ($edit!=='Yes') ? $this->game_name : '<a href="#" onclick="return gameAddEdit('.$this->gameid.",'".$action."/".$this->gameid."','". $saveaction."','". $lookupaction."','". $lookupsaveaction."'". ');" >'.$this->game_name.'</a>';
               $ret .= '</td>';
               $ret .= '</tr>';
             }
            if ($edit=='Yes')
                 {
                    $ret .= '<tr>';
                    $ret .= '<td colspan="2" class="gameadd_right">';;
                    $ret .= '<input name="add" type="button"  class="btn btn-secondary" value="Add" onclick="gameAddEdit(0,' . "'" . $action . "','". $saveaction."','". $lookupaction."','". $lookupsaveaction."'". ');" />';
                    $ret .= '</td>';
                    $ret .= '</tr>';
                 }
            $ret .= '</table>';                               
        }
        else{
            $ret .= '<tr>';
            $ret .= '<td colspan="3" align="center">';
            $ret .= '*** SELECT A GAME TYPE ***';
            $ret .= '</td>';
            $ret .= '</tr>';
        }
        return $ret;
    }
//***********************************
//
//***********************************
    public function getGameSelect($gtype=0, $pc=FALSE, $rt=1, $grp=TRUE){
        $ci = &get_instance();               
        $conid = $ci->session->ogre_conid;
        $ci->convention->init($conid);
        $action = site_url('ogrex/getGameDescription','https');
        $paction = site_url('ogrex/getGamePlayers','https');
        $ret = '';               
        if(is_numeric($gtype)){
            $qry = 'SELECT ogre_games.*, ogre_games_descriptor_xref.*, ogre_games_descriptor.*, ogre_games_descriptor_type.*';
            $qry .= ' FROM (ogre_games INNER JOIN ogre_games_descriptor_xref ';
            $qry .= ' ON ogre_games.gn_game_id = ogre_games_descriptor_xref.gdx_gn_id)';
            $qry .= ' INNER JOIN (ogre_games_descriptor ';
            $qry .= ' INNER JOIN ogre_games_descriptor_type ';
            $qry .= ' ON ogre_games_descriptor.gd_descriptor_type = ogre_games_descriptor_type.gdt_id) ';
            $qry .= ' ON ogre_games_descriptor_xref.gdx_gd_id = ogre_games_descriptor.gd_id ';
            $qry .= ' WHERE ogre_games_descriptor.gd_descriptor_type = 1 AND ogre_games_descriptor.gd_id = ' . $gtype;
            $qry .= ' AND ogre_games.gn_rtype = '.$rt;
            $qry .= ($grp == FALSE) ? ' AND ogre_games.gn_game_group_flag = 0 ' : '';
            $qry .= ' ORDER BY ogre_games.gn_game_name, ogre_games_descriptor.gd_descriptor;';
        }
        else{
            if(trim($gtype) != ''){
                $qry = 'SELECT ogre_games.*, ogre_games_descriptor_xref.*, ogre_games_descriptor.*, ogre_games_descriptor_type.*';
                $qry .= ' FROM (ogre_games INNER JOIN ogre_games_descriptor_xref ';
                $qry .= ' ON ogre_games.gn_game_id = ogre_games_descriptor_xref.gdx_gn_id)';
                $qry .= ' INNER JOIN (ogre_games_descriptor ';
                $qry .= ' INNER JOIN ogre_games_descriptor_type ';
                $qry .= ' ON ogre_games_descriptor.gd_descriptor_type = ogre_games_descriptor_type.gdt_id) ';
                $qry .= ' ON ogre_games_descriptor_xref.gdx_gd_id = ogre_games_descriptor.gd_id ';
                $qry .= ' WHERE ogre_games_descriptor.gd_descriptor_type = 1 AND ogre_games.gn_game_name LIKE "%' . $gtype . '%" ';
                $qry .= ' AND ogre_games.gn_rtype = '.$rt;
                $qry .= ($grp == FALSE) ? ' AND ogre_games.gn_game_group_flag = 0 ' : '';
                $qry .= ' ORDER BY ogre_games.gn_game_name, ogre_games_descriptor.gd_descriptor;'; 
            }
        }
        if( trim($gtype) != '' ){
            $query = $ci->db->query($qry);
            $ret .= '<select class="form-select mt-4" ' . (($pc === TRUE) ? ' multiple="multiple" ' : '') . ' id="gs_gn_id" name="gs_gn_id" size="12" ' . (($pc === TRUE) ? '' : ' onclick="newGameHeader(this.options[this.selectedIndex].text, this.options[this.selectedIndex].value,'."'".$action."','".$paction."'".');"') . '>';
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                    $this->init($row->gn_game_id);
                    $ret .= '<option value="' . $this->gameid . '">' . $this->game_name . ' (' . $this->game_type . ')' . '</option>';
                 }
            }

            $ret .= '</select>';
            $ret .= '<input type="hidden" id="gn_game_description" name="gn_game_description" value="x">';
        }  else {
            $ret .= '<select class="form-select mt-4" ' . (($pc===TRUE) ? ' multiple="multiple" ' : '') . ' id="gs_gn_id" name="gs_gn_id" size="12" onclick="newGameHeader(this.options[this.selectedIndex].text, this.options[this.selectedIndex].value,'."'".$action."','".$paction."'".');">';
            $ret .= '</select>';
            $ret .= '<input type="hidden" id="gn_game_description" name="gn_game_description" value="x">';                    
        }
        return $ret;
    }            
//------------------------
//
//------------------------
    public function getGameViewHeader($gtid=-1){ 
        $action = site_url('ogrex/gameListX','https');
        $ret = '<h2>OGRe Game DB</h2>';
        $ret .= '<label for="gametype">Game Type:</label>';
        $ret .= $this->getBaseTypeSelect($gtid, FALSE);
        $ret .= '<label for="bg-db-keyword">Keyword:</label>';
        $ret .= '<input type="text" class="form-control m-1" id="bg-db-keyword" name="bg-db-keyword" />';
        $ret .= '<div class="d-grid gap-2"><input name="add" type="button"  class="btn btn-secondary m-1" value="Search" onclick="loadGamesKeyword('."'".$action."'".');" /></div>';
        $image_properties = array('src' =>'images/ajax-loader.gif','alt'=>'ajax-loader.gif'); 
        $ret .= '<div id="glwait" style="display: none">' . img($image_properties) . '</div>'; 

        return $ret;
    }
//------------------------
//
//------------------------
    public function getBaseTypeSelect($gtype=-1, $action='', $stype=1){
        $ci = &get_instance();
        $qry = 'SELECT ogre_games_descriptor.* ';
        $qry .= ' FROM ogre_games_descriptor ';
        $qry .= ' INNER JOIN ogre_games_descriptor_type ';
        $qry .= ' ON ogre_games_descriptor.gd_descriptor_type = ogre_games_descriptor_type.gdt_id ';
        $qry .= ' WHERE ogre_games_descriptor_type.gdt_id = 1 ';
        $qry .= ' AND ogre_games_descriptor.gd_descriptor_subtype = ' . $stype;
        $qry .= ' ORDER BY ogre_games_descriptor.gd_descriptor;';               
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            $onchange = ((trim($action) !== '') ? ' onchange="loadgames(this.options[this.selectedIndex].value,'."'".$action."'".');"' : '');
            $ret = '<select class="form-control mt-2" id="gametype" name="gametype" size="1" '.$onchange.'>';
            if($gtype<=0){
                $ret .= '<option value="0" hidden="hidden">(Select One)</option>';
            }
            foreach ($query->getResult() as $row){
                if ($gtype == $row->gd_id){
                    $ret .= '<option value="' . $row->gd_id . '" selected="selected">' . $row->gd_descriptor . '</option>';
                }
                else
                {                       
                    $ret .= '<option value="' . $row->gd_id . '">' . $row->gd_descriptor . '</option>';
                }
            }
        }
        $ret .= '</select>';

        return $ret;
    }
//------------------------
//
//------------------------
    public function getKeywordSearch($action=''){   
        $ret = '<input type="text" id="gamekeyword" name="gamekeyword" title="Single word in the title of the game" />'; 
        $ret .= '<input value=" Go " title="Search"  type="button" id="searchgamekw" name="searchgamekw" onclick="loadgames('."'".'gamekeyword'."'". ','."'".$action."'".')" />';  
        return $ret;
    }            
//------------------------
//
//------------------------
    public function getDescriptorsSelect($name='gametype', $defval=0, $gtype=0, $gt=0){
        $ci = &get_instance();
        $lastgt=0;
        $qry = 'SELECT ogre_games_descriptor.*, ogre_games_descriptor_type.* ';
        $qry .= ' FROM ogre_games_descriptor ';
        $qry .= ' INNER JOIN ogre_games_descriptor_type ';
        $qry .= 'ON ogre_games_descriptor.gd_descriptor_type = ogre_games_descriptor_type.gdt_id ';
        $qry .= ' WHERE ';
        $qry .=  (($gt <= 0) ? ' (ogre_games_descriptor_type.gdt_id <> 1 AND ogre_games_descriptor_type.gdt_id <> 5 AND ogre_games_descriptor_type.gdt_id <> 3)' : ' ogre_games_descriptor_type.gdt_id = ' . $gt);                                 
        $qry .= ' ORDER BY ogre_games_descriptor_type.gdt_game_descriptor_type, ogre_games_descriptor.gd_descriptor;';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            $ret = '<select class="form-control m-1" name="' . $name . '" id="' . $name . '" size="1">';
            $ret .= '<option value="0" selected="selected">' . $defval . '</option>';
            foreach ($query->getResult() as $row){
                if($lastgt!=$row->gdt_id){
                    $ret .= '<optgroup label="'.$row->gdt_game_descriptor_type.'">';
                }                    
                $ret .= ($gtype == $row->gd_id) ? '<option value="' . $row->gd_id . '" selected="selected">' . $row->gd_descriptor . '</option>' : '<option value="' . $row->gd_id . '">' . $row->gd_descriptor . '</option>';                       
                $lastgt = $row->gdt_id;
            }

        }
        $ret .= '</select>';
        return $ret;
    }
//------------------------

//------------------------
    public function getManufacturerSelect($id=0){
       $ci = &get_instance();
        $qry = 'SELECT ogre_manufacturers.gman_id, ogre_manufacturers.gman_name ';
        $qry .= ' FROM ogre_manufacturers ';
        $qry .= ' ORDER BY ogre_manufacturers.gman_name;';
        $ret = '';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            $ret .= '<select class="form-control m-1" name="gn_gman_id" id="gn_gman_id" size="1">';
            $ret .= ($id == 0) ? '<option value="0" selected="selected">-SELECT-</option>' : '';
            foreach ($query->getResult() as $row){
                $ret .=  ($id == $row->gman_id) ? '<option value="' . $row->gman_id . '" selected="selected">' . $row->gman_name . '</option>' : '<option value="' . $row->gman_id . '">' . $row->gman_name . '</option>';
            }
        }
        $ret .= '</select>';
        return $ret;                
    }
//------------------------
//
//------------------------           
    public function game_form($gid=0){
        $ret = '';
        if($gid!==0){
            $this->init($gid);
        }         
        $gtypeids = explode(",", $this->game_type_ids);     
        $ret .= '<div id="results" class="results"></div>';
        $ret .= '<p>* = Required</p>';
        $ret .= '<form name="game_form" id="game_form" action="">';
        $ret .= '<input id="gn_game_id" name="gn_game_id" type="hidden"  value="' . $this->gameid . '" />';                
        $ret .= '<label for="gn_game_name">Game Name* (Include version number or descriptor, and core rules if applicable (see below))</label>';
        $ret .= '<input class="form-control m-1" title="Name of the Game" id="gn_game_name" name="gn_game_name" type="text"  value="' . entities_to_ascii($this->game_name) . '" />';
        $ret .= '<label for="gn_abrev_name">Game Abbreviation</label>';
        $ret .= '<input class="form-control m-1" title="Abbreviated designation of the game.  Not required." id="gn_abrev_name" name="gn_abrev_name" type="text" value="' . entities_to_ascii($this->game_abrev) . '" />';
        $ret .= '<label for="gn_game_subname">Game Sub Title</label>';
        $ret .= '<input class="form-control m-1" title="Secondary title of the game, if applicable.  Not required." id="gn_game_subname" name="gn_game_subname" type="text" value="' . entities_to_ascii($this->game_subname) . '" />';
        $ret .= '<label for="basetype">Game Base Type*</label>';
        $ret .= $this->getDescriptorsSelect('basetype', "Choose Base Type", $this->game_typeid, 1);
        $ret .= '<div id="existgman"><label for="gn_gman_id">Game Publisher*</label>';
        $ret .= $this->getManufacturerSelect($this->game_manid);
        $ret .= ($gid===0)?'<div class="d-grid gap-2"><button class="btn btn-primary m-1" title="" type="button" id="newgman_button" onclick="newgman(true);">Not Listed (If Publisher not listed, click here)</button></div>':'';
        $ret .= '</div>';
        $ret .= '<div id="newgman" style="display:none; padding: 3px 3px 3px 3px;";><label for="gman_name">Game Publisher*</label>';
        $ret .= '<input class="form-control mt-1 me-4" title="Required.  Name of the Publisher" id="gman_name" name="gman_name" type="text" value="" />';
        $ret .= '<label for="gman_web">Game Pub. Website</label>';
        $ret .= '<input class="form-control mt-1 me-4" title="Publisher Web site.  Not required" id="gman_web" name="gman_web" type="text" value="" />';
        $ret .= '<div class="d-grid gap-2"><input class="btn btn-primary m-1" type="button" value="Back" id="existgman_button" onclick="newgman(false);" /></div>' . '</div>';               
        $ret .= '<label for="orgtype">Organized Play? (RPGs only)</label>';      
        $ret .= $this->getDescriptorsSelect('orgtype', "Regular Game", $this->game_orgtypeid, 3);
        $ret .= '<label for="affiliation">Game Affiliation (If Organized Play RPG)</label>';
        $ret .= $this->getDescriptorsSelect('affiliation', "No Affiliation", $this->game_affiliationid, 5);
        $ret .= '<label for="gametype1">Desciptor 1*</label>';
        if (!isset($gtypeids[1])){
            $gtypeids[1] = 0;
        }
        $ret .= $this->getDescriptorsSelect('gametype1',"Select One", $gtypeids[1], -1);
        $ret .= '<label for="gametype2">Desciptor 2</label>';
        if (!isset($gtypeids[2])){
            $gtypeids[2] = 0;
        }                
        $ret .= $this->getDescriptorsSelect('gametype2',"Select One", $gtypeids[2], -1);
        $ret .= '<label for="gn_game_min_players">Min Number of Players*</label>';
        $ret .= '<input class="form-control" title="Required. Minimum number of players" id="gn_game_min_players" name="gn_game_min_players" type="text" value="' . $this->min_players . '" />';
        $ret .= '<label for="gn_game_max_players">Max Number of Players*</label>';                
        $ret .= '<input class="form-control" title="Required. Maximum number of players" id="gn_game_max_players" name="gn_game_max_players" type="text" value="' . $this->max_players . '" />';
        $ret .= '<label for="gn_game_website">Game Web Site</label>';
        $ret .= '<input class="form-control" title="Not Required. Game Web site" id="gn_game_website" name="gn_game_website" type="text" value="' . entities_to_ascii($this->website) . '" />';
        $ret .= '<label for="gn_game_group_flag">Game Group Flag</label>';
        $ret .=  ($this->group_flag == 0) ? '<input class="form-control" title="Mark only if this is a parent to a group of games, like a game library or players choice" id="gn_game_group_flag" name="gn_game_group_flag" type="checkbox" size="10" />' :  '<input class="form-control" title="Mark only if this is a parent to a group of games, like a game library or players choice" id="gn_game_group_flag" name="gn_game_group_flag" type="checkbox" checked="checked" size="10" />';
        $ret .= '<label for="gn_game_description">Game Description*</label>';
        $ret .= '<textarea name="gn_game_description" id="gn_game_description">' . entities_to_ascii($this->game_desc)  . '</textarea>';            
        $ret .= '</form>';

        return $ret;

    }           
//------------------------   ------------------------   
//
//
//
//------------------------   ------------------------           
    public function getWhatGameForm($pc=FALSE, $gid=0, $propid=0, $stype=1){
        $ci = &get_instance();
        $ret ='';
        $ret .='<div class="gameadmin_what">';
        if($propid!=0){
         $ci->proposal->prop_init($propid);
         $ret .= $this->proposal->proposalWhat();
        }
        switch ($stype){
            case 1:
                if($pc===FALSE){                    
                    $ret .= $ci->ogre_lib->getMiscContent('%%WHAT-GAME%%',0,TRUE);
                }
                else{
                    $ret .= $ci->ogre_lib->getMiscContent('%%ADD-PC-GAMES%%',0,TRUE);                   
                }
                $gnid = $ci->event->get_gs_gn_id($gid);
                $gtid = $this->getPrimaryGameType($gnid);
                $rt = 1;
                break;
            case 0:
                $ret .= '<h3>Select Operational Shift</h3> ';
                $gtid = OPERATIONAL_SHIFT;
                $rt = 3;
                break;
            case 2:                  
                $ret .= '<h3>Select Panel/Con Event</h3> ';
                $gtid = PANELS;
                $rt = 2;
                break;                        
            default:
                $ret .= '<h3>Error</h3> ';
        }
        $ret .= '<div id="what-game">';
        $action = site_url('ogrex/getGames' . ($pc===TRUE ? '/1' : '/0'),'https');
        $ret .= $this->gameSearchFields($action, $gtid, $stype);
        $image_properties = array('src' =>'images/ajax-loader.gif','alt'=>'ajax-loader.gif');
        $ret .= '<div id="glwait" style="display: none">' . img($image_properties) . '</div>';                 
        $ret .= '<div id="game-list">';
        $ret .= $this->getGameSelect($gtid, $pc, $rt, TRUE);
        $ret .= '</div>';
        if ($pc === TRUE){
            $ret .= '<form name="pc-game-add" id="pc-game-add" action="">';
            $ret .= '<div id="add-remove-pc"><button name="addpc" id="addpc" type="button" class="btn btn-secondary" onclick="addPCG();" />Add</button></div>';
            $ret .= $ci->ogre_lib->getMiscContent('%%ADDED-GAME-APPEAR%%',0,TRUE);
            $ret .= '<select size="12" multiple="multiple" name="pc-add-selec" id="pc-add-select" onclick="removePCG(this);">';
            $ret .= '</select>';
            $ret .= '</form>';                
        }
        $ret .='</div>';
        return $ret;
    }
//------------------------   
//
//------------------------                
    private function gameSearchFields($action, $gtid, $stype=1){
        switch($stype){
            case 0: 
                $ret = '<div id="game-search-fields">';
                $ret .= '<p><input type="hidden" id="gamekeyword" name="gamekeyword" title="" />'; 
                $ret .= '<select disabled="disabled" class="form-select" id="searchby" name="searchby" size="1" onchange="changeSearchOption(this.value);" >';
                $ret .= '<option value="0">Search by Type: </option>';
                $ret .= '</select></p>';   
                $ret .= '<p><span id="gsf_gametype"> ' . str_replace('<select ', '<select disabled="disabled" ', $this->getBaseTypeSelect(OPERATIONAL_SHIFT, $action, $stype)) . '</span></p>';
                $ret .= '<input type="hidden" id="get-action" name="vol-action" value="'.$action.'" />';
                $ret .= '</div>';
                break;
            case 1:
                $ret = '<div id="game-search-fields">';
                $ret .= '<select class="form-select" id="searchby" name="searchby" size="1" onchange="changeSearchOption(this.value);">';
                $ret .= '<option value="0">Search by Game Type: </option>';
                $ret .= '<option value="1">Search by Keyword: </option>';
                $ret .= '</select>';                
                $ret .= '<span id="gsf_keyword" style="display:none;"> ' .  $this->getKeywordSearch($action) . '</span>';
                $ret .= '<span id="gsf_gametype"> ' .  $this->getBaseTypeSelect($gtid, $action, $stype) . '</span>';

                $ret .= '</div>';                        
                break;
            case 2:
                $ret = '<div id="game-search-fields">';
                $ret .= '<input type="hidden" id="gamekeyword" name="gamekeyword" title="" />';
                $ret .= '<select disabled="disabled" class="form-select" id="searchby" name="searchby" size="1" onchange="changeSearchOption(this.value);">';
                $ret .= '<option value="0">Search by Type: </option>';
                $ret .= '</select>';                           
                $ret .= '<span id="gsf_gametype"> ' .  str_replace('<select ', '<select disabled="disabled" ', $this->getBaseTypeSelect(PANELS, $action, $stype) ). '</span>';
                $ret .= '<input type="hidden" id="get-action" name="vol-action" value="'.$action.'" />';
                $ret .= '</div>';                        
                break;
        }
        return $ret;
    }
//------------------------   ------------------------   
//
//
//
//------------------------   ------------------------                 
    public function game_insert($p){
        $ci = &get_instance();                
        $qry='';
        $bValid = TRUE;
        $errmsg='';
        $result = array('success'=>FALSE,'errormsg'=>'');
        $descriptors = array('0'=>array('gamid'=>0,'descid'=>0));                
        if($p['basetype'] == 0){
            $bValid = FALSE;
            $errmsg = '<p>Base Type is Required</p>';
        }                
        $gnexists = $this->check_gamelistfor($p["gn_game_name"]);                
        if($gnexists != TRUE){
            $bValid = FALSE;
            $errmsg = '<p>Game Name Already Exists.  Rename this game [Back Button]</p>';                    
        }
        if ($bValid == TRUE){
            if(!isset($p["gn_game_group_flag"])){
                $groupflag = 0;
            }
            else{
                $groupflag = 1;
            }

            $data = array('gn_game_name' => quotes_to_entities(($p["gn_game_name"])), 
                          'gn_abrev_name' => quotes_to_entities($p["gn_abrev_name"]), 
                          'gn_game_subname' => quotes_to_entities($p["gn_game_subname"]), 
                          'gn_game_description' => quotes_to_entities($p["gn_game_description"]), 
                          'gn_game_min_players' => $p["gn_game_min_players"],
                          'gn_game_max_players' => $p["gn_game_max_players"], 
                          'gn_game_group_flag' => $groupflag,
                          'gn_game_website' => quotes_to_entities($p["gn_game_website"]),
                          'gn_gman_id' => quotes_to_entities($p["gn_gman_id"])
                         );

            $ci->db->insert('ogre_games', $data);

            if ($ci->db->affectedRows() > 0){
                $bValid = TRUE;  

            }
            else{
               $bValid = FALSE;
               $errmsg = '<p>Error in INSERT: ogre_games '. $ci->db->last_query . '</p>';
            }

            if($bValid == TRUE){
               $gid = $ci->db->insertID();

               $descriptors[0]['descid'] = $p['basetype'];
               $descriptors[0]['gameid'] = $gid;

               $i=1;

               if($p['orgtype'] != 0)
               {
                   $descriptors[$i]['descid'] = $p['orgtype'];
                   $descriptors[$i]['gameid'] = $gid;                       
                   $i++;
               }
               if($p['affiliation'] != 0)
               {
                   $descriptors[$i]['descid'] = $p['affiliation'];
                   $descriptors[$i]['gameid'] = $gid;     
                   $i++;
               }  
               if($p['gametype1'] != 0)
               {
                   $descriptors[$i]['descid'] = $p['gametype1'];
                   $descriptors[$i]['gameid'] = $gid;  
                   $i++;
               }      
               if($p['gametype2'] != 0)
               {
                   $descriptors[$i]['descid'] = $p['gametype2'];
                   $descriptors[$i]['gameid'] = $gid;    
                   $i++;
               }                       

               $qry='';

               for($j=0;$j<=count($descriptors)-1;$j++)
               {

                    $data = array('gdx_gn_id' => $descriptors[$j]['gameid'], 'gdx_gd_id' => $descriptors[$j]['descid']);

                    $ci->db->insert('ogre_games_descriptor_xref', $data);

                    if ($ci->db->affectedRows() > 0)
                    {
                        $bValid = TRUE;  

                    }
                    else
                    {
                       $bValid = FALSE;
                       $errmsg .= '<p>Error in INSERT: ogre_games_descriptor_xref</p>';
                    }                    
               }
            }                 
       }

       $result['success'] = $bValid;
       $result['errormsg'] = $errmsg;                 

       return $result;
    }
            //------------------------
            //
            //
            //
            //------------------------                 
            public function game_update($p)
            {
                $ci = &get_instance();
                
                $qry='';
                $bValid = TRUE;
                $errmsg='';
                $result = array('success'=>FALSE,'errormsg'=>'');
                
                if($p['basetype'] == 0){
                    $bValid = FALSE;
                    $errmsg = '<p>Base Type is Required</p>';
                }
                
                $gnexists = $this->check_gamelistfor($p["gn_game_name"], $p["gn_game_id"]);
                
                if($gnexists != TRUE){
                    $bValid = FALSE;
                    $errmsg = '<p>Game Name Already Exists.  Rename this game [Back Button]</p>';                    
                }
                
                if ($bValid == TRUE){
                    if(!isset($p["gn_game_group_flag"])){
                        $groupflag = 0;
                    }
                    else{
                        $groupflag = 1;
                    }                
            
                    $data = array('gn_game_name' => quotes_to_entities($p["gn_game_name"]), 
                                  'gn_abrev_name' => quotes_to_entities($p["gn_abrev_name"]), 
                                  'gn_game_subname' => quotes_to_entities($p["gn_game_subname"]), 
                                  'gn_game_description' => quotes_to_entities($p["gn_game_description"]), 
                                  'gn_game_min_players' => $p["gn_game_min_players"],
                                  'gn_game_max_players' => $p["gn_game_max_players"], 
                                  'gn_game_group_flag' => $groupflag,
                                  'gn_game_website' => quotes_to_entities($p["gn_game_website"]),
                                  'gn_gman_id' => quotes_to_entities($p["gn_gman_id"])
                                 );
                    
                    $ci->db->where('gn_game_id',$p["gn_game_id"]);
                    $ci->db->update('ogre_games', $data);                                 
                    $gid = $p["gn_game_id"];                                       
                    $descriptors = array('0'=>array('gamid'=>0,'descid'=>0));
                    
                    if ($bValid== TRUE){                                                             
                        $bValid = $this->delete_descriptors($p["gn_game_id"]);                       
                        $descriptors[0]['descid'] = $p['basetype'];
                        $descriptors[0]['gameid'] = $gid;
                        $i=1;
                        if($p['orgtype'] != 0){
                           $descriptors[$i]['descid'] = $p['orgtype'];
                           $descriptors[$i]['gameid'] = $gid;                       
                           $i++;
                        }
                        if($p['affiliation'] != 0){
                           $descriptors[$i]['descid'] = $p['affiliation'];
                           $descriptors[$i]['gameid'] = $gid;     
                           $i++;
                        }  
                        if($p['gametype1'] != 0){
                           $descriptors[$i]['descid'] = $p['gametype1'];
                           $descriptors[$i]['gameid'] = $gid;  
                           $i++;
                        }      
                        if($p['gametype2'] != 0){
                           $descriptors[$i]['descid'] = $p['gametype2'];
                           $descriptors[$i]['gameid'] = $gid;    
                           $i++;
                        }                       
                        $qry='';
                        for($j=0;$j<=count($descriptors)-1;$j++){
                            $qry='';                          
                            $data = array('gdx_gn_id' => $descriptors[$j]['gameid'], 'gdx_gd_id' => $descriptors[$j]['descid']);
                            $ci->db->insert('ogre_games_descriptor_xref', $data);                           
                            if ($ci->db->affectedRows() > 0){
                                $bValid = TRUE;  
                            }
                            else{
                               $bValid = FALSE;
                               $errmsg .= '<p>Error in INSERT: ogre_games_descriptor_xref</p>';
                            }                    
                        }
                    }
                }
                
               $result['success'] = $bValid;
               $result['errormsg'] = $errmsg;
               
               return $result;                
            }            
            //------------------------
            //
            //
            //
            //------------------------                
            private function check_gamelistfor($gn, $gid=0){
                $ci = &get_instance();           
                $bValid = TRUE;                                     
                $qry = 'SELECT * FROM ogre_games WHERE gn_game_name = "' . quotes_to_entities($gn) . '" ';              
                if($gid != 0 ){
                    $qry .= 'AND gn_game_id <> ' . $gid;
                }                              
                $query = $ci->db->query($qry);
                if ($query->getNumRows() != 0){
                    $bValid = FALSE;               
                }                
                return $bValid;
            }
            
            //------------------------
            //
            //
            //
            //------------------------                
            private function delete_descriptors($gid){
                $ci = &get_instance();            
                $done = FALSE;
                $qry = 'DELETE FROM ogre_games_descriptor_xref  ';
                $qry .= ' WHERE gdx_gn_id = ' . $gid;
                $ci->db->query($qry);
                if ($ci->db->affectedRows() > 0){
                    $done = TRUE;
                }
                return $done;                           
            }

            
}  /* END OF GAME CLASS */ ?>