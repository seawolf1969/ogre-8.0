<?php	
namespace App\Models;
use CodeIgniter\Model;
use CodeIgniter\I18n\Time;

//---------------------------------------------------
// Class: Game Proposal 
//
//
//---------------------------------------------------
class Proposal extends Game{
        var $conventionid;
        var $convention_name;
        var $game_title;
        var $request_id;
        var $gm_name;
        var $gm_email;
        var $gm_alt_email;
        var $gm_id;
        var $gm_age;
        var $gm_xp;
        var $gm_congamebefore;
        var $gm_gender;
        var $gm_city;
        var $gm_state;
        var $gm_phone_day;
        var $gm_phone_night;
        var $gm_gamerole;
        var $proposal_number;
        var $proposal_number_total;
        var $date_created;
        var $total_rounds;
        var $final_round;
        var $play_more_than_once;
        var $anytime;
        var $specialschedule;
        var $spec_sched_day1;
        var $spec_sched_time1;
        var $spec_sched_day2;
        var $spec_sched_time2;
        var $spec_sched_day3;
        var $spec_sched_time3;
        var $players_responsibilities;
        var $player_know;
        var $attitude;
        var $number_of_gms;
        var $gm_list;
        var $campaign;
        var $table_space;
        var $play_area;
        var $additional_comments;
        var $rp_rating;
        var $action_rating;
        var $puzzle_rating;
        var $complexity_rating;
        var $delete;
//---------------------------------------------------
//
//---------------------------------------------------
    public function __construct(){
    }	        

//---------------------------------------------------
//
//---------------------------------------------------
    public function prop_init($requestid, $conid=0){
        if($requestid != 0){
                $this->getRequestInfo($requestid, $conid);
        }
    }
//---------------------------------------------------
//
//---------------------------------------------------
    private function getRequestInfo($requestid, $conid=0){
        $ci=&get_instance();
        if($conid==0){
            $conid = $ci->session->ogre_conid;
        }               
        $qry = "SELECT * FROM `ogre_gamerequest` WHERE gr_id = " . $requestid ;
        $query = $ci->db->query($qry);        
        $ci->convention->init($conid); 
        if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                    $this->conventionid =  $row->gr_con_id;
                    $this->convention_name =  $ci->convention->name;
                    $this->request_id = $row->gr_id;
                    $this->id = $row->gr_schedule_id;
                    $this->gm_id = $row->gr_gm_id;
                    $this->gm_name = $row->gr_gm_name;
                    $this->gm_email = $row->gr_gm_email;
                    $this->gm_alt_email = $row->gr_alt_email;
                    $this->gm_age = $row->gr_gm_age;
                    $this->gm_xp = $row->gr_gmexp;
                    $this->gm_congamebefore = $row->gr_congamebefore;
                    $this->gm_gender = $row->gr_gm_gender;
                    $this->gm_city = $row->gr_gm_city;
                    $this->gm_state = $row->gr_gm_state;
                    $this->gm_phone_day = $row->gr_gm_phone_day;
                    $this->gm_phone_night = $row->gr_gm_phone_night;
                    $this->proposal_number = $row->gr_proposal_number;
                    $this->proposal_number_total = $row->gr_proposal_number_total;
                    $this->game_type = $row->gr_game_type;
                    $this->game_type_id = $row->gr_game_type_id;
                    $this->event_type = $row->gr_event_type;
                    $this->game_title = $row->gr_scenario_title;
                    $this->game_name = $row->gr_game_system;
                    $this->game_notes = $row->gr_game_description;
                    $this->slot_length = $row->gr_total_hours;
                    $this->total_rounds = $row->gr_total_rounds;
                    $this->final_round = $row->gr_final_round;
                    $this->play_more_than_once = $row->gr_play_more_than_once;
                    $this->specialschedule = $row->gr_specialschedule;
                    $this->anytime = $row->gr_anytime;
                    $this->spec_sched_day1 = $row->gr_spec_sched_day1;
                    $this->spec_sched_day1 = $row->gr_spec_sched_day1;
                    $this->spec_sched_time1 = $row->gr_spec_sched_time1;
                    $this->spec_sched_day2 = $row->gr_spec_sched_day2;
                    $this->spec_sched_time2 = $row->gr_spec_sched_time2;
                    $this->spec_sched_day3 = $row->gr_spec_sched_day3;
                    $this->spec_sched_time3 = $row->gr_spec_sched_time3;
                    $this->max_number_of_players = $row->gr_max_players;
                    $this->min_num_of_players = $row->gr_min_players;
                    $this->players_responsibilities = $row->gr_players_responsibilities;
                    $this->player_know = $row->gr_player_know;
                    $this->attitude = $row->gr_attitude;
                    $this->maturity_rate = $row->gr_age_rating;
                    $this->number_of_gms = $row->gr_number_of_gms;
                    $this->gm_list = $row->gr_gm_list;
                    $this->campaign = $row->gr_campaign;
                    $this->table_space = $row->gr_table_space;
                    $this->play_area = $row->gr_play_area;
                    $this->additional_comments = $row->gr_additional_comments;
                    $this->min_players = $row->gr_min_players;
                    $this->max_players = $row->gr_max_players;
                    $this->gm_gamerole = $row->gr_playormarshal;                       
                    $this->rp_rating = $row->gr_rate_rp;
                    $this->action_rating = $row->gr_rate_action;
                    $this->puzzle_rating = $row->gr_rate_puzzle;
                    $this->complexity_rating = $row->gr_rate_complex;
                    $this->delete = $row->gr_delete;
            }
        }
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function insertGameRequest($p){
        $ci=&get_instance();               
        if(!isset($p["propnum"])){
            $p["propnum"] = "1";
        }
        if(!isset($p["propof"])){
            $p["propof"] = "1";
        }           
            $ci->convention->init($p["conid"]);
            $sql = 'INSERT INTO ogre_gamerequest ';
            $sql .= '(';
            $sql .= 'gr_msa_conid, ';
            $sql .= 'gr_con_id, ';
            $sql .= 'gr_gm_id, ';
            $sql .= 'gr_gm_name, ';
            $sql .= 'gr_gm_email, ';
            $sql .= 'gr_gm_age, ';
            $sql .= 'gr_gmexp, ';
            $sql .= 'gr_congamebefore, ';
            $sql .= 'gr_gm_gender, ';
            $sql .= 'gr_gm_city, ';
            $sql .= 'gr_gm_state, ';
            $sql .= 'gr_gm_phone_day, ';
            $sql .= 'gr_proposal_number, ';
            $sql .= 'gr_proposal_number_total, ';
            $sql .= 'gr_game_type_id, ';
            $sql .= 'gr_game_type, ';
            $sql .= 'gr_event_type, ';
            $sql .= 'gr_scenario_title, ';
            $sql .= 'gr_game_system, ';
            $sql .= 'gr_game_description, ';
            $sql .= 'gr_total_hours, ';
            $sql .= 'gr_total_rounds, ';
            $sql .= 'gr_anytime, ';
            $sql .= 'gr_specialschedule, ';
            $sql .= 'gr_min_players, ';
            $sql .= 'gr_max_players, ';
            $sql .= 'gr_playormarshal, ';
            $sql .= 'gr_players_responsibilities, ';
            $sql .= 'gr_player_know, ';
            $sql .= 'gr_attitude, ';
            $sql .= 'gr_age_rating, ';
            $sql .= 'gr_rate_rp, ';
            $sql .= 'gr_rate_action, ';
            $sql .= 'gr_rate_puzzle, ';
            $sql .= 'gr_rate_complex, ';
            $sql .= 'gr_number_of_gms, ';
            $sql .= 'gr_gm_list, ';
            $sql .= 'gr_table_space, ';
            $sql .= 'gr_play_area, ';
            $sql .= 'gr_additional_comments  ';
            $sql .= ') ';
            $sql .= 'VALUES(';
            $sql .= $ci->convention->msa_conid . ', ';
            $sql .= $p["conid"] . ', ';
            $sql .= $p["gm_id"] . ", ";
            $sql .= "'" . quotes_to_entities(urldecode($p["gmname"])) . "', ";
            $sql .= "'" . urldecode($p["gmemail"]) . "', " ;
            $sql .= "'" . urldecode($p["gm_age"]) . "', ";
            $sql .= "'" . urldecode($p["gm_xp"]) . "', ";
            $sql .= "'" . urldecode($p["gm_runcongame"]) . "', ";
            $sql .= "'" . urldecode($p["gm_gender"]) . "', ";
            $sql .= "'" . urldecode($p["gm_city"]) . "', ";
            $sql .= "'" . urldecode($p["gm_state"]) . "', ";
            $sql .= "'" . urldecode($p["gm_dphone"]) . "', ";
            $sql .= $p["propnum"] . ", ";
            $sql .= $p["propof"] . ", ";
            $sql .= urldecode($p["gametype"]) . ", ";
            $sql .= "'" . $this->getDescriptor( $p["gametype"]) . "', ";
            $sql .= "'" . urldecode($p["eventtype"]) . "', ";
            $sql .= "'" . quotes_to_entities(urldecode($p["gametitle"])) . "', ";
            $sql .= "'" . quotes_to_entities(urldecode($p["gamesystem"])) . "', ";
            $sql .= "'" . quotes_to_entities(urldecode($p["gamenotes"])) . "', ";
            $sql .= urldecode($p["gametime"]) . ", ";
            $sql .= urldecode($p["gamesessions"]) . ", ";
            $sql .= "'" . urldecode($p["anytime"]) . "', ";
            $sql .= "'" . quotes_to_entities(urldecode($p["specialschedule"])) . "', ";
            $sql .= urldecode($p["minplay"]) . ", ";
            $sql .= urldecode($p["maxplay"]) . ", ";
            $sql .= "'" . urldecode($p["playormarshal"]) . "', ";
            $sql .= "'" . urldecode($p["playbring"]) . "', ";
            $sql .= "'" . urldecode($p["knowledge"]) . "', ";
            $sql .= "'" . urldecode($p["attitude"]) . "', ";
            $sql .= "'" . urldecode($p["agerate"]) . "', ";
            $sql .= urldecode($p["rprating"]) . ", ";
            $sql .= urldecode($p["actrating"]) . ", ";
            $sql .= urldecode($p["psrating"]) . ", ";
            $sql .= urldecode($p["cmplxrating"]) . ", ";
            $sql .= "'" . $p["gmnum"] . "', ";
            $sql .= "'" . quotes_to_entities(urldecode($p["otherGMs"])) . "', ";
            $sql .= "'" . urldecode($p["tspace"]) . "', ";
            $sql .= "'" . urldecode($p["space"]) . "', ";
            $rh = $ci->ogre_lib->getMiscContent($p['reghandling']);
            $sql .= "'" . '<p>'.$rh['title'] .':</p>'. $rh['content'] . quotes_to_entities(urldecode($p["comments"])).  "'";
            $sql .= ")";
            $ci->db->query($sql);
            $ret = ($ci->db->affectedRows() > 0)?  TRUE : FALSE;
            return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function emailGameRequest($p, $gc, $insert = TRUE){
        $ci=&get_instance(); 
        $insmsg = ($insert === TRUE) ? '<p>Proposal Information Saved to the Database.</p>' : '<p>There was a problem with the Proposal Database. Contact the Gaming Coordinator</p>' ;
        $mail['from_eaddress'] = urldecode($p["gmemail"]);
        $mail['replyto_eaddress'] = urldecode($p["gmemail"]);
        $mail['subject'] = urldecode($p["eventname"]) . " Game Proposal" ;
        $mail['body'] = "--------------------------------------------------------------------------" . "<br/>";
        $mail['body'] .= urldecode($p["eventname"]) . "<br/>" .  urldecode($p["eventdates"])  . "<br/>";
        $mail['body'] .= "--------------------------------------------------------------------------"  . "<br/>";
        $mail['body'] .= "<strong>GM Information</strong>"  . "<br/>";
        $mail['body'] .= "Name: " . urldecode($p["gmname"]) . "<br/>";
        $mail['body'] .= "Age: " . urldecode($p["gm_age"]) . '(GM EXP: ' . urldecode($p["gm_xp"]) . ") <br/>";
        $mail['body'] .= "Gender: " . urldecode($p["gm_gender"]) . "<br/>";
        $mail['body'] .= "City: " . urldecode($p["gm_city"]) . "<br/>";
        $mail['body'] .= "State: " . urldecode($p["gm_state"]). "<br/>";
        $mail['body'] .= "Contact Phone: " . urldecode($p["gm_dphone"]). "<br/>";
        $mail['body'] .= "GM E-mail: " . urldecode($p["gmemail"]) . "<br/><br/>";
        $mail['body'] .= "Sent this " . urldecode($p["eventname"]) . "<br/><br/>";
        $mail['body'] .= "This is Proposal Number " . $p["propnum"] . "  of  " .  $p["propof"] . "  <br /><br />";
        $mail['body'] .= "Game: " . urldecode($p["gamesystem"]) . "<br />";
        $mail['body'] .= (trim($p["gametitle"])!="")? "Title: " . urldecode($p["gametitle"])."<br />":""  ;
        $mail['body'] .= "Game Type: " . $this->getDescriptor($p["gametype"]) . "<br />";
        $mail['body'] .= "Event Type: " . urldecode($p["eventtype"]) . "<br /><br />";
        $mail['body'] .= "Game Length of Time: " . urldecode($p["gametime"]) . "<br />";
        $mail['body'] .= "Number of sessions: " . urldecode($p["gamesessions"]) . "<br /><br />";
        $mail['body'] .= "Number of Players (Min/Max): " . $p["minplay"] . '/' .$p["maxplay"] . "<br /><br />";
        $mail['body'] .= "GM Role: " . urldecode($p["playormarshal"]) . "<br /><br />";
        if ($p["anytime"] != "Special"){
            $mail['body'] .= "Anytime: " . urldecode($p["anytime"]) . "<br />";
        }
        else{
            $mail['body'] .= 'Specific Schedule: ' . "<br />";
            if (trim($p["specialschedule"]) != ""){
                $mail['body'] .= "Specific Preference: " . urldecode($p["specialschedule"]) . "<br /><br />";
            }
        }
        $mail['body'] .= "Number of Players (Min/Max): " . $p["minplay"] . " / " . urldecode($p["maxplay"]) . "<br />";
        $mail['body'] .= "Playing Requirements: All Materials are" . urldecode($p["playbring"]) . " / " . urldecode($p["knowledge"]) . "<br />";
        $mail['body'] .= "Play Style/Attitude: " . urldecode($p["attitude"]) . "<br />";
        $mail['body'] .= "Age Rating: " . urldecode($p["agerate"]) . "<br />";
        $mail['body'] .= "RP Rating: " . urldecode($p["rprating"]) . "<br />";
        $mail['body'] .= "Action Rating: " . urldecode($p["actrating"]) . "<br />";
        $mail['body'] .= "Puzzle Solving Rating: " . urldecode($p["psrating"]) . "<br />";
        $mail['body'] .= "Complexity Rating: " . urldecode($p["cmplxrating"]) . "<br />";
        $mail['body'] .= "Number of GMs: " . urldecode($p["gmnum"]) . "<br />";
        if ($p["gmnum"] > 1){
            $mail['body'] .= "List of other GMs: " . urldecode($p["otherGMs"]) . "<br /><br />";
        }
        $mail['body'] .= "Table Space Requirements: " . urldecode($p["tspace"]) . "<br />";
        $mail['body'] .= "Table Size: " . urldecode($p["tablesize"]) . $p["space"] . "<br />";
        $mail['body'] .= "Notes:" . "<br />" . urldecode($p["gamenotes"]) . "<br /><br />";
        $rh = $ci->ogre_lib->getMiscContent($p['reghandling']);
        $mail['body'] .= "Other Comments:" . '<br />' . '<p>'.$rh['title'] .':</p>'. $rh['content'] . urldecode($p["comments"]) . "<br /><br />";
        $mail['body'] .= "--------------------------------------------------------------------------<br />";
        $mail['body'] .= "Gaming Coordinator<br />" . urldecode($p["eventname"]) . "<br />";
        $mail['body'] .= "--------------------------------------------------------------------------<br />";
        $mail['to_eaddress1']  = $gc;
        $mail['to_eaddress2']  = '';
        $mail['to_eaddress3']  = '';
        $mail['cc_eaddress1'] = urldecode($p["gmemail"]);
        $ret = '<p>Game Proposal Submitted!  Thank You!</p>';
        $ret .= '<p>A confirmation E-mail has been sent to the e-mail address you supplied. </p>';
        $ret .= '<p>E-mail ' . $gc . ' if you have any problems.';
        $ret .= '<p>You should hear back from the gaming coordinator soon once it is accepted.  ';
        $ret .= 'Once your games are on the schedule, your account will be activated as a GM.</p>';
        $mail['sent_msg'] = '' . $insmsg . $ret . '';
        $mail['sent_errmsg'] = '' . $insmsg . '<p>Proposal Message has not been sent.  Error sending email.</p>';
        return $mail;
    }
//---------------------------------------------------
//
//---------------------------------------------------            
    public function emailGMProposalStatus($pid, $status){              
        $ci = &get_instance();
        $orgid = $ci->config->item('organization_id');
        if(intval($pid)!=0){
            $this->prop_init($pid);
        }
        $ret['sent'] = FALSE;
        $ret['to_eaddress1'] = $this->gm_email;
        $ret['from_eaddress'] = $this->ogre_lib->getConfigKey('OGReAdmin_Email_ReplyTo', $orgid);   
        switch ($status){
            case "-1": // REJECTED
                $ret['subject'] = $ci->convention->name . " OGRe Proposal Status: Rejected";  
                $ret['body'] = 'Your proposal ' . $this->request_id . ' has been rejected by the Gaming Coordinator.'.'<br /><br />';
                $ret['body'] .= 'GAME: '. $this->game_name;                             
                $ret['body'] .= ($p['game_title']!='')? ' - '. $p['game_title'] .'<br /><br />' : "";                   
                $ret['body'] .= 'Please contact the coordinator by replying to this email for the reasons why.';
                $ret['sent'] = $ci->ogre_lib->emailMessageArray($ret);   
                break;
            case "0": // PENDING
                $ret['sent'] = FALSE; 
                break;
            case "1":  // ACCEPTED
                $ret['subject'] = $ci->convention->name . " OGRe Proposal Status: Accepted";  
                $ret['body'] = 'Your proposal ' . $this->request_id . ' has been accepted and scheduled by the Gaming Coordinator.'.'<br /><br />';
                $ret['body'] .= 'GAME: '. $this->game_name ;                             
                $ret['body'] .= (trim($this->game_title) !='')? ' - '. $this->game_title .'<br /><br />' : '<br /><br />';                   
                $ret['body'] .= 'Please log back into OGRe and click My Schedule on the Events Schedule screen to see when it was scheduled.';  
                $ret['sent'] = $ci->ogre_lib->emailMessageArray($ret);  
                break;            
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function gameTypeSelect($gtype=''){
        $ci = &get_instance();
        $qry ='SELECT * FROM ogre_games_descriptor ';
        $qry .= ' INNER JOIN ogre_games_descriptor_type ';
        $qry .= ' ON ogre_games_descriptor_type.gdt_id = ogre_games_descriptor.gd_descriptor_type ';
        $qry .= ' WHERE ogre_games_descriptor.gd_descriptor_type = 1 ';
        $qry .= ' AND ogre_games_descriptor.gd_descriptor_subtype = 1 ';
        $qry .= ' ORDER BY gd_descriptor';
        $query = $ci->db->query($qry);
        $ret = '';
        $ret .= '<option value="0" hidden="hidden">-</option>';
        foreach ($query->getResult() as $row){
            if($gtype==$row->gd_descriptor){
                $ret .= '<option value="'. $row->gd_id . '" selected="selected">' . $row->gd_descriptor . '</option>';
            }
            else{
                $ret .= '<option value="'. $row->gd_id . '">' . $row->gd_descriptor . '</option>';
            }
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function eventTypeSelect($etype='', $dmode = "P"){
        $ci = &get_instance();
        $qry ='SELECT * FROM ogre_eventtype ';
        $qry .=' WHERE ogre_eventtype.et_displaymode = "' . $dmode . '"';
        $qry .= ' ORDER BY ogre_eventtype.et_name ';
        $query = $ci->db->query($qry);
        $ret = '';
        $ret .= '<option value="0" hidden="hidden">-</option>';
        foreach ($query->getResult() as $row){
            if($etype == $row->et_name){
                $ret .= '<option value="'. $row->et_name . '" selected="selected">' . $row->et_name . '</option>';
            }
            else{
                $ret .= '<option value="'. $row->et_name . '">' . $row->et_name . '</option>';
            }
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function personalGameLibraryList($conid=0, $gmid=0, $admin=TRUE){
        $action = site_url('ogrex/infoPGLibrary','https');
        $ci = &get_instance();
        if($conid==0){
            $conid = $ci->session->get('ogre_conid');
        }
        $ret='';    
        $qry='';
        $qry.='SELECT ogre_gameschedule.gs_id ';
        $qry.=' FROM ogre_gameschedule ';
        $qry.=' WHERE ogre_gameschedule.gs_convention_id=' . $conid;
        $qry.=' AND ogre_gameschedule.gs_cancelled = 0';
        $qry.=' AND ogre_gameschedule.gs_gn_id = ' . PERSONAL_LIBRARY_ID;
        if($gmid!=0){
            $qry.=' AND gr_gm_id='. $gmid;
        }
        $qry.=' ORDER BY gs_date_created DESC';
        $dmode='R';
        $ret .= '<div id="pgl-results"  class="results"></div>';
        $gidiv ='game-info-dialog';
        $vmode = 'MAIN';
        $ret .= '<h2>Personal Game Library Requests</h2>';
        $ret .= '<table id="pgl-proposal-table_table-boot" class="table table-hover">';
        $ret .= '<tr>';
        $ret .= '<th>Game/Title (GM Name)</th>';
        $ret .= (!$ci->agent->isMobile()) ?  '<th>Status</th>' : '';
        $ret .= '</tr>';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $ret .= '<tr>';
                $ret .= '<td>';                    
                $ci->event->event_init($row->gs_id, $conid);
                $ginfo = site_url('ogrex/getGameInformation','https');
                $rowrefresh = site_url('ogrex/regularRowRefresh/'.$row->gs_id.'/'.$dmode,'https');
                $rowdiv = 'gsrow'.$row->gs_id;          
                $girefresh = site_url('ogrex/gameInfoRefresh/'.$row->gs_id,'https');
                $regbuttons = 'ogrex/gameRegDialog/' . $row->gs_id;
                $em = $ci->event->get_gmcontact($row->gs_id,1);
                $gm = $ci->event->getGMNames($row->gs_id,1);
                $glink = '' . (trim($em)!= '' ? mailto($em, $gm)  : $gm) . '';                                        
                $ret .= ($ci->event->cancel <> 0 || $ci->event->displaymode == 'X') ? '<del>' : '';
                $link = $ci->event->game_name;
                $titleline = $ci->event->game_title;
                if (trim($ci->event->game_title) != ""){
                       $link .= ' - <span class="gametitle">' . $ci->event->game_title . '</span>';
                       $titleline = ' - ' . $ci->event->game_title;
                }              
                $ret .= str_pad($row->gs_id,5,'0', STR_PAD_LEFT);
                $ret .= $ci->schedule_lib->gameDialogLink($link . ' (' . $glink . ') ', $ci->event->id, $ginfo, $rowrefresh, $rowdiv, $girefresh, $gidiv, $vmode, $dmode, $regbuttons);
                $ret .= ($ci->event->cancel <> 0 ||$ci->event->displaymode == 'X') ? '</del>' : '';
                $ret .= ($ci->event->displaymode == 'R')?'<span class="badge bg-primary">PENDING</span>':'';
                $ret .= ($ci->event->cancel <> 0) ? '<span class="badge bg-warning">CANCELLED</span>':'';
                $ret .= ($ci->event->displaymode == 'X')? '<span class="badge bg-warning">CANCELLED</span>':'';
                $ret .= '</td>';
                $ret .= '<td>';                 
                $ret1 = $this->getStatusSelect($ci->event->displaymode, $row->gs_id);     
                if ($admin !== TRUE){
                    $ret1 = str_replace('<select ', '<select disabled="disabled" ', $ret1);
                }
                $ret .= $ret1;
                $ret .= '</td>';
                $ret .= '</tr>';
            }
        }
        else
        {
            $ret .= '<p align="center">None</p>';
        }
        $ret .= '</table>';
        return $ret;

    }        
//---------------------------------------------------
//
//---------------------------------------------------
    public function proposalList($conid=0, $gmid=0, $deleteflag=0){
        $action = site_url('ogrex/proposalInfo','https');
        $ci = &get_instance();
        if($conid == 0){
            $conid = $ci->session->ogre_conid;
        }
        $ret='';    
        $qry='';
        $qry.='SELECT ogre_gamerequest.* ';
        $qry.=' FROM ogre_gamerequest ';
        $qry.=' WHERE ogre_gamerequest.gr_con_id=' . $conid;
        $qry.=' AND ogre_gamerequest.gr_delete = ' . $deleteflag;
        if($gmid!=0){
            $qry.=' AND gr_gm_id='. $gmid;
        }
        $qry.=' ORDER BY gr_date_created DESC';
        $ret .= '<div id="results"  class="results"></div>';
        $ret .= '<div style="padding:10px;">';
        $ret .= '<label for="gm-id-list">Filter by Game Master:</label>';
        $ret .= $this->buildProposalGMList($conid, $gmid);
        $ret .= '</div>';

        $ret .= '<div id="game-proposal-table">';
        $ret .= '<h4>Game Proposals</h4>';
        $ret .= '<table id="game-proposal-table-table-boot" class="table table-striped table-hover">';
        $ret .= '<tr>';
        $ret .= '<th>Game/Title (GM Name)</th>';
        $ret .= (!$ci->agent->isMobile()) ?  '<th>Status</th>' : '';
        $ret .= '</tr>';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $this->prop_init($row->gr_id, $conid);
                $ret .= '<tr>';
                $ret .= '<td>';
                $glink = '<strong>' . (trim($row->gr_gm_email)!= '' ? mailto($row->gr_gm_email, $row->gr_gm_name)  : $row->gr_gm_name) . '</strong>';                                        
                $ret .= ((intval($this->id) < 0) ? '<del>' : '');
                $link = $this->game_name;
                $titleline = $this->game_name;
                if (trim($this->game_title) != ""){
                       $link .= ' - <span class="gametitle">' . $this->game_title . '</span>';
                       $titleline = ' - ' . $this->game_title;
                }              
                $ret .= str_pad($this->request_id,5,'0', STR_PAD_LEFT) . ' - <a href="#" onclick="return getproposalInfo('.$this->request_id.",'".$action.'/'.$this->request_id."'".');" name="ID' . $this->request_id . '" class="proposallink" title="' . $titleline . '">';
                $ret .= $link . ' (' . $glink . ') ';
                $ret .= '</a>';
                $ret .= ($this->id < 0) ? '</del>' : '';
                $ret .= ($this->id == 0)?'<span class="badge bg-primary">PENDING</span>':'';
                $ret .= ($this->id < 0) ? '<span class="badge bg-warning">REJECTED</span>':'';
                $ret .= '</td><td>';
                $ret .= $this->getStatusSelect($this->id, $this->request_id);                                                          
                $ret .= '</td></tr>';
            }
        }
        else
        {
            $ret .= '<p align="center">None</p>';
        }
        $ret .= '</table>';
        $ret .= '</div>';
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------        
//        public function proposalTab($grid=0){
//            $ret = '';
//            $ci=&get_instance();
//            $ret .= '<div id="proptabs">';          
//            $ret .= '<ul>';                   
//            $ret .= '<li>';
//            $ret .= '<a href="#proptab-0" >';
//            $ret .= 'Who';
//            $ret .= '</a>';
//            $ret .= '</li>';            
//            $ret .= '<li>';
//            $ret .= '<a href="#proptab-1" >';
//            $ret .= 'What';
//            $ret .= '</a>';
//            $ret .= '</li>';
//            $ret .= '<li>';
//            $ret .= '<a href="#proptab-2" >';
//            $ret .= 'When';
//            $ret .= '</a>';
//            $ret .= '</li>';
//            $ret .= '<li>';
//            $ret .= '<a href="#proptab-3" >';
//            $ret .= 'Where';
//            $ret .= '</a>';
//            $ret .= '</li>';
//            $ret .= '<li>';
//            $ret .= '<a href="#proptab-4" >';
//            $ret .= 'The Rest...';
//            $ret .= '</a>';
//            $ret .= '</li>';            
//            $ret .= '</ul>';
//            $ret .= '<div id="proptab-0">';
//            $ret .= $this->proposalWho($grid);
//            $ret .= '</div>';
//            $ret .= '<div id="proptab-1">';
//            $ret .= $this->proposalWhat($grid);
//            $ret .= '</div>';
//            $ret .= '<div id="proptab-2">';
//            $ret .= $this->proposalWhen($grid); 
//            $ret .= '</div>';
//            $ret .= '<div id="proptab-3">';
//            $ret .= $this->proposalWhere($grid);  
//            $ret .= '</div>';
//            $ret .= '<div id="proptab-4">';
//            $ret .= $this->proposalOther($grid);   
//            $ret .= '</div>';            
//            $ret .= '</div>';      
//            return $ret;
//        }
//---------------------------------------------------
//
//---------------------------------------------------        
    private function buildProposalGMList($conid=0, $gmid=0, $deleteflag=0){
        $ci = &get_instance();
        if($conid!=0){
           $conid = $ci->session->get('ogre_conid');
        }            
        $qry='SELECT DISTINCT ogre_gamerequest.gr_gm_id, ';
        $qry.=' ogre_gamerequest.gr_gm_name, ';
        $qry.=' ogre_gamerequest.gr_gm_email, ';
        $qry.=' ogre_gamerequest.gr_con_id ';
        $qry.=' FROM ogre_gamerequest ';
        $qry.=' WHERE ogre_gamerequest.gr_con_id=' . $conid;
        $qry.=' AND ogre_gamerequest.gr_delete=' . $deleteflag;
        $query = $ci->db->query($qry);
        $ret = "";
        $action=site_url('ogrex/getProposalListByGM','https');
        $ret .= '<select class="form-control" id="gm-id-list" name="gm-id-list" onchange="loadFilterProposalList(' ."'". $action."'," . 'this.value)">';   
        $ret .= '<option value="ALL" hidden="hidden">All</option>';
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                if($row->gr_gm_id!=$gmid){
                    $ret .= '<option value="' . $row->gr_gm_id . '">'.$row->gr_gm_name.'</option>';
                }
                else{
                    $ret .= '<option value="' . $row->gr_gm_id . '" selected="selected">'.$row->gr_gm_name.'</option>';
                }
            }
        }
        $ret .= '</select>';
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------        
    private function getStatusSelect($status, $id){
        $ret='';
        if(is_numeric($status)){
            $action=site_url('ogrex/proposalStatusIn','https');
            $ret.='<select name="status" id="status" size="1" class="form-control" onchange="changePropStatus(this.options[this.selectedIndex].value,'. $id .','."'". $action."'".');">';
            if(intval($status)==0){                                     
                $ret.='<option value="-1">Rejected</option>';
                $ret.='<option value="0" selected="selected">Pending</option>';
                $ret.='<option value="1">Accepted</option>';                
            }
             elseif (intval($status) < 0){            

                $ret.='<option value="-1" selected="selected">Rejected</option>';
                $ret.='<option value="0">Pending</option>';
                $ret.='<option value="1">Accepted</option>';
             }
             elseif (intval($status) > 0){
                $ret.='<option value="-1">Rejected</option>';
                $ret.='<option value="0">Pending</option>';
                $ret.='<option value="1" selected="selected">Accepted</option>';
             }
            else{
                $ret.='<option value="" selected="selected" hidden="hidden">-Select One-</option>';
                $ret.='<option value="-1">Rejected</option>';
                $ret.='<option value="0">Pending</option>';
                $ret.='<option value="1">Accepted</option>';
            }

        } else {
            $div1 = 'pgl-proposal-list';
            $action = site_url('ogrex/pglApprove','https');
            $ret .= '<select name="pgl-status" id="pgl-status" size="1" class="form-control" onchange="changepglStatus(this.options[this.selectedIndex].value'.",'". $action . '/' . $id."'".', '.$id.",'".$div1."'".');" />';
            switch($status){
            case "X":
                $ret.='<option value="X" selected="selected">Rejected</option>';
                $ret.='<option value="R">Pending</option>';
                $ret.='<option value="P">Accepted</option>';
                break;
             case "P":
                $ret.='<option value="X">Rejected</option>';
                $ret.='<option value="R">Pending</option>';
                $ret.='<option value="P" selected="selected">Accepted</option>';
                break;
             case "R":
                $ret.='<option value="X">Rejected</option>';
                $ret.='<option value="R" selected="selected">Pending</option>';
                $ret.='<option value="P">Accepted</option>';
                break;            
            default:
                $ret.='<option value="U" hidden="hidden">-Select One-</option>';
                $ret.='<option value="X">Rejected</option>';
                $ret.='<option value="R">Pending</option>';
                $ret.='<option value="P">Accepted</option>';
                break;
            }            
        }
        $ret.='</select>'; 
        return $ret;
    }   
//---------------------------------------------------
//
//---------------------------------------------------       
    public function proposalWhat($propid=0){
        $ci = &get_instance();
        if($propid != 0){
            $this->prop_init($propid);
        }                
        $ret='';
        $ret .= '<div id="game-proposal1">';
        $ret .= '<div id="game-proposal-table-what" class="proposal-display-table">';
        $ret .= '<p><strong>';             
        $ret .= ' Proposed Game: ';
        $ret .= str_pad($this->request_id,5,'0', STR_PAD_LEFT);
        $ret .= '</strong></p>';
        $ret .= '<div class="game-proposal-table-info-right">';
        $ret .= 'Proposal '. $this->proposal_number .' of ' . $this->proposal_number_total . '';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-label">';
        $ret .= 'Game Name';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-info">';
        $ret .= $this->game_name;
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-label">';
        $ret .= 'Game Type/Event Type';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-info">';
        $ret .= $this->game_type . ' / ' . $this->event_type;
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-label">';
        $ret .= 'Players/GM Role';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-info">';
        $ret .= $this->min_players . ' / ' . $this->max_players .' (' . $this->gm_gamerole .' )';
        $ret .= '</div>';
        $ret .= '<div colspan="2" class="game-proposal-table-label_notes">';
        $ret .= 'Game Description';
        $ret .= '</div>';
        $ret .= '<div colspan="2"  class="game-proposal-table-info">';
        $ret .= txt2html(quotes_to_entities($this->game_notes));
        $ret .= '</div>';
        $ret .= '</div>';
        return $ret;
    }
//---------------------------------------------------
//gr_gm_age gr_gm_gender gr_gmexp gr_congamebefore
//---------------------------------------------------       
    public function proposalWho($propid=0){
        if($propid!=0){
            $this->prop_init($propid);
        }    
        $ret='';
        $ret .= '<div id="gameproposal15">';
        $ret .= '<div id="game-proposal-table-who" class="proposal-display-table">';
        $ret .= '<div colspan="2" class="gameproposaltable_title">';
        $ret .= 'Proposed by';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-label">';
        $ret .= 'GM Name (email)';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-info">';
        $ret .= $this->gm_name .' (' . $this->gm_email .' )';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-label">';
        $ret .= 'GM Age/Gender';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-info">';
        $ret .= $this->gm_age .' / ' . $this->gm_gender .' ';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-label">';
        $ret .= 'GM Exp/Con GM';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-info">';
        $ret .= $this->gm_xp .' / ' . $this->gm_congamebefore .' ';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-label">';
        $ret .= 'GM Role';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-info">';
        $ret .= $this->gm_gamerole;
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';             
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------       
    public function proposalWhen($propid=0){
        $ci = &get_instance();
        if($propid!=0){
            $this->prop_init($propid);
        }            
        $ret='';
        $ret .= '<div id="gameproposal2">';
        $ret .= '<div id="game-proposal-table-when" class="proposal-display-table">';
        $ret .= '<div class="gameproposaltable_title">';
        $ret .= 'Proposed Time';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-label">';
        $ret .= 'Desired start time(s):';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-info">';
        $ret .= $this->anytime;
        $ret .= '</div>';            
        $x = strtolower($this->anytime) == 'special';
        if($x!=FALSE){
              $ret .= '<tr>';
              $ret .= '<div class="game-proposal-table-label_notes" colspan="2">';
              $ret .= 'Specific Preference:';
              $ret .= '</div>';               
              $ret .= '<div class="game-proposal-table-info" colspan="2">';
              $ret .= $this->specialschedule;
              $ret .= '</div>';            
        }
        $ret .= '<div class="game-proposal-table-label_notes">';
        $ret .= 'Hours/Rounds';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-info">';
        $ret .= $this->slot_length .' hrs / '. $this->total_rounds. ' round(s) ';
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';
        return $ret;            
    }
//---------------------------------------------------
//
//---------------------------------------------------       
    public function proposalSelect($n, $key){        
        $ci = &get_instance();
        $conid = $ci->session->get('ogre_conid');
        $val = $ci->ogre_lib->getMiscContent($key, $conid);
        $ret='';
        $ret .= '<select class="form-control" size="1" name="'.$n.'" name="'.$n.'">';
        $ret .= '<option value="0" hidden="hidden" selected="selected">[-SELECT ONE-]</option>';
        $list = explode(";",$val['content']);
        foreach($list as $items){
           $options=explode(",",$items);
           $x = strpos($options[0], '*');
           if($x === FALSE){
                $ret .= '<option value="' . $options[0] . '">' . $options[1] . ' </option>'; 
           }
           else{
               $ret .= '<option value="' . $options[0] . '" selected="selected">' . $options[1] . ' </option>';
           }
        }                
        $ret .= '</select>';

        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------       
    public function proposalSelectSchedPref($n, $key){        
       $ci = &get_instance();
       $conid = $ci->session->get('ogre_conid');
       $val=$ci->ogre_lib->getMiscContent($key, $conid);
       $ret='';
       $ret .= '<select class="form-control" size="1" name="'.$n.'" name="'.$n.'" onchange="showSchedOptions(this.options[this.selectedIndex].value);">';
       $ret .= '<option value="0" selected="selected" hidden="hidden">[-SELECT ONE-]</option>';
       $list=explode(";",$val['content']);
       foreach($list as $items){
         $options=explode(",",$items);
         $x = strpos($options[0], '*');
         if($x===FALSE){
              $ret .= '<option value="' . $options[0] . '">' . $options[1] . ' </option>'; 
         }
         else{
             $ret .= '<option value="' . $options[0] . '" selected="selected">' . $options[1] . ' </option>';
         }
       }                
       $ret .= '</select>';

       return $ret;
    }         
//---------------------------------------------------
//
//---------------------------------------------------            
    public function delGameProp($gpid=0){
        $ci = &get_instance();
        if($gpid==0){
           $gpid=$_POST['gpid'];
        }
        $qry = 'UPDATE ogre_gamerequest  ';
        $qry .= ' SET gr_delete = 1 ';                
        $qry .= ' WHERE gr_id = ' . $gpid;                
        $ci->db->query($qry);
        $done=($ci->db->affectedRows() > 0)?TRUE:FALSE;
        return $done;               
    }  
//---------------------------------------------------
//
//---------------------------------------------------       
    public function proposalWhere($propid=0){
        $ci = &get_instance();
        if($propid!=0){
            $this->prop_init($propid);
        }             
        $ret='';
        $ret .= '<div id="gameproposal4">';
        $ret .= '<table id="game-proposal-table-where" class="proposal-display-table">';
        $ret .= '<tr>';
        $ret .= '<div colspan="2" class="gameproposaltable_title">';
        $ret .= 'Proposed Location';
        $ret .= '</div>';
        $ret .= '</tr>';
        $ret .= '<tr>';
        $ret .= '<div class="game-proposal-table-label">';
        $ret .= 'Table Space:';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-info">';
        $ret .= $this->table_space;
        $ret .= '</div>';            
        $ret .= '</tr>';
        $ret .= '<tr>';
        $ret .= '<div class="game-proposal-table-label">';
        $ret .= 'Play Area';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-info">';
        $ret .= $this->play_area;
        $ret .= '</div>';
        $ret .= '</tr>';
        $ret .= '<tr>';
        $ret .= '<div colspan="2" class="game-proposal-table-label_notes">';
        $ret .= 'Hours/Rounds';
        $ret .= '</div>';
        $ret .= '</tr>';
        $ret .= '<tr>';
        $ret .= '<div colspan="2" class="game-proposal-table-info">';
        $ret .= $this->slot_length .' hrs / '. $this->total_rounds. ' round(s)';
        $ret .= '</div>';
        $ret .= '</tr>';
        $ret .= '</table>';
        $ret .= '</div>';             
        return $ret;             
    }
//---------------------------------------------------
//
//---------------------------------------------------       
    public function proposalOther($propid=0){
        $ci = &get_instance();
        if($propid!=0){
            $this->prop_init($propid);
        }
        $ret='';
        $ret .= '<div id="gameproposal3">';
        $ret .= '<div id="gameproposaltable_other" class="proposaldisplay_table">';
        $ret .= '<div colspan="2" class="gameproposaltable_title">';
        $ret .= 'Other Details';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-label">';
        $ret .= 'Number of GMs:';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-info">';
        $ret .= $this->number_of_gms;
        $ret .= '</div>';            
        $ret .= '<div class="game-proposal-table-label">';
        $ret .= 'Additional GM List';
        $ret .= '</div>';
        $ret .= '<div class="game-proposal-table-info">';
        $ret .= $this->gm_list;
        $ret .= '</div>';
        $ret .= '<div colspan="2"  class="game-proposal-table-label_notes">';
        $ret .= 'Additional Comments';
        $ret .= '</div>';
        $ret .= '<div colspan="2"  class="game-proposal-table-info">';
        $ret .= txt2html(quotes_to_entities($this->additional_comments));
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';
        return $ret;             
    }
//---------------------------------------------------
//
//---------------------------------------------------                       
    public function proposalStatusIn($id, $stat){
        $ci = &get_instance();
        if($id!=0){
           $sql='';
           $sql .= 'UPDATE ogre_gamerequest ';
           $sql .= ' SET gr_schedule_id = ' . $stat;
           $sql .= ' WHERE gr_id = ' . $id;
           $ci->db->query($sql);
           $ret = ($ci->db->affectedRows() > 0)?TRUE:FALSE;	                
           return $ret; 
        }
    }
}  /* END GAMEREQUEST CLASS */ ?>
