<?php 
namespace App\Models;
use CodeIgniter\Model;
use CodeIgniter\I18n\Time;

class Convention extends Model{
    var $orgid = 0;
    var $conid = 0;
    var $msa_conid = 0;
    var $name = '';
    var $year = '';
    var $location = '';
    var $loc_address = '';
    var $loc_city = '';
    var $loc_state = '';
    var $loc_zip = '';
    var $loc_phone = '';
    var $loc_website = '';
    var $eventhomepage = '';
    var $ogre_dir = '';
    var $website = '';
    var $logo_img = '';
    var $start_date = '';
    var $start_time = '';
    var $end_date = '';
    var $end_time = '';
    var $eventtype = '';
    var $lastyear_conid=0;
    var $gaming_reg_open_date= '';
    var $gaming_reg_close_date= '';
    var $nonrpga_gm_deadline_prereg = ''; 
    var $nonrpga_gm_deadline_notprereg = '';  
    var $gamingcoordinatoremail = '';
//---------------------------------------------------
//
//---------------------------------------------------			
    public function __construct()
    {
     
    }	
//---------------------------------------------------
//
//---------------------------------------------------
    function init($conid=0){
        if ($conid != 0)  {
            $this->orgid = 0;
            $this->conid = 0;
            $this->msa_conid = 0;
            $this->name = '';
            $this->year = '';
            $this->location = '';
            $this->loc_address = '';
            $this->loc_city = '';
            $this->loc_state = '';
            $this->loc_zip = '';
            $this->loc_phone = '';
            $this->loc_website = '';
            $this->eventhomepage = '';
            $this->ogre_dir = '';
            $this->website = '';
            $this->logo_img = '';
            $this->start_date = '';
            $this->start_time = '';
            $this->end_date = '';
            $this->end_time = '';
            $this->eventtype = '';
            $this->lastyear_conid=0;
            $this->gaming_reg_open_date= '';
            $this->gaming_reg_close_date= '';
            $this->nonrpga_gm_deadline_prereg = '';
            $this->nonrpga_gm_deadline_notprereg = '';
            $this->gamingcoordinatoremail = '';
            $this->getConData($conid);
        }  
    } 
//---------------------------------------------------
//
//--------------------------------------------------- 
    private function getConData($conid){
        $ci=&get_instance();
        $qry = 'SELECT * FROM ogre_convention WHERE con_id = ' . $conid . ';';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){ 
                $this->orgid = $row->con_org_id;
                $this->conid = $conid;
                $this->msa_conid = $row->con_msa_id;    	
                $this->name = $row->con_name;
                $this->year = $row->con_year;
                $this->location = $row->con_location;
                $this->loc_address = $row->con_loc_address;
                $this->loc_city = $row->con_loc_city;
                $this->loc_state = $row->con_loc_state;
                $this->loc_zip = $row->con_loc_zip;
                $this->loc_phone = $row->con_loc_phone;
                $this->loc_website = $row->con_loc_website;
                $this->eventhomepage = $row->con_eventhomepage;
                $this->ogre_dir = $row->con_ogre_dir;
                $this->website = $row->con_website;
                $this->logo_img = $row->con_logo_img;
                $this->gaming_reg_open_date = $row->con_gaming_reg_open_date;
                $this->gaming_reg_close_date = $row->con_gaming_reg_close_date;
                $this->eventtype = $row->con_eventtype;
                $sdate = new Time($row->con_start_date);
                $edate = new Time($row->con_end_date);  
              
                $this->start_date = $sdate->format('Y-m-d');
                $this->start_time = $sdate->format('H:i:s');
                $this->end_date = $edate->format('Y-m-d');
                $this->end_time = $edate->format('H:i:s');	
                $this->gamingcoordinatoremail = $row->con_gamingcoordinatoremail;	
            }
        }
        $ly = intval($this->year)-1;			
        $qry = 'SELECT * FROM ogre_convention ';
        $qry .= ' WHERE con_name = "' . $this->name . '" AND con_year = "' . $ly . '";';
        $query = $ci->db->query($qry);

        if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){ 
                        $this->lastyear_conid = $row->con_id;    	
                }	
        }   
    }
//---------------------------------------------------
//
//--------------------------------------------------- 
    public function orgname($conid=0){
        $ci=&get_instance();
        $ret ='';
        if ($conid==0){
            $conid = $ci->session->get('ogre_conid');  
        }
        if(trim($conid)!=''){
            $qry = 'SELECT org_name FROM ogre_convention, ogre_organization ';
            $qry .= ' WHERE ogre_organization.org_id = ogre_convention.con_org_id ';
            $qry .= ' AND con_id = ' . $conid . ';';
            $query = $ci->db->query($qry);
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){ 
                    $ret = $row->org_name;
                }
            }
            else{
                $ret = 'ERROR';
            }
        }
        return $ret;
    }    
//---------------------------------------------------
//
//--------------------------------------------------- */
    public function get_msa_conid($conid){
        $ci=&get_instance();
        $qry = 'SELECT con_msa_id FROM ogre_convention ';
        $qry .= ' WHERE con_id = ' . $conid . ';';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){ 
                $ret = $row->con_msa_id;
            }
        }
        return $ret;
    }
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function getOrgid($conid){
        $ci=&get_instance();
        $qry = 'SELECT con_org_id FROM ogre_convention WHERE con_id = '.$conid.';';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){ 
                $ret = $row->con_org_id;
            }
        }
        return $ret;
    }    
//---------------------------------------------------
//
//  
//
//--------------------------------------------------- 
    public function saveConventions($p, $thisd=0){
                    $bvalid = TRUE;
                    if($p["con_name"]==""){
                            $bvalid = FALSE;
                    }			
                    if($p["con_year"]==""){
                            $bvalid = FALSE;
                    }
			
                    if($bvalid ==TRUE){
                        if (intval($thisd) > 0){
                                $ret = $this->updateCon($p, $thisd);
                        }
                        else{
                                $ret = $this->insertCon($p);
                        }
                    }
                    else
                    {
                        $ret = FALSE;
                    }				
                    return $ret;	 
		}
//---------------------------------------------------
//
//--------------------------------------------------- 
    private function updateCon($p, $thisd){
        $ci = &get_instance();                   
        $qry='UPDATE ogre_convention SET ';
        $qry.='con_name = ' . '"' . $p["con_name"] . '", ';
        $qry.='con_year = ' . '"' . $p["con_year"] . '", ';
        $qry.='con_logo_img = ' . '"' . $p["con_logo_img"] . '", ';
        $qry.='con_location = ' . '"' . $p["con_location"] . '", ';
        $qry.='con_loc_address = ' . '"' . $p["con_loc_address"] . '", ';
        $qry.='con_loc_city = ' . '"' . $p["con_loc_city"] . '", ';
        $qry.='con_loc_state = ' . '"' . $p["con_loc_state"] . '", ';
        $qry.='con_loc_zip = ' . '"' . $p["con_loc_zip"] . '", ';
        $qry.='con_loc_phone = ' . '"' . $p["con_loc_phone"] . '", ';
        $qry.='con_loc_website = ' . '"' . $p["con_loc_website"] . '", ';
        $qry.='con_website = ' . '"' . $p["con_website"] . '", ';
        $qry.='con_eventhomepage = ' . '"' . $p["con_eventhomepage"] . '", ';
//			$qry.='con_ogre_dir = ' . '"' . $p["con_ogre_dir"] . '", ';
        $qry.='con_eventtype = ' . '"' . $p["con_eventtype"] . '", ';		
        $qry.='con_gaming_reg_open_date = ' . '"' . $p["gpopen_year"] . '-' . $p["gpopen_month"] . '-' . $p["gpopen_day"] . '", ';
        $qry.='con_gaming_reg_close_date = ' . '"' . $p["gpclose_year"] . '-' . $p["gpclose_month"] . '-' . $p["gpclose_day"] . '", ';			
        $qry.='con_start_date = ' . '"' . $p["con_start_date_year"] . '-' . $p["con_start_date_month"] . '-' . $p["con_start_date_day"] . '", ';
        $qry.='con_start_time = ' . '"' . $p["con_start_time"] . '", ';
        $qry.='con_end_date = ' . '"' . $p["con_end_date_year"] . '-' . $p["con_end_date_month"] . '-' . $p["con_end_date_day"] . '", ';
        $qry.='con_end_time = ' . '"' . $p["con_end_time"] . '" ';			
        $qry.=' WHERE con_id =' . $thisd . ';';
        $ci->db->query($qry);
        $ret = ($ci->db->affectedRows() > 0)?TRUE:FALSE;
        return $ret;   	
    }
//--------------------------------------------------
//
//--------------------------------------------------- */
    private function insertCon($p){
        $ci=&get_instance();                   
        $orgid = $ci->session->get('ogre_orgid');                       
        $qry='INSERT INTO ogre_convention(';
        $qry.= 'con_org_id,';
        $qry.= 'con_name,';
        $qry.= 'con_year,';
        $qry.= 'con_logo_img,';
        $qry.= 'con_location,';
        $qry.= 'con_loc_address,';
        $qry.= 'con_loc_city,';
        $qry.= 'con_loc_state,';
        $qry.= 'con_loc_zip,';
        $qry.= 'con_loc_phone,';
        $qry.= 'con_loc_website,';
        $qry.= 'con_website,';
        $qry.= 'con_eventhomepage,';
        $qry.= 'con_eventtype,';
        $qry.= 'con_gaming_reg_open_date,';
        $qry.= 'con_gaming_reg_close_date,';
        $qry.= 'con_start_date,';
        $qry.= 'con_start_time,';
        $qry.= 'con_end_date,';
        $qry.= 'con_end_time  ) ';
        $qry.= ' VALUES (';
        $qry.= '"' . $orgid . '", ';
        $qry.= '"' . $p["con_name"] . '", ';
        $qry.= '"' . $p["con_year"] . '", ';
        $qry.= '"' . $p["con_logo_img"] . '", ';
        $qry.= '"' . $p["con_location"] . '", ';
        $qry.= '"' . $p["con_loc_address"] . '", ';
        $qry.= '"' . $p["con_loc_city"] . '", ';
        $qry.= '"' . $p["con_loc_state"] . '", ';
        $qry.= '"' . $p["con_loc_zip"] . '", ';
        $qry.= '"' . $p["con_loc_phone"] . '", ';
        $qry.= '"' . $p["con_loc_website"] . '", ';
        $qry.= '"' . $p["con_website"] . '", ';
        $qry.= '"' . $p["con_eventhomepage"] . '", ';
        $qry.= '"' . $p["con_eventtype"] . '", ';
        $qry.= '"' . $p["gpopen_year"] . '-' . $p["gpopen_month"] . '-' . $p["gpopen_day"] . '", ';
        $qry.= '"' . $p["gpclose_year"] . '-' . $p["gpclose_month"] . '-' . $p["gpclose_day"] . '", ';
        $qry.= '"' . $p["con_start_date_year"] . '-' . $p["con_start_date_month"] . '-' . $p["con_start_date_day"] . '", ';
        $qry.= '"' . $p["con_start_time"] . '", ';
        $qry.= '"' . $p["con_end_date_year"] . '-' . $p["con_end_date_month"] . '-' . $p["con_end_date_day"] . '", ';
        $qry.= '"' . $p["con_end_time"] . '" ';	   
        $qry.= ');';
        $ci->db->query($qry);
        $ret = ($ci->db->affectedRows() > 0)?TRUE:FALSE;
        return $ret;   
    }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
    public function date_select($n, $d=''){
        date_default_timezone_set("America/New_York");
        $sdate = new Time($this->start_date);
        $edate = new Time($this->end_date);
        $edate->modify("+1 day");
        $e = $edate->format('Y-m-d');
        $ret = '<select name="' . $n . '" id="' . $n . '" size="1" class="form-select">'; 
        $ret .= '<option value="0">-</option>';
        do{
            if($d == $sdate->format('Y-m-d')){	  
                    $ret .= '<option value="' . $sdate->format('Y-m-d') . '" selected="selected">';
            }
            else{
                    $ret .= '<option value="' . $sdate->format('Y-m-d') . '">';	    
            }  
            $ret .= $sdate->format('Y-m-d');
            $ret .= '</option>';	
            $sdate->modify("+1 day");
            $s = $sdate->format('Y-m-d');			
        }
        while ($s != $e);			
        $ret .= '</select>'; 			
        return $ret; 
    }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------   
    public function dateSelectBoot($conid, $n, $label='', $d=''){
        date_default_timezone_set("America/New_York");
        if($this->conid==0){
            $this->initialize($conid);
        }      
        $sdate = new Time($this->start_date);
        $edate = new Time($this->end_date);
        $edate->modify("+1 day");
        $e = $edate->format('Y-m-d');

        $ret ='';
        $ret .= '<label for="'.$n.'">'.$label.'</label>';
        $ret .= '<select name="' . $n . '" id="' . $n . '" size="1" class="form-control my-1" placeholder="-">'; 
        $ret .= '<option hidden="hidden" value="0">-</option>';
        do{
            if($d == $sdate->format('Y-m-d')){	  
                    $ret .= '<option value="' . $sdate->format('Y-m-d') . '" selected="selected">';
            }
            else{
                    $ret .= '<option value="' . $sdate->format('Y-m-d') . '">';	    
            }  
            $ret .= $sdate->format('l Y-m-d');
            $ret .= '</option>';	
            $sdate->modify("+1 day");
            $s = $sdate->format('Y-m-d');			
        }
        while ($s != $e);			
        $ret .= '</select>'; 			
        return $ret; 
    }    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function dateSelectParsed($name, $darray, $part, $val=0){
        $ret = '<select name="' . $name . '">';
        $last ='';
        foreach ($darray as $cday){
            if ($last != $cday[$part]){
                if($cday[$part] != $val){
                    $ret .= '<option value=" ' . $cday[$part] . '">  ' . str_pad($cday[$part],2,'0', STR_PAD_LEFT) . '  </option>';
                }
                else{
                    $ret .= '<option value="' . $cday[$part] . '" selected="selected">  ' . str_pad($cday[$part],2,'0', STR_PAD_LEFT) . '  </option>';
                }
            }
            $last = $cday[$part];
        }
        $ret .= '</select>  ';
        return $ret;
    }
                
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function datePartSelectParsed($name, $min, $max, $val=0){
        $ret = '<select name="' . $name . '">';
        for ($i=$min;$i <= $max; $i++){
            if($i != $val){
                $ret .= '<option value=" ' . $i . '">  ' . str_pad($i,2,'0', STR_PAD_LEFT) . '  </option>';
            }
            else{
                $ret .= '<option value="' . $i . '" selected="selected">  ' . str_pad($i,2,'0', STR_PAD_LEFT) . '  </option>';
            }
        }
        $ret .= '</select>  ';
        return $ret;
    }                
//---------------------------------------------------
//
//---------------------------------------------------
    public function dateArray(){
        date_default_timezone_set("America/New_York");
        $sdate = new Time($this->start_date);
        $edate = new Time($this->end_date);
        $edate->modify("+1 day");
        $e = $edate->format('Y-m-d');
        $i = 1;
        do{
                $condates[$i] = $sdate->format('Y-m-d');
                $sdate->modify("+1 day");
                $s = $sdate->format('Y-m-d');
                $i++;	  
        }
        while ($s != $e);
        return $condates; 
    }  
//---------------------------------------------------
//
//---------------------------------------------------
    public function dayOfWeekArray(){
        date_default_timezone_set("America/New_York");
        $sdate = new Time($this->start_date);
        $edate = new Time($this->end_date);
        $edate->modify("+1 day");
        $e = $edate->format('Y-m-d');
        $condates=array();
        $i = 1;
        do {
                $condates[$sdate->format("l")] = $sdate->format('Y-m-d');
                $sdate->modify("+1 day");
                $s = $sdate->format('Y-m-d');
                $i++;	  
        }
        while ($s != $e);
        return $condates; 
    }        
//---------------------------------------------------
//
//---------------------------------------------------
    public function dayArray(){
        date_default_timezone_set("America/New_York");
        $sdate = new Time($this->start_date);
        $edate = new Time($this->end_date);
        $condates = array(); 
        $edate->modify("+1 day");
        $e = $edate->format('Y-m-d');
        $i = 1;			
        do{
            $condates[$i] = $sdate->format('l');
            $sdate->modify("+1 day");
            $s = $sdate->format('Y-m-d');
            $i++;	  
        }
        while ($s != $e);
        return $condates;
    } 
		//---------------------------------------------------
		//
		//  
		//
		//---------------------------------------------------
		public function parse_date($xdate){
                    $dtarry[1] = substr($xdate,0,4);
                    $dtarry[2] = substr($xdate,5,2);
                    $dtarry[3] = substr($xdate,8,2);                         			
                    return $dtarry; 	
		}
                
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
		public function parse_dates($sdate, $edate){              
                        $sDateTime = new Time($sdate);
                        $xDateTime = new Time($sdate);
                        $eDateTime = new Time($edate);
                        $dtarry = array();
                        $x=1;
                        do 
                        {                      
                            $dtarry[$x] = $this->parse_date($xDateTime->format('Y-m-d'));
                            $x++;
                            $xDateTime->modify('+1 day'); 
                        }    
                        while ($xDateTime <= $eDateTime);                    
			return $dtarry; 	
		}                
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
    public function getConDates(){
        date_default_timezone_set("America/New_York");
        $sdate = new Time($this->start_date);
        $edate = new Time($this->end_date);  

        if (intval($edate->Format('m')) == intval($sdate->Format('m'))){   
            if($this->eventtype!='day'){
                $condates = $sdate->Format('F') . " " . $sdate->Format('d') . " - " . $edate->Format('d') . ", " . $sdate->Format('Y') ;
            }
            else{
                $condates = $sdate->Format('F') . " " . $sdate->Format('d') . ", " . $sdate->Format('Y') ;
            }
        }
        else{
                $condates = $sdate->Format('F') . " " . $sdate->Format('d') . " - " . $edate->Format('F') . " " . $edate->Format('d') . ", " . $edate->Format('Y') ;
        }
        return  $condates; 
    }  
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
    public function gamePreregDatePrompt(){
        $ci=&get_instance();
        if($this->conid===0){
            $conid = $ci->session->get('ogre_conid');
            $this->initialize($conid);
        }
        $status = ($this->isBefore($this->conid)==TRUE ? 'BEFORE' : ""). ($this->isClosed($this->conid)==TRUE ? 'CLOSED' : "") . ($this->isOpen($this->conid)==TRUE ? 'OPEN' : "");  //. ($this->isCutoff($this->conid)==TRUE ? 'CUTOFF' : "")
        $last_date = new Time($this->gaming_reg_close_date);
        $last_date = date_modify($last_date,'-1 day');
        $regopen_date = new Time($this->gaming_reg_open_date);
        switch($status){
            case 'BEFORE':
                $ret = $this->name . ' Gaming Sign Up Opens ' . $regopen_date->format('F d, Y');
            break;
            case 'OPEN':
                $ret = $this->name . ' Game Sign Up Closes After ' . $last_date->format('F d, Y');
            break;    
//            case 'CUTOFFOPEN':
//                $ret = $this->name . ' Gaming Sign Up Closes After ' . $last_date->format('F d, Y');
            break;     
            case 'CLOSED':
                $ret = $this->name . ' Gaming Sign Up is Closed';    
            break;     
            default:
                $ret = '';
            break;
        }                  
        return $ret;
    }
		//---------------------------------------------------
		//
		//  
		//
		//---------------------------------------------------
		public function slot_info($sid, $colname)
		{
                    $ci=&get_instance();
                    $qry = 'SELECT * FROM ogre_gameslots WHERE slot_conid = ' . $this->conid . ' AND slot_id = ' . $sid .' ;';

			$query = $ci->db->query($qry);
			
			if ($query->getNumRows() > 0)
			{
				foreach ($query->getResult() as $row)
				{
					$ret = $row->$colname;
				}
			
			} 
			
			return $ret;   
		}

//---------------------------------------------------
//
//---------------------------------------------------
    public function slotInfoByCode($scode, $colname, $conid=0){
        $ci=&get_instance();
        if($conid!=0){
            $this->initialize($conid);
        }
        $qry = 'SELECT * FROM ogre_gameslots WHERE slot_conid = ' . $this->conid . ' AND slot_code = "' . $scode .'" ;';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row)
            {
                    $ret = $row->$colname;
            }
        }
        return $ret;   
    }                
                
//---------------------------------------------------
//
//---------------------------------------------------
    public function viewSlotList($edit=FALSE, $conid=0){
            if($conid==0){
                $conid=$this->conid;
            }
            $this->initialize($conid);
            $ci=&get_instance();
            $qry = 'SELECT * ';
            $qry .= ' FROM ogre_gameslots ';
            $qry .= ' WHERE slot_conid = ' . $conid;
            $qry .= ' ORDER BY slot_length, slot_rpga_number;';
            $query = $ci->db->query($qry);
            $ret = '';
            $ret .= '<div class="table-responsive">';
            $ret .= '<table id="conslotlist" class="table table-striped">';
            $sl = "";
            $i=1;	
            if ($query->getNumRows() > 0){ 
                foreach ($query->getResult() as $row){
                    $rempage = 'ogrex/slotsRem';
                    $editpage = 'ogrex/slotsx';
                    $action = site_url($editpage.'/'.$row->slot_id.'/'.$conid,'https');
                    $saveaction = site_url('ogrex/slotsInX/'.$conid,'https');
                    $listrefresh = site_url('ogrex/slotsListx','https');  
                    $chkdelaction = site_url($rempage.'/'.$row->slot_id.'/'.$row->slot_conid,'https');                                
                    $importaction = site_url('ogrex/slotsImport','https');  
                    $importsaveaction = site_url('ogrex/slotsImportIn','https');  

                    if($sl != $row->slot_length){
                        $ret .= '<tr>';
                        $ret .= '<th colspan="6">';
                        $ret .= 'Slot Length: ' .  $row->slot_length . ' hrs.';
                        $ret .= '</th>';
                        $ret .= '</tr>';
                        $ret .= '<tr><th width="15%">';
                        $ret .= 'Slot Number';	   
                        $ret .= '</th>';
                        $ret .= '<th width="20%">';
                        $ret .= 'Date';
                        $ret .= '</th>'; 
                        $ret .= '<th width="25%">';
                        $ret .= 'Start Time';
                        $ret .= '</th>';
                        $ret .= '<th width="20%">';
                        $ret .= 'End Time';
                        $ret .= '</th>';  
                        $ret .= '<th width="10%">';
                        $ret .= 'Length';
                        $ret .= '</th>'; 
                        $ret .= '<th width="10%">';
                        $ret .= 'Delete';
                        $ret .= '</th>';
                        $ret .= '</th>';                                        
                    }
                        $i++;
                        $ret .= '<tr>';
                        $ret .= '<td>';
                        if ($edit==TRUE){ 
                            $ret .= '<a href="#" onclick="return addeditslot('.$row->slot_id.",'".$action."','".$saveaction."','".$listrefresh."','".$importaction."','".$importsaveaction."'".');">'.$row->slot_number.'</a>';
                        }
                        else{
                            $ret .= $row->slot_number;
                        }				   
                    $ret .= '</td>';
                    $ret .= '<td>';
                    $ret .= $row->slot_date;	
                    $ret .= '</td>';
                    $ret .= '<td>';
                    $ret .= date('h:i:s A',mktime(substr($row->slot_start_time,0,2),substr($row->slot_start_time,3,2),0,1,1,2009));	
                    $ret .= '</td>';	 

                    $ret .= '<td>';
                    if(intval($row->slot_length) == $row->slot_length)
                    {
                            $ret .= date('h:i:s A',mktime(intval(substr($row->slot_start_time,0,2)) + intval($row->slot_length),substr($row->slot_start_time,3,2),0,1,1,2009));	
                    }
                    else
                    {			
                            if(substr($row->slot_start_time ,3,2) == '00')
                            { 
                                    $ret .= date('h:i:s A',mktime(intval(substr($row->slot_start_time,0,2)) + intval($row->slot_length),30,0,1,1,2009));	
                            }
                            else
                            {
                                    $ret .= date('h:i:s A',mktime(intval(substr($row->slot_start_time,0,2)) + intval($row->slot_length) + 1,0,0,1,1,2009));	
                            } 	 	
                    }  
                    $ret .= '</td>';	  

                    $ret .= '<td>';
                    $ret .= $row->slot_length;	
                    $ret .= '</td>';	                                          
                    $ret .= '<td align="center">';
                    if($edit===TRUE){
                        $ret .= '<input type="checkbox" id="remove'.$row->slot_id.'" name="remove'.$row->slot_id.'"  onclick="slot_rem('.$row->slot_id.",'".$chkdelaction."'".');" />';	
                    }
                    $ret .= '</td>';	                                          
                    $ret .= '</tr>';
                    $sl = $row->slot_length;
                }
        } 

        $ret .= '</table>';  
        $ret .= '</div>'; 
        return $ret; 
    }  
		
		
		//---------------------------------------------------
		//
		//  
		//
		//--------------------------------------------------- 
		public function new_slot_data($p, $slotid=0){
                    $ret = ($slotid == 0) ? $this->save_new_slot($p) : $this->updateSlotData($p, $slotid);  
                    return $ret;		
		}
		//---------------------------------------------------
		//
		//  
		//
		//--------------------------------------------------- 
		public function save_new_slot($p, $conid=0){
                    $ci=&get_instance();
                    if($conid!==0){
                        $this->initialize($conid);
                    }
                    
                    $sdate = new Time(trim($p["slot_date"]));
                    $sday = $sdate->format('l');
                    $ins = 'INSERT INTO ogre_gameslots ';
                    $ins .= '(slot_conid, ';
                    $ins .= 'slot_date, ';
                    $ins .= 'slot_day, ';
                    $ins .= 'slot_start_time, ';
                    $ins .= 'slot_length, ';
                    $ins .= 'slot_time, ';
                    $ins .= 'slot_number, ';
                    $ins .= 'slot_baseslot, ';
                    $ins .= 'slot_rpga_number, '; 
                    $ins .= 'slot_latenight, ';     
                    $ins .= 'slot_RPGA, ';
                    $ins .= 'slot_code) '; 
                    
                    $ins .= 'VALUES (';
                    
                    $slate = !isset($p["slot_latenight"]) ? '0' : (is_numeric($p["slot_latenight"]) ? $p["slot_latenight"] : '1');  
                    $hr = $this->process_hour($p["slot_start_time_hour"],$p["slot_start_time_min"],$p["slot_start_time_AMPM"]);
                    $start =  str_pad($hr,2,'0',STR_PAD_LEFT) . substr($p["slot_start_time_min"],0,1);
                    
                    $ins .= '' . $p["conid"] . ', ';
                    $ins .= '"' . $sdate->format('Y-m-d') . '", ';
                    $ins .= '"' . $sday  . '", ';
                    $ins .= $this->process_starttime($p["slot_start_time_hour"],$p["slot_start_time_min"],$p["slot_start_time_AMPM"]);
                    $ins .= '' . $p["slot_length"] . ', ';
                    $ins .= '"' . $this->genSlotTime($p, $hr) . '", '; 
                    $ins .= '"' . $p["slot_number"] . '", ';
                    $ins .= (isset($p["slot_RPGA"]) ? '1' : '0') . ', ';
                    $ins .= $p["slot_rpga_number"] . ', ';
                    $ins .= $slate . ', ';                   
                    $ins .= (isset($p["slot_RPGA"]) ? '1' : '0') . ', ';
                    $ins .= $this->genSlotCode($sday, $start, $p["slot_length"], $p["slot_rpga_number"], $slate);
                    $ins .= ')';
                    
                    $ci->db->query($ins);
                    $ret = ($ci->db->affectedRows() > 0)?TRUE:FALSE;		
                    return $ret;  
		
		}
    //---------------------------------------------------
    //
    //  
    //
    //---------------------------------------------------                 
    public function process_starttime($slot_start_time_hour, $slot_start_time_min, $slot_start_time_AMPM){
        $ins = '';
        if($slot_start_time_AMPM == 'AM'){
            $hr =  (intval($slot_start_time_hour) != 12) ?  intval($slot_start_time_hour) :  intval($slot_start_time_hour) - 12;	 
            $ins .= '"' . $hr . ':' . $slot_start_time_min . ':00 ' . '", ';
        }
        else{
            $hr = (intval($slot_start_time_hour) != 12) ?  intval($slot_start_time_hour) + 12 : intval($slot_start_time_hour);
            $ins .= '"' . $hr . ':' . $slot_start_time_min . ':00 ' . '", ';
        }
        return $ins;
    } 
    //---------------------------------------------------
    //
    //  
    //
    //---------------------------------------------------                 
    public function process_hour($slot_start_time_hour, $slot_start_time_min, $slot_start_time_AMPM){
        if ($slot_start_time_AMPM === 'AM'){
            $hr = intval($slot_start_time_hour);
        }
        else {
            $hr = intval($slot_start_time_hour) + 12;
        }       
        return $hr;
    }            
    
    //---------------------------------------------------
    //
    //--------------------------------------------------- 
    public function genSlotTime($p, $hr){
        date_default_timezone_set("America/New_York");
        $sdate1 = new Time(trim($p["slot_date"]) . ' ' . $hr . ':' . trim($p["slot_start_time_min"]) . ':00 ');
        $stime1 = $sdate1->format('g:i A');
        $lenarr = explode('.',$p["slot_length"]);
        $sdate1->modify('+' . $lenarr[0] . ' hour');
        if (count($lenarr) > 1){
                $sdate1->modify('+30 minute'); 	
        }
        $etime1 = $sdate1->format('g:i A');
        return $stime1 . '-' . $etime1;
    }
    
    //--------------------------------------------------- 
    //
    //--------------------------------------------------- 
    public function makeSlotTime($sd, $st, $length){
        date_default_timezone_set("America/New_York");
        $sdate1 = new Time(trim($sd) . ' ' . trim($st));
        $stime1 = $sdate1->format('g:i A');
        $lenarr = explode('.',$length);
        $sdate1->modify('+' . $lenarr[0] . ' hour');
        if ($lenarr[1] !=0){
                $sdate1->modify('+30 minute'); 	
        }
        $etime1 = $sdate1->format('g:i A');
        return $stime1 . '-' . $etime1;
    }    
//---------------------------------------------------
//
//---------------------------------------------------  
    public function updateSlotData($p, $slotid){
            $ci=&get_instance();

            $sdate = new Time(trim($p["slot_date"]));

            $sday = $sdate->format('l');			

            $ins = 'UPDATE ogre_gameslots SET ';
            $ins .= 'slot_date ="' . trim($p["slot_date"]) . '", ';
            $ins .= 'slot_day="' . $sday  . '", ';
            $ins .= 'slot_start_time =' ;

            if($p["slot_start_time_AMPM"] == 'AM'){
                    if (intval($p["slot_start_time_hour"]) != 12){
                            $hr = intval($p["slot_start_time_hour"]);
                    }
                    else{
                            $hr = intval($p["slot_start_time_hour"]) - 12;
                    }	 	  
            }
            else{
                    if (intval($p["slot_start_time_hour"]) != 12){
                            $hr = intval($p["slot_start_time_hour"]) + 12;
                    }
                    else{
                            $hr = intval($p["slot_start_time_hour"]);
                    }	 
            }	 
            $start =  str_pad($hr,2,'0',STR_PAD_LEFT) . substr($p["slot_start_time_min"],0,1);
            $ins .= '"' . $hr . ':' . $p["slot_start_time_min"] . ':00 ' ;	
            $ins .= '", ';
            $ins .= 'slot_length =' . $p["slot_length"] . ', ';

            $ins .= 'slot_time="' . $this->genSlotTime($p, $hr) . '", ';  
            $ins .= 'slot_rpga_number=' . $p["slot_rpga_number"] . ', '; 
            $ins .= 'slot_latenight=' ;
            $ins .= (isset($p["slot_latenight"]) ? '1' : '0') .', ';
            if(isset($p["slot_latenight"])){
                $slate = 1;
            }  
            else{
                $slate = 0;
            } 
            $ins .= 'slot_baseslot=' . (isset($p["slot_RPGA"]) ? '1' : '0').', ';
            $ins .= 'slot_RPGA=' . (isset($p["slot_RPGA"]) ? '1' : '0').', ';	 				
            $ins .= 'slot_code = "' . $this->genSlotCode($sday, $start, $p["slot_length"], $p["slot_rpga_number"], $slate). '" ';
            $ins .= 'WHERE slot_id = ' . $slotid . ';';

            $ci->db->query($ins);

            $ret = ($ci->db->affectedRows() > 0)?TRUE:FALSE;

            return $ret; 
    } 
//---------------------------------------------------
//
//---------------------------------------------------  
    public function opSlotNumberSelect($n, $id=0){ 
        $days = $this->dateArray();
        $nod = count($days);
        $x = $this->getMaxSlots();
        $maxslots = $x * $nod;
        $ret = '<select class="form-select" id="' . $n . '" name="' . $n . '" size="1">';
        $ret .= '<option value="0" selected="selected">';
        $ret .= '-';
        $ret .= '</option>';
        for ($i = 1; $i <= intval($maxslots); $i++){
            if($i==$id){ 
                    $ret .= '<option value="' . $i . '" selected="selected">  ';
                    $ret .= $i;
                    $ret .= '  </option>';
            } 
            else{ 
                    $ret .= '<option value="' . $i . '">  ';
                    $ret .= $i;
                    $ret .= '  </option>';
            } 
        }
        $ret .= '</select>';
        return $ret;
    }
                
//---------------------------------------------------
//
//---------------------------------------------------                 
    public function getMaxSlots($sl=0){
        $ci = &get_instance();
        if(intval($sl)==0){
            $sql="SELECT Max(ogre_optablecolcount.tcc_colcount) AS MaxOftcc_colcount FROM ogre_optablecolcount";
            $query = $ci->db->query($sql);
            $ret = 1;
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){                        
                    $ret = $row->MaxOftcc_colcount;
                }
            }
        }
        else{
            $sql = 'SELECT ogre_optablecolcount.tcc_colcount ';
            $sql .= ' FROM ogre_optablecolcount';
            $sql .= ' WHERE tcc_slotlength=' . $sl;
            $query = $ci->db->query($sql);
            $ret = 1;
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){                        
                    $ret = $row->tcc_colcount;
                }
            }                        
        }
        return $ret;
    }
                
//---------------------------------------------------
//
//---------------------------------------------------                 
    public function getMaxSlotNum($sl=4){
         $ci = &get_instance();    
        $sql='SELECT Max(ogre_gameslots.slot_rpga_number) AS Maxcolcount FROM ogre_gameslots ';
        $sql.=' WHERE slot_length = ' . $sl;
        $query = $ci->db->query($sql);
        $ret = 1;
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){                        
                $ret = $row->Maxcolcount;
            }
         }    
        return $ret;
    }
                
//---------------------------------------------------
// # ### ### ###
// 1  2   3  4
// 1 = DAY - Ordinal digit of the day of the con. 1 = first day, 2 = second day, ...
// 2 = START TIME - first three digits of the 24 hour time
// 3 = SLOT LENGTH - 2 digit hours and 1 digit minutes (0 or 3)
// -x- 4 = RPGA Slot = 10 is Slot 1, 20 is Slot 2, 25 is Slot 2MM, etc
// 4 = RPGA Slot = 010 is Slot 1, 020 is Slot 2, 025 is Slot 2MM, etc  .
// 2016/03/30 - EXPAND SLOT CODE TO 10 DIGITS
//---------------------------------------------------  
    public function genSlotCode($day, $st, $sl, $rpga=0, $late=0){
       $ci = &get_instance();
       var_dump($day . ' ' .$st . ' ' .$sl . ' ' .$rpga . ' ' .$late);
       if($this->conid == 0 ){
           $conid = $ci->session->get('ogre_conid');
           $this->initialize($conid);
       }
       $days = $this->dayArray();
       $dayint = array_search($day, $days);
       $strtm = str_pad($st,3,'0');			
       if($strtm == '000'){
               $strtm = '240';
               $dayint = intval($dayint) - 1;
       }
       $slarry = explode('.',$sl);
       $sltlen1 = (count($slarry) > 1) ? $slarry[0] . $slarry[1]: $slarry[0] . '0'; 
       $sltlen = str_pad($sltlen1,3,'0',STR_PAD_LEFT);
       $rpgadig=str_pad($rpga, 2, "0", STR_PAD_LEFT);
       if(strlen($rpga) <= 2){
           $rpgadig .= ($late != 0) ? '5' : '0';
       }
       return 	$dayint . $strtm . $sltlen . $rpgadig;   
    }	
//---------------------------------------------------
//
//---------------------------------------------------
    public function opSlotExists($snum,$late,$length=4){
        $ci=&get_instance();
        $qry = 'SELECT * FROM ogre_gameslots WHERE slot_conid = ';
        $qry .= $this->conid . ' AND slot_rpga_number = ' . $snum;
        $qry .= ' AND slot_length = ' . $length .' ';
        $qry .= ' AND slot_latenight = ' . $late .' ;';
        $query = $ci->db->query($qry);
        $ret = ($query->getNumRows() > 0) ?  TRUE : FALSE;
        return $ret;  
    }  

//---------------------------------------------------
//
//---------------------------------------------------
    public function slotNumberExists($snum){
        $ci=&get_instance();
        $qry = 'SELECT * FROM ogre_gameslots ';
        $qry .= ' WHERE slot_conid = ' . $this->conid;
        $qry .= ' AND slot_number = "' . $snum .'" ;';
        $query = $ci->db->query($qry);
        $ret = ($query->getNumRows() > 0)? TRUE : FALSE;
        return $ret;   
    }  

//---------------------------------------------------
//
//---------------------------------------------------
    public function removeSlot($sid){
        $ci=&get_instance();
        $del = 'DELETE FROM ogre_gameslots WHERE slot_id = ' . $sid .' ;';
        $ci->db->query($del);
        $ret = ($ci->db->affectedRows() > 0)?TRUE:FALSE;
        return $ret;   
    }             
//------------------------
//
//------------------------  
    public function buildOPSlotArray($late=0, $sl=4){ 			
        $ci=get_instance();
        $aryRPGASlots = array();
        $qry = "SELECT * ";
        $qry .= " FROM ogre_gameslots";
        $qry .= " WHERE ogre_gameslots.slot_RPGA = 1 ";
        $qry .= " AND ogre_gameslots.slot_conid =  " . $this->conid;
        $qry .= " AND ogre_gameslots.slot_length =  " . $sl;
        $qry .= ($late >= 0) ? " AND ogre_gameslots.slot_latenight = " . $late : '';
        $qry .= " AND slot_conid = " . $this->conid;
        $qry .= " ORDER BY ogre_gameslots.slot_code;";
        $query = $ci->db->query($qry);  
        $i = 1;
        $aryRPGASlots[1][1] = '';
        $tmpday = '';
        $enum = 0;  

        if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                    $aryRPGASlots[$i][0] =  "Slot " . $row->slot_rpga_number . ": " . $row->slot_time;   
                    $aryRPGASlots[$i][1] =  "Session " . $row->slot_rpga_number . ": " . $row->slot_time;
                    $aryRPGASlots[$i][2] =  $row->slot_code;
                    $aryRPGASlots[$i][3] =  $row->slot_time;
                    $aryRPGASlots[$i][4] =  $row->slot_start_time;
                    $aryRPGASlots[$i][5] =  $row->slot_length;	  
                    $aryRPGASlots[$i][6] =  $row->slot_number;	
                    $aryRPGASlots[$i][7] =  $row->slot_latenight;	 
                    $aryRPGASlots[$i][8] =  $row->slot_day;
                    if($tmpday != $row->slot_day){
                            $tmpday = $row->slot_day;
                            $enum = 1;
                    }
                    else{
                            $enum++;
                    }	       			
                    $aryRPGASlots[$i][9] =  $enum;				
                    $aryRPGASlots[$i][10] = $this->getHighestRoweNum($row->slot_code); 
                    $aryRPGASlots[$i][11] = $row->slot_date;
                    $aryRPGASlots[$i][12] = $row->slot_baseslot;
                    $i++;
                }
        }
        return $aryRPGASlots; 	
    }   
//------------------------
//
//------------------------  
    public function getHighestRoweNum($slotcode){
        $ci=&get_instance();

        $rnum = 0;
            $qry = 'SELECT ogre_gameschedule.gs_row_enum ';
            $qry .= ' FROM ogre_gameschedule ';
            $qry .= ' WHERE  gs_row_enum <> 0 ';
            $qry .= ' AND ogre_gameschedule.gs_slot_code ="' . $slotcode . '" ';
            $qry .= ' AND ogre_gameschedule.gs_convention_id =' . $this->conid . ' ';
            $qry .= ' ORDER BY ogre_gameschedule.gs_row_enum DESC LIMIT 1;';
            $query = $ci->db->query($qry);  

            if ($query->getNumRows() > 0){
                    foreach ($query->getResult() as $row){
                            $rnum = $row->gs_row_enum;
                    }
            }
            return $rnum; 
    } 
//------------------------
//
//------------------------  
    public function slot_array_search($slots, $slot){
        $index = 0;
        for ($j = 1; $j <= count($slots); $j++){
            if ($slots[$j][2] == $slot){
                    $index = $j;
            }
        }
        return $index; 
    }  
//***********************************
//
//***********************************
    public function gameBaseSlotSelect($selval=0) {
        $ci=&get_instance();

        $qry ='SELECT * FROM ogre_gameslots  ';
            $qry .= ' WHERE slot_conid = ' . $this->conid;
            $qry .= ' ORDER BY slot_code';


            $query = $ci->db->query($qry);
            $ret = '<option value="0">-</option>';		 
            if ($query->getNumRows() > 0)
            {			
                    foreach ($query->getResult() as $row)
                    {
                            if($row->slot_code == $selval)
                            {
                                $ret .= '<option value="'. $row->slot_id . '" selected="selected">' .$row->slot_day. ': ' . $row->slot_time . '</option>';
                            }
                            else
                            {
                                $ret .= '<option value="'. $row->slot_id . '">' . $row->slot_day. ': ' . $row->slot_time . '</option>';
                            }
                    }
            }

            return $ret;	 
    }	
//***********************************
//
//***********************************
    public function gameTableSelect($selval=0){
        $ci=&get_instance();
        $qry ='SELECT * FROM ogre_tables, ogre_location  ';
            $qry .= ' WHERE ogre_tables.tbl_locationid = ogre_location.loc_locationid ';
            $qry .= ' AND loc_con_id = ' . $this->conid;
            $qry .= ' ORDER BY tbl_number';
            $query = $ci->db->query($qry);
            $ret = '<option value="0">-</option>';		 
            if ($query->getNumRows() > 0){			
                    foreach ($query->getResult() as $row)
                    {
                            if($row->tbl_id == $selval)
                            {
                                    $ret .= '<option value="'. $row->tbl_id . '" selected="selected">' . $row->loc_table_prefix . '-'.  $row->tbl_number . '( ' . $row->loc_location_name . ')</option>';
                            }
                            else
                            {
                                    $ret .= '<option value="'. $row->tbl_id . '">'  . $row->loc_table_prefix . '-'.  $row->tbl_number . '( ' . $row->loc_location_name . ')</option>';
                            }
                    }
            }
            return $ret;
    }	
//***********************************
//
//***********************************
    public function getScenarioSelect($conid, $n, $aff='', $scenid=0){		
        $ci=&get_instance();                   
        $qry = 'SELECT ogre_rpga_scenario_setup.rss_scenario_name, ';
        $qry .= ' ogre_rpga_scenario_setup.rss_scenario_id, ';
        $qry .= ' ogre_rpga_scenario_setup.rss_number_of_slots, ';
        $qry .= ' ogre_rpga_scenario_setup.rss_campaign_id, ';
        $qry .= ' ogre_rpga_scenario_setup.rss_affiliation  ';
        $qry .= ' FROM ogre_rpga_scenario_setup ';
        $qry .= ' WHERE ogre_rpga_scenario_setup.rss_convention_id =' . $conid;
        if(($aff!=='') && ($aff!=='0')){
            $qry .= ' AND ogre_rpga_scenario_setup.rss_affiliation = "'.$aff.'" ';
        }
        $qry .= ' AND ogre_rpga_scenario_setup.rss_deleteflag = 0 ';
        $qry .= ' ORDER BY ogre_rpga_scenario_setup.rss_affiliation, ogre_rpga_scenario_setup.rss_scenario_name';	

        $query = $ci->db->query($qry);	
        $ret = '<select class="form-control m-2" id="'. $n . '" name="'. $n . '">';
        $ret .= '<option value="0">(scenario title)</option>';
        if ($query->getNumRows() > 0){			
            foreach ($query->getResult() as $row){
                $ci->game->init($row->rss_campaign_id);
                $ret .= ($scenid == $row->rss_scenario_id) ?  '<option value="' . $row->rss_scenario_id . '" selected="selected">' . $row->rss_scenario_name . ' (' . $ci->game->game_affiliation  . ')' . ' [' . $row->rss_number_of_slots  . ']</option>' :  '<option value="' . $row->rss_scenario_id . '">' . $row->rss_scenario_name . ' (' . $ci->game->game_affiliation  . ')' . ' [' . $row->rss_number_of_slots  . ']</option>';
            } 
        }				
            $ret .= '</select>';			
        return $ret; 	
    } 
		
//---------------------------------------------------
// E-MAIL HEADER
//---------------------------------------------------
    public function getEmailHeader($conid){ 			
        $msg = '-------------------------------------------------------------------------- <br /><br />';
        $msg .= $this->name . '<br />';
        $msg .= $this->getConDates() . '<br />';
        $msg .= $this->website . '<br />';
        $msg .= '-------------------------------------------------------------------------- <br /><br />';	
        return $msg;  
    }
//---------------------------------------------------
// E-MAIL FOOTER
//---------------------------------------------------
    public function getEmailFooter($conid){
            $msg = '--------------------------------------------------------------------------<br />';
            $msg .= 'Gaming Coordinator<br />';
            $msg .= $this->gamingcoordinatoremail . '<br />';			
            $msg .= $this->name . '<br />';
            $msg .= $this->website . '<br />';
            $msg .= '--------------------------------------------------------------------------<br />';
            return $msg; 
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function timeSelectHour($n, $time=''){
        if($time == '00'){
            $time = '12';
        }
        $ret = '<select class="form-select" style="#'.$n.':first-child{color:gray;}" id="' . $n . '" name="' . $n . '" size="1">';
        $ret .= '<option hidden="hidden" value="0">HR</option>';
        for ($i = 1; $i <= 12; $i++){
            if (str_pad($i,2,'0',STR_PAD_LEFT) == $time){
                $ret .= '<option value="' . str_pad($i,2,'0',STR_PAD_LEFT)  . '" selected="selected">  ';
                $ret .= str_pad($i,2,'0',STR_PAD_LEFT);
                $ret .= '  </option>';
            }
            elseif ($i + 12 == $time){
                $ret .= '  <option value="' . str_pad($i,2,'0',STR_PAD_LEFT)  . '" selected="selected">';
                $ret .= str_pad($i,2,'0',STR_PAD_LEFT);
                $ret .= '  </option>';
            }
            else{
                $ret .= '  <option value="' . str_pad($i,2,'0',STR_PAD_LEFT)  . '">';
                $ret .= str_pad($i,2,'0',STR_PAD_LEFT);
                $ret .= '  </option>';
            }
        }
        $ret .= '</select>';
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function timeSelectMin($n, $time=''){
        $ret = '<select class="form-select" id="' . $n . '" name="' . $n . '" size="1">';
        $ret .= '<option value="" hidden="hidden">MIN</option>';
        for ($i = 0; $i <= 3; $i++){
            $t = ($i * 15);
            if (str_pad($t,2,'0',STR_PAD_LEFT) == $time){
                $ret .= '<option value="' . str_pad($t,2,'0',STR_PAD_LEFT)  . '" selected="selected">';
                $ret .= str_pad($t,2,'0',STR_PAD_LEFT);
                $ret .= '</option>';
            }
            else{
                $ret .= '<option value="' . str_pad($t,2,'0',STR_PAD_LEFT)  . '">';
                $ret .= str_pad($t,2,'0',STR_PAD_LEFT);
                $ret .= '</option>';
            }
        }
        $ret .= '</select>';
        return $ret;
    }

//---------------------------------------------------
//
//---------------------------------------------------
    public function timeSelectAMPM($n, $time=''){
        $ret = '<select class="form-select" id="' . $n . '" name="' . $n . '" size="1">';
        $ret .= '<option value="0" hidden="hidden">AM/PM</option>';
        if ($time == 'AM' || $time=='0'){
            $ret .= '<option value="AM" selected="selected">';
            $ret .= 'AM';
            $ret .= '</option>';
            $ret .= '<option value="PM">';
            $ret .= 'PM';
            $ret .= '</option>';
        }
        elseif($time == 'PM'){
            $ret .= '<option value="AM">';
            $ret .= 'AM';
            $ret .= '</option>';
            $ret .= '<option value="PM" selected="selected">';
            $ret .= 'PM';
            $ret .= '</option>';
        }
        else{
            $ret .= '<option value="AM" >';
            $ret .= 'AM';
            $ret .= '</option>';
            $ret .= '<option value="PM">';
            $ret .= 'PM';
            $ret .= '</option>';
        }
        $ret .= '</select>';

        return $ret;
    }
//***********************************
//
//***********************************
    public function timeSelectBootGroup($lbl, $hrName,$minName,$ampmName){
        $ci = &get_instance();
        $ret = '';
        $ret .= '<div class="form-group my-1">';
        $ret .= '<div class="input-group my-1">';
        $ret .= '<label class="form-label" for="'.$hrName.'">'.$lbl.'</label>';
        $ret .= str_replace('<select', '<select class="form-control"', $this->timeSelectHour($hrName));
        $ret .= str_replace('<select', '<select class="form-control"', $this->timeSelectMin($minName));
        $ret .= str_replace('<select', '<select class="form-control"', $this->timeSelectAMPM($ampmName));
        $ret .= '</div>';
        $ret .= '</div>';     
        return $ret;
    }
//***********************************
//
//***********************************
    public function conventionSelect($selval=0, $oid=0){
        $ci=&get_instance();
        $orgid = $ci->session->ogre_orgid;
//            $conid = $ci->session->ogre_conid;
        $qry ='SELECT * FROM ogre_convention WHERE con_start_date >= NOW() AND con_org_id = '. $orgid;
        $ret = '';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $ret .= ($row->con_id == $selval) ? '<option value="'. $row->con_id . '" selected="selected">' . $row->con_name . '</option>' : '<option value="'. $row->con_id . '">' . $row->con_name . '</option>';
            }
        }
        return $ret;
    }
//***********************************
//
//***********************************
    public function isGamePreregOpen($conid=0){
        $ci=&get_instance();
        $conid = ($conid==0)? $ci->session->get('ogre_conid') : $conid;
        $this->initialize($conid);
        $ret = TRUE;
        $qry = 'SELECT con_id "';
        $qry .= 'FROM ogre_convention ';
        $qry .= 'WHERE ogre_convention.con_end_date < NOW() ';
        $qry .= 'AND ogre_convention.con_id = ' .  $conid;
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            $ret = FALSE;
        }else{
            $qry = 'SELECT con_id "';
            $qry .= 'FROM ogre_convention ';
            $qry .= 'WHERE DATE_ADD(ogre_convention.con_gaming_reg_open_date, INTERVAL -5 HOUR) > NOW() ';
            $qry .= 'AND ogre_convention.con_id = ' .  $conid;
            $query = $ci->db->query($qry);
            $ret = ($query->getNumRows() > 0) ? FALSE : TRUE;
        }	           
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getConfigKey($key, $conid=0, $orgid=0){

            $ci=&get_instance();
            $qry= 'SELECT * FROM ogre_config WHERE cfg_param_name="' . $key . '"';
            $ret='';
            $qry .= ($orgid!=0) ? ' AND cfg_orgid = ' . $orgid : '';               
            $qry .= ($conid!=0) ? ' AND cfg_conid = ' . $conid : '';
            $query = $ci->db->query($qry);
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                        $ret .= $row->cfg_param_value;
                }
            }
            else{
                $ret='-1'; 
            }
            return $ret;
        }  
//---------------------------------------------------
//
//---------------------------------------------------
        public function gameRegIsClosed($conid=0){
            $ci = &get_instance();
            if($conid!==0){
                $this->init($conid);
            }
            $now_date = new Time();
            $end_date = $ci->ogre_lib->getConGamingInfoKey($conid,'con_end_date');
            $close_date = new Time($end_date);
            $start_date = $ci->ogre_lib->getConGamingInfoKey($conid,'con_gaming_reg_open_date');
            $open_date = new Time($start_date);
            $ret = FALSE;
            if($now_date->format("U") > $close_date->format("U")){
                $ret = 1;
            }
            elseif($now_date->format("U") < $open_date->format("U")){	
                $ret = -1;
            }else{
                $ret = 0;
            }
            return $ret;
        }           
//---------------------------------------------------
//
//---------------------------------------------------
    public function isOnsite(){
        $ci = &get_instance();
        if(intval($this->conid) == 0){
            $conid = $ci->session->ogre_conid;
            $this->initialize($conid);
        }else{
            $conid = $this->conid;
        }
        $ret = FALSE;
        $ci=&get_instance();
        $qry= 'SELECT con_id FROM ogre_convention ';
        $qry .= ' WHERE con_start_date <= NOW() ';
        $qry .= ' AND con_end_date >= NOW() ';
        $qry .= ' AND con_id = ' .  $conid; 

        $query = $ci->db->query($qry);
        $ret = ($query->getNumRows() > 0) ? TRUE : FALSE;
        return $ret;        
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function isOpen($conid=0){
        $ci = &get_instance();
        $conid = ($conid==0)? $ci->session->get('ogre_conid') : $conid;
        $qry = 'SELECT con_id FROM ogre_convention WHERE con_gaming_reg_open_date <= NOW() AND con_gaming_reg_close_date >= NOW() AND con_id = :conid:'; 
        $query = $ci->db->query($qry,['conid' => $conid]);
        $x = $query->getNumRows();
        $ret = ($x > 0) ? TRUE : FALSE;
        return $ret;
    }      
        //---------------------------------------------------
        //
        //---------------------------------------------------
        public function isClosed($conid=0){
            $ci=&get_instance();
            $conid = ($conid==0)? $ci->session->get('ogre_conid') : $conid;
            $qry= 'SELECT con_id FROM ogre_convention WHERE con_gaming_reg_close_date <= NOW() AND con_id = :conid:';
            $query = $ci->db->query($qry,["conid" => $conid]);
            $x = $query->getNumRows();
            $ret = ($x > 0) ? TRUE : FALSE;
            return $ret;
        }      
        //---------------------------------------------------
        //
        //
        //
        //---------------------------------------------------
        public function isCutoff($conid=0){
            //con_gaming_reg_close_date
                $ci=&get_instance();
                $conid = ($conid==0)? $ci->session->get('ogre_conid') : $conid;
                $qry= 'SELECT con_id FROM ogre_convention ';
                $qry .= ' WHERE con_gaming_reg_close_date <= NOW() ';
                $qry .= ' AND con_end_date >= NOW() ';
                $qry .= ' AND con_id = ' .  $conid; 
                $query = $ci->db->query($qry);
                $ret = ($query->getNumRows() > 0) ? TRUE : FALSE;
                return $ret;
            }      
            
        //---------------------------------------------------
        //
        //
        //
        //---------------------------------------------------
        public function isBefore($conid = 0){
            //con_gaming_reg_open_date
                $ci=&get_instance();
                $conid = ($conid==0)? $ci->session->get('ogre_conid') : $conid;
                $qry= 'SELECT con_id FROM ogre_convention WHERE con_gaming_reg_open_date > NOW() AND con_id = :conid:'; 
                $query = $ci->db->query($qry,["conid" => $conid]);
                $x = $query->getNumRows();
                $ret = ($x > 0) ? TRUE : FALSE;
                return $ret;
            }                  
//---------------------------------------------------
//
//---------------------------------------------------
    public function isRegConnected($conid=0){
            $ci=&get_instance();
            $conid = ($conid==0)? $ci->session->get('ogre_conid') : $conid;
            $key = 'OGRE.ACTIVATION.MODE';      
            $activationmode = $this->getConfigKey($key, $conid);
            $ret = (intval($activationmode) != 2) ? TRUE : FALSE;
            return $ret;
    }          
//***********************************
//
//***********************************
    public function getConventionForm($cid=0){
        $ci = &get_instance();
        $yr = date("Y");
        $ret = '';
        if (intval($cid) > 0){
            $this->init($cid);
        }
        $ret .= ((intval($cid) > 0) ? '<h2>Convention: Edit</h2>' : '<h2>Convention: Add</h2>');
        $ret .= '<form name="convention-form" id="convention-form">';
        $ret .= '<label for="con_name">Con Name*</label>';
        $ret .= (intval($cid) <= 0) ? '<input name="con_name" id="con_name" type="text" class="form-control" />' :  '<input name="con_name" id="con_name" type="text" class="form-control" value="' . $this->name . '" />';             
        $ret .= '<label>Con Year</label>';
        $ret .= (intval($cid) <= 0) ? '<input name="con_year" type="text" class="form-control" value="' . $yr . '" />':'<input name="con_year" type="text" class="form-control" value="' . $this->year . '" />';             
        $ret .= '<label for="con_start_date_month">Con Start Date</label>';
        $ret .= '<div class="input-group mb-3">';
        if (intval($cid) <= 0){
            $ret .= $ci->admin_lib->datePartSelect("m", 'con_start_date_month');
            $ret .= $ci->admin_lib->datePartSelect("d", 'con_start_date_day');
            $ret .= $ci->admin_lib->datePartSelect("y", 'con_start_date_year', $yr);
        }
        else{
            $sdate = $this->parse_date($this->start_date);
            $ret .= $ci->admin_lib->datePartSelect("m",'con_start_date_month', $sdate[2]);
            $ret .= $ci->admin_lib->datePartSelect("d",'con_start_date_day', $sdate[3]);
            $ret .= $ci->admin_lib->datePartSelect("y",'con_start_date_year', $sdate[1]);
        }
        $ret .= '</div>';
        $ret .= '<label for="con_start_time">Con Start Time</label>';
        $ret .= (intval($cid) <= 0) ? $ci->admin_lib->timeSelect('con_start_time') :  $ci->admin_lib->timeSelect('con_start_time', $this->start_time);
        $ret .= '<label for="con_end_date_month">Con End Date</label>';
        $ret .= '<div class="input-group mb-3">';
        if (intval($cid) <= 0){
            $ret .= $ci->admin_lib->datePartSelect("m",'con_end_date_month');
            $ret .= $ci->admin_lib->datePartSelect("d",'con_end_date_day');
            $ret .= $ci->admin_lib->datePartSelect("y",'con_end_date_year', $yr);
        }
        else{
            $sdate = $this->parse_date($this->end_date);
            $ret .= $ci->admin_lib->datePartSelect("m",'con_end_date_month',$sdate[2]);
            $ret .= $ci->admin_lib->datePartSelect("d",'con_end_date_day',$sdate[3]);
            $ret .= $ci->admin_lib->datePartSelect("y",'con_end_date_year',$sdate[1]);
        }
        $ret .= '</div>';
        $ret .= '<label for="con_end_time">Con End Time</label>';
        $ret .= (intval($cid) <= 0) ? $ci->admin_lib->timeSelect('con_end_time'):  $ci->admin_lib->timeSelect('con_end_time', $this->end_time);
        $ret .= '<label for="con_logo_img">Con Logo Image</label>';
        $ret .= (intval($cid) <= 0) ? '<input name="con_logo_img" type="text" class="form-control" />': '<input name="con_logo_img" type="text" class="form-control" value="' . $this->logo_img . '" />';
        $ret .= '<label for="con_location">Con Location/Hotel</label>';
        $ret .= (intval($cid) <= 0) ? '<input name="con_location" type="text" class="form-control" />':'<input name="con_location" type="text" class="form-control" value="' . $this->location . '" />';
        $ret .= '<label for="con_loc_address">Con Location Address</label>';
        $ret .= (intval($cid) <= 0) ? '<input name="con_loc_address" type="text" class="form-control" />' : '<input name="con_loc_address" type="text" class="form-control" value="' . $this->loc_address . '" />';
        $ret .= '<label for="con_loc_city">Con Location City</label>';
        $ret .= (intval($cid) <= 0) ?'<input name="con_loc_city" type="text" class="form-control" />':'<input name="con_loc_city" type="text" class="form-control" value="' . $this->loc_city . '" />';               
        $ret .= '<label for="con_loc_state">Con Location State</label>';
        $ret .= (intval($cid) <= 0) ? '<input name="con_loc_state" type="text" class="form-control" size="4" maxlength="2"  />':'<input name="con_loc_state" type="text" class="form-control" value="' . $this->loc_state . '" size="4" maxlength="2"  />';
        $ret .= '<label for="con_loc_zip">Con Location Zip</label>';
        $ret .= (intval($cid) <= 0) ? '<input name="con_loc_zip" type="text" class="form-control"  />' : '<input name="con_loc_zip" type="text" class="form-control" value="' . $this->loc_zip . '"   />';
        $ret .= '<label for="con_loc_phone">Con Location Phone</label>';
        $ret .= (intval($cid) <= 0) ? '<input name="con_loc_phone" type="text" class="form-control"  />' : '<input name="con_loc_phone" type="text" class="form-control" value="' . $this->loc_phone . '"   />';
        $ret .= '<label for="con_loc_website">Con Location Website</label>';
        $ret .= (intval($cid) <= 0) ?  '<input name="con_loc_website" type="text" class="form-control"  />': '<input name="con_loc_website" type="text" class="form-control" value="' . $this->loc_website . '"   />';
        $ret .= '<label for="con_website">Con Web Site</label>';
        $ret .= (intval($cid) <= 0) ?  '<input name="con_website" type="text" class="form-control" />' : '<input name="con_website" type="text" class="form-control" value="' . $this->website . '" />';
        $ret .= '<label for="con_eventhomepage">Con Homepage File</label>';
        $ret .= (intval($cid) <= 0) ?  '<input name="con_eventhomepage" type="text" class="form-control" />': '<input name="con_eventhomepage" type="text" class="form-control" value="' . $this->eventhomepage . '" />';              
        $ret .= '<label for="con_eventtype">Con Event Type</label>';
        if (intval($cid) <= 0){
            $ret .= '<select class="form-select" name="con_eventtype" size="1"><option value="day">Day</option><option value="weekend" selected="selected">Weekend</option></select>';
        }
        else{
            if ($this->eventtype == 'day'){
                $ret .= '<select class="form-select" name="con_eventtype" size="1"><option value="day" selected="selected">Day</option><option value="weekend">Weekend</option></select>';
            }
            else{
                $ret .= '<select class="form-select" name="con_eventtype" size="1"><option value="day">Day</option><option value="weekend" selected="selected">Weekend</option></select>';
            }
        }
        $ret .= '<label for="gpopen_month">Gaming Prereg Open Date (mm/dd/yyyy)</label>';
        $ret .= '<div class="input-group mb-3">';
        if (intval($cid) <= 0){
            $ret .= $ci->admin_lib->datePartSelect("m",'gpopen_month');
            $ret .= $ci->admin_lib->datePartSelect("d",'gpopen_day');
            $ret .= $ci->admin_lib->datePartSelect("y",'gpopen_year', $yr);
        }
        else{
            $sdate = $this->parse_date($this->gaming_reg_open_date);
            $ret .= $ci->admin_lib->datePartSelect("m",'gpopen_month',$sdate[2]);
            $ret .= $ci->admin_lib->datePartSelect("d",'gpopen_day',$sdate[3]);
            $ret .= $ci->admin_lib->datePartSelect("y",'gpopen_year',$sdate[1]);
        }
        $ret .= '</div>';
        $ret .= '<label for="gpclose_month">Gaming Prereg Close Date (mm/dd/yyyy)</label>';
        $ret .= '<div class="input-group mb-3">';
        if (intval($cid) <= 0){
            $ret .= $ci->admin_lib->datePartSelect("m",'gpclose_month');
            $ret .= $ci->admin_lib->datePartSelect("d",'gpclose_day');
            $ret .= $ci->admin_lib->datePartSelect("y",'gpclose_year', $yr);
        }
        else{
            $sdate = $this->parse_date($this->gaming_reg_close_date);
            $ret .= $ci->admin_lib->datePartSelect("m",'gpclose_month',$sdate[2]);
            $ret .= $ci->admin_lib->datePartSelect("d",'gpclose_day',$sdate[3]);
            $ret .= $ci->admin_lib->datePartSelect("y",'gpclose_year',$sdate[1]);
        }
        $ret .= '</div>';
        $ret .=  '<input type="hidden" name="cid" value="' . intval($cid) . '" />';
        $ret .= '<label>Con MSA ID</label>';
        if (intval($cid) <= 0){
            $ret .= '<input name="con_msa_id" type="text" class="form-control" />';
            $ret .= '<input name="con_id" id="con_id" type="hidden" value="0" />';
        }
        else
        {
            $ret .= '<input name="con_msa_id" type="text" class="form-control" value="' . $this->msa_conid . '" disabled="disabled" />';
            $ret .= '<input name="con_id" id="con_id" type="hidden" value="' . $this->conid . '" />';
        }
        $ret .= '</form>';
        $ret .= '<div id="results" class="results"></div>';
        return $ret;
        }
        
//--------------------------------------
//
//--------------------------------------
    public function conventionListHeader(){
        $ci = &get_instance();  
        $ret = '';
        $orgid = $ci->session->ogre_orgid;
        $ret .= $this->conventionYearSelect(date("Y"), $orgid);
        return $ret;
    }
//--------------------------------------
//
//--------------------------------------
    public function conventionList($cyear=0){
        $ci = &get_instance();
        $ret = '';
        $cyear = ($cyear ==0) ? date("Y") : $cyear;
        $orgid = $ci->session->ogre_orgid;
        $ret .= '<div id="conventionlist">';
        $ret .= '<div class="d-grid gap-2"><input class="btn btn-primary m-1" type="button" value="  New Convention " onclick="openConInfo(' . "'" . site_url('ogre/convention/-1','https') . "',". "'" .site_url('ogrex/conventionIn','https')."'".');"  /></div>';
        $qry = 'SELECT * ';
        $qry .= ' FROM ogre_convention ';
        $qry .= ' WHERE con_org_id = ' . $orgid;
        $qry .= ' AND con_year = "' . $cyear . '" ';
        $qry .= ' ORDER BY con_start_date DESC;';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $ret .= '<br /><br />';
                $ret .= '<table class="table table-striped">';
                $ret .= '<tr>';
                $ret .= '<td colspan="2">';
                $ret .= '<h2>' . $row->con_name . '</h2>' ;
                $ret .= '</td>';
                $ret .= '</tr>';	 
                $ret .= '<tr>';
                $ret .= '<td width="30%">';
                $ret .= 'Name';
                $ret .= '</td>';
                $ret .= '<td>';
                $ret .= $row->con_name;
                $ret .= '</td>';
                $ret .= '</tr>';
                $ret .= '<tr>';
                $ret .= '<td width="30%">';
                $ret .= 'Start Date/Time';
                $ret .= '</td>';
                $ret .= '<td>';
                $ret .= $row->con_start_date . ' ' . $row->con_start_time  ;
                $ret .= '</td>';
                $ret .= '</tr>';
                $ret .= '<tr>';
                $ret .= '<td width="30%">';
                $ret .= 'End Date Time';
                $ret .= '</td>';
                $ret .= '<td>';
                $ret .= $row->con_end_date . ' ' . $row->con_end_time;
                $ret .= '</td>';
                $ret .= '</tr>';
                $ret .= '<tr>';
                $ret .= '<td colspan="2" align="right">';
                $ret .= '<div class="d-grid gap-2"><input class="btn btn-secondary" type="button" value="  Edit  " onclick="openConInfo(' . "'" . site_url('ogre/convention' . '/' . $row->con_id,'https') . "','" .site_url('ogrex/conventionIn','https')."'".');" /></div>';
                $ret .= '</td>';
                $ret .= '</tr>';
                $ret .= '</table>';
            }
        }
        $ret .= '</div>';
        return $ret;
    }        
//***********************************
//
//***********************************
    private function conventionYearSelect($cyear="0", $orgid=0){
        $ci = &get_instance();
        $qry = 'SELECT DISTINCT con_year FROM ogre_convention ';
        if ($orgid != 0){
            $qry .= ' WHERE con_org_id = ' . $orgid;
        }
        $qry .= ' ORDER BY con_year;';
        $query = $ci->db->query($qry);
        $action = site_url("ogre/convention/0",'https');
        $ret = '<select class="form-control" id="conyear" name="conyear" size="1" onchange="get_conventions('."'".$action."',".'this.options[this.selectedIndex].value);">';
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                if ($cyear == $row->con_year){
                    $ret .= '<option value = "' . $row->con_year  . '" selected="selected">' . $row->con_year  . '</option>';
                }
                else{
                    $ret .= '<option value = "' . $row->con_year  . '">' . $row->con_year  . '</option>';
                }
            }
        }
        $ret .= '</select>';
        return $ret;
    }              
}   /* END CLASS */

?>