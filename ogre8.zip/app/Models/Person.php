<?php 
namespace App\Models;
use CodeIgniter\Model;
use CodeIgniter\I18n\Time;

//---------------------------------------------------
// Class: Player/User/Participent
//---------------------------------------------------
class Person extends Model {
    var $user_id_num = 0;
    var $firstname = "";
    var $lastname = "";
    var $fullname = "";
    var $email = "";
    var $user_login_id= "";
    var $password = "";
    var $notes = "";
    var $ogre_level_rating = 0;
    var $ogre_sec_rating = 0;
    var $access_rating = 0;
    var $user_verified = 0;
    var $rpga_number = "";
    var $user_login_name = "";

    var $game_id_list = "";      //All games prereg'ed or GMing for
    var $gamegm_id_list = "";    //games GMing
    var $gamepl_id_list = "";    //games Playing
    var $slotcode_list = "";
    var $request_id_list = "";   //request List  
    var $comment_id_list = "";
    var $convention_id ="";
    var $address1 ="";
    var $address2="";
    var $city="";
    var $state="";
    var $zip="";
    var $country="";
    var $phone="";
    var $notify_registration=0;
    var $notify_scehdule_changes=0;
    var $notify_my_games_players=0;
    var $date_created="";
    var $date_last_modified="";
    var $totalGMhours=0;


//---------------------------------------------------  
//
//---------------------------------------------------	
    public function __construct(){
        
    }	    
    
//---------------------------------------------------
//
//---------------------------------------------------	
                
    public function get($id, $conid=0){
        return $this->init($conid, '', $id);
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function init($conid, $email='', $id=0, $login=''){
        $this->clear();
        $this->convention_id = $conid;
        if ((trim($email) <> '') ||($id <> 0) || (trim($login) <> '')){
            $this->getPlayerData($conid, $email, $id, $login);
        }
        return TRUE;
    }
//---------------------------------------------------
//
//---------------------------------------------------    
    public function clear(){
        $this->user_id_num = 0;
        $this->firstname = '';
        $this->lastname = '';
        $this->fullname = '';
        $this->email = '';
        $this->user_login_id = '';
        $this->password = "";
        $this->notes = "";
        $this->ogre_level_rating = 0;
        $this->ogre_sec_rating = 0;
        $this->access_rating = 0;
        $this->user_verified = 0;
        $this->rpga_number = "";
        $this->user_login_name = "";
        $this->game_id_list = '';   
        $this->gamegm_id_list = '';   
        $this->gamepl_id_list = '';   
        $this->request_id_list = '';     
        $this->convention_id ='';
        $this->address1 = '';
        $this->address2= '';
        $this->city = '';
        $this->state = '';
        $this->zip = '';
        $this->country = '';
        $this->phone = '';
        $this->notify_registration = 0;
        $this->notify_scehdule_changes = 0;
        $this->notify_my_games_players = 0;
        $this->date_created = '';
        $this->date_last_modified = '';
        $this->totalGMhours = 0;
        $this->convention_id = 0;
        return true;
    }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
    public function getPlayerSchedule($conid, $gm=-1, $pid=0, $alt=1){
        $ci = &get_instance();
        $this->user_id_num = ($pid != 0 ) ? $pid : $this->user_id_num;
        $conid = (($conid=='' || $conid==0) ? $ci->session->ogre_conid : $conid);
        $qry = 'SELECT ogre_gameschedule.gs_cancelled, ';
        $qry .= ' ogre_gameschedule.gs_convention_id, ';
        $qry .= ' ogre_gameschedule.gs_id, ';                    
        $qry .= ' ogre_gameschedule.gs_game_type, ';
        $qry .= ' ogre_gameschedule.gs_affiliation, ';
        $qry .= ' ogre_gameschedule.gs_displaymode, ';
        $qry .= ' ogre_gameschedule.gs_game_name, ';
        $qry .= ' ogre_gameschedule.gs_game_title, ';
        $qry .= ' ogre_gameschedule.gs_slot_code, ';
        $qry .= ' ogre_prereg_player.pp_gs_id, ';
        $qry .= ' ogre_prereg_player.pp_delete_flag, ';
        $qry .= ' ogre_prereg_player.pp_gm_judge_flag ';
        $qry .= ' FROM ogre_gameschedule ';
        $qry .= ' INNER JOIN ogre_prereg_player';
        $qry .= ' ON ogre_gameschedule.gs_id = ogre_prereg_player.pp_gs_id ';
        $qry .= ' WHERE pp_player_id  = "' . $this->user_id_num . '" ';
        $qry .= ($gm != -1) ? ' AND ABS(pp_gm_judge_flag) = ' . $gm : ' ';                   
        $qry .= ($alt == 0) ? ' AND pp_player_confirmed <> 0 ' : ' ';
        $qry .= ' AND pp_delete_flag = 0 ';
        $qry .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
        $qry .= ' AND ogre_gameschedule.gs_cancelled = 0 ';
        $qry .= ' ORDER BY ogre_gameschedule.gs_slot_code, ogre_gameschedule.gs_game_type, ogre_gameschedule.gs_affiliation,  ';
        $qry .= ' ogre_gameschedule.gs_game_name,  ogre_gameschedule.gs_game_title';
        $query = $ci->db->query($qry);
        $gl = '';
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){ 
                $gl .= $row->pp_gs_id . ",";                                   
            }
        }
        return $gl;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getPlayerScheduleRoles($conid, $pid=0){
        $ci = &get_instance();
        $this->user_id_num = ($pid != 0 ) ? $pid : $this->user_id_num;
        $conid = ($conid=='' || $conid==0) ? $ci->session->get('ogre_conid') : $conid;
        $qry = 'SELECT ogre_gameschedule.gs_cancelled, ';
        $qry .= ' ogre_gameschedule.gs_convention_id, ';
        $qry .= ' ogre_gameschedule.gs_id, ';                    
        $qry .= ' ogre_gameschedule.gs_game_type, ';
        $qry .= ' ogre_gameschedule.gs_affiliation, ';
        $qry .= ' ogre_gameschedule.gs_displaymode, ';
        $qry .= ' ogre_gameschedule.gs_game_name, ';
        $qry .= ' ogre_gameschedule.gs_game_title, ';
        $qry .= ' ogre_gameschedule.gs_slot_code, ';
        $qry .= ' ogre_prereg_player.pp_gs_id, ';
        $qry .= ' ogre_prereg_player.pp_delete_flag, ';
        $qry .= ' ogre_prereg_player.pp_gm_judge_flag, ';
        $qry .= ' ogre_prereg_player.pp_player_confirmed ';
        $qry .= ' FROM ogre_gameschedule, ogre_prereg_player ';
        $qry .= ' WHERE pp_player_id  = "' . $this->user_id_num . '" ';
        $qry .= ' AND pp_delete_flag = 0 ';
        $qry .= ' AND ogre_gameschedule.gs_id = ogre_prereg_player.pp_gs_id ';
        $qry .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
        $qry .= ' AND ogre_gameschedule.gs_cancelled = 0 ';
        $qry .= ' ORDER BY ogre_gameschedule.gs_slot_code, ogre_gameschedule.gs_game_type, ogre_gameschedule.gs_affiliation,  ';
        $qry .= ' ogre_gameschedule.gs_game_name,  ogre_gameschedule.gs_game_title';
        $query = $ci->db->query($qry);
        $gl = "";
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){ 
                // 1 P 1 = GM, 0 P 1 = Player, 0 P 0 = Alt Player, 1 R 1 = Volunteer
                $gl .= $row->pp_gs_id.'~'. abs(intval($row->pp_gm_judge_flag)) .'~'. $row->gs_displaymode . '~'. abs($row->pp_player_confirmed) .",";                                   
            }
        }
        return $gl;
    }       
//---------------------------------------------------
//
//---------------------------------------------------
    public function  getPlayerScheduleSlotCodes($conid=0, $pid=0){
        $ci = &get_instance();
        $gl = array();
        $this->user_id_num = ($pid != 0 ) ? $pid : $this->user_id_num;
        $conid = ($conid=='' || $conid==0) ? $ci->session->get('ogre_conid') : $conid;
        $qry = 'SELECT ogre_gameschedule.gs_cancelled, ';
        $qry .= ' ogre_gameschedule.gs_convention_id, ';
        $qry .= ' ogre_gameschedule.gs_id, ';                    
        $qry .= ' ogre_gameschedule.gs_game_type, ';
        $qry .= ' ogre_gameschedule.gs_affiliation, ';
        $qry .= ' ogre_gameschedule.gs_game_name, ';
        $qry .= ' ogre_gameschedule.gs_game_title, ';
        $qry .= ' ogre_gameschedule.gs_slot_code, ';
        $qry .= ' ogre_prereg_player.pp_gs_id, ';
        $qry .= ' ogre_prereg_player.pp_delete_flag, ';
        $qry .= ' ogre_prereg_player.pp_gm_judge_flag ';
        $qry .= ' FROM ogre_gameschedule, ogre_prereg_player ';
        $qry .= ' WHERE pp_player_id  = "' . $this->user_id_num . '" ';
        $qry .= ' AND pp_delete_flag = 0 ';
        $qry .= ' AND ogre_gameschedule.gs_id = ogre_prereg_player.pp_gs_id ';
        $qry .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
        $qry .= ' AND ogre_gameschedule.gs_cancelled = 0 ';
        $qry .= ' ORDER BY ogre_gameschedule.gs_slot_code, ogre_gameschedule.gs_game_type, ogre_gameschedule.gs_affiliation,  ';
        $qry .= ' ogre_gameschedule.gs_game_name,  ogre_gameschedule.gs_game_title';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){ 
                        $gl[strval(substr($row->gs_slot_code,0,6))] = $row->gs_id;                                   
                }
        }
        return $gl;
    }
//---------------------------------------------------
// COMMENT LIST AS A PLAYER
//---------------------------------------------------    
    private function getCommentList(){
        $ci=&get_instance();                
        $qry = 'SELECT ogre_messages.* ';
        $qry .= ' FROM ogre_messages ';
        $qry .= ' WHERE ogre_messages.msg_userid  = ' . $this->user_id_num . ' ';
        $qry .= ' AND msg_replyid = 0 ';
        $query = $ci->db->query($qry);
        $cl = '';
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){ 
                    $cl .= $row->msg_id . ',';
            }
        }
        return $cl;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    private function  getPlayerRequests($conid){
        $ci=&get_instance();
        $conid = ($conid=='' || $conid==0) ? $ci->session->get('ogre_conid') : $conid;                  
        $qry = 'SELECT ogre_gamerequest.*, ogre_users.* ';
        $qry .= ' FROM ogre_gamerequest, ogre_users ';
        $qry .= ' WHERE ogre_users.user_index_id  = "' . $this->user_id_num . '" ';
        $qry .= ' AND ogre_gamerequest.gr_gm_id = ogre_users.user_index_id ';
        $qry .= ' AND ogre_gamerequest.gr_con_id = ' . $conid;
        $qry .= ' AND ogre_gamerequest.gr_delete = 0';
        $qry .= ' ORDER BY ogre_gamerequest.gr_date_created';
        $query = $ci->db->query($qry);
        $gl = "";
        if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){ 
                        $gl .= $row->gr_id . ",";
                }
        }
        return $gl;
    }
//---------------------------------------------------
//
//---------------------------------------------------
		
    private function getPlayerData($conid, $email='', $id=0, $userid=''){
        $ci=&get_instance();
        if (trim($userid) != ''){
                $qry = 'SELECT * FROM ogre_users WHERE user_login_id = "' . $userid . '";';
        }
        elseif(trim($email) != ''){
                $qry = 'SELECT * FROM ogre_users WHERE user_email = "' . $email . '";';

        }
        else{
                $qry = 'SELECT * FROM ogre_users WHERE user_index_id = "' . $id . '";';	
        }
        $query = $ci->db->query($qry);		
        if ($query->getNumRows() > 0){		
            foreach ($query->getResult() as $row){ 
                $this->user_id_num = $row->user_index_id;
                $this->user_login_id = $row->user_login_id;
                $this->email = $row->user_email;
                $this->fullname = $row->user_full_name;
                $this->notes = $row->user_notes;
                $this->ogre_level_rating = $row->user_access_rating;   // -1 = SYSTEM LEVEL, 0 = CON LEVEL, ORG ID = ORG LEVEL
                $this->ogre_sec_rating = $row->user_access_rating2;
                $this->rpga_number = $row->user_rpga_number;
                $this->firstname = $row->user_first_name;
                $this->lastname = $row->user_last_name;
                $this->user_login_name = $row->user_login_name; 
                $this->password = $row->user_password; 
                $this->game_id_list = $this->getPlayerSchedule($conid, -1);
                $this->gamegm_id_list = $this->getPlayerSchedule($conid, 1);
                $this->gamepl_id_list = $this->getPlayerSchedule($conid, 0);
                $this->request_id_list = $this->getPlayerRequests($conid);
                $this->slotcode_list = $this->getPlayerScheduleSlotCodes($conid);
                $this->comment_id_list = $this->getCommentList($conid, -1);
                $this->address1 = $row->user_address1;
                $this->address2 = $row->user_address2;
                $this->city = $row->user_city;
                $this->state = $row->user_state;
                $this->zip = $row->user_zip;
                $this->country = $row->user_country;
                $this->phone = $row->user_phone;
                $this->notify_registration = $row->user_notify_registration;
                $this->notify_scehdule_changes = $row->user_notify_scehdule_changes;
                $this->notify_my_games_players = $row->user_notify_my_games_players;
                $this->date_created = $row->user_date_created;
                $this->date_last_modified = $row->user_date_last_modified;
                $ret = $this->getUserVerified($conid); //user verified and user access rating
            }	
        }	
    }
//---------------------------------------------------
//
//---------------------------------------------------
		
    public function getPlayerFilename($id=0){
        $ci=&get_instance();
        $filename = '';
        $qry = 'SELECT * FROM ogre_users WHERE user_index_id = "' . $id . '";';
        $query = $ci->db->query($qry);		
        if ($query->getNumRows() > 0){		
            foreach ($query->getResult() as $row){ 
                $filename .= strtolower(substr(trim($row->user_first_name), 0, 1)) . strtolower(trim($row->user_last_name));
            }   
        }
        $filename = str_replace(" ","-",str_replace("`","-",str_replace("'","-",$filename)));
        return $filename;
    }
//--------------------------------------------------- 
//
//---------------------------------------------------
    public function getUserVerified ($conid, $pid=0){
        $ci=&get_instance();
        $conid = ($conid == 0) ? $ci->session->get('ogre_conid') : $conid;
        $pid = ($pid==0) ? $this->user_id_num : $pid;
        if ($this->user_id_num == 0){
            $this->get($pid);
        }
        $orgid = $ci->session->get('ogre_orgid');
        if ($this->ogre_level_rating == 0){ 
            $qry = 'SELECT * FROM ogre_user_verified WHERE uv_user_id = ' . $pid  . ' AND uv_con_id = ' . $conid . ';';
            $query = $ci->db->query($qry);	
            if ($query->getNumRows() > 0){
                $this->user_verified = 1;
                foreach ($query->getResult() as $row){
                    $this->access_rating = $row->uv_user_access_rating2;
                }
                $this->ogre_level_rating = 0;
            }   
            else{
                $this->user_verified = 0;
                $this->access_rating = PLAYER;
                $this->ogre_level_rating = 0;
            } 
        }else{
            if ($this->ogre_level_rating > 0){
                if ($this->ogre_level_rating == $orgid){
                    $this->access_rating = $this->ogre_sec_rating;
                    $this->user_verified = 1;                               
                }else{
                    $this->user_verified = 0;
                    $this->access_rating = PLAYER;                                
                }
            }elseif ($this->ogre_level_rating < 0) {
                $this->access_rating = $this->ogre_sec_rating;
                $this->user_verified = 1;                            
            }else{
                    $this->user_verified = 0;
                    $this->access_rating = PLAYER;
                    $this->ogre_level_rating = 0;                           
            } 
        }
                   
        return TRUE;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getUserAccessLevelRating ($cid=0, $pid=0){
        $ci=&get_instance();
        $conid = ($cid == 0) ? $ci->session->get('ogre_conid') : $cid;
        $ret = 0;
        if ($this->user_id_num == 0){
            $this->get($pid,$conid);
        }
        $act = $this->user_verified;
        if ($act != 0){
            switch($this->access_rating){
                case PLAYER:
                    $ret = (($this->ogre_level_rating == 0) ? -1 * $this->access_rating : $this->access_rating);
                    break;
                case GAMEMASTER:
                    $ret = (($this->ogre_level_rating == 0) ?  -1 * $this->access_rating : $this->access_rating);
                    break;
                case REGVOL:
                    if ($this->ogre_level_rating < 0){
                        $ret = 100 + $this->access_rating;
                    }elseif ($this->ogre_level_rating == 0) {
                        $ret = -1 * $this->access_rating;
                    }else{
                        $ret = $this->access_rating;
                    }                         
                    break;
                case CONADMIN:
                    if ($this->ogre_level_rating < 0){
                        $ret = 100 + $this->access_rating;
                    }elseif ($this->ogre_level_rating == 0) {
                        $ret = -1 * $this->access_rating;
                    }else{
                        $ret = $this->access_rating;
                    }                           
                    break;
                case ADMIN:
                    if ($this->ogre_level_rating < 0){
                        $ret = 100 + $this->access_rating;
                    }elseif ($this->ogre_level_rating == 0) {
                        $ret = -1 * $this->access_rating;
                    }else{
                        $ret = $this->access_rating;
                    }                          
                    break;
                case SUPERADMIN:
                    if ($this->ogre_level_rating < 0){
                        $ret = 100 + $this->access_rating;
                    }elseif ($this->ogre_level_rating == 0) {
                        $ret = -1 * $this->access_rating;
                    }else{
                        $ret = $this->access_rating;
                    }                        
                    break;
                }
            }else{
                $ret = 0;
            }
        return $ret;
    }               
//---------------------------------------------------
//
//---------------------------------------------------
    private function getUserProfileStatus(){
        $ci = &get_instance();
        $ret='';
        $orgid = $ci->session->get('ogre_orgid');
        $ci->organization->init($orgid);
        $cntlr = (($ci->organization->ogrecontroller==NULL) ? '' : $ci->organization->ogrecontroller);
        $ret .= '<strong>Status:</strong>';
        $ret .= (($this->user_verified != 0) ? 'Verified/Activated' : '<a href="'.site_url($cntlr .'/myprofile#usertab-3').'" class="text-light" >Not Verified/Inactive</a>');
        $ret .= ' | <strong>Access rating: </strong>';
        switch ($this->access_rating) {
            case "10":
                    $ret .= 'Player/Participant';
                    break;
            case "20":
                    $ret .= 'Game Master';
                    break;
            case "80":
                    $ret .= 'Registration Vol';
                    break;
            case "90":
                    $ret .= 'Co-Admin';
                    break;                                    
            case "99":
                    $ret .= 'Admin';
                    break;
            case "100":
                    $ret .= 'Super Admin';
                    break;
            default:
                    $ret .= 'Unknown Access';
        }
        return $ret;
    }
//--------------------------------------------------- 
//
//---------------------------------------------------
    public function getUserProfile($pid=0){
        $ci=&get_instance();
        $conid = $ci->session->ogre_conid;
        $orgid = $ci->session->ogre_orgid;
        $isconnected = $ci->convention->isRegConnected($conid);
        $pid  = (($pid==0)? $ci->session->ogre_user_ID : $pid);
        $act = ((intval($ci->session->get("ogre_user_accesslevel_".$orgid)) > 10) ? TRUE : $this->isActivated($pid));
        $divid = 'user-profile-save-results';
        $ret='';        
        if ($pid!==0){
            $this->get($pid);
            $ret .= '<div id="user-profile">';        
            $ret .= '<div id="'.$divid.'"></div>';  
            $ret .= '<div id="userhorizontalTab">';
            $ret .= '<ul>';        
            $ret .= '<li>'.'<a href="#usertab-0">My Dashboard</a></li>';
            $ret .= '<li>'.'<a href="#usertab-1">Profile Basics</a></li>';
            $ret .= '<li>'.'<a href="#usertab-2">Optional Info</a></li>';
            $ret .= (($act!== TRUE) ? '<li><a href="#usertab-3">Activation</a></li>':'');
            $ret .= '</ul>';
            $ret .= '<div id="usertab-0">';
            $ret .= $this->breadCrumbUserBasics();
            $ret .= $this->buildMyDashboard();
            $ret .= '</div>'; 
            $ret .= '<div id="usertab-1">';
            $ret .= $this->getBasicUserInfoForm($pid);
            $ret .= '</div>'; 
            $ret .= '<div id="usertab-2">';
            $ret .= $this->breadCrumbUserBasics();
            $ret .= $this->getAdvancedUserInfoForm($pid);
            $ret .= '</div>';
            $this->get($pid);
            if($act!== TRUE){
                $key = 'OGRE.ACTIVATION.MODE';  
                $activationmode = $ci->convention->getConfigKey($key, $conid);
                $ret .= '<div id="usertab-3">';
                $ret .= $this->breadCrumbUserBasics();
                $ret .= (($activationmode !=0) ? $this->activationAccordianMenu($conid, $isconnected) :  $ci->ogre_lib->activationForm($conid));
                $ret .= '<div id="activate-results" class="results"></div>'.'<div id="act-code-results" class="results"></div>';              
                $ret .= '</div>';
            }
            $ret .= '</div>';
            $ret .= '</div>';
        }
        return $ret;
    }
//---------------------------------------------------
//  
//---------------------------------------------------    
    private function getAdvancedUserInfoForm($pid){ 
        $ci=&get_instance();
        $ret = '';
        $saveaction = site_url('ogrex/myProfileInX','https');
        $olertaction = site_url('ogrex/ogreAlert','https');
        $divid = 'user-profile-save-results';
        $this->get($pid);       
        $ret .= '<form id="User-Profile-Form2" autocomplete="off">';
        $ret .= '<label for="usernotes" class="form-label">Notes</label>';        
        $ret .= '<textarea class="form-control" id="usernotes" rows="5">' . $this->notes . '</textarea>'; 
        $ret .= '<label for="NewStreet1" class="form-label">Street Address</label>';
        $ret .= '<input type="text" class="form-control" id="NewStreet1" name="NewStreet1" maxlength="100" value="' . $this->address1 .'" />';       
        $ret .= '<label class="form-label" for="NewStreet2">Apt. Number or P.O. Box  (if applicable):</label>';
        $ret .= '<input type="text" class="form-control" id="NewStreet2" name="NewStreet2" maxlength="100" value="' . $this->address2 .'" />';     
        $ret .= '<label class="form-label" for="NewCity">City:</label>';
        $ret .= '<input class="form-control" type="text" name="NewCity" id="NewCity" maxlength="100" value="' . $this->city .'" />';
        $ret .= '<label class="form-label" for="NeNewStatewCity">State/Province:<br /></label>';
        $ret .= '<input  class="form-control"type="text" name="NewState" id="NewState" maxlength="100" value="' . $this->state .'" />';
        $ret .= '<label class="form-label" for="NewPostalCode">Zip/Postal Code:</label>';
        $ret .= '<input  class="form-control"type="text" name="NewPostalCode" id="NewPostalCode" maxlength="100" value="' . $this->zip .'" />'; 
        $ret .= '<label class="form-label" for="NewCountry">Country:</label>';
        $ret .= '<input class="form-control"type="text" name="NewCountry" id="NewCountry" value="' . $this->country .'" maxlength="50" />';
        $ret .= '<label class="form-label" for="DayTimePhone">Contact Phone:</label>';
        $ret .= '<input class="form-control"type="text" type="text" name="DayTimePhone" id="DayTimePhone" value="' . $this->phone .'" maxlength="100" />';
        $ret .= '<input type="hidden" id="userIndexId" name="userIndexId" value="' . $this->user_id_num . '" />';
        $ret .= '<div class="d-grid gap-2">';
        $ret .= '<button class="btn btn-secondary" type="button" id="usermodify" name="usermodify" onclick="saveProfile('."'".$saveaction."','".$divid."','".$olertaction."'".');" >Save</button>';
        $ret .= '</div>'; 
        $ret .= '</form>';
        return $ret;
    }
//---------------------------------------------------
//  
//---------------------------------------------------    
    private function getBasicUserInfoForm($pid){
        $ci=&get_instance();
        $ret = '';
        $saveaction = site_url('ogrex/myProfileInX','https');
        $olertaction = site_url('ogrex/ogreAlert','https');
        $divid = 'user-profile-save-results';
        $this->get($pid);
        $ret .= $this->breadCrumbUserBasics();      
        $ret .= '<form id="User-Profile-Form1" autocomplete="off">';
        $ret .= '<input type="hidden" id="rpgaNumber" name="rpgaNumber" value="' . $this->rpga_number . '" />';
        $ret .= '<input type="hidden" id="Entered_On" name="Entered_On" value="'. time() . '" />';
        $ret .= '<label for="userfirstname" class="form-label">First Name*</label>';
        $ret .= '<input autocomplete="off" type="text" class="form-control" placeholder="First Name" id="userfirstname" name="userfirstname" value="'. $this->firstname . '" maxlength="80" />';
        $ret .= '<label for="userlastname"  class="form-label">Last Name*</label>';
        $ret .= '<input autocomplete="off" type="text" class="form-control" placeholder="Last Name" id="userlastname" name="userlastname" value="'. $this->lastname . '" maxlength="80" />';       
        $ret .= '<label for="user_email" class="form-label">E-mail Address (Must be unique in the system)*</label>';
        $emaction = site_url('ogrex/checkEmailAddress','https');
        $ret .= '<input autocomplete="email-address" class="form-control" placeholder="Email Address" title="Email Address Must be unique in the system for each user."  type="text" id="user_email" name="user_email" value="' . $this->email . '" maxlength="80"  onblur="check_userinfo(this,'."'".$emaction."','emailvalid'". ',' . $this->user_id_num .",'user_email'". ');"  />';
        $ret .= '<div class="invalid-feedback" id="emailvalid"></div>';     
        
        $ret .= '<label for="user_login_id" class="form-label">Login ID (Must be unique in the system.)</label>'; //Alternative Log in used instead of email address.  Must also be unique.
        $ret .= '<div class="input-group mb-3" id="userloginid">';       
        $idaction = site_url('ogrex/check_userid','https');          
        $ret .= '<input type="text" autocomplete="login-id" class="form-control" placeholder="Login ID" disabled="disabled" id="user_login_id" name="user_login_id" value="'. $this->user_login_id . '"  onblur="check_userinfo(this,'."'".$idaction."','idvalid'". ',' . $this->user_id_num .",'user_login_id'" . ');" aria-label="Login ID (Must be unique in the system.)" aria-describedby="changeidbutton" />'; 
        $ret .= '<button id="changeidbutton" type="button" class="btn btn-secondary ms-2" onclick="changeID();">Change Login ID</button>';
        $ret .= '</div>';
        $ret .= '<div class="invalid-feedback" id="idvalid"></div>';
        $ret .= '<label for="user_login_id" class="form-label">Password</label>';
        
        $ret .= '<div class="input-group mb-3" id="userpassword">';        
        $ret .= '<input class="form-control" type="text" disabled="disabled" value="************" />'; 
        $ret .= '<button id="changepwbutton" name="changepwbutton" type="button" class="btn btn-secondary ms-2" onclick="changepw();">Change Password</button>';
        $ret .= '</div>';   
        
        $ret1 = '<label for="userpassword1" class="form-label">New Password</label>';
        $ret1 .= '<input class="form-control m-2" type="password" id="userpassword1" autocomplete="off"  />';
        $ret1 .= '<label for="userpassword2" class="form-labell">Repeat New Password</label>';
        $ret1 .= '<input class="form-control m-2" type="password" id="userpassword2" name="userpassword2" onblur="validatePasswordMatch(this);" autocomplete="off" />';
        $ret1 .= '<div id="pwvalid" class="invalid-feedback"></div>';
        $ret1 .= '<div class="d-grid gap-2"><button id="user-modify1" type="button" class="btn btn-outline-warning text-dark" onclick="saveProfile('."'".$saveaction."','".$divid."','".$olertaction."'".');">Save Password</button></div>';
        $ret .= $ci->ogre_lib->bootCard('', $ret1, 'changepassword', 'Change OGRe Password', '' );  

        $ret .= '<div class="d-grid gap-2">';
        $ret .= '<button id="user-modify" name="user-modify" type="button" class="btn btn-secondary" onclick="saveProfile('."'".$saveaction."','".$divid."','".$olertaction."'".');">Save</button>';
        $ret .= '</div>';              
        $ret .= '<p class="text-info">* indicates a required field</p>';        
        $ret .= '</form>';
        

        return $ret;
    }
//---------------------------------------------------
//  
//---------------------------------------------------    
    private function activationAccordianMenu($conid, $isconnected){
        $ci=&get_instance();
        $ret = '<div id="accordion-activation">';
        $ret .= '<h3>Get Code</h3><div>';
        $ret .= $ci->ogre_lib->getActivationCode($isconnected);
        $ret .= '</div>';
        $ret .= '<h3>Activation</h3><div>';
        $ret .= $ci->ogre_lib->activationForm($conid); 
        $ret .= '</div>';
        $ret .= '<h3>On Site</h3><div>';
        $ret .= $ci->ogre_lib->onsiteActivationForm($conid);
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '<script>$( function() { $( "#accordion-activation" ).accordion(); } ); </script>';
        return $ret;
    }
//---------------------------------------------------
//  
//---------------------------------------------------
    private function breadCrumbUserBasics(){
        $ret='';
        $ret .= '<ol class="breadcrumb" id="userbasics">';
        $ret .= '<li class="breadcrumb-item">My OGRE ID #:' . str_pad($this->user_id_num,6,"0",STR_PAD_LEFT).'</li>';
        $ret .= '<li class="breadcrumb-item">'. str_replace("|",'</li><li class="breadcrumb-item">',$this->getUserProfileStatus()) .'</li>';
        $ret .= '</ol>';      
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    private function myDashProposeButton(){    
        $ci=&get_instance();
        $conid = $ci->session->ogre_conid;
        $cntlr = $ci->session->ogre_control;
        $pid = $ci->session->ogre_user_ID;                
        $ci->convention->init($conid);
        $ci->proposal->prop_init(0, $conid);           
        $ci->person->init($conid, '', $pid);                              
        $conname = $ci->convention->name;                
        $key = '%PROPHEADER%';
        $needle = '%AGREEMENTLINK%';
        $proposal = site_url($cntlr.'/propose');
        $txt = $ci->ogre_lib->getMiscContent($key);
        $link1 = '<a href="#" onclick="return get_gmpolicy('."'".site_url('ogrex/gmPolicyX','https')."'".')">Game Master Guidelines</a>.';
        $eventname = $conname;
        $eventdates = $ci->convention->getConDates();
        $ret = '';
        $ret .= str_replace($needle, $link1, $txt['content']);
        if($ci->session->ogre_logged_in == TRUE){
            $verified= $ci->session->get('ogre_user_activated_' . $conid);
            if (intval($verified) == 0){
                $txt1 = $ci->ogre_lib->getMiscContent('%%NOT-ACTIVE-PROPOSE%%',$conid,TRUE);
                $ret .= $ci->ogre_lib->bootAlert('alert-info','00','Proposing while Inactive', $txt1);
            }
        } 
        $ret .= '<div class="d-grid gap-2"><button type="button" class="btn btn-primary btn-lg" onclick="self.location='."'".$proposal."'".'">Propose Event</button></div>';
        
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    private function buildMyDashboard(){
        $ci=&get_instance();
        $ret = '';
        $conid = $ci->session->get('ogre_conid');
// Row 0  
        $ret .= '<div class="row">';
        $ret .= '<div class="col mb-4">';
        $ret .= '<div class="card border-info h-100">';
        $ret .= '<h4 class="card-header">Propose Event</h4>';    
        $ret .= '<div class="card-body">';
        $ret .= $this->myDashProposeButton();
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';
        
        $ret .= '<div class="row">';
// Row 1        
        $ret .= '<div class="col m-1">';
        $ret .= '<div class="card border-info h-100">';
        $ret .= '<h4 class="card-header">Convention Status</h4>';
        $ret .= '<div class="card-body">';
        $ret .= '<p class="card-text">';
        $ret .= 'Here you can see general stats of the current convention.';
        $ret .= '</p>';
        $ret .= $ci->schedule_lib->getSeatTotals($conid);
        $ret .= $ci->schedule_lib->getBreakDownList($ci->session->ogre_conid,"P");
        $ret .= '</div>';
        $ret .= '<div class="card-footer">';
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '<div class="row">';
// Row 2         
        $ret .= '<div class="col m-1">';
        $ret .= '<div class="card border-info h-100">';
        $ret .= '<h4 class="card-header">My Schedule</h4>';
        $ret .= '<div class="card-body">';
        $ret .= $ci->ogre_lib->getMiscContent('%%MYSCHEDULECARDTEXT%%',0,TRUE);
        $ret .= $ci->schedule_lib->getSchedulePDFLinks($this->user_id_num);
        $ret .= '<div id="my-ogre-schedule">';
        $ret .= $this->displayMySchedule($ci->session->ogre_conid);
        $ret .= '</div>';
        $isGM = $this->isGM($ci->session->ogre_user_ID);
        $unread = $this->getUnreadMessages() + (($isGM) ? $this->getUnreadMessagesGM() : 0 );
        $haction = site_url('ogrex/getMySchedule','https');
        $saction = site_url('ogrex/gameEditInx','https');          
        $ret .= '<button class="btn btn-primary m-2 position-relative" id="my-ogre-schedule-button" onclick="return displayHistory('."'".$haction."',". $this->user_id_num . ",'". $saction ."',". ');">My Schedule';
        if($unread !== 0){
            $ret .= '<span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="unread-messages">';
            $ret .= $unread;
//            $ret .= '<span class="visually-hidden">unread messages</span>';
            $ret .= '</span>';
        }
        $ret .= '</button>';
        $haction = site_url('ogrex/getMyHistory','https');
        $ret .= '<button class="btn btn-primary m-2" onclick="return displayHistory('."'".$haction."',". $this->user_id_num .",''".')">My History</button>';
        $ret .= '</div>';
        $ret .= '<div class="card-footer">';
        if (trim($this->game_id_list) != ""){
            $ret .= '<p>' . $ci->ogre_lib->getMiscContent('%DROPOUTOFALLGAMES%',$ci->session->ogre_conid, TRUE) . '</p>';
            $idaction = site_url('ogrex/get_gameidlist','https');
            $remaction= site_url('ogrex/removePlayerResults','https');
            $refaction= site_url('ogrex/refreshMySchedule','https');
            $divid = 'my-ogre-schedule';
            $resdivid = 'drop-out-all-progress-results';
            $progressbar = site_url('ogrex/dropAllProgress','https');
            $progressdiv = 'dropoutall_progress';
            $ret .= '<button class="btn btn-primary" onclick="displayDeleteAllProgess('.$this->user_id_num.",'".site_url('ogrex/getDeleteProgress','https')."',".((!$ci->agent->isMobile()) ? '0.75' : '0.90'). ",". ((!$ci->agent->isMobile()) ? '0.50' : '0.70').','."'".$idaction."','". $remaction."','".$refaction."','".$divid."','".$resdivid."'".",'".$progressbar."','".$progressdiv."'".');">Drop Out of All Games</button>';
        }
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';        
        $ret .= '</div>';
// Row 3
        $laction = site_url('ogrex/getGameLibraryBuilder','https');
        $ret .= '<div class="row">';
        $ret .= '<div class="col m-1">';
        $ret .= '<div class="card border-info h-100">';
        $ret .= '<h4 class="card-header">Personal Game Library</h4>';
        $ret .= '<div class="card-body">';
        $ret .= $ci->ogre_lib->getMiscContent('%%GAMELIBRARYTEXT%%',0,TRUE);
        $ret .= $ci->proposal->personalGameLibraryList($conid, $ci->session->user_id_num, FALSE);
        $ret .= '</div>';
        $ret .= '<div class="card-footer">';
        $ret .= '<button class="btn btn-primary" onclick="return displayBuildMyLibrary('."'".$laction."',". $this->user_id_num .');">Game Library</a>';
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>'; 
        $ret .= '</div>'; 
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getUnreadMessagesSingleGame($gid){
        $ci = &get_instance();
        $pid = $ci->session->ogre_user_ID;
        $conid = $ci->session->get('ogre_conid');
        $this->get($pid);   
        $ret = 0 ;
        $qry = 'SELECT * FROM ogre_messages WHERE msg_gsid = ' . $gid. ' AND msg_replyid = 0 AND msg_dateread IS NULL;';
        $query = $ci->db->query($qry);
        if($query->getNumRows() > 0){
            $ret = $query->getNumRows();
        }        
        return $ret;
    }  
//---------------------------------------------------
//
//---------------------------------------------------
    public function getUnreadMessagesSingleGameReplies($gid){
        $ci = &get_instance();
        $pid = $ci->session->ogre_user_ID;
        $conid = $ci->session->get('ogre_conid');
        $this->get($pid);   
        $ret = 0 ;
        if (trim($this->comment_id_list) !== ""){
            $qry = 'SELECT * FROM ogre_messages WHERE msg_gsid = ' . $gid. ' AND msg_replyid IN ('.substr($this->comment_id_list, 0, strlen($this->comment_id_list)-1).') AND msg_dateread IS NULL;';
            $query = $ci->db->query($qry);
            if($query->getNumRows() > 0){
                $ret = $query->getNumRows();
            }  
        }
        return $ret;
    }     
//---------------------------------------------------
//
//---------------------------------------------------
    public function getUnreadMessages($gid=0){
        $ci = &get_instance();
        $pid = $ci->session->ogre_user_ID;
        $conid = $ci->session->get('ogre_conid');
        $this->get($pid);
        $isGM = $this->isGM($pid);
        $ret = 0;
        if($gid==0){
            $games = explode(",", $this->gamepl_id_list);
        }
        else{
            $games = [$gid];
        }
        if(trim($this->comment_id_list) !== ''){
            foreach ($games as $game){
                if(trim($game) !== ''){
                    $qry = 'SELECT * FROM  ogre_messages WHERE msg_gsid = ' . $game. ' AND msg_replyid IN ('.substr($this->comment_id_list, 0, strlen($this->comment_id_list)-1).') AND msg_dateread IS NULL;';
                    $query = $ci->db->query($qry);
                    if($query->getNumRows() > 0){
                        $ret = $ret + $query->getNumRows();

                    }
                }
            }
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------       
    public function getUnreadMessagesGM(){
        $ci = &get_instance();
        $pid = $ci->session->ogre_user_ID;
        $conid = $ci->session->get('ogre_conid');
        $this->get($pid);        
        $ret = 0;
        $games = explode(",", $this->gamegm_id_list);
        foreach ($games as $game){
            if(trim($game) !== ''){    
                $qry = 'SELECT * FROM  ogre_messages WHERE msg_gsid = ' . $game . ' AND msg_replyid = 0 AND msg_dateread IS NULL;';      
                $query = $ci->db->query($qry);
                if($query->getNumRows() > 0){
                    $ret = $ret + $query->getNumRows();
                }
            }
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------    
    public function markCommentRead($pid, $gid=0){
        $ci = &get_instance();
        $this->get($pid);
        $ret = TRUE;
        $qry = 'UPDATE ogre_messages ';
        $qry .= ' SET msg_dateread = NOW() ';
        $qry .= ' WHERE ';
        if($gid == 0){
            $qry .= ' msg_replyid IN ('.substr($this->comment_id_list,0,strlen($this->comment_id_list)-1).')';
        } else {
            $qry .= ' msg_replyid = ' . $gid;
        }
        var_dump($qry);
        $ci->db->query($qry);
        $ret = (($ci->db->affectedRows() > 0) ? TRUE : FALSE);
        return $ret;
    }
    
//---------------------------------------------------
//
//---------------------------------------------------    
    public function markCommentReadGM($pid, $gid=0){
        $ci = &get_instance();
        $this->get($pid);
        $ret = TRUE;
        $isGM = $this->isGM($pid, $gid);
        if ($isGM){
            if($gid == 0){
                $qry = 'UPDATE ogre_messages ';
                $qry .= ' SET msg_dateread = NOW() ';
                $qry .= ' WHERE msg_replyid = 0 AND msg_gsid IN ('.substr($this->gamegm_id_list,0,strlen($this->gamegm_id_list)-1).')';
            } else {
                $qry = 'UPDATE ogre_messages ';
                $qry .= ' SET msg_dateread = NOW() ';
                $qry .= ' WHERE msg_replyid = 0 AND msg_gsid =' . $gid;            
            }
        }
        var_dump($qry);
        $ci->db->query($qry);
        $ret = (($ci->db->affectedRows() > 0) ? TRUE : FALSE);
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function saveProfileInfoOld($p){
        $ci = &get_instance();
        $ret = array();
        $ret['errmsg'] = '';
        $ret['result'] = FALSE;
        $validFlag = TRUE;
        if( trim($p["user_email"]) == ''){
            $validFlag = FALSE;
            $ret['result'] = FALSE;
            $ret['errmsg'] = "Invalid E-mail/User ID: Required Field";
        } 
        else {
            $validFlag = TRUE;
        } 
        if (trim($p["userfirstname"]) == ''){
            $validFlag = FALSE;
            $ret['result'] = FALSE;
            $ret['errmsg'] .= "<br />Invalid User First Name";
        } 
        else{
            $validFlag = TRUE;
        }
        if (isset($p["userIndexId"])){
            $qry = "SELECT * FROM ogre_users WHERE user_email = '" . $p["user_email"] . "' AND user_index_id  <> " . $p["userIndexId"] . ';';
            $query = $ci->db->query($qry);
            if ($ci->db->getNumRows() == 0){
                $validFlag = TRUE;
            }
            else{
                $validFlag = FALSE;
                $ret['result'] = FALSE;
                $ret['errmsg'] .= ' User E-mail already in use.';
            }
        }
        if ($validFlag == TRUE){
            $ret['result'] = ($this->user_id_num <> 0) ? $this->saveUserInfo($p) : $this->insertUserInfo($p,  $p['userpassword1']);
        }
        else{
            $ret['errmsg'] .= '<br />ERROR! Invalid data.';
        }
        if (trim($ret['errmsg']) != ''){
            $ret['result'] = FALSE;
            $ret['errmsg']= $ret['errmsg'];
        }
        else{
            $ret['result'] = TRUE;
            $ret['errmsg'] = 'Done';
        }
        return $ret;
    }
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function saveProfileInfo($p){
        $pwret[]='';
        $ret['result'] = TRUE;
        $ret['errmsg'] = '';
        if ($this->user_id_num !== 0){
            $p["user_login_id"] = urldecode($p["user_login_id"]);
            $p["user_email"] = urldecode($p["user_email"]);
            $p["userfirstname"] = urldecode($p["userfirstname"]);
            $p["userlastname"] = urldecode($p["userlastname"]);
            $p["userpassword1"] = urldecode($p["userpassword1"]);
            $p["userpassword2"] = urldecode($p["userpassword2"]);
            $p["rpgaNumber"] = (isset($p["rpgaNumber"]) ? urldecode($p["rpgaNumber"]) : '');
            $p["usernotes"] = (isset($p["usernotes"]) ? urldecode($p["usernotes"]) : '');     
            $p["NewStreet1"] = (isset($p["NewStreet1"]) ? urldecode($p["NewStreet1"]) : ''); 
            $p["NewStreet2"] = (isset($p["NewStreet2"]) ? urldecode($p["NewStreet2"]) : '');
            $p["NewCity"] = (isset($p["NewCity"]) ? urldecode($p["NewCity"]) : '');
            $p["NewState"] = (isset($p["NewState"]) ? urldecode($p["NewState"]) : '');
            $p["NewPostalCode"] = (isset($p["NewPostalCode"]) ? urldecode($p["NewPostalCode"]) : '');
            $p["DayTimePhone"] = (isset($p["DayTimePhone"]) ? urldecode($p["DayTimePhone"]) : '');    
            $p["userIndexId"] = urldecode($p["userIndexId"]);
            $p["Entered_On"] = urldecode($p["Entered_On"]);
            $ret1 = $this->saveUserInfo($p);
            $ret['errmsg'] = ($ret1 === TRUE) ? '<p>Profile successfully saved.</p>' :  '<p>There was a problem with saving the profile.</p>';
            $ret['result'] = $ret1;
            if(($p["userpassword1"] != "") && ($p["userpassword2"] != "")){
                if($p["userpassword1"] === $p["userpassword2"]){
                    $pwret = $this->changePasswordIn($p);
                    $ret['errmsg'] .= ($pwret['result']=== TRUE) ? '<p>Password successfully changed.</p>' : '<p>There was a problem with changing the password.</p>';
                    $ret['result'] = $pwret['result'];
                }
            }
        }
        else{
            $p["userloginid"] = urldecode($p["userloginid"]);
            $p["user_email"] = urldecode($p["user_email"]);
            $p["userfirstname"] = urldecode($p["userfirstname"]);
            $p["userlastname"] = urldecode($p["userlastname"]);
            $p["userpassword1"] = urldecode($p["userpassword1"]);
            $p["userpassword2"] = urldecode($p["userpassword2"]);
            $p["RPGANumber"] = (isset($p["RPGANumber"]) ? urldecode($p["RPGANumber"]) : '');
            $p["pnotes"] = (isset($p["pnotes"]) ? urldecode($p["pnotes"]) : '');
            $ret1 = $this->insertUserInfo($p,  $p['userpassword1']);
            $ret['errmsg'] =($ret1 === TRUE) ? '<p>Profile successfully saved.</p>' : '<p>There was a problem with saving the profile.</p>';                
            $ret['result'] = $ret1;         
        }
        return $ret;
    }    
    
    //---------------------------------------------------
    //
    //---------------------------------------------------
    private function insertUserInfo($p, $pw, $acclvl=0, $accrate=10){
        $ci = &get_instance();
        $qry = 'INSERT INTO ';
        $qry .= ' ogre_users ';
        $qry .= '(';
        $qry .= 'user_login_id, ';
        $qry .= 'user_email, ';
        $qry .= 'user_password, ';
        $qry .= 'user_passwordhash, ';
        $qry .= 'user_first_name, ';
        $qry .= 'user_last_name, ';
        $qry .= 'user_full_name, ';
        $qry .= 'user_access_rating, ';
        $qry .= 'user_access_rating2, ';
        $qry .= 'user_rpga_number, ';
        $qry .= 'user_date_created';                    
        $qry .= ')';
        $qry .= ' VALUES (';
        $qry .= '"' . $p["userloginid"] . '",';
        $qry .= '"' . strtolower(trim($p["user_email"])) . '", ';
    // ---------------  Encryption HERE                    
        $qry .= '"' . $pw . '", ';
        $qry .= '"' . password_hash($pw, PASSWORD_DEFAULT) . '", ';
    // ---------------                    
        $qry .= '"' . trim($p["userfirstname"]) . '", ';
        $qry .= '"' . trim($p["userlastname"]) . '", ';
        $qry .= '"' . trim($p["userfirstname"]) . ' ' . trim($p["userlastname"]) . '",';
        $qry .= $acclvl .', ';
        $qry .= $accrate .', ';
        $qry .= '"' . $p["RPGANumber"] .'", ';
        $qry .= '"' . date("Y-m-d H:i:s",time()) . '"';
        $qry .= ')';
        $ci->db->query($qry);
        $ret = (($ci->db->affectedRows() > 0) ? TRUE : FALSE);
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    private function saveUserInfo($p){
        $ci = &get_instance();
//        $changedate = date('Y-m-d H:i:s',$p['Entered_On']);
        $qry = 'UPDATE ogre_users SET ';
        $qry .= ' user_login_id = "' . (isset($p["user_login_id"]) ? strtolower(trim($p["user_login_id"])) : '' ). '", ';
        $qry .= ' user_email = "' . (isset($p["user_email"]) ? strtolower(trim(str_replace("'","`",$p["user_email"]))) : '') . '", ';
        $qry .= ' user_first_name = "' . trim(str_replace("'","`", $p["userfirstname"])) . '", ';
        $qry .= ' user_last_name = "' . trim(str_replace("'","`", $p["userlastname"])) . '", ';
        $qry .= ' user_full_name = "' . trim(str_replace("'","`", $p["userfirstname"])) . ' ' . trim(str_replace("'","`", $p["userlastname"])) . '", ';
        $qry .= ' user_notes = "' . (isset($p["usernotes"]) ?  (trim(str_replace("'","`",$p["usernotes"]))) : '') . '", ';
        $qry .= ' user_rpga_number = "' . (isset($p["rpgaNumber"]) ? $p["rpgaNumber"] : '') . '", ';
        $qry .= ' user_address1 = "' . (isset($p["NewStreet1"]) ? str_replace("'","`",$p["NewStreet1"]) : '') . '" ,';
        $qry .= ' user_address2 = "' . (isset($p["NewStreet2"]) ? trim(str_replace("'","`",$p["NewStreet2"])) : ''). '", ';
        $qry .= ' user_city = "' . (isset($p["NewCity"]) ? trim(str_replace("'","`",$p["NewCity"])): '') . '", ';
        $qry .= ' user_state = "' . (isset($p["NewState"])? trim(str_replace("'","`",$p["NewState"])) : '') . '", ';
        $qry .= ' user_zip = "' . (isset($p["NewPostalCode"])? trim(str_replace("'","`",$p["NewPostalCode"])) : '') . '", ';
        $qry .= ' user_country = "' . (isset($p["NewCountry"]) ? trim(str_replace("'","`",$p["NewCountry"])) : ''). '", ';
        $qry .= ' user_phone = "' . (isset($p["DayTimePhone"]) ? str_replace("'","`",$p["DayTimePhone"]) : '') . '", ';
        $qry .= ' user_date_last_modified = NOW()';
        $qry .= ' WHERE user_index_id = ' . $p["userIndexId"];
        $ci->db->query($qry);			
        $ret = ($ci->db->affectedRows() > 0) ? TRUE : FALSE;			
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function changePasswordForm() {                   	
        $ret = '';                 
        $ret .= '<div id="changepassword">';
        $ret .= '<strong>Change Password!!</strong>';
        $ret .= '<label for="userpassword1" class="form-label">New Password</label>';
        $ret .= '<input type="password" class="form-control" id="userpassword1" name="userpassword1" size="15" maxlength="16" autocomplete="off" />';
        $ret .= '<label for="userpassword2" class="form-label">Repeat New Password</label>';
        $ret .= '<input type="password" class="form-control" id="userpassword2" name="userpassword2" size="15" maxlength="16" autocomplete="off" />';
        $ret .= '</div>';
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function changePasswordIn($p){
        $pw1 = $p["userpassword1"];
        $pw2 = $p["userpassword2"];
        $pwOK = TRUE;
        $ret = TRUE;
        $ret = array('result' => TRUE, 'errmsg' => '');
        if (trim($pw1 . $pw2) != ''){
            $goodPW = ( $pw1 == $pw2 ) ? $p["userpassword1"] : $goodPW = '-1';
            if ($goodPW == '-1'){
                $pwOK = FALSE;
                $ret['errmsg'] .= 'Error!  Passwords do not Match!';
            }else{
                $pwOK = TRUE;
                $this->password = $goodPW;
            }
        }
        else{
            $pwOK = FALSE;
            $ret['errmsg']  .= 'Error!  Passwords are blank!';
        }

        if ($pwOK === TRUE){
            $ret['result'] = $this->updatePassword($this->user_id_num, $goodPW);
            $ret['errmsg'] = ($ret['result'] === TRUE) ? 'Password successfully changed': 'Password not changed';
        }
        return $ret;
    }
    
//---------------------------------------------------
//
//---------------------------------------------------    
    public function updatePassword($id=0, $pw=""){
        $ci = &get_instance();
        $qry = 'UPDATE ogre_users ';
        $qry .= ' SET user_password = "' . $pw . '",';
        $qry .= ' user_passwordhash = "' . password_hash($pw, PASSWORD_DEFAULT). '" ';            
        $qry .= ' WHERE user_index_id = ' . $id;
        $ci->db->query($qry); 
        $ret=($ci->db->affectedRows() > 0)?TRUE:FALSE;
        return $ret;
    }    
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function changeLogInIDForm(){
        $ret = '';
        $ret .= '<div id="change-user-login">';
        $ret .= '<h1>Change MY OGRe Log In ID</h1>';
        $ret .= '<form action="' . site_url('ogre/loginid_in','https') . '" method="POST">';
        $ret .= '<div id="change-user-login-table">';
        $ret .= '<p<><strong>Log In ID</strong>:'. $this->user_login_id . '</p>';
        $ret .= '<label for="new-login-id" class="form-label">New Log In ID:';
        $ret .= '<input class="form-control" type="text" id="new-login-id" name="new_loginid" value="' . $this->user_login_id .'" size="30" maxlength="100" />';
        $ret .= '<button class="btn btn-secondary" name="submit-new-id" type="button" onclick="alert('.'"'.'oops!'.'"'.');">Save</button>';
        $ret .= '</form>';
        $ret .= '</div>';
            return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function changeLoginIDIn($p){
        $ci=&get_instance();
        $new1 = $p["new-login-id"];
        $isOK = TRUE;
        $ret = array('result' => TRUE, 'errmsg' => '');
        $isOK = !$ci->ogre_lib->userIDExists($new1, $this->email);
        if ($isOK == TRUE){
            $qry = "UPDATE ogre_users SET user_login_id  = '" . $new1 . "' WHERE user_index_id = " . $this->user_id_num;
            $ci->db->query($qry);
            if ($ci->db->affectedRows() > 0){
                $ret['result'] = TRUE;
                $ret['errmsg'] = 'User ID Changed';
            }
            else{
                $ret['result'] = FALSE;
                $ret['errmsg'] = 'Error while Changing User ID.';
            }
        }
        else{
            $ret['result'] = FALSE;
            $ret['errmsg'] = 'User ID Already Exists.  Try a different one.<input type="button"  class="btn btn-secondary" value="  Back   " onclick="history.back()">';
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function saveUserInfoAdmin($p){
        $ci=&get_instance();
        $changedate = date("Y-m-d H:i:s",$p['Entered_On']);
        $login = trim(urldecode($p['user_login']))!="" ? urldecode($p['user_login']): urldecode($p['user_email']);
        $qry = 'UPDATE ogre_users SET ';
        $qry .= ' user_email = "' . urldecode($p['user_email']) . '", ';
        $qry .= ' user_login_id = "' . strtolower($login) . '", ';
        $qry .= ' user_first_name = "' . quotes_to_entities(urldecode($p["user_first_name"])) . '", ';
        $qry .= ' user_last_name = "' . quotes_to_entities(urldecode($p["user_last_name"])) . '", ';
        $qry .= ' user_full_name = "' . quotes_to_entities(urldecode($p["user_first_name"])) . ' ' . quotes_to_entities(urldecode($p["user_last_name"])) . '", ';
        $qry .= ' user_notes = "' . quotes_to_entities(urldecode($p["pnotes"])) . '", ';
        $acclvl = $this->processAccessLevel($p['accessrating'], 1);
        $qry .= ' user_access_rating = ' . $acclvl . ', ';
        $accrate = $this->processAccessLevel($p['accessrating'], 2);
        $qry .= ' user_access_rating2 = ' . $accrate . ', ';                        
        $qry .= ' user_date_last_modified = "' . $changedate . '"';
        $qry .= ' WHERE user_index_id = ' . $p['userIndex'];
        $ci->db->query($qry);
        $ret = ($ci->db->affectedRows() > 0)? TRUE: FALSE;
        if (intval($acclvl) == 0){
            $ret2 = $this->resetUserAccessAdmin($p['userIndex']);
            $access = abs($p['accessrating']);
            $verif = ($access != 0) ? 1 : 0;
            $ret2 = ($verif == 1) ? $this->activate($access): $this->deactivate($p['conid']);
        }else{
            $ret2 = $this->deactivate($p['conid']);
        }
        $ret1 = $ret && $ret2;	
        return $ret1;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function resetUserAccessAdmin($pid){
        $ci=&get_instance();
        $qry = 'UPDATE ogre_users SET ';
        $qry .= ' user_access_rating = 0 , ';
        $qry .= ' user_access_rating2 = 10 ';                        
        $qry .= ' WHERE user_index_id = ' . $pid;
        $ci->db->query($qry);
        $ret = ($ci->db->affectedRows() > 0)? TRUE: FALSE;
        return $ret;
    }    

//-----------------------------------
//
//-----------------------------------
    function insertNewUserAdmin($p){
        $ci = &get_instance();
        $pw1 = substr($p["user_email"],0, 6);
        $pw1 = str_replace("@",mt_rand(1,10),$pw1);
        $pw1 = strtolower(str_shuffle($pw1));
        $login = trim($p['user_login'])!="" ? trim($p['user_login']) : trim($p['user_email']);
        $qry = 'INSERT INTO ogre_users (';
        $qry .= 'user_email, ';
        $qry .= 'user_login_id, ';
        $qry .= 'user_password, ';
        $qry .= 'user_passwordhash, ';
        $qry .= 'user_first_name, ';
        $qry .= 'user_last_name, ';
        $qry .= 'user_full_name, ';
        $qry .= 'user_access_rating, ';
        $qry .= 'user_access_rating2, ';
        $qry .= 'user_date_created  )';
        $qry .= ' VALUES (';
        $qry .= '"' . $p['user_email'] . '", ';
        $qry .= '"' . $p['user_login'] . '", ';
        $qry .= '"' . $pw1 . '", ';
        $qry .= '"' . password_hash($pw1,PASSWORD_DEFAULT) . '", ';
        $qry .= '"' . $p['user_first_name'] . '", ';
        $qry .= '"' . $p['user_last_name'] . '", ';
        $qry .= '"' . $p['user_first_name'] . ' ' . $p['user_last_name'] . '", ';
        $levelaccess = $this->processAccessLevel($p['accessrating'], 1);
        $qry .= $levelaccess .', ';
        $access = $this->processAccessLevel($p['accessrating'], 2);
        $qry .= $access . ', ';
        $qry .= '"' . date('Y-m-d H:i:s',time()) . '")';
        $ci->db->query($qry);
        $ret = (($ci->db->affectedRows() > 0) ? TRUE : FALSE);      
        $newid = $ci->db->insertID();
        $this->get($newid);
        if (intval($p['accessrating']) < 0){
            $verif = ($access != 0 )? 1 : 0;
            $ret2 = ($verif == 1) ? $this->activate($access): TRUE;
        }else{
            $ret2 = TRUE;
        }
        return $ret && $ret2;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function processAccessLevel($ar=0, $lvl=1){
        $ci = &get_instance();
        $arval = intval($ar);
        $orgid = $ci->session->get('ogre_orgid');
        switch($arval){
            case ($ar == 0):
                $ret = ($lvl == 1) ? 0 : 10;
                break;
            case ($ar < 0):  // Convention Level
                $ret = ($lvl == 1) ? 0 : abs($ar);
                break;
            case ($ar > 0 && $ar <= 100):  // Organization Level
                $ret = ($lvl == 1) ? $orgid : abs($ar);
                break;
            case ($ar > 100): //System level
                $ret = ($lvl == 1) ? -1 : abs($ar) - 100;
                break;            
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function codeActivation($tranxid, $emailaddress, $access=PLAYER){
        $ci=&get_instance();
        $vld = FALSE;
        $ret1 = FALSE;
        $conid = $ci->session->get('ogre_conid');
        $qry = 'SELECT ogre_paypal_cart_info.txnid, ';
        $qry .= ' ogre_paypal_cart_info.ppci_buyer_email,';
        $qry .= ' ogre_paypal_cart_info.ppci_conid';
        $qry .= ' FROM ogre_paypal_cart_info ';
        $qry .= ' WHERE UCASE(txnid) = "' . strtoupper(trim($tranxid)) . '"';
        $qry .= ' AND LCASE(ppci_buyer_email) = "' . strtolower(trim($emailaddress)) . '"';
        $qry .= ' AND ppci_conid = ' . $conid;
        $query = $ci->db->query($qry);
        if($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $conid = $row->ppci_conid;
                $vld = $this->validateRegistration($row);
            }
            $ret1 = ($vld==TRUE) ? $this->activate($access, $conid) :  FALSE;
        }
        $ret=($ret1===TRUE) ? $conid : 0;
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function codeActivationOnsite($code){
        $ci = &get_instance();
        $ret1 = FALSE;
        $conid = $ci->session->get('ogre_conid');
        $orgid = $ci->session->get('ogre_orgid');
        $onsitecode = $ci->ogre_lib->getConfigKey('ONSITE.ACTIVATION.CODE',$orgid,$conid);
        if(trim($code) != ''){
            if (strtoupper(trim($code)) == strtoupper(trim($onsitecode))){
            $ret1 = $this->activate(10, $conid);
            }
        }
        $ret = ($ret1===TRUE) ? $conid : 0;
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getTransactionID($email){
        $ci=&get_instance();  ;
        $conid = $ci->session->get('ogre_conid');
        $id = '';
        $qry = 'SELECT DISTINCT ogre_paypal_payment_info.buyer_email, ogre_paypal_payment_info.txnid ';
        $qry .= ' FROM ogre_paypal_cart_info ';
        $qry .= ' INNER JOIN ogre_paypal_payment_info ';
        $qry .= ' ON ogre_paypal_cart_info.txnid = ogre_paypal_payment_info.txnid ';
        $qry .= ' WHERE ogre_paypal_payment_info.buyer_email="' . $email . '" ';
        $qry .= ' AND ogre_paypal_cart_info.ppci_conid=' . $conid;   

        $query = $ci->db->query($qry);
         if($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $id .= $row->txnid . ' ,';
            }
        }
        else{
              $id = '';
        }
        return $id;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function emailTransaction($id, $email){
        $ci=&get_instance();
        $conid = $ci->session->get('ogre_conid');
        $ci->convention->init($conid);
        $gc = $ci->ogre_lib->getConGamingInfoKey($conid, "con_gamingcoordinatoremail");
        $mailmsg['from_eaddress']= $gc;
        $mailmsg['to_eaddress1'] = $email;
        $mailmsg['to_eaddress2'] = '';
        $mailmsg['to_eaddress3'] = '';
        $mailmsg['cc_eaddress'] = '';
        $msg = $ci->convention->name . ' OGRe Activation Code: ';
        $trans=explode(',', $id);
        foreach ($trans as $tid){ 
            $msg .=  ' <br /> ' . $tid;
        }
        $mailmsg['body'] = $msg;
        $mailmsg['subject'] = 'OGRe Activation Code';
        $mailmsg['sent_errmsg'] = 'Unable to send email.  Invlaid Email address';
        $mailmsg['sent_msg'] = 'OGRe Activation Code email sent.';
        return $mailmsg;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function validateRegistration($reg){
        $ci=&get_instance();
        $conid = $ci->session->get('ogre_conid');
        $ci->convention->init($conid);
        $qry = 'SELECT txnid, ppi_name, expired, itemnumber, ppi_itemcode, ppi_type_id, ppi_orgid ';
        $qry .= ' FROM ogre_paypal_cart_info INNER JOIN ogre_paypalitem ';
        $qry .= ' ON ogre_paypal_cart_info.itemnumber = ogre_paypalitem.ppi_itemcode ';
        $qry .= ' WHERE ogre_paypalitem.ppi_conid = ' . $conid;
        $qry .= ' AND ogre_paypal_cart_info.txnid = "' . $reg->txnid . '"';
        $qry .= ' AND ogre_paypal_cart_info.expired = 0';
        $query = $ci->db->query($qry);
        $ret = ($query->getNumRows() > 0) ? TRUE: FALSE;
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function expireCode($tranxid, $actconid){
        $ci=&get_instance();
        if ($this->user_id_num===0){
            $pid = $ci->session->get('ogre_user_ID'); 
            $this->init($actconid,'',$pid);
        }
        $qry = 'SELECT ogre_paypal_cart_info.ppci_id, ogre_paypal_cart_info.txnid ';
        $qry .= 'FROM ogre_paypal_cart_info WHERE UCASE(txnid) = "' . strtoupper(trim($tranxid)) . '" AND expired = ' . $this->user_id_num . ';';
        $query = $ci->db->query($qry);
        if($query->getNumRows() == 0){
            $qry = 'SELECT ogre_paypal_cart_info.ppci_id, ogre_paypal_cart_info.txnid ';
            $qry .= 'FROM ogre_paypal_cart_info WHERE UCASE(txnid) = "' . strtoupper(trim($tranxid)) . '" AND expired = 0;';
            $ret = FALSE;
            $i = 0;
            $query = $ci->db->query($qry);
            if($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                   if ($i == 0){
                        $upt = 'UPDATE ogre_paypal_cart_info SET ogre_paypal_cart_info.expired =  ' . $this->user_id_num;
                        $upt .= ' WHERE ogre_paypal_cart_info.ppci_id = ' . $row->ppci_id;
                        $ci->db->query($upt);
                        if ($ci->db->affectedRows() > 0){
                            $ret = TRUE;
                            $i++;
                        }
                   }

                }
             }

             if ($i == 0){
                 $ret = FALSE;
             }
        }
        else{
             $ret = FALSE;
        }
        return $ret;
    }

//---------------------------------------------------
//
//---------------------------------------------------
    public function activate($access=PLAYER, $conid=0){			
        $ci=&get_instance();                 
        $id = $this->user_id_num; 
        if($conid===0){
            $conid = $ci->session->get('ogre_conid');
        }
        $qry = 'SELECT * FROM ogre_user_verified ';
        $qry .= 'WHERE uv_user_id = ' . $id;
        $qry .= ' AND uv_con_id = ' . $conid . ';';
        $query = $ci->db->query($qry);
        if($query->getNumRows() == 0){
            $insrt = 'INSERT ogre_user_verified  ( ';
            $insrt .= 'uv_user_access_rating2,';
            $insrt .= 'uv_user_id,';
            $insrt .= 'uv_con_id';
            $insrt .= ') ';
            $insrt .= 'VALUES (' ;
            $insrt .= $access . ', ';
            $insrt .= $id . ',';
            $insrt .= $conid;
            $insrt .= ');';
            $ci->db->query($insrt);
            $ret =($ci->db->affectedRows() > 0)? TRUE:FALSE;
        }
        else{
            $update = 'UPDATE ogre_user_verified SET ';
            $update .= 'uv_user_access_rating = ' . $access . ', ';
            $update .= 'uv_user_access_rating2 = ' . $access . ' ';
            $update .= 'WHERE uv_con_id = ' . $conid . ' AND ';
            $update .= 'uv_user_id = ' . $id;
            $ci->db->query($update);

            $ret= ($ci->db->affectedRows() > 0)? TRUE : FALSE;
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function deactivate($conid){
        $ci=&get_instance();
        $id = $this->user_id_num;
        $ret = TRUE;
        $qry = 'SELECT * FROM ogre_user_verified ';
        $qry .= ' WHERE uv_user_id = ' . $id;
        $qry .= ' AND uv_con_id = ' . $conid . ';';
        $query = $ci->db->query($qry);
        if($query->getNumRows() != 0){
            $del = 'DELETE ogre_user_verified.* FROM ogre_user_verified ';
            $del .= ' WHERE uv_user_id = ' . $id . ' AND uv_con_id = ' . $conid . ';';
            $ci->db->query($del);
            $ret = (($ci->db->affectedRows() > 0)? TRUE : FALSE);
        }			
        return $ret;		
    }

//---------------------------------------------------
//
//---------------------------------------------------
    public function emailActivation($conid=0){
        $ci=&get_instance();
        if($conid===0){
            $conid = $ci->session->get('ogre_conid');
        }
        $ogrewebsite = base_url();
        $conname = $ci->ogre_lib->getConGamingInfoKey($conid, "con_name");
        $conwebsite = $ci->ogre_lib->getConGamingInfoKey($conid, "con_website");
        $gamingcoemail = $ci->ogre_lib->getConGamingInfoKey($conid, "con_gamingcoordinatoremail"); 
        $msg = $ci->ogre_lib->getMiscContent('%OGREACTIVATIONEMAIL%');
        $msg['content'] = str_replace('%OGREWEBSITE%', $ogrewebsite, $msg['content']);
        $msg['content'] = str_replace('%CONNAME%', $conname, $msg['content']);
        $msg['content'] = str_replace('%CONWEBSITE%', $conwebsite, $msg['content']);
        $msg['content'] = str_replace('%GAMINGCOEMAIL%', $gamingcoemail, $msg['content']);

        $mailmsg['from_eaddress']= $ci->ogre_lib->getConGamingInfoKey($conid, "con_gamingcoordinatoremail");
        $mailmsg['to_eaddress1'] = $this->email;
        $mailmsg['subject'] = $ci->ogre_lib->getConGamingInfoKey($conid, "con_name") . ' OGRe Activation Confirmation';
        $mailmsg['body'] = $msg['content'];
        $mailmsg['sent_errmsg'] = '';
        $mailmsg['sent_msg'] = '<p>Activation Confirmation Sent.</p>';
        return $mailmsg;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function displayMySchedule($conid, $pid=0){
        $ci=&get_instance();
        $ret = '';
        $pid = ($pid == 0) ? $this->user_id_num : $pid;
        $this->get($pid);
        if (trim($this->game_id_list) != ""){
            $gl = explode(",", $this->game_id_list);
            $qry = "SELECT ogre_gameschedule.*, ogre_preregistergamelist.*, ogre_prereg_player.* ";
            $qry .= "FROM (ogre_gameschedule LEFT JOIN ogre_preregistergamelist ON ogre_gameschedule.gs_id = ogre_preregistergamelist.pgl_gs_id) ";
            $qry .= "INNER JOIN ogre_prereg_player ON ogre_gameschedule.gs_id = ogre_prereg_player.pp_gs_id ";
            $qry .= " WHERE ogre_prereg_player.pp_delete_flag = 0 AND ogre_gameschedule.gs_convention_id = " . $conid;
            $qry .= " AND ogre_prereg_player.pp_player_email = '" . $this->email . "' AND (";
            $i = 1;
            foreach ($gl as $gameid){
                if (trim($gameid) != ""){
                    $qry .=  (($i == 1) ? "gs_id = " . $gameid : " OR gs_id = " . $gameid);
                }
                $i++;
            }
            $qry .= ') ORDER BY ogre_gameschedule.gs_slot_code ';

            $query = $ci->db->query($qry);
            $hrstotal = 0;
            if ($query->getNumRows() > 0){
                $ret .= '<form name="my-schedule">';
                $ret .= '<table class="table table-hover" width="100%">';
                $ret .= '<tr>';
                $ret .= '<th scope="col">OGRe Event ID</th>';
                $ret .= '<th scope="col">Day/Time - Game/Title (Location)</th>';
                $ret .= '<th scope="col">Drop Out</th>';	
                $ret .= '<th scope="col">Plyrs</th>';
                $ret .= '</tr>';
                foreach ($query->getResult() as $row){
                    $color = ((abs($row->pp_gm_judge_flag) == 1) ? 'class="table-primary"' : $color = "");
                    $ret .= '<tr ' . $color . ' id="mysched'.$row->gs_id.'">';
                    $ret .= $this->displayMyScheduleRow($conid, $row);
                    $ret .= '</tr>';
                    $hrstotal = ((abs($row->pp_gm_judge_flag) == 1) ? $hrstotal + $row->gs_slot_length : $hrstotal + 0);
                }
            $ret .= '</table>';
            $ret .= '</form>';
            $ret .= '<p class="card-text">';
            $ret .= $ci->ogre_lib->getMiscContent('%LIGHTBLUEMEANSGM%', 0, TRUE);
            $ret .= '</p>';            
            if (intval($this->access_rating) > 10){
                    $this->totalGMhours = floatval($hrstotal);
                }
            }   
        }else{
            $ret .= '<div id="my-ogre-schedule">';
            $ret .= '<h4>' . strip_tags($ci->ogre_lib->getMiscContent('%NOCURRENTSCHEDULE%', 0, TRUE)) . '</h4>';
            $ret .= '</div>'; 
        }
        
         if(floatval($this->totalGMhours) > 0){
            $ret .= '<div class="alert alert-success">';           
            $ret .= '<p class="card-text">';
            $ret .= 'TOTAL GM HOURS: ' . $this->totalGMhours . ' hours.'; 
            $ret .= '</p>'; 
            if (floatval($this->totalGMhours) > 3 && floatval($this->totalGMhours) < 10){
                $ret .= '<p class="card-text">';
                $ret .= $ci->ogre_lib->getMiscContent('%THANKYOUFORGMING%', 0, TRUE);
                $ret .= '</p>';
            }
            $ret .= '</div>';
              
         }       
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function displayMyScheduleRow($conid, $row){
        $ci=&get_instance();
        $ret = '';
        $rowrefresh = site_url('ogrex/refresh_myschedulerow/'.$row->gs_id);
        $rowdiv = 'mysched'.$row->gs_id;
        $girefresh = site_url('ogrex/gameInfoRefresh/'.$row->gs_id,'https');
        $gidiv ='game-info-dialog';
        $ginfo = site_url('ogrex/getGameInformation','https');
        $vmode = 'MAIN';
        $regbuttons = 'ogrex/gameRegDialog/' . $row->gs_id;
        $remaction = site_url('ogrex/preregActionX/' . $row->gs_id . '/TRUE/TRUE','https');
        
        $ret .= '<td align="center">';
        $ret .= str_pad($row->gs_id, 6,"0",STR_PAD_LEFT);
        $ret .= '</td>';   
        $ret .= '<td>';      
        $slottime = str_replace(" AM", "a", str_replace(" PM", "p", str_replace("***", "10:", str_replace(":3", ":30", str_replace("0", "", str_replace("10:", "***", str_replace(":00", "", $row->gs_slot_time)))))));
        $gname = '<strong>' . substr($row->gs_slot_day,0,3) . " " . $slottime . '</strong>'  .': ' ;
        $gname .= $row->gs_game_name . ((trim($row->gs_game_title) != '') ? ' - <em>' . $row->gs_game_title . '</em>': '');
        $gname .= ' (' . ($row->gs_table_number!='-' ? $row->gs_table_number : $row->gs_location_name) . ')';
        $ret .= $gname;
        $ret .= '</td>';       
        $ret .= '<td align="center">';
        $daction = site_url('ogrex/removePlayerMyschedule','https');
        $raction = site_url('ogrex/refreshMySchedule','https');
        if($row->gs_mmrpgFlag == 0){
            $ret .= (abs($row->pp_gm_judge_flag) != "1") ? '<input type="Checkbox" name="removebutton' . $row->gs_id . '" value ="' . $row->gs_id . '" onclick="removePlayerMySchedule('.$this->user_id_num .','. $row->gs_id.','."'".$daction."'".','."'".'my-ogre-schedule'."'".','."'".$raction."',"."'',''".');" />' : "&nbsp;";
        }else{
            $ret .= '<input type="Checkbox" name="removebutton' . $row->gs_id . '" value ="' . $row->gs_id . '"  onclick="removePlayerMySchedule('.$this->user_id_num .','. $row->gs_id.','."'".$daction."'".','."'".'my-ogre-schedule'."'".','."'".$raction."',"."'',''".');" />';
        }
        $ret .= '</td>';
        $ret .= '<td align="center">';
        $ret .= $this->getNumberOfPlayers($row->gs_id);
        $ret .= '</td>';
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function displayJQUIMySchedule($pid,$conid,$past){    
        $ci=&get_instance();
        $ret = '';        
        $cconid = 0;
        $gs = '';
        $i=1;
        $ret .= ($past===TRUE) ? '<h4>My Schedule History</h4>' : '<h4>My Schedule</h4>';
        $ret .= '<div id="editdiv"></div>';
        $this->get($pid);
        $conlist = $this->getMyConList($pid,$conid,$past);
        if ($conlist !== NULL){
            $ret .= '<div id="accordion-con" class="jqui-accordion">';    
            foreach ($conlist as $citem){
                if($cconid !== 0 ){
                    if ((intval($cconid) !== intval($citem['conid']))){
                    $ret .= $this->getMyJQUIConSchedule($gs, $i, $pid, $past);
                        $gs = '';
                        $ret .= '</div>';
                    }           
                }
                
                if (intval($cconid) !== intval($citem['conid'])){
                    $ret .= '<h3>'. $citem['con_name']. '</h3>';
                    $ret .= '<div>';
                }    
                $gs .= $citem['gsid'].',';
                $cconid = $citem['conid'];
                $i++;
            }
            $ret .= $this->getMyJQUIConSchedule($gs, $i, $pid, $past);
            $gs = '';
            $ret .= '</div>';
            $ret .= '</div>';
        }        
        return $ret;
    }   
//---------------------------------------------------   
//
//---------------------------------------------------
    public function getMyJQUIConSchedule($gsid, $i, $pid, $past){    
        $ci=&get_instance();     
        $ret = '';        
        $cconid = 0;
        $gs = '';
        $orgid  = $ci->session->ogre_orgid;
        $ar = $ci->session->get('ogre_user_accesslevel_' . $orgid);  
        $userid = $ci->session->ogre_user_ID;
        $editaction = site_url('ogrex/gameEditX');
        $daction = site_url('ogrex/removePlayerMyschedule','https');
        $raction = site_url('ogrex/refreshMySchedule','https');
        $rdaction = site_url('ogrex/getMySchedule','https');     
//        $ret .= '<input type="hidden" id="game-id-list" value="" />';
        $ret .= '<div id="accordion2-'.$i.'" class="jqui-accordion">';
        if ($gsid !== ''){
            $gs = explode(',', $gsid);
            foreach ($gs as $id){
                if($id !== ''){
                    $ci->event->event_init($id);
                    $role = $ci->event->isPlayerGM($pid, $id);
                    $roletitle = ((intval(abs($role))== 1)?'GM':'Player');
                    $ret .= '<h3>'.$ci->event->slot_day . ' ' . $ci->event->slot_time . ': ' . $ci->event->game_name . ' ['.$roletitle.']'.'</h3>';
                    $ret .= '<div id="my-schedule-profile-'.$ci->event->id.'">';
                    if ($past !== TRUE){
                        $ret .= '<div class="row">';
                        $ret .= '<div class="col text-end mb-2">';
                        $ret .= '<div class="btn-group float-end" role="group" aria-label="Game Buttons">';
                        $drop = (intval($role) == 0) || ((intval($ci->event->mmrpgFlag) == 1) && (abs(intval($role)) == 1));
                        $ret .= '<button type="button" class="btn btn-secondary"' . ((intval($drop) == TRUE) ? '' : ' disabled ' ) . ' onclick="return removePlayerMySchedule('.$userid .','. $id.','."'".$daction."'".','."'".'my-ogre-schedule'."'".','."'".$raction."','dialog','".$rdaction."'".');">Drop Out</button>';
                        $edit = (intval($role) == 1);
                        $ret .= '<button type="button" class="btn btn-secondary" onclick="return editMyGame('."'".$editaction."',".$id.','."'".'editdiv'."'".');" ' . ((intval($edit) == TRUE) ? '' : ' disabled ' ) . '>Edit</button>';
                        $ret .= '</div>';
                        $ret .= '</div>';
                        $ret .= '</div>';
                    }
                    $mraction = site_url('ogrex/markMessagesRead','https');
                    $ret .= '<div id="my-schedule-tabs-'.$ci->event->id.'" class="jqui-tabs">';
                    $ret .= '<ul>';
                    $ret .= '<li><a href="#tabs-1">Game Info</a></li>';
                    $ret .= '<li><a href="#tabs-2" onclick="markMessagesRead('."'".$mraction."'".','. $userid.', '.$id.');">Comments</a>';
                    $unread = $this->getUnreadMessagesSingleGame($id) + $this->getUnreadMessagesSingleGameReplies($id); 
//----------------------                    
                    $ret .= '<span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="my-schedule-tab-msg-count-'.$ci->event->id.'">'.$unread.'</span>';  //<span class="visually-hidden">unread messages</span>
//----------------------                    
                    $ret .= '</li>';
                    $ret .= '</ul>';
                    $ret .= '<div id="tabs-1">';
                    $ret .= $ci->schedule_lib->gameInfoDialogBoot($id, "P");
                    $ret .= '</div>';
                    $ret .= '<div id="tabs-2">';
                    $role = $ci->event->isPlayerGM($userid, $id);
                    if($role == 1){
                      $ret .= $ci->event->getEventCommentsGMView($id, !$past);      // $ci->ogre_lib->bootCard('bg-light',,'my-schedule-comments','Comments') $type, $text='', $id='', $title='', $stitle='', $footer='' 
                    }elseif($role == 0){
                      $ret .= '<div id="prereg-edit-comments-'.$id.'">';
                      $ret .= $ci->event->getEventComments($id);            //$ci->ogre_lib->bootCard('bg-light',,'my-schedule-comments','Comments')
                      $ret .= '</div>';
                      $ret .= (($past === FALSE) ? $ci->event->buildRegistrationFormRegularCommentsX($id, TRUE) : '');

                    }
                    $ret .= '</div>';
                    $ret .= '</div>';
                    $ret .= '</div>';
                }
            }
        }
        $ret .= '</div>';        
        return $ret;
    }    
    
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function displayBootMySchedule($pid,$conid,$past){    
        $ci=&get_instance();
        $ret = '';        
        $cconid = 0;
        $gs = '';
        $i=1;
        $ret .= ($past===TRUE) ? '<h4>My Schedule History</h4>' : '<h4>My Schedule</h4>';
        $ret .= '<div id="editdiv"></div>';
        $ret .= '<div id="accordion-con">';
        $this->get($pid);
        $conlist = $this->getMyConList($pid,$conid,$past);
        if ($conlist !== NULL){
            foreach ($conlist as $citem){
                if ((intval($cconid) !== intval($citem['conid'])) && ($cconid !== 0 )){
                    $ret .= $this->getMyConSchedule($gs, $i, $pid, $past);
                    $gs = '';
                    $ret .= '</div>';
                    $ret .= '</div>';
                    $ret .= '</div>';
                    $ret .= '</div>';
                }                
                
                if (intval($cconid) !== intval($citem['conid'])){
                    $ret .= '<div class="accordion" id="accordion-con-'.$citem['conid'].'">';
                    $ret .= '<div class="accordion-item">';
                    $ret .= '<h5 class="accordion-header" id="heading-'.$citem['conid'].'">';
                    $ret .= '<button class="accordion-button '.(($past===TRUE) ?'collapsed':'show').'" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-'.$citem['conid'].'" aria-expanded="'.(($past===TRUE) ?'false':'true').'" aria-controls="collapse-'.$citem['conid'].'">';
                    $ret .= $citem['con_name'];
                    $ret .= '</button>';
                    $ret .= '</h5>';
                    $ret .= '<div id="collapse-'.$citem['conid'].'" class="accordion-collapse '.(($past===TRUE) ?'collapsed':'show').'" aria-labelledby="heading-'.$citem['conid'].'" data-bs-parent=="#accordion-con-'.$citem['conid'].'">';
                    $ret .= '<div class="accordion-body">';
                    
                }    
                $gs .= $citem['gsid'].',';
                $cconid = $citem['conid'];
                $i++;
            }
            $ret .= $this->getMyConSchedule($gs, $i, $pid, $past);
            $gs = '';
            $ret .= '</div>';
            $ret .= '</div>';
            $ret .= '</div>';
            $ret .= '</div>';                     
        }
        $ret .= '</div>';
        return $ret;
    }
//---------------------------------------------------   
//
//---------------------------------------------------
    public function getMyConSchedule($gsid, $i, $pid, $past){    
        $ci=&get_instance();
        $ret = '';        
        $cconid = 0;
        $gs = '';
        $orgid  = $ci->session->ogre_orgid;
        $ar = $ci->session->get('ogre_user_accesslevel_' . $orgid);  
        $userid = $ci->session->ogre_user_ID;
        $ret .= '<div id="accordion2-'.$i.'">';
        if ($gsid !== ''){
            $gs = explode(',', $gsid);
            foreach ($gs as $id){
                if($id !== ''){
                    $ci->event->event_init($id);
                    $role = $ci->event->isPlayerGM($pid, $id);
                    $ret .= '<div class="accordion" id="accordian-game-'.$id.'">';
                    $ret .= '<div class="accordion-item">';
                    $ret .= '<h6 class="accordion-header" id="heading-game-'.$id.'">';
                    $ret .= '<button class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapse-game'.$id.'" aria-expanded="true" aria-controls="collapse-game'.$id.'">';
                    $ret .= $ci->event->slot_day . ' ' . $ci->event->slot_time . ': ' . $ci->event->game_name . ' ['.((intval(abs($role))== 1)?'GM':'Player').']';
                    $ret .= '</button>';
                    $ret .= '</h6>';
                    $ret .= '<div id="collapse-game'.$id.'" class="collapse collapsed" aria-labelledby="heading-game-'.$id.'" data-bs-parent="#accordian-game-'.$id.'">';
                    $ret .= '<div class="accordion-body">';
                    $ret .= '<div class="row">';
                    $ret .= '<div class="col-6"></div>';
                    $ret .= '<div class="col-6">';
                    $ret .= '<div class="btn-group float-end" role="group" aria-label="Game Buttons">';
                    if ($past !== TRUE){
                        $drop = (intval($role) == 0) || ((intval($ci->event->mmrpgFlag) == 1) && (abs(intval($role)) == 1));
                        $editaction = site_url('ogrex/gameEditX');
                        $daction = site_url('ogrex/removePlayerMyschedule','https');
                        
                        $raction = site_url('ogrex/refreshMySchedule','https');
                        $rdaction = site_url('ogrex/getMySchedule','https');
                        
                        $ret .= '<button type="button" class="btn btn-secondary"' . ((intval($drop) == TRUE) ? '' : ' disabled ' ) . ' onclick="return removePlayerMySchedule('.$userid .','. $id.','."'".$daction."'".','."'".'my-ogre-schedule'."'".','."'".$raction."','dialog','".$rdaction."'".');">Drop Out</button>';
                        $edit = (intval($role) == 1);
                        $ret .= '<button type="button" class="btn btn-secondary" onclick="return editMyGame('."'".$editaction."',".$id.','."'".'editdiv'."'".');" ' . ((intval($edit) == TRUE) ? '' : ' disabled ' ) . '>Edit</button>';
                    }
                    $ret .= '</div>';
                    $ret .= '</div>';
                    $ret .= '</div>';
                    $ret .= '<p class="card-title font-italic font-weight-bold">'.strip_tags($ci->event->game_title).'</p>';
                    $ret .= '<p class="card-text">'.strip_tags($ci->event->game_notes).'</p>';
                    $ret .= '<p class="card-text">'.strip_tags($ci->event->game_desc).'</p>';
                    $ret .= '<p class="card-text">GM/Player List</p>';
                    $allowed = $ci->event->getPreregPlayersAllowed($id);
                    
                    $withemail = ($role != -999) ? (($role == 0)? FALSE : TRUE) : FALSE;
                    $withemail = (intval($ar) >= CONADMIN) ? TRUE : $withemail;
                    $numTotlPlayers = $ci->event->getPlayerNum($id, $allowed);
                        
                    $ret .= $ci->schedule_lib->genPlayeList($id, $ci->event->getPlayerList(1, $id), $numTotlPlayers, $withemail, 1);

                    $ret .= $ci->schedule_lib->genPlayeList($id, $ci->event->getPlayerList(0, $id), $numTotlPlayers, $withemail, 0);
                    $ret .= '</div>';
                    $ret .= '</div>';
                    $ret .= '</div>';
                    $ret .= '</div>';
                }
            }
        }
        $ret .= '</div>';
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------    
    public function getMyConList($pid,$conid,$past){
        $sql='';
        $ret = array();
        $ci = &get_instance();
        $orgid  = $ci->session->ogre_orgid;
        $conid  = $ci->session->ogre_conid;
        $i = 0;
        $sql .= 'SELECT ogre_gameschedule.gs_convention_id, ogre_convention.con_start_date, ogre_convention.con_name, ogre_prereg_player.pp_gs_id,ogre_prereg_player.pp_gm_judge_flag ';
        $sql .= ' FROM ((ogre_users INNER JOIN ogre_prereg_player ON ogre_users.user_index_id = ogre_prereg_player.pp_player_id) ';
        $sql .= ' INNER JOIN ogre_gameschedule ON ogre_prereg_player.pp_gs_id = ogre_gameschedule.gs_id) ';
        $sql .= ' INNER JOIN ogre_convention ON ogre_gameschedule.gs_convention_id = ogre_convention.con_id';
        $sql .= ' WHERE ogre_users.user_index_id =  ' . $pid;
        $sql .= ' AND ogre_convention.con_org_id = ' . $orgid;
        if($past === TRUE){
            $sql .= ' AND ogre_convention.con_id <> ' . $conid;
        }
        else{
            $sql .= ' AND ogre_convention.con_id = ' . $conid;
        }
        $sql .= ' AND ogre_gameschedule.gs_date_created <= ogre_convention.con_end_date ';
        $sql .= ' AND ogre_gameschedule.gs_cancelled <> 1 ';
        $sql .= ' AND ogre_prereg_player.pp_delete_flag <> 1 ';
        $sql .= ' ORDER BY ogre_convention.con_start_date, ogre_gameschedule.gs_slot_code ;';
 
        $query = $ci->db->query($sql);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $ret[$i]['conid'] = $row->gs_convention_id;
                $ret[$i]['con_name'] = $row->con_name;
                $ret[$i]['gsid'] = $row->pp_gs_id;
                $ret[$i]['GM'] = $row->pp_gs_id;
                $i++;
            }
        }   
        else{
            $ret = NULL;
        }    
        return $ret;
    }
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function displayPlayerSchedule($print, $gpo=FALSE){
        $ci = &get_instance();   
        $conid = $ci->session->ogre_conid;
        $orgid  = $ci->session->ogre_orgid;
        $userid = $ci->session->ogre_user_ID;    
        $this->init($conid, '', $userid);
        $atts1 = array(
          'width'      => '640',
          'height'     => '480',
          'scrollbars' => 'yes',
          'status'     => 'no',
          'resizable'  => 'yes',
          'screenx'    => '0',
          'screeny'    => '0'
        );
        $atts2 = array(
          'width'      => '640',
          'height'     => '480',
          'scrollbars' => 'yes',
          'status'     => 'no',
          'resizable'  => 'no',
          'screenx'    => '0',
          'screeny'    => '0'
        );
        $now_date = new Time();
        $ret = '';
        $close_date =  $ci->ogre_lib->getConGamingInfoKey($conid, 'con_gaming_reg_close_date');
        $close_date = new Time($close_date);
        $this->game_id_list = $this->getPlayerSchedule($conid);
        if (trim($this->game_id_list) != ""){
            $gl = explode(",", $this->game_id_list);
            $i = 1;
            $hrstotal = 0;
            $rcount = 1;
            if (trim($this->game_id_list) != ""){
                $ret = '<div id="my-schedule" style="text-align: center">';
                $ret .= '<h2>';
                $ret .= '<strong>My Game Schedule</strong>';
                $ret .= '</h2>';
                if ($print == FALSE){
                    $ret .= '<div style="text-align: right">';
                    $ret .= '<a href="' . site_url('ogre_pdf/pdfMyscedule','https'). '/' . $this->user_id_num . '" rel="_blank">';
                    $ret .= 'Printable Version';
                    $ret .= '</a>';
                    $ret .= '&nbsp;&nbsp;';
                    $ret .= '<a href="' . site_url('ogre_pdf/pdfTickets','https'). '/' . $this->user_id_num . '" rel="_blank">';
                    $ret .= 'Print Tickets';
                    $ret .= '</a>';
                    $ret .= '</div>';
                }                                        
                $ret .= '<form id="my-schedule" name="my-schedule" action="' . site_url('ogre/myschedule_re/','https') . '" method="post">';
                $ret .= '<table class="padded-table2px"  width="100%" align="center" border="1" cellpadding="0" bordercolor="#000000" cellspacing="0">'; //
                $ret .= '<tr>';
                $ret .= '<th>';
                $ret .= 'Day/Time';
                $ret .= '</th>';
                $ret .= '<th>';
                $ret .= 'Table';
                $ret .= '</th>';
                $ret .= '<th>';
                $ret .= 'Game/Title';
                $ret .= '</th>';
                $ret .= '<th>';
                $ret .= 'Role';
                $ret .= '</th>';
                if ($print == FALSE){
                    $ret .= '<th>';
                    $ret .= 'Edit';
                    $ret .= '</th>';
                }
                $ret .= '<th>';
                $ret .= 'Plyrs';
                $ret .= '</th>';
                $ret .= '</tr>';
                foreach ($gl as $gameid){
                    if (trim($gameid) != ""){
                        $ci->event->event_init($gameid);
                        $gm_flag = $ci->event->isPlayerGM($this->user_id_num);
                        $color =  (abs(intval($gm_flag)) == 1) ?  "yellow" : "white";
                        $ret .= '<tr bgcolor="' . $color . '">';
                        $rcount++;
                        $slottime = $ci->event->getSlotTimeShort();
                        $ret .= '<td align="left">' . substr($ci->event->slot_day,0,3) . " " . $slottime . '</td>';
                        $ret .= '<td align="center">';
                        $ret .= ($ci->event->table_placeholder_virtual == 1) ? "-" : $ci->event->table_number;
                        $ret .= '</td>';
                        $ret .= '<td>';
                        $tlink = '';
                        if($ci->event->mmrpgFlag == 1){
                            $tlink = $ci->event->game_title;
                        }
                        else{                                                        
                            $tlink = $ci->event->game_name;
                            $tlink1 = (trim($ci->event->game_title) != '') ? ' <em>' . $ci->event->game_title . '</em>' : '';
                        }
                        $tlink .= ($ci->event->affiliation != "None") ?  ' (' . $ci->event->affiliation . ')' : '';
                        if (abs(intval($gm_flag)) == 1){
                            $ret .= '<table border="0" cellpadding="0" cellspacing="0" style="padding:0px;margins:0px;"><tr><td>';
                            $ret .= ($ci->event->editable==1) ?  anchor('ogrex/gameEdit/' . $ci->event->id . '/100/TRUE' , $tlink, $atts2) : $tlink;
                            $ret .= '</td>';
                            $ret .= '</tr>';
                            if ($tlink1!=''){
                                $ret .= '<tr>';
                                $ret .= '<td>';
                                $ret .=  ($ci->event->editable==1) ? anchor('ogrex/gameEdit/' . $ci->event->id . '/100/TRUE' , $tlink1, $atts2) : $tlink1;
                                $ret .= '</td>';
                                $ret .= '</tr>';
                            }
                            $ret .= '</table>';    
                        }
                        else{
                            $ret .= $tlink;
                        }
                        $ret .= '</td>';
                        $ret .= '<td>';
                        $ret .= (abs(intval($gm_flag)) == 1) ? ' GM ' : 'PL ';
                        $hrstotal = (abs(intval($gm_flag)) == 1) ? $hrstotal + $ci->event->slot_length : $hrstotal + 0;                            
                        $ret .= '</td>';
                        if ($print == FALSE){
                                $ret .= '<td>';
                                if ($gpo == TRUE){
                                    if (abs(intval($gm_flag)) == 1){
                                        if ( $ci->event->mmrpgFlag != 1){
                                            if($ci->event->editable==1){                                                 
                                                $ret .= anchor('ogrex/gameEdit/' . $ci->event->id , '[Edit]', $atts1);                                                                                           
                                            }
                                            else{
                                                $ret .= '-';
                                            }
                                        }
                                        else{
                                            $ret .= anchor('ogrex/preregForm/' . $ci->event->id . '/100/TRUE' , '[Edit]', $atts2);
                                        }
                                    }
                                    else{                                                              
                                        $ret .= anchor('ogrex/preregForm/' . $ci->event->id . '/100/TRUE' , '[Edit]', $atts2);                                  
                                    }
                                }
                                else{
                                    $ret .= '-';
                                }
                            $ret .= '</td>';
                        }
                        $gid = $ci->event->id;
                        $ret .= '<td>';                                                    
                        $ret .= '<a href="' . site_url('ogre/preregReport/' . $ci->event->id,'https') . '" target="_blank">';
                        $ret .= $this->getNumberOfPlayers($gid);
                        $ret .= '</a>';                                                    
                        $ret .= '</td>';
                        $ret .= '</tr>';
                    }
                }
                $ret .= '<tr bgcolor="white">';
                $ret .= '<td colspan="8">';
                $ret .= '<p>Yellow entries are game you are a GM/Judge for.</p>';
                $ret .= '<p>Game masters of non-Organized Play events can Edit their game descriptions.  ';
                $ret .= 'Any Player can edit there Preregistration information.</p>';
                $ret .= '</td>';
                $ret .= '</tr>';
                $ret .= '</table>';
                $ret .= '</form>';
                $ret .= '</div>';
                $this->totalGMhours = (intval($this->access_rating) == GAMEMASTER) ? intval($hrstotal) : $this->totalGMhours;
            }
        }
        else{
            $ret = "<h1>No Current schedule</h1>";
        }
        return $ret;

    }		
//---------------------------------------------------
//
//---------------------------------------------------
    public function displayPlayerSchedulex($print=FALSE, $pid=0, $gpo=FALSE, $editview="player-admin-view", $refresh1 = ''){                  
        $ci = &get_instance();   
        $conid = $ci->session->ogre_conid;                   
        $userid = ($pid==0) ?  $ci->session->ogre_user_ID : $pid;    
        $this->init($conid, '', $userid);   
        $ret = '';
        $this->game_id_list = $this->getPlayerSchedule($conid);               
        $ret .= '<div id="player-admin-view">';
        if (trim($this->game_id_list) != ""){
            $gl = explode(",", $this->game_id_list);
            $i = 1;
            $rcount = 1;
            $ret .= '<div id="myschedule_outer">';
            $ret .= ($print === FALSE) ? $ci->schedule_lib->getSchedulePDFLinks($this->user_id_num) : '<h2>'. $this->fullname .'&#39;s Schedule</h2>';
            $ret .= '<form id="myschedule_form" name="myschedule_form" action="' . site_url('ogre/myschedule_re/','https') . '" method="post">';
            $ret .= '<table '. (($print === FALSE) ? 'id="my-schedule"' : 'id="myschedprint"') . (($print === FALSE) ? 'class="table-primary table-hover"' : 'class="table table-striped"') . '>'; //
            $ret .= '<tr>';
            $ret .= '<th id="mys_datetime">';
            $ret .= 'Event ID';
            $ret .= '</th>';            
            $ret .= '<th id="mys_datetime">';
            $ret .= 'Day/Time';
            $ret .= '</th>';
            $ret .= '<th id="mys_table">';
            $ret .= 'Table';
            $ret .= '</th>';
            $ret .= '<th id="mys_gametitle">';
            $ret .= 'GAME ID/Game/Type/Tag';
            $ret .= '</th>';
            $ret .= '<th id="mys_role">';
            $ret .= 'Role';
            $ret .= '</th>';
            $ret .= '<th id="mys_players">';
            $ret .= 'Plyrs';
            $ret .= '</th>';
            if ($print == FALSE){
                $ret .= '<th id="mys_delete">';
                $ret .= 'Del';
                $ret .= '</th>';
            }
            $ret .= '</tr>';
            foreach ($gl as $gameid){                                           
                if (trim($gameid) != ""){ 
                    $ret .= '<tr id="my-schedule'.$gameid.'">';                                        
                    $ret .= $this->displayPlayerSchedulex_row($gameid, $conid, $print, $gpo);
                    $rcount++;
                    $ret .= '</tr>';
                }
            }
            if($print == FALSE){
                $ret .= '<tr>';
                $ret .= '<td colspan="6">';
                $txt = $ci->ogre_lib->getMiscContent('%MYSCHEDULETEXT%');
                $ret .= $txt['content'];
                $ret .= '</td>';
                $ret .= '</tr>';
            }               
            $ret .= '</table>';
            $ret .= '</form>';
            $ret .= '</div>';
        }
        else{
                $ret .= '<h3><span class="badge bg-secondary">You have no current schedule.</span></h3>';
        }        
        $ret .= '</div>';
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------      
    public function displayPlayerSchedulex_row($gameid, $conid, $print=FALSE, $gpo=FALSE){
        $ci = &get_instance();
        $now_date = new Time();
        $close_date =  $ci->ogre_lib->getConGamingInfoKey($conid, 'con_gaming_reg_close_date');
        $close_date = new Time($close_date);  
        $remaction=site_url('ogrex/removePlayerMyschedule','https'); 
        $action=site_url('ogrex/gameEditX','https');
        $editsave ='ogrex/gameEditInx';     
        $refresh ='';
        $refresh1='';
        $refresh2='';
        $editview='';
        $divid ='my-schedule';        
        $ci->event->event_init($gameid);
        $ppid = $this->getPPPplayerPreregID($gameid);
        $gm_flag = $ci->event->isPlayerGM($this->user_id_num);
        $color=($gm_flag == 1)?'class="gmrow"':'class="playerrow"';
        $ret='';
        $ret .= '<td class="mys_datetime">';
        $ret .= str_pad($ci->event->id,5,'0', STR_PAD_LEFT);
        $ret .= '</td>';                
        $slottime = $ci->event->getSlotTimeShort();
        $ret .= '<td class="mys_datetime">';
        $ret .= substr($ci->event->slot_day,0,3) . " " . $slottime;
        $ret .= '</td>';
        $ret .= '<td class="mys_table">';
        $ret .= ($ci->event->table_placeholder_virtual == 1)?'-':$ci->event->table_number;                                       
        $ret .= '</td>';

        $ret .= '<td class="mys_gametitle">';
        $tlink = ''; 
        $gnarray = $ci->schedule_lib->processGameName($ci->event->game_name, $ci->event->game_title, $ci->event->gameid); 
        $tlink = $gnarray['gname'];        
        if ($ci->event->affiliation != 'None'){
            $tlink .= ' (' . $ci->event->affiliation . ')';
        }
        if ($gm_flag == 1){
//      GAMEMASTER            
            if ($ci->event->mmrpgFlag != 1){
//          NOT OGRANIZED PLAY                
                if($ci->event->editable==1){
//              EDITTABLE    
                    $action=site_url('ogrex/gameEditX','https');
                    $ret .= ($print===FALSE)? '<a href="#" onclick="return gamedit('."'".$action."'".','. $ci->event->id . ','."'".$editsave."'".','."'".$refresh."'".','."'".$divid.$ci->event->id."'".')">'.$tlink.'</a>' : $tlink;
                }
                else{
                    $ret .= $tlink;
                }
            }
            else{
                // EDIT OP GM Prereg
                $action = site_url('ogrex/preRegFormX/TRUE','https');
                $ret .= ($print===FALSE) ? '<a href="#" onclick="return preregedit('."'".$action."'".','. $ci->event->id.','. $this->user_id_num . ')">' .$tlink. '</a>' : $tlink;                 
            }
        }
        else{
////            PLAYER EDIT PREREG
                $action = site_url('ogrex/preRegFormX/TRUE','https');
                $ret .= ($print===FALSE) ? '<a href="#" onclick="return preregedit('."'".$action."'".','. $ci->event->id.','. $this->user_id_num . ')">' .$tlink. '</a>' : $tlink;                                         
        }
        $ret .= '</td>';
        $ret .= '<td class="mys_role">';
        $ret .= ($gm_flag == 1) ?  'GM':'PL';
        $ret .= '</td>';

        $gid = $ci->event->id;
        $ret .= '<td class="mys_players">';
        $pn = $this->getNumberOfPlayers($gid);
        $of='';
        $numTotlPlayers = $ci->event->getPlayerNum($ci->event->id, $ci->event->prereg_players_allowed);
        if($numTotlPlayers > 0){
            if(intval($pn) > $numTotlPlayers){
                $of = intval($pn) - intval($numTotlPlayers);
                $pn = $numTotlPlayers;  
            }    
        }
        if($pn != 0){
            if(intval($ci->event->prereg_players_allowed) >0){
                $ret .= ($of!='') ? $pn . " (+".$of.")" : $pn;
            }
            else{
                $ret .= '-';
            }
        }
        else{
            if(intval($ci->event->prereg_players_allowed) > 0){
                $ret .= '0';
            }else{
                $ret .= '-';
            }
        }
        $ret .= '</td>';
        if ($print == FALSE){
            $ret .= '<td class="mys_delete">';
            if($now_date <= $close_date){
                    $gm_mmrpgflag = $gm_flag . $ci->event->mmrpgFlag;
                    switch ($gm_mmrpgflag){
                        case '00':          
                        // PLAYER, NON-OP
                        $ret .= '<input type="checkbox" id="btnRemove" name="btnRemove" onclick="removePlayerOnsite(' . $ppid . ", " . $ci->event->id . ", " . "'" . $remaction . "'". ", " . "'" . $editview . "', '" . $refresh1 . "', '" . $refresh2 . "', " . "'m'" . ')" />';
                        break;
                        case '01':
                        //PLAYER, OP
                        $ret .= '<input type="checkbox" id="btnRemove" name="btnRemove" onclick="removePlayerOnsite(' . $ppid . ", " . $ci->event->id . ", " . "'" . $remaction . "'". ", " . "'" . $editview . "', '" . $refresh1 . "', '" . $refresh2 . "', " . "'m'" . ')" />';
                        break;
                        case '11':
                        // GM, OP
                        $ret .= '<input type="checkbox" id="btnRemove" name="btnRemove" onclick="removeJudgeOnsite(' . $ppid . ", " . $ci->event->id . ", " . "'" . $remaction . "'". ", " . "'" . $editview . "', '" . $refresh1 . "', '" . $refresh2 . "', " . "'m'" . ')" />';
                        break;                                          
                        default:
                        // GM, NON-OP
                        $ret .= '-';
                        break;
                    }
                }
        }
        $ret .= '</td>';
        $ret .= '</tr>';                                                
        return $ret;
    }
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function displayPlayerRequests(){           
        $ci = &get_instance();   
        $conid = $ci->session->get('ogre_conid');
        $orgid  = $ci->session->get('ogre_orgid');
        $userid = $ci->session->get('ogre_user_ID');    
        $this->init($conid, '', $userid);
        $grtotal = 0;                
        $ret = '';
        $ret .= '<div id="my-proposal-list" class="my-proposal-list">';
        $ret .= '<h1><strong>My Game Proposals</strong></h1>';
        $ret .= '<div id="results"  class="results"></div>';
        $ret .= '<table id="my-proposal-table" class="table table-hover">';   

        $qry = 'SELECT con_id, con_name FROM ogre_convention ';
        $qry .= ' WHERE (con_start_date >= NOW()) OR (con_id='. $conid .') ';
        if ($orgid != 0){
            $qry .= ' AND con_org_id = ' . $orgid;
        }                        
        $qry .= ' ORDER BY con_start_date;'; 
        
        
        $query = $ci->db->query($qry);
        
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $grtotal = $ci->propose_lib->numberOfProposal($userid, $row->con_id);
                if($grtotal > 0){
                    $this->request_id_list = $this->getPlayerRequests($row->con_id);                   
                    $ret .= '<tr>';
                    $ret .= '<td colspan="5" id="proposal_con_name-'.$row->con_id.'"><strong>';
                    $ret .= $row->con_name;
                    $ret .= '</strong></td>';
                    $ret .= '</tr>';
                    $ret .= '<tr>';
                    $ret .= '<td>';
                    if (trim($this->request_id_list) != ""){            
                        $gl = explode(",", $this->request_id_list);
                        $i = 1;
                        $rcount = 1;                    
                        $ret .= '<table id="proposalList-'.$row->con_id.'" class="table table-hover">';
                        if($ci->agent->isMobile() !== TRUE){
                            $ret .= '<tr>';
                            $ret .= '<th>Proposal #</th>';
                            $ret .= '<th>Game/Title</th>';
                            $ret .= '<th>Day/Time</th>';
                            $ret .= '<th>Status</th>';
                            $ret .= '<th>Delete</th>';
                            $ret .= '</tr>';   
                        }                            
                        if (trim($this->request_id_list) != ""){
                            foreach ($gl as $gameid){   
                                if (trim($gameid) != ""){  
                                    $ci->proposal->prop_init($gameid, $conid);
                                    $ret .= ($ci->proposal->id == 0)?'<tr class="newproposal">':(($ci->proposal->id > 0) ? '<tr>' : '<tr class="rejectedproposal">');   
                                    $rcount++;	
                                    $ret .= '<td>';

                                    $ret .= '<p>'.str_pad($ci->proposal->request_id,5,'0', STR_PAD_LEFT) . '</p>';
                                    if(!$ci->agent->isMobile()){
                                        $ret .= '</td>';
                                        $ret .= '<td>';
                                    }
                                    $link = $ci->proposal->game_name;
                                    if (trim($ci->proposal->game_title) != ""){
                                            $link .= ' - ' . $ci->proposal->game_title . '';
                                    }                                                        
                                    $action = site_url('ogrex/gamesReqDetails/'.$ci->proposal->request_id.'/TRUE','https');
                                    $ret .= '<p>';
                                    $ret .= '<a href="#" onclick="return displayProposal('."'".$action."',".$ci->proposal->request_id.')">' . $link .'</a>';
                                    $ret .= '</p>';
                                    if(!$ci->agent->isMobile()){
                                    $ret .= '</td>';
                                    $ret .= '<td>';
                                    }
                                    $ret .= '<p>';
                                    if ($ci->proposal->anytime == "special"){
                                            $ret .= "(See Details)";
                                    }
                                    elseif ($ci->proposal->anytime == "0"){
                                            $ret .= "Not Specified";
                                    }
                                    else{
                                    $ret .= $ci->proposal->anytime;
                                    }
                                    $ret .= '</p>';
                                    if(!$ci->agent->isMobile()){
                                    $ret .= '</td>';
                                    $ret .= '<td>';
                                    }
                                    $ret .= '<p>';
                                    if (intval($ci->proposal->id) == 0){
                                            $ret .=  "Pending";
                                    }
                                    elseif (intval($ci->proposal->id) < 0){
                                            $ret .= "Rejected/Canceled";
                                    }
                                    else{
                                            $ret .=   "Accepted";
                                    }
                                    $action=site_url('ogrex/gameproposal_del','https');
                                    $ret .= '</p>';
                                    if(!$ci->agent->isMobile()){
                                    $ret .= '</td>';
                                    $ret .= '<td>';
                                    }
                                    $ret .= '<p>';
                                    if($ci->agent->isMobile()){
                                        $ret .= 'Delete: ';
                                    }                                    
                                    if (intval($ci->proposal->id) <= 0){                                       
                                        $ret .= '<input type="checkbox" id="removeGP" name="removeGP" onclick="delProposal('."'".$action."',".$ci->proposal->request_id.')" />';
                                    }
                                    $ret .= '</p>';
                                    $ret .= '</td>';
                                    $ret .= '</tr>';                                               
                                } 
                            }                                   			
                        }
                    }
                    $ret .= '</table>';
                }
                $ret .= '</td>';
                $ret .= '</tr>';                            
            }
        }
                        
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '</table>';
        $ret .= '</div>';                      
        return $ret;
    }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
    private function getNumberOfPlayers($schedid){
        $ci = &get_instance();
        $qry ='SELECT ogre_prereg_player.pp_player_prereg_id ';
        $qry .=' FROM ogre_prereg_player ';
        $qry .=' WHERE ogre_prereg_player.pp_gs_id = ' . $schedid;
        $qry .=' AND ogre_prereg_player.pp_gm_judge_flag <> 1 ';
        $qry .=' AND pp_delete_flag = 0;';
         $query = $ci->db->query($qry);			
         return $query->getNumRows();
    }
		
//---------------------------------------------------
//
//---------------------------------------------------
    public function getPPPplayerPreregID($schedid, $userid = 0){
        $ci = &get_instance();
        $userid = ((intval($userid) == 0) ? $this->user_id_num : $userid);
        $qry ='SELECT ogre_prereg_player.pp_player_prereg_id ';
        $qry .=' FROM ogre_prereg_player ';
        $qry .=' WHERE ogre_prereg_player.pp_gs_id = ' . $schedid;
        $qry .=' AND ogre_prereg_player.pp_player_id = ' . $userid;                                                
        $qry .=' AND ogre_prereg_player.pp_delete_flag = 0';

        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){	
                $ret = $row->pp_player_prereg_id;
            }	
        }
        return $ret;
    }	
//---------------------------------------------------
//
//---------------------------------------------------
        public function resetPlayerSchedule($conid=0){
            $ci = get_instance();
            if($conid==0){
                $conid = $ci->session->get('ogre_conid');
            }                    
            $this->game_id_list = $this->getPlayerSchedule($conid, -1);
            $this->gamegm_id_list = $this->getPlayerSchedule($conid, 1);
            $this->gamepl_id_list = $this->getPlayerSchedule($conid, 0);
            $this->request_id_list = $this->getPlayerRequests($conid);
            $this->slotcode_list = $this->getPlayerScheduleSlotCodes($conid);     
            return TRUE;
        }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getRegistrationInfo($gameid,  $colname){		
        $ci = get_instance();
        $qry = 'SELECT * FROM ogre_prereg_player ';
        $qry .= 'WHERE pp_player_id  = "' . $this->user_id_num . '"';
        $qry .= ' AND pp_gs_id = ' . $gameid;
        $qry .= ' AND pp_delete_flag = 0;';

        $query = $ci->db->query($qry);
        $ret = "";
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){ 
                $ret = $row->$colname;
            }
        }
        return $ret;                       
    }
    //---------------------------------------------------
    //
    //  
    //
    //---------------------------------------------------		
    private function updatePreregRecords($old_email, $new_email){
        $ci = &get_instance(); 
        $qry= ' UPDATE ogre_prereg_player SET ogre_prereg_player.pp_player_email = "' . $new_email . '" ';
        $qry.= ' WHERE ogre_prereg_player.pp_player_email = "' . $old_email . '"; ';
        $ci->db->query($qry);
        $ret = (($ci->db->affectedRows() > 0) ? TRUE : FALSE);
        return $ret;
    }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------		
    private function insertDeleteLog( $game){
        $ci = &get_instance(); 
        $ins = "";
        $ins = "INSERT ogre_prereg_delete_log  ( ";
        $ins .= "ppd_name,";
        $ins .= "ppd_scheduleid,";
        $ins .= "ppd_gs_id,";
        $ins .= "ppd_date";
        $ins .= ") ";
        $ins .= "VALUES (" ;	 
        $ins .= '"' . $this->fullname . '", ';
        $ins .= $game->schedule_id . ',';
        $ins .= $game->id . ',';
        $ins .= 'NOW()';
        $ins .= ');';
            
        $ci->db->query($ins);
        $ret =  ($ci->db->affectedRows() > 0) ?  FALSE : TRUE;
        return $ret;
    }        
//---------------------------------------------------
//
//---------------------------------------------------		
        public function isActivated($pid){
            $ci=&get_instance();                  
            $conid = $ci->session->get('ogre_conid');
            $this->get($pid);                           
            $qry = "";
            $qry .= 'SELECT ogre_users.*, ogre_user_verified.* FROM ogre_users ';
            $qry .= ' INNER JOIN ogre_user_verified ';
            $qry .= ' ON ogre_users.user_index_id = ogre_user_verified.uv_user_id ';
            $qry .= ' WHERE  ogre_user_verified.uv_con_id = ' . $conid;
            $qry .= ' AND  ogre_users.user_index_id = '. $this->user_id_num . ';';    
            $query = $ci->db->query($qry);
            $ret = (($query->getNumRows() > 0) ? TRUE : FALSE);
            return $ret;
        }   
//---------------------------------------------------
// $pid = 0, use current user.  $gid <> 0 isGM of this game
//---------------------------------------------------		
        public function isGM($pid=0, $gid=0){
            $ci=&get_instance();
            $pid = (($pid == 0) ? $ci->session->ogre_user_ID : $pid);
            $conid = $ci->session->get('ogre_conid');
            $this->gamegm_id_list = $this->getPlayerSchedule($conid, 1, $pid);
            if ($gid==0){
                $ret = (($this->gamegm_id_list !='') ? TRUE : FALSE);
            }
            else{
                $ret = ((strpos($this->gamegm_id_list,strval($gid)) >= 0) ? TRUE : FALSE);
            }
            return $ret;
        }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getTickets($pid, $conid){
        $ci = &get_instance();                                                              
        $this->get($pid);
        $this->game_id_list = $this->getPlayerSchedule($conid,0);
        $ci->convention->init($conid); 
        if (trim($this->game_id_list) != ""){
            $gl = explode(",", $this->game_id_list);
            $i = 1;
            $rcount = 1; 
            $ret = '<div id="tickets">';
            foreach ($gl as $gameid){
                if (trim($gameid) != ""){
                    $part = $ci->event->isParticipant($pid, $gameid);
                    $prt = explode(',', $part);
                    $ret .= ($rcount == 1) ? '<div class="page-first">' : '';
                    $ret .= '<table class="padded-ticket-table3">'; 
                    $ret .= '<tr>';
                    $ret .= '<td colspan="2" class="ticket-titlerow">';
                    $ret .= $ci->convention->name . ' Game Preregister Ticket';
                    $ret .= (($prt[1]=="0") ? " <em>(ALTERNATE)</em>" : "");
                    $ret .= '</td>';
                    $ret .= '<td rowspan="6" class="back">';                                
                    $instr = $ci->ogre_lib->getMiscContent('%TICKETNOTES%');
                    $ret .= '<div class="padded">'.$instr['content'].'</div>';
                    $ret .= '</td>';
                    $ret .= '</tr>';
                    $ci->event->event_init($gameid);                                    
                    $ret .= '<tr>';
                    $ret .= '<td class="ticket-titlerow">Name:</td>';
                    $ret .= '<td class="ticket-playername">';                                
                    $ret .= $this->fullname;
                    $ret .= '</td>';           
                    $ret .= '</tr>';
                    $ret .= '<tr>';
                    $ret .= '<td class="ticket-titlerow">Game:</td>';
                    $ret .= '<td class="ticket-inforow">';
                    $tlink = ($ci->event->mmrpgFlag == 1) ? $ci->event->game_title : $ci->event->game_name;                                
                    $tlink1 = ($ci->event->mmrpgFlag == 1 ? '' : (trim($ci->event->game_title) != '' ? '<em>' . $ci->event->game_title . '</em>' : ''));
                    $tlink .= ($ci->event->affiliation != "None" ? ' (' . $ci->event->affiliation . ')' : '');                             
                    $ret .= $tlink;
                    $ret .=  ($tlink1 !='' ) ? '<br />' .  $tlink1 : '';
                    $ret .= '</td>';
                    $ret .= '</tr>'; 

                    $ret .= '<tr>';                                                                    
                    $ret .= '<td class="ticket-titlerow">Host:</td>';
                    $ret .= '<td class="ticket-inforow" align="left">';
                    $gmlist = $ci->event->getPlayerList(1);
                    $gmnames='';
                    $i=1;
                    foreach ($gmlist as $gm){                                   
                        $gmnames .= $gm[1];                                    
                        $gmnames .= ($i >count($gmlist,0)) ? ',' : '';
                        $i++;
                    }
                    $ret .= $gmnames;
                    $ret .= '</td>';
                    $ret .= '</tr>';
                    $ret .= '<tr>';                                                                    
                    $ret .= '<td class="ticket-titlerow">Time:</td>';
                    $ret .= '<td class="ticket-inforow" align="left">';
                    $slottime = $ci->event->getSlotTimeShort();
                    $ret .= substr($ci->event->slot_day,0,3) . " " . $slottime;
                    $ret .= '</td>';
                    $ret .= '</tr>';

                    $ret .= '<tr>';
                    $ret .= '<td class="ticket-titlerow">Place:</td>';
                    $ret .= '<td class="ticket-inforow">';    
                    $ret .=  ($ci->event->table_placeholder_virtual == 1) ?  $ci->event->location_name :  $ci->event->location_name .': '.$ci->event->table_number;
                    $ret .= '</td>';
                    $ret .= '</table>';
                    if(($rcount % 7)==0){
                        $ret .= '</div>';
                        if($rcount < count($gl)){
                            $ret .= '<div class="page">';
                        }
                    }                               
                    $rcount++;
                }                                                                                 
        }
        $ret .= '</div>';
        return $ret;
        }    
    }
                
//---------------------------------------------------
//
//---------------------------------------------------               
    public function alreadyInSlot($slotcode){
        $ssc = substr($slotcode,0,6);
        $ret = 0;
        $ret1 = $this->resetPlayerSchedule();
        if(isset($this->slotcode_list[$ssc])){
            $ret = $this->slotcode_list[$ssc];
        } 
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function removeMeAll($pid=0, $conid=0){  
        $ci = &get_instance();
        $ret = TRUE;                                 
        $pid = ($pid === 0) ? $this->user_id_num : $pid;  
        $this->get($pid, $conid);
        $playlist = split(",", $this->game_id_list);
        foreach ($playlist as $gid) {
            $ci->event->event_init($gid,$conid);
            $gm = $ci->event->isPlayerGM($pid);
            $op = $ci->event->mmrpgFlag;
            if(intval($gm)==0){
                $ret = $ci->event->removePlayer(0, $pid, $gid);
                $ret = $ci->event->promote_alternate($gid);
            }elseif (intval($gm)==1 && intval($op)==1) {
                $ret = $ci->event->removePlayer(0, $pid, $gid);
                $ret = $ci->event->promote_alternate($gid);
            }
        }
        return $ret; 
    }   
//---------------------------------------------------
//
//---------------------------------------------------
    public function deleteFromAllProgress($pid){
        $ci = &get_instance();
        $ret = '';  
        $ret .= '<h4>Drop Out of All Games</h4>';
        $ret .= '<p>' . $ci->ogre_lib->getMiscContent('%DROPOUTOFALLGAMES%',$ci->session->ogre_conid, TRUE) . '</p>';
        $ret .= $ci->ogre_lib->getMiscContent('%DROPOUTOFALLGAMES2%',$ci->session->ogre_conid, TRUE);
        $ret .= '<div class="progress" id="dropoutall_progress">';
        $ret .= $this->dropoutProgressBar(0);
        $ret .= '</div>';
        $ret .= '<div id="drop-out-all-progress-results" style="padding-top: 15px;">';
        $ret .= '</div>';            
        return $ret;
    }            
//---------------------------------------------------
//
//---------------------------------------------------         
    public function dropoutProgressBar($perc=0){
        $ret = '<div id="dropoutall_progress1" class="progress-bar progress-bar-striped" role="progressbar" style="width:'.$perc.'%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>';
        return $ret;
    }
//--------------------------------------------------- 
//
//---------------------------------------------------     
    public function addAsGM($pid, $sid){
            $ci = &get_instance();
            $this->init($pid);
            $ret = array();
            $qry = 'INSERT INTO ';
            $qry .= ' ogre_prereg_player  ';
            $qry .= ' (';
            $qry .= ' pp_gs_id, ';
            $qry .= ' pp_schedule_id, ';
            $qry .= ' pp_player_id, ';
            $qry .= ' pp_player_name, ';
            $qry .= ' pp_player_email, ';
            $qry .= ' pp_player_prereg_date, ';
            $qry .= ' pp_datemodified, ';
            $qry .= ' pp_player_confirmed, ';
            $qry .= ' pp_player_notes, ';
            $qry .= ' pp_rpga_combat_role, ';
            $qry .= ' pp_rpga_level, ';
            $qry .= ' pp_rpga_player_apl, ';
            $qry .= ' pp_rpga_open_to_judging,';
            $qry .= ' pp_gm_judge_flag, ';
            $qry .= ' pp_rpga_judge_apl';
            $qry .= ') ';
            $qry .= 'VALUES (';  
            $qry .= $sid . ', ';
            $qry .= '0, ';
            $qry .= $this->user_id_num . ', ';
            $qry .= '"'  . $this->fullname . '", ';
            $qry .= '"' . $this->email . '", ';
            $qry .= ' NOW(), NOW(), 1, ';
            $qry .= '"","","","",0,1,""';
            $qry .= ')';            
            $ci->db->query($qry);                                
            $ret['result']= (($ci->db->affectedRows() > 0)? TRUE : FALSE);                                  
            $ret['pp_player_prereg_id'] = ($ret['result']==TRUE) ? $ci->db->insertID() : 0; 
            return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------     
    public function addAsPlayer($pid, $sid){
            $ci = &get_instance();
            $this->init($pid);
            $ret = array();
            $qry = 'INSERT INTO ';
            $qry .= ' ogre_prereg_player  ';
            $qry .= ' (';
            $qry .= ' pp_gs_id, ';
            $qry .= ' pp_schedule_id, ';
            $qry .= ' pp_player_id, ';
            $qry .= ' pp_player_name, ';
            $qry .= ' pp_player_email, ';
            $qry .= ' pp_player_prereg_date, ';
            $qry .= ' pp_datemodified, ';
            $qry .= ' pp_player_confirmed, ';
            $qry .= ' pp_player_notes, ';
            $qry .= ' pp_rpga_combat_role, ';
            $qry .= ' pp_rpga_level, ';
            $qry .= ' pp_rpga_player_apl, ';
            $qry .= ' pp_rpga_open_to_judging,';
            $qry .= ' pp_gm_judge_flag, ';
            $qry .= ' pp_rpga_judge_apl';
            $qry .= ') ';
            $qry .= 'VALUES (';  
            $qry .= $sid . ', ';
            $qry .= '0, ';
            $qry .= $this->user_id_num . ', ';
            $qry .= '"'  . $this->fullname . '", ';
            $qry .= '"' . $this->email . '", ';
            $qry .= ' NOW(), NOW(), 1, ';
            $qry .= '"","","","",0,0,""';
            $qry .= ')';            
            $ci->db->query($qry);                                
            $ret['result']= (($ci->db->affectedRows() > 0)? TRUE : FALSE);                                  
            $ret['pp_player_prereg_id'] = ($ret['result']==TRUE) ? $ci->db->insertID() : 0; 
            return $ret;        
    }
//---------------------------------------------------
//
//---------------------------------------------------      
    public function forgotPasswordEmail($data, $pw, $from, $user){
        $ci = &get_instance();
        $msg = $ci->ogre_lib->getMiscContent('%%FORGOT.PASSWORD.EMAIL%%');
        $msg['content'] = str_replace('%%USERID%%', $pw["userid"], $msg['content']);
        $msg['content'] = str_replace('%%PASSWORD%%', $pw["password"], $msg['content']);
        $data['from_eaddress']= $from;
        $data['to_eaddress1'] = $user;
        $data['to_eaddress2'] = '';
        $data['to_eaddress3'] = '';
        $data['subject'] = 'OGRe E-mail: Password Retrieve';
        $data['body'] =  $msg['content'];
        return $data;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    function removeFromGame($p){  
        $ci = &get_instance();
        $orgid = $ci->session->ogre_orgid;
        $qry2 = '-';
        $qry1 = '-';
        $ret = TRUE;
        $delflag = 1;
        $accessrating= $ci->session->get('ogre_user_accesslevel_' . $orgid);     
        if($accessrating <= GAMEMASTER){
            $cutoff = $ci->event->getCutOffMultiplier(FALSE);
            $delflag = $delflag * $cutoff;
        }                    
        foreach ($p as $gameid){
            if ((trim($gameid) != "") && ($gameid != " Remove ")){
                $ci->event->initialize($gameid);			
                $qry1 = "UPDATE ogre_prereg_player ";
                $qry1 .= " SET pp_delete_flag = " . $delflag;
                $qry1 .= " WHERE pp_gs_id = " . $gameid;
                $qry1 .= " AND pp_player_id = " . $this->user_id_num;
                $ci->db->query($qry1);
                if ($ci->db->affectedRows() > 0){
                    $ret = TRUE;					
                    if($ret===TRUE){
                        if (intval($ci->event->rpga_number_of_slots) > 1){
                            $childid = $ci->event->findOPMultiRoundChild();
                            foreach($childid as $child){                                           
                                $qry2 = "UPDATE ogre_prereg_player SET pp_delete_flag = ".$delflag.", pp_datemodified = NOW() WHERE pp_gs_id = " . $child . " AND pp_player_id = " . $this->user_id_num;
                                $ci->db->query($qry2);
                                $ret=($ci->db->affectedRows() > 0) ? TRUE : FALSE;
                                if($ret===TRUE){
                                    $ret = $this->reset_player_schedule();
                                }
                            }
                        }
                    }
                }
                else
                {
                    $ret = FALSE;
                }				
            }
        }			                                       		                 
        return $ret; 
    }     
} //  END CLASS
