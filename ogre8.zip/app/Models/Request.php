<?php	
namespace App\Models;
use CodeIgniter\Model;
use CodeIgniter\I18n\Time;

//---------------------------------------------------
// Class: Game Proposal
//
//
//---------------------------------------------------
class Request extends Game
{
    var $request_id = 0;
    var $gm_name = '';
    var $gm_email = '';
    var $gm_alt_email = '';
    var $gm_id = 0;
    var $gm_age = 0;
    var $gm_gender = '';
    var $gm_city = '';
    var $gm_state = '';
    var $gm_phone_day = '';
    var $gm_phone_night = '';
    var $proposal_number = 0;
    var $proposal_number_total = 0;
    var $date_created = '';
    var $total_rounds = '';
    var $final_round = '';
    var $play_more_than_once  = '';
    var $anytime = '';
    var $spec_sched_day1 = '';
    var $spec_sched_time1 = '';
    var $spec_sched_day2 = '';
    var $spec_sched_time2 = '';
    var $spec_sched_day3 = '';
    var $spec_sched_time3 = '';
    var $players_responsibilities = '';
    var $player_know = '';
    var $attitude = '';
    var $number_of_gms = '';
    var $gm_list = '';
    var $campaign = '';
    var $table_space = '';
    var $play_area = '';
    var $additional_comments = '';

			//---------------------------------------------------
			//
			//  
			//
			//---------------------------------------------------	
//			public function Event()
//			{
//			   parent::__construct();
//			}
    public function __construct()
    {
       parent::__construct();
    }					
			//---------------------------------------------------
			//
			//  
			//
			//---------------------------------------------------
			public function initialize( $requestid, $con)  
			{
				if($requestid != 0)
				{
					$this->getRequestInfo($requestid, $con);
				}
			}
		//---------------------------------------------------
		//
		//  
		//
		//---------------------------------------------------
		private function getRequestInfo($requestid=0, $con=0){
                $ci = &get_instance();
			    $qry = "SELECT * FROM `ogre_gamerequest` WHERE gr_id = " . $requestid ;
                $query = $ci->db->query($qry);
                if ($query->getNumRows() > 0){
                    foreach ($query->getResult() as $row){
                        $this->conventionid =  $row->gr_con_id;
                        $this->convention_name =  $con->name;
                        $this->request_id = $row->gr_id;
                        $this->id = $row->gr_schedule_id;
                        $this->gm_id = $row->gr_gm_id;
                        $this->gm_name = $row->gr_gm_name;
                        $this->gm_email = $row->gr_gm_email;
                        $this->gm_alt_email = $row->gr_alt_email;
                        $this->gm_age = $row->gr_gm_age;
                        $this->gm_gender = $row->gr_gm_gender;
                        $this->gm_city = $row->gr_gm_city;
                        $this->gm_state = $row->gr_gm_state;
                        $this->gm_phone_day = $row->gr_gm_phone_day;
                        $this->gm_phone_night = $row->gr_gm_phone_night;
                        $this->proposal_number = $row->gr_proposal_number;
                        $this->proposal_number_total = $row->gr_proposal_number_total;
                        $this->game_type = $row->gr_game_type;
                        $this->game_type_id = $row->gr_game_type_id;
                        $this->event_type = $row->gr_event_type;
                        $this->game_title = $row->gr_scenario_title;
                        $this->game_name = $row->gr_game_system;
                        $this->game_notes = nl2br(strip_tags($row->gr_game_description));
                        $this->slot_length = $row->gr_total_hours;
                        $this->total_rounds = $row->gr_total_rounds;
                        $this->final_round = $row->gr_final_round;
                        $this->play_more_than_once = $row->gr_play_more_than_once;
                        $this->anytime = $row->gr_anytime;
                        $this->spec_sched_day1 = $row->gr_spec_sched_day1;
                        $this->spec_sched_time1 = $row->gr_spec_sched_time1;
                        $this->spec_sched_day2 = $row->gr_spec_sched_day2;
                        $this->spec_sched_time2 = $row->gr_spec_sched_time2;
                        $this->spec_sched_day3 = $row->gr_spec_sched_day3;
                        $this->spec_sched_time3 = $row->gr_spec_sched_time3;
                        $this->max_number_of_players = $row->gr_max_players;
                        $this->min_num_of_players = $row->gr_min_players;
                        $this->players_responsibilities = $row->gr_players_responsibilities;
                        $this->player_know = $row->gr_player_know;
                        $this->attitude = $row->gr_attitude;
                        $this->maturity_rate = $row->gr_age_rating;
                        $this->number_of_gms = $row->gr_number_of_gms;
                        $this->gm_list = $row->gr_gm_list;
                        $this->campaign = $row->gr_campaign;
                        $this->table_space = $row->gr_table_space;
                        $this->play_area = $row->gr_play_area;
                        $this->additional_comments = $row->gr_additional_comments;
                        $this->min_players = $row->gr_min_players;
                        $this->max_players = $row->gr_max_players;
				    }
			    }
		}
		//---------------------------------------------------
		//
		//  
		//
		//---------------------------------------------------
		public function insertGameRequest($p, $con){
			$sql = 'INSERT INTO ogre_gamerequest ';
			$sql .= '(gr_con_id , ';
			$sql .= 'gr_msa_conid, '; 
			$sql .= 'gr_gm_id, ';
			$sql .= 'gr_gm_name, ';
			$sql .= 'gr_gm_email, ';
			$sql .= 'gr_date_created, ';
			$sql .= 'gr_alt_email, ';
			$sql .= 'gr_gm_age, ';
			$sql .= 'gr_gm_gender, ';
			$sql .= 'gr_gm_city, ';
			$sql .= 'gr_gm_state, ';
			$sql .= 'gr_gm_phone_day, ';
			$sql .= 'gr_gm_phone_night, ';
			$sql .= 'gr_proposal_number, ';
			$sql .= 'gr_proposal_number_total, ';
			$sql .= 'gr_game_type, ';
			$sql .= 'gr_game_type_id, ';
			$sql .= 'gr_event_type, ';
			$sql .= 'gr_scenario_title, ';
			$sql .= 'gr_game_system, ';
			$sql .= 'gr_game_description, ';
			$sql .= 'gr_total_hours, ';
			$sql .= 'gr_total_rounds, ';
			$sql .= 'gr_final_round, ';
			$sql .= 'gr_anytime, ';
			$sql .= 'gr_spec_sched_day1, ';
			$sql .= 'gr_spec_sched_time1, ';
			$sql .= 'gr_spec_sched_day2, ';
			$sql .= 'gr_spec_sched_time2, ';
			$sql .= 'gr_spec_sched_day3, ';
			$sql .= 'gr_spec_sched_time3, ';
			$sql .= 'gr_play_more_than_once, ';
			$sql .= 'gr_min_players, ';
			$sql .= 'gr_max_players, ';
			$sql .= 'gr_players_responsibilities, ';
			$sql .= 'gr_player_know, ';
			$sql .= 'gr_attitude, ';
			$sql .= 'gr_age_rating, ';
			$sql .= 'gr_number_of_gms, ';
			$sql .= 'gr_gm_list, ';
			$sql .= 'gr_campaign, ';
			$sql .= 'gr_table_space, ';
			$sql .= 'gr_play_area, ';
			$sql .= 'gr_additional_comments';
			$sql .= ') ';
			$sql .= 'VALUES(';
			$sql .= $p["conid"] . ', ';
			$sql .= $con->msa_conid . ', ';
			$sql .= $p["gm_id"] . ", '";
			$sql .= quotes_to_entities($p["gmname"]) . "', '";
			$sql .= $p["gmemail"] . "', " ;
			$sql .= " CURDATE(), '";
			$sql .= $p["gm_contactemail"] . "', '";
			$sql .= $p["gm_age"] . "', '";
			$sql .= $p["gm_gender"] . "', '";
			$sql .= $p["gm_city"] . "', '";
			$sql .= $p["gm_state"] . "', '";
			$sql .= $p["gm_dphone"] . "', '";
			$sql .= $p["gm_nphone"] . "', ";
			$sql .= $p["propnum"] . ", ";
			$sql .= $p["propof"] . ", '";
			$sql .= $this->getDescriptor( $p["gametype"]) . "', "; 
			$sql .= $p["gametype"] . ", '";
			$sql .= $p["eventtype"] . "', '";
			$sql .= $p["gametitle"] . "', '";
			$sql .= $p["gamesystem"] . "', '";
			$sql .= quotes_to_entities($p["gamenotes"]) . "', ";
			$sql .= $p["gametime"] . ", ";
			$sql .= $p["gamesessions"] . ", '";
			$sql .= $p["final"] . "', '";
			$sql .= $p["anytime"] . "', '";
			$sql .= $p["spec_day1"] . "', '";
			$sql .= $p["spec_time1"] . "', '";
			$sql .= $p["spec_day2"] . "', '";
			$sql .= $p["spec_time2"] . "', '";
			$sql .= $p["spec_day3"] . "', '";
			$sql .= $p["spec_time3"] . "', '";
			$sql .= $p["multi"] . "', ";
			$sql .= $p["minplay"] . ", ";
			$sql .= $p["maxplay"] . ", '";
			$sql .= $p["playbring"] . "', '";
			$sql .= $p["knowledge"] . "', '";
			$sql .= $p["attitude"] . "', '";
			$sql .= $p["agerate"] . "', '";
			$sql .= $p["gmnum"] . "', '";
			$sql .= $p["otherGMs"] . "', '";
			$sql .= $p["campaign"] . "', '";
			$sql .= $p["tspace"] . "', '";
			$sql .= $p["space"] . "', '";
			$sql .= quotes_to_entities($p["comments"]) . "'";
			$sql .= ")";
			/*  echo $sql; */
				
			$ret = (!mysql_query($sql))? "Failure: " . mysql_error(): TRUE;
                        
			return $ret;
		}

		//---------------------------------------------------
		//
		//  
		//
		//---------------------------------------------------
		public function emailGameRequest($mail, $host, $user, $pw, $p, $gc)
		{
			$mail->Host = $host ;    // SMTP servers
			$mail->SMTPAuth = TRUE;     // turn on SMTP authentication
			$mail->Username = $user;  // SMTP username
			$mail->Password = $pw ; // SMTP password
			
			$mail->From = $p["gmemail"];
			
			$subject= $p["eventname"] . " Game Proposal" ;
			
			$message = "--------------------------------------------------------------------------" . "<br/>";
			$message .= $p["eventname"] . "<br/>" .  $p["eventdates"]  . "<br/>";
			$message .= "--------------------------------------------------------------------------"  . "<br/>";
			$message .= "<u>GM Information</u>"  . "<br/>";
			$message .= "Name: " . $p["gmname"] . "<br/>";
			$message .= "Age: " . $p["gm_age"] . "<br/>";
			$message .= "Gender: " . $p["gm_gender"] . "<br/>";
			$message .= "City:: " . $p["gm_city"] . "<br/>";
			$message .= "State: " . $p["gm_state"]. "<br/>";
			$message .= "Day Phone: " . $p["gm_dphone"]. "<br/>";
			$message .= "Evening Phone: " . $p["gm_nphone"] . "<br/><br/>";
			
			$message .= "GM E-mail: " . $p["gm_contactemail"] . "<br/><br/>";
			
			$message .= "Sent this " . $p["eventname"] . "<br/><br/>";
			
			$message .= "This is Proposal Number " . $p["propnum"] . "  of  " .  $p["propof"] . "  <br /><br />";
			
			$message .= "Game Master: " . $p["gmname"] . "<br />";                    
			$message .= "Game Master E-mail: " . $p["gmemail"] . "<br /><br />" ;
			
			$message .= "Game: " . $p["gamesystem"] . "<br />";
			$message .= "Title: " . $p["gametitle"] . "<br />";
			$message .= "Game Type: " . $this->getDescriptor($p["gametype"]) . "<br />";
			$message .= "Event Type: " . $p["eventtype"] . "<br /><br />"; 
			
			$message .= "Game Length of Time: " . $p["gametime"] . "<br />";          
			$message .= "Number of sessions: " . $p["gamesessions"] . "<br /><br />";
			
			$message .= "Is the last round a final round? " . $p["final"] . "<br />";
			
			if ($p["anytime"] != "special")
			{ 
			$message .= "Anytime: " . $p["anytime"] . "<br />";
			}
			else
			{
			$message .= 'Specific Schedule: ' . "<br />";
			if ($p["spec_day1"] != "0"){
                            $message .= "First Preference: " . $p["spec_day1"] . " " . $p["spec_time1"] . "<br /><br />";
			}
			if ($p["spec_day2"] != "0"){
                            $message .= "Second Preference: " . $p["spec_day2"] . " " . $p["spec_time2"] . "<br /><br />";
			}  
			if ($p["spec_day3"] != "0"){
                            $message .= "Third Preference: " . $p["spec_day3"] . " " . $p["spec_time3"] . "<br /><br />";
                            }  	
			}  
			$message .= "Are players able to play in more than one preliminary/single round? " . $p["multi"] . "<br />";
			
			$message .= "Number of Players (Min/Max): " . $p["minplay"] . " / " . $p["maxplay"] . "<br />";
			
			$message .= "Playing Requirements: All Materials are" . $p["playbring"] . " / " . $p["knowledge"] . "<br />";
			$message .= "Play Style/Attitude: " . $p["attitude"] . "<br />";
			$message .= "Age Rating: : " . $p["agerate"] . "<br />";
			
			$message .= "Number of GMs: " . $p["gmnum"] . "<br />";
			if ($p["gmnum"] > 1){
                            $message .= "List of other GMs: " . $p["otherGMs"] . "<br /><br />";
			}
			
			$message .= "Part of an on-going campaign: " . $p["campaign"] . "<br /><br />";
			
			$message .= "Table Space Requirements: " . $p["tspace"] . "<br />";
			$message .= "Table Size: " . $p["tablesize"] . $p["space"] . "<br />";
			
			$message .= "Notes:" . "<br />" . $p["gamenotes"] . "<br /><br />";
			
			$message .= "Other Comments:" . "<br />" . $p["comments"] . "<br /><br />";
			
			$message .= "--------------------------------------------------------------------------<br />";
			$message .= "Ron McClung<br />Gaming Coordinator<br />" . $p["eventname"] . "<br />";
			
			$message .= "--------------------------------------------------------------------------<br />";
			
			$headers  = 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			
			$mail->AddAddress($user,$gc);  
			
			$mail->AddCC($p["gmemail"],$p["gmname"]);
			
			$mail->AddReplyTo($p["gmemail"], $p["gmname"]);
			
			$mail->WordWrap = 75;                              // set word wrap
			
			$mail->IsHTML(TRUE);                               // send as HTML
			
			$mail->Subject = $subject;
			
			$mail->Body =  $message ;
			
			if(!$mail->Send()){
                            $ret = "<p>Message was not sent </p>";
                            $ret .= "<p>Mailer Error: " . $mail->ErrorInfo . '</p>';
			}
			else{
                            $ret =  "Message has been sent";
                            $ret .= '<div align="center">';
                            $ret .= '<table align="center" width="80%" cellpadding="5" border="1">';
                            $ret .= '<tr valign="middle"><td align="center">';
                            $ret .= '<h4 align="center">Game Proposal Sent!  Thank You!<br>';
                            $ret .= 'A confirmation E-mail has been sent to the e-mail address you supplied. ';
                            $ret .= 'E-mail ' . $user . ' if you have any problems.';
                            $ret .= 'You should hear back from the gaming coordinator soon.</h4>';
                            $ret .= '<p align="center">';
                            $ret .= '<input type="button"  class="btn btn-secondary" value=" Back " onclick="self.location=' . "'" . $p["returnpage"] . "'" . '">';
                            $ret .= '</p></td></tr></table></div>';
			}
			return $ret;
		}
		//---------------------------------------------------
		//
		//  
		//
		//---------------------------------------------------   
		public function gameTypeSelect(){
			
			$qry ='SELECT * FROM ogre_games_descriptor, ogre_games_descriptor_type ';
			$qry .= 'WHERE ogre_games_descriptor_type.gdt_id = ogre_games_descriptor.gd_descriptor_type ';
			$qry .= 'AND ogre_games_descriptor.gd_descriptor_type = 1 ORDER BY gd_descriptor';
			
			
			$query = $this->db->query($qry);
			$ret = '';		 
			$ret .= '<option value="0">-</option>';
			
			foreach ($query->getResult() as $row)
			{
			
			$ret .= '<option value="'. $row->gd_id . '">' . $row->gd_descriptor . '</option>';
			
			}
			
			return $ret;	
			
		}   
		

}  /* END GAMEREQUEST CLASS */ ?>