<?php
/* ----------------------------------------------------------------------------------- */
namespace App\Models;
use CodeIgniter\Model;
use CodeIgniter\I18n\Time;


//---------------------------------------------------
// Class: Game From BGG
//
//
//---------------------------------------------------

class BggGame extends Game{
    public function __construct(){
       parent::__construct();
    }	        
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function bgg_init($id){
        $this->zeroOut();
        $xmla = $this->bggItemDetail($id);
        if (is_array($xmla)){
            $this->getGameInfo($xmla);
        }
    }
//------------------------------------------------   
//
//
//
//------------------------------------------------ 
    private function zeroOut(){
        $this->init();
    }
//------------------------------------------------   
//
//
//
//------------------------------------------------      
    public function bggItemDetail($id){
        $bgg_thing = "https://www.boardgamegeek.com/xmlapi2/things?id=";
        $xml = simplexml_load_file($bgg_thing . $id);
        $xmla = $this->xmlstring2array($xml); 
        return $xmla;
    } 

//---------------------------------------------------
//
//
//
//
//---------------------------------------------------  
    private function xmlstring2array($xml){
        $array = json_decode(json_encode($xml), TRUE);
        return $array;
    }                
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    private function getGameInfo($xmla){
        $this->gameid= $xmla['item']['@attributes']['id'];
        $this->msa_id=0;
        $this->game_name= $this->getPrimaryBggName($xmla);
        $this->game_subname='';
        $this->game_abrev='';
        $this->game_type=$this->getBggType($xmla);
        $this->game_typeid=0;
        $this->game_man=$this->get_bgggamepub($xmla);;
        $this->game_manid=0;                        
        $this->game_affiliation='';
        $this->game_affiliationid=0;
        $this->game_orgtype='';
        $this->game_orgtypeid=0;                      
        $this->game_type_ids=''; 
        $this->game_types= $this->get_bgggametypes($xmla); 
        $this->game_desc = $xmla['item']['description'];
        $this->min_players=$xmla['item']['minplayers']['@attributes']["value"];
        $this->max_players=$xmla['item']['maxplayers']['@attributes']["value"];  
        $this->group_flag=0;
        $this->website='';        
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------   
    private function getPrimaryBggName($xmla){
        $namelist = $xmla['item']['name'];
        $ret = '';
        if (is_array($namelist)){
            foreach ($namelist as $nameitem){
                if (isset($nameitem['@attributes']['type'])){
                    if($nameitem['@attributes']['type']=='primary'){
                        $ret = $nameitem['@attributes']['value'];
                    }
                }else{
                    if($nameitem['type']=='primary'){
                        $ret = $nameitem['value'];
                    }
                    
                }
                    
            }
        }
        return $ret;
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------   
    private function getBggType($xmla){
        $ret = "Unknown";
        $btype = '';
        $catlist = '';
        if (is_array($xmla)){    
            $btype = $xmla['item']['@attributes']['type'];
            switch ($btype){
                case 'boardgame':
                    $catlist = $xmla['item']['link'];
                    if(in_array_r('Card Game', $catlist)){
                        $ret = 'Card Game';
                    }
                    else{
                        $ret = 'Board/Tabletop Game';
                    }
                    break;            
                case 'rpgitem':
                    $ret = 'RPG';
                    break;           
            }             
        }      
        return $ret;
    }
//---------------------------------------------------
//
//
//
//--------------------------------------------------- 
    private function get_bgggametypes($xmla){
        $ret = '';
        if(is_array($xmla)){ 
            $linklist = $xmla['item']['link'];
            foreach($linklist as $link){
                $bglinktype = $link['@attributes']['type'];
                if(($bglinktype == 'boardgamecategory') || ($bglinktype == 'boardgamemechanic')){
                    $ret .= $link['@attributes']['value'] . ',';
                }
            }
        }
    }
//---------------------------------------------------
//
//
//
//--------------------------------------------------- 
    private function get_bgggamepub($xmla){
        $ret = '';
        if(is_array($xmla)){ 
            $linklist = $xmla['item']['link'];
            foreach($linklist as $link){
                $bglinktype = $link['@attributes']['type'];
                if(($bglinktype == 'boardgamepublisher')){
                    $ret .= $link['@attributes']['value'] . ',';
                }
            }
        }
    }            
   
}  