<?php
/* ----------------------------------------------------------------------------------- */
namespace App\Models;
use CodeIgniter\Model;
use CodeIgniter\I18n\Time;
//---------------------------------------------------
// Class: Event
//---------------------------------------------------

class Event extends Game{
        var $schedule_id=0;  //also known as gameid
        var $id=0;
        var $conventionid=0;
        var $slot_code=0;
        var $convention_name='';
        var $location_name='';
        var $table_number='';
        var $table_id=0;
        var $table_placeholder_virtual=0;
        var $slot_date='';
        var $slot_day='';
        var $slot_start_time='';
        var $slot_length=0;
        var $late_night=0;
        var $slot_time=''; 
        var $baseslot=0;
        var $affiliation='';
        var $game_title='';
        var $game_subtitle='';
        var $game_notes='';
        var $gameevent_desc='';
        var $game_type='';
        var $game_type_id=0;
        var $event_type='';
        var $special_event='';
        var $editable=0;
        var $mmrpgFlag=0;
        var $BYOC_flag=0;
        var $lockgmsignup=0;
        var $alternate_preregPage='';
        var $max_number_of_players=0;
        var $min_num_of_players=0;
        var $game_fee=0;
        var $game_list=0;
        var $roll_up=0;
        var $displaymode='P';       
        var $roleplaying_rate=0;
        var $action_rate=0;
        var $puzzlesolving_rate=0;
        var $complexity_rate=0;
        var $maturity_rate=0;
        var $cancel=0;
        var $descriptor_list='';
        
        /* OP */
        var $row_enum=0;
        var $slot_enum=0;
        var $rpga_number_of_tables=1;
        var $rpga_max_players_per_table=0;
        var $rpga_active=0;
        var $rpga_slot_zero=0;
        var $rpga_game_apl_low=NULL;
        var $rpga_game_apl_high=NULL;
        var $rpga_apl_low=0;
        var $rpga_apl_high=0;
        var $rpga_level_range="";
        var $rpga_pregens=0;
        var $rpga_exp_level=NULL;
        var $rpga_scenario_id=0;
        var $rpga_scenario_name='';
        var $rpga_game_name='';
        var $rpga_rss_scenario_desc='';
        var $rpga_game_round=1;
        var $rpga_2slot_schedule_id=0;
        var $rpga_2slot_gs_id=0;    
        var $rpga_number_of_slots=1;

        var $prereg_id = 0;
        var $prereg_notes='';
        var $prereg_players_allowed=0;
        var $prereg_contact='';     
        var $prereg_opentoalt='';
        var $prereg_list= '';
        //---------------------------------------------------
        //
        //
        //
        //---------------------------------------------------
//        public function Event(){
//             parent::__construct();
//        }
    public function __construct(){
       parent::__construct();
    }	        
        //---------------------------------------------------
        //
        //
        //
        //---------------------------------------------------
        public function event_init($scheduleid=-999, $conid=0){
            $this->zeroOut();
            if ($scheduleid > 0){
                $this->getGameInfo($scheduleid, $conid);
            }
        }

        private function zeroOut(){
            $this->id=0;
            $this->conventionid =  0;
            $this->convention_name = '';
            $this->slot_date = '';
            $this->slot_day = '';
            $this->slot_start_time  = '';
            $this->slot_length = 0;
            $this->slot_time='';
            $this->table_number ='';
            $this->schedule_id =0;
            $this->affiliation ='';
            $this->gameid =0;
            $this->msa_id = 0;
            $this->game_name = '';
            $this->game_title = '';
            $this->game_type = '';
            $this->game_notes = '';
            $this->gameevent_desc = '';
            $this->game_desc = '';
            $this->event_type = '';
            $this->special_event = 0;
            $this->location_name = '';
            $this->mmrpgFlag = 0;
            $this->BYOC_flag = 0;
            $this->alternate_preregPage = '';
            $this->max_number_of_players = 0;
            $this->min_num_of_players = 0;
            $this->slot_code = '';
            $this->id = 0;
            $this->game_fee = 0;
            $this->game_list = 0;
            $this->game_subtitle = '';
            $this->maturity_rate = 0;
            $this->baseslot = 0;
            $this->late_night = 0;
            $this->roleplaying_rate = 0;
            $this->puzzlesolving_rate = 0;
            $this->action_rate = 0;
            $this->complexity_rate =0;
            $this->row_enum =0;
            $this->slot_enum = 0;
            $this->roll_up = 0;
            $this->editable = 0;
            $this->displaymode = '';
            $this->rpga_number_of_tables = 1;
            $this->rpga_max_players_per_table = 0;
            $this->rpga_scenario_id = 0;
            $this->rpga_active = 0;
            $this->rpga_slot_zero = 0;
            $this->rpga_game_apl_low = 0;
            $this->rpga_game_apl_high = 0;
            $this->rpga_2slot_schedule_id = 0;
            $this->rpga_2slot_gs_id = 0;                          
            $this->rpga_game_round  = 0;

            $this->rpga_pregens = 0;
            $this->rpga_apl_high = 0;
            $this->rpga_apl_low = 0;
            $this->rpga_level_range = 0;
            $this->rpga_exp_level = 0;
            $this->rpga_scenario_name = '';
            $this->rpga_rss_scenario_desc = '';
            $this->rpga_number_of_slots = 0;
            $this->rpga_game_name = '';

            $this->prereg_id = 0;
            $this->prereg_notes = '';
            $this->prereg_contact = '';
            $this->prereg_players_allowed = 0;
            $this->prereg_opentoalt = 0;
            $this->descriptor_list = '';
        }
        
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    private function getGameInfo($id, $conid=0){
        $ci = &get_instance();                
        $qry_gs = "SELECT * FROM `ogre_gameschedule` WHERE gs_id = " . $id;
        $qry_gs .= ($conid != 0) ? ' AND gs_convention_id = ' . $conid : '';
        $query = $ci->db->query($qry_gs);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                parent::init($row->gs_gn_id);
                $this->conventionid =  $row->gs_convention_id;
                $this->convention_name =  $row->gs_convention_name;
                $this->slot_date = $row->gs_slot_date;
                $this->slot_day = $row->gs_slot_day;
                $this->slot_start_time  = $row->gs_slot_start_time;
                $this->slot_length = $row->gs_slot_length;
                $this->slot_time=$row->gs_slot_time;
                $this->table_number = $row->gs_table_number;
                $this->table_id = $row->gs_tbl_id;
                $this->table_placeholder_virtual = $row->gs_table_placeholder_virtual;
                $this->schedule_id = $row->gs_schedule_id;
                $this->affiliation = $row->gs_affiliation;
                $this->gameid = $row->gs_gn_id;
                $this->msa_id = $row->gs_gn_msa_id;
                $this->game_name = html_entity_decode($row->gs_game_name,ENT_QUOTES);
                $this->game_title = html_entity_decode($row->gs_game_title,ENT_QUOTES);
                $this->game_type = $row->gs_game_type;
                $this->game_type_id = '';
                $this->game_notes = $row->gs_game_notes;
                $this->game_desc = $row->gs_game_desc;
                $this->gameevent_desc = $row->gs_game_desc;
                $this->event_type = $row->gs_event_type;
                $this->special_event = $row->gs_special_event;
                $this->location_name = $row->gs_location_name;
                $this->mmrpgFlag = $row->gs_mmrpgFlag;
                $this->BYOC_flag = $row->gs_BYOC_flag;
                $this->lockgmsignup = $row->gs_lockgmsignup;                                   
                $this->alternate_preregPage = $row->gs_alternate_preregPage;
                $this->max_number_of_players = $row->gs_max_number_of_players;
                $this->min_num_of_players = $row->gs_min_num_of_players;
                $this->slot_code = $row->gs_slot_code;
                $this->id = $row->gs_id;
                $this->game_fee = $row->gs_game_fee;
                $this->game_list = $row->gs_game_list;
                $this->game_subtitle = $row->gs_game_subtitle;
                $this->maturity_rate = $row->gs_maturity;
                $this->baseslot = $row->gs_base_slot;
                $this->late_night = intval($row->gs_late_night);
                $this->roleplaying_rate = $row->gs_roleplaying;
                $this->puzzlesolving_rate = $row->gs_puzzle_solving;
                $this->action_rate = $row->gs_action;
                $this->complexity_rate =$row->gs_complexity;
                $this->row_enum =$row->gs_row_enum;
                $this->slot_enum = $row->gs_slot_enum;
                $this->roll_up = $row->gs_roll_up_game;
                $this->editable = $row->gs_editable;
                $this->displaymode = $row->gs_displaymode;
                $this->cancel = $row->gs_cancelled;
                $this->descriptor_list = $row->gs_descriptorlist;
            }
        }
        else{
            $this->zeroOut();
        }
        if (intval($this->mmrpgFlag) != 0) {
            $ret = $this->getOPGameSetup($id) && $this->getOPScenarioSetup();
        }        
        $this->prereg_players_allowed = $this->getPreregPlayersAllowed($id);
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------   
    public function getOPGameSetup($scheduleid){
        $ci = &get_instance();
        $qry_rgs = "SELECT * FROM `ogre_rpga_game_setup` WHERE rgs_gs_id = " . $scheduleid;
        $query = $ci->db->query($qry_rgs);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $this->rpga_number_of_tables = $row->rgs_number_of_tables;
                $this->rpga_max_players_per_table = $row->rgs_max_players_per_table;
                $this->rpga_scenario_id = $row->rgs_scenario_id;
                $this->rpga_active = $row->rgs_active;
                $this->rpga_slot_zero = $row->rgs_slot_zero;
                $this->rpga_game_apl_low = $row->rgs_apl_low;
                $this->rpga_game_apl_high = $row->rgs_apl_high;
                $this->rpga_2slot_schedule_id = $row->rgs_2slot_schedule_id;
                $this->rpga_2slot_gs_id = $row->rgs_2slot_gs_id;
                $this->rpga_game_round  = $row->rgs_game_round;
            }
        }
        else{
            $this->rpga_number_of_tables = 1;
            $this->rpga_max_players_per_table = 0;
            $this->rpga_scenario_id = 0;
            $this->rpga_active = 0;
            $this->rpga_slot_zero = 0;
            $this->rpga_game_apl_low = 0;
            $this->rpga_game_apl_high = 0;
            $this->rpga_2slot_schedule_id = 0;
            $this->rpga_2slot_gs_id = 0;
            $this->rpga_game_round  = 0;

        }
        return true;
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------   
    public function getOPScenarioSetup(){
        $ci = &get_instance();
        $qry_rss = "SELECT * FROM ogre_rpga_scenario_setup WHERE rss_scenario_id = " . $this->rpga_scenario_id;
        $query = $ci->db->query($qry_rss);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $this->rpga_pregens = $row->rss_pregens;
                $this->rpga_apl_high = $row->rss_apl_high;
                $this->rpga_apl_low = $row->rss_apl_low;
                $this->rpga_level_range = $row->rss_level_range;
                $this->rpga_exp_level = $row->rss_exp_level;
                $this->rpga_scenario_name = html_entity_decode($row->rss_scenario_name,ENT_QUOTES);
                $this->rpga_rss_scenario_desc = ( trim($row->rss_scenario_author) != '') ?  'By ' . html_entity_decode($row->rss_scenario_author,ENT_QUOTES) . '<br/>' :  '';
                $this->rpga_rss_scenario_desc .= html_entity_decode($row->rss_scenario_desc,ENT_QUOTES);
                $this->rpga_number_of_slots = $row->rss_number_of_slots;
                $this->rpga_game_name = $row->rss_campaign_name;
            }

        } else {
            $this->rpga_pregens = 0;
            $this->rpga_apl_high = 0;
            $this->rpga_apl_low = 0;
            $this->rpga_level_range = '';
            $this->rpga_exp_level = '';
            $this->rpga_scenario_name = '';
            $this->rpga_rss_scenario_desc = '';
            $this->rpga_number_of_slots = 0;
            $this->rpga_game_name = '';            
        }
        return true;
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function getCutOffMultiplier($admin=FALSE){
        $ci = &get_instance();
        $conid = $ci->session->ogre_conid;  
        $ret = 1;
        $now_date = new Time();         
        
        $cut_date = $ci->ogre_lib->getConGamingInfoKey($conid,'con_gaming_reg_close_date');
        $cutoff_date = new Time($cut_date);
        
        $start_date = $ci->ogre_lib->getConGamingInfoKey($conid,'con_gaming_reg_open_date');
        $open_date = new Time($start_date);
            
        if ($now_date->format("U") >= $cutoff_date->format("U")){
                $ret = -1;
        }
        elseif ($now_date->format("U") >= $open_date->format("U")) {
                $ret = 1;
        }        
        if ($admin === TRUE){
            $ret = 1;
        }
        return $ret;
    }
    //---------------------------------------------------
    //
    //
    //
    //---------------------------------------------------
    public function registerPlayer($p, $userid=0, $noaccount=FALSE, $alternate=FALSE){
        $ci = &get_instance();
        $orgid = $ci->session->ogre_orgid;
        $conid = $ci->session->ogre_conid;
        $ci->convention->init($conid);
        $ret=array();
        $ret['result']=FALSE;
        $ret['resp']='';
        $ret['pp_player_prereg_id']=0;
        $msg='';
        $inputErr = FALSE;
        $opentogm = 0;
        $rnotes = "";
        $confirmed = ($alternate==TRUE) ? 0 : 1;
        if (($userid==0) && ($noaccount==FALSE)){
             $userid = $ci->session->ogre_user_ID;
             $accessrating= $ci->session->get('ogre_user_accesslevel_' . $orgid);
        }
        $accessrating= $ci->session->get('ogre_user_accesslevel_' . $orgid);     
        if($accessrating <= GAMEMASTER){
            $cutoff = $this->getCutOffMultiplier(FALSE);
            $confirmed = $confirmed * $cutoff;
        }
        $ci->person->init($conid, '', $userid);
        if (!isset($p["pname"]) || $p["pname"]==""){
             $p["pname"] =$ci->person->fullname;}
        if (!isset($p["pemail"]) || $p["pemail"]==""){
             $p["pemail"] =$ci->person->email;}                        
        if(trim($p["pname"]) == '' ){
                $inputErr = TRUE;
                $msg.='<p>Name is blank.</p>:';}
        if((trim($p["pemail"]) == '' ) && ($noaccount===FALSE)){
            $inputErr = TRUE;
            $msg.='<p>Email is blank.</p>';}
            
        $ret["contactGM"] = (trim($p["pnotes"]) != "") ? TRUE : FALSE;
        if($inputErr != TRUE){                            
            $qry_insertPlayer = 'INSERT INTO ';
            $qry_insertPlayer .= ' ogre_prereg_player  ';
            $qry_insertPlayer .= ' (';
            $qry_insertPlayer .= ' pp_gs_id, ';
            $qry_insertPlayer .= ' pp_schedule_id, ';
            $qry_insertPlayer .= ' pp_player_id, ';
            $qry_insertPlayer .= ' pp_player_name, ';
            $qry_insertPlayer .= ' pp_player_email, ';
            $qry_insertPlayer .= ' pp_player_prereg_date, ';
            $qry_insertPlayer .= ' pp_datemodified, ';
            $qry_insertPlayer .= ' pp_player_confirmed, ';
            $qry_insertPlayer .= ' pp_player_notes, ';
            $qry_insertPlayer .= ' pp_rpga_combat_role, ';
            $qry_insertPlayer .= ' pp_rpga_level, ';
            $qry_insertPlayer .= ' pp_rpga_player_apl, ';
            $qry_insertPlayer .= ' pp_rpga_open_to_judging,';
            $qry_insertPlayer .= ' pp_gm_judge_flag, ';
            $qry_insertPlayer .= ' pp_rpga_judge_apl';
            $qry_insertPlayer .= ') ';
            $qry_insertPlayer .= 'VALUES (';            
            foreach ($p as $item ){
                $item = quotes_to_entities($item);}                                                  
                $opentogm = (isset($p["playgm_checked"])) ?  ((($p["playgm_checked"]=='false') ||($p["playgm_checked"]==''))? 0 : 1) :  ((isset($p["playgm"]))? 0 : 1);
                if($this->mmrpgFlag == '1'){		                                                                      
                    if($p["activity2"] == 'Player'){
                        $rnotes = $this->get_rnotes($p);
                        $qry_insertPlayer .= $this->id . ', ';
                        $qry_insertPlayer .= $this->schedule_id . ', ';
                        $qry_insertPlayer .= $ci->person->user_id_num . ', ';
                        $qry_insertPlayer .= '"' . $p["pname"] . '",';
                        $qry_insertPlayer .= '"' . $p["pemail"] . '", ';
                        $qry_insertPlayer .= 'NOW(),';
                        $qry_insertPlayer .= 'NOW(),';
                        $qry_insertPlayer .= $confirmed . ',';
                        $qry_insertPlayer .= '"' . $rnotes . '", ';
                        $qry_insertPlayer .= '"' . $p["combatrole"] . '",';
                        $qry_insertPlayer .= '"' . $p["charlevel"] . '", ';
                        $qry_insertPlayer .= '"' . $p["playerAPL"] . '",';
                        $qry_insertPlayer .= $opentogm . ',0, ""';
                        $qry_insertPlayer .=  ')';
                    } elseif ($p["activity2"] == "Judge"){
                            $qry_insertPlayer .= $this->id . ', ';
                            $qry_insertPlayer .= $this->schedule_id .  ', ';
                            $qry_insertPlayer .= $ci->person->user_id_num . ', ';
                            $qry_insertPlayer .= '"'  . $p["pname"] . '", ';
                            $qry_insertPlayer .= '"' . $p["pemail"] . '", ';
                            $qry_insertPlayer .= 'NOW(), ';
                            $qry_insertPlayer .= 'NOW(), ';
                            $qry_insertPlayer .= '1,"","","","",0,1,';
                            $qry_insertPlayer .= '"' . $p["judgeAPL"] . '"';
                            $qry_insertPlayer .= ')';
                    }                            
                } else{
                    if(!isset($p['activity2'])){
                            $qry_insertPlayer .= $this->id . ', ';
                            $qry_insertPlayer .= $this->schedule_id . ', ';
                            $qry_insertPlayer .= $ci->person->user_id_num . ',';
                            $qry_insertPlayer .= '"' . $p["pname"] . '", ';
                            $qry_insertPlayer .= '"' . $p["pemail"] . '", ';
                            $qry_insertPlayer .= 'NOW(), ';
                            $qry_insertPlayer .= 'NOW(), ';
                            $qry_insertPlayer .= $confirmed . ',';
                            $qry_insertPlayer .= '"' . $p["pnotes"] . '",';
                            $qry_insertPlayer .= '"","","",0,0,""';
                            $qry_insertPlayer .= ')';                             
                    }
                    else{
                        if($p["activity2"] == 'Player'){   
                                $qry_insertPlayer .= $this->id . ', ';
                                $qry_insertPlayer .= $this->schedule_id . ', ';
                                $qry_insertPlayer .= $ci->person->user_id_num . ', ';
                                $qry_insertPlayer .='"' . $p["pname"] . '",';
                                $qry_insertPlayer .='"' . $p["pemail"] . '", ';
                                $qry_insertPlayer .='NOW(), ';
                                $qry_insertPlayer .='NOW(), ';
                                $qry_insertPlayer .= $confirmed .', ';
                                $qry_insertPlayer .= '"","","","",0,0,""';
                                $qry_insertPlayer .= ')';
                        } elseif ($p["activity2"] == "Judge"){
                                $qry_insertPlayer .= $this->id . ', ';
                                $qry_insertPlayer .= $this->schedule_id .  ', ';
                                $qry_insertPlayer .= $ci->person->user_id_num . ', ';
                                $qry_insertPlayer .= '"'  . $p["pname"] . '", ';
                                $qry_insertPlayer .= '"' . $p["pemail"] . '", ';
                                $qry_insertPlayer .= ' NOW(), NOW(), 1, ';
                                $qry_insertPlayer .= '"","","","",0,1,""';
                                $qry_insertPlayer .= ')';                                   
                        }
                    }
                }
                $ci->db->query($qry_insertPlayer);                                
                $ret['result']= ($ci->db->affectedRows() > 0)? TRUE : FALSE;                                  
                $ret['pp_player_prereg_id'] = ($ret['result']==TRUE) ? $ci->db->insertID() : 0;                                
            }
        else{
            $ret['result']=!$inputErr;
            $ret['msg'].= $msg;
        }              
    return $ret ;
    }
    //---------------------------------------------------
    //
    //
    //
    //---------------------------------------------------    
    
    private function get_rnotes($p){
        if ($p['combatrole'] != '0' && $p["charlevel"] != '0' && $p["playerAPL"] !='0'){
              $rnotes = $p["combatrole"] . " " . $p["charlevel"];
              $rnotes .= ((trim($p["playerAPL"]) !='') && (trim($p["playerAPL"]) !='0')) ?  $rnotes .= " / " . $p["playerAPL"] :"";
          }                                        
          elseif ($p["charlevel"] != '0' && $p["playerAPL"] !='0'){
              $rnotes = "Level " . $p["charlevel"];
              $rnotes .= (trim($p["playerAPL"])!="") ? "   APL: " . $p["playerAPL"] : "";                                                                                
          }       
          else{
              $rnotes = "";
          }             
          return $rnotes;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function registerPlayerUpdate($p, $conid){
        $ci = &get_instance();
        $inputErr = FALSE;
        $conid = $ci->session->ogre_conid;
        $curr_userid = $ci->session->ogre_user_ID;
        $msg = "";
        $ret['resp']='';
        $ret['result']=TRUE;
        if ($curr_userid != 0){
            $ci->person->init($conid, '', $curr_userid);
        }
        $ci->convention->init($conid);
        $opentogm = ((isset($p["playgm_checked"])) ? ((($p["playgm_checked"]=='false') ||($p["playgm_checked"]==''))? 0 : 1) : ((isset($p["playgm"]))? 0 : 1));
        if(trim($p["pname"]) == '' ){
                $inputErr = TRUE;
                $msg.='<p>Name is blank.</p>:';}
        if(trim($p["pemail"]) == '' ){
                $inputErr = TRUE;
                $msg.='<p>Email is blank.</p>';}
        if($inputErr != TRUE){
            foreach ( $p as $item ){
                $item = quotes_to_entities($item);}
            if($this->mmrpgFlag == 1){
                if($p["activity2"] == "Player"){

                    if ($p["combatrole"] != '0' && $p["charlevel"] != '0' && $p["playerAPL"] !='0'){
                            $rnotes = $p["combatrole"] . " " . $p["charlevel"] . " / " . $p["playerAPL"];
                    }
                    elseif ($p["charlevel"] != '0' && $p["playerAPL"] !='0'){
                            $rnotes = "Level " . $p["charlevel"] . ' / ' . $p["playerAPL"];
                    }
                    else{
                            $rnotes = "";
                    }
                    $qry = "UPDATE ogre_prereg_player SET ";
                    $qry .= " pp_player_id = " . $ci->person->user_id_num . ",";
                    $qry .= " pp_player_name = '" . $p["pname"] . "',";
                    $qry .= " pp_player_email = '" . $p["pemail"] . "',";
                    $qry .= " pp_player_notes = '" . $rnotes . "',";
                    $qry .= " pp_gm_judge_flag <= 0,";
                    $qry .= " pp_rpga_combat_role = '" . $p["combatrole"] . "',";
                    $qry .= " pp_rpga_level = " . $p["charlevel"] . ",";
                    $qry .= " pp_rpga_player_apl = '" . $p["playerAPL"] . "',";
                    $qry .= " pp_rpga_open_to_judging = " . $opentogm . ",";
                }
                elseif ($p["activity2"] == "Judge")
                {
                        $rnotes = $p["judgeAPL"];
                        $qry = "UPDATE ogre_prereg_player SET ";
                        $qry .= " pp_player_id = " . $ci->person->user_id_num . ",";
                        $qry .= " pp_player_name = '" . $p["pname"] . "',";
                        $qry .= " pp_player_email = '" . $p["pemail"] . "',";
                        $qry .= " pp_player_notes = '" . $rnotes . "',";
                        $qry .= " ABS(pp_gm_judge_flag) = 1,";
                        $qry .= " pp_rpga_judge_apl = '" . $p["judgeAPL"] . "',";
                }

            }
            else
            {
                    $qry = "UPDATE ogre_prereg_player SET ";
                    $qry .= " pp_player_id = " . $ci->person->user_id_num . ",";
                    $qry .= " pp_player_name = '" . $p["pname"] . "',";
                    $qry .= " pp_player_email = '" . $p["pemail"] . "',";
                    $qry .= " pp_player_notes = '" . $p["pnotes"] . "',";

            }           
            $qry .= " pp_datemodified = NOW() ";
            $qry .= " WHERE pp_player_prereg_id = " . $p["preregid"] . ";";

            $ci->db->query($qry);
            $ret['result']= ($ci->db->affectedRows() > 0)? TRUE : FALSE;                             
        }
        else
        {
            $ret['result']= !$inputErr;                            
            $ret['resp'] .= $msg;
        }
        return $ret ;
    }
//---------------------------------------------------
//
//---------------------------------------------------                
        public function get_prereg_players_notes($gid = 0){          
            $ci = &get_instance();
            $gid = intval($gid);
            if(intval($this->id) == 0){ 
                $qry = 'SELECT * ';
                $qry .= ' FROM ogre_preregistergamelist ';
                $qry .= ' WHERE pgl_gs_id = ' . $gid;
                $query = $ci->db->query($qry);                
                if ($query->getNumRows() > 0){
                    foreach ($query->getResult() as $row){
                        $this->prereg_id = $row->pgl_prereg_id;
                        $this->prereg_notes = $row->pgl_prereg_notes;
                        $this->prereg_contact = $row->pgl_contact_email;
                        $this->prereg_players_allowed = $row->pgl_number_of_preregs_allowable;
                        $this->prereg_opentoalt = $row->pgl_opentoalt;
                    }
                }
            }   
            return $this->prereg_notes;
        }
//---------------------------------------------------
//
//---------------------------------------------------
    public function get_preregistergamelist_preregs_allowable($gid = 0){
        $ci = &get_instance(); 
        $ret = 0;
        $qry_gamereg = 'SELECT ogre_gameschedule.*, ogre_preregistergamelist.* ';
        $qry_gamereg .= ' FROM ogre_preregistergamelist, ogre_gameschedule ';
        $qry_gamereg .= ' WHERE ogre_preregistergamelist.pgl_gs_id = ogre_gameschedule.gs_id ';
        $qry_gamereg .= ' AND ogre_gameschedule.gs_id = '. ((intval($gid) == 0)? $this->id : $gid);
        $query = $ci->db->query($qry_gamereg);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                    $ret = $row->pgl_number_of_preregs_allowable;
            }
        }    
        return $ret;    
    }
    public function get_prereg_player_total($gid=0){
        $ci = &get_instance();
        $qury_prcount = 'SELECT ogre_prereg_player.pp_player_name ';
        $qury_prcount .= ' FROM ogre_prereg_player  ';
        $qury_prcount .= ' WHERE ogre_prereg_player.pp_gs_id= ' . ((intval($gid) == 0) ? $this->id : $gid);
        $qury_prcount .= ' AND ogre_prereg_player.pp_player_confirmed = 1 ';
        $qury_prcount .= ' AND ogre_prereg_player.pp_gm_judge_flag <= 0 ';
        $qury_prcount .= ' AND pp_delete_flag = 0';
        $query2 = $ci->db->query($qury_prcount);
        $pnumreged = $query2->getNumRows();   
        return $pnumreged;
    }
//---------------------------------------------------
//  Game Is Ful
//---------------------------------------------------
    public function is_full($gid=0){
            $ret = FALSE;
            $ci = &get_instance(); 
            $gid = ($gid=='') ? 0 : $gid;
            $plyrnumallow = ($this->id == 0) ? $this->get_preregistergamelist_preregs_allowable($gid) : $this->prereg_players_allowed;
            $pnumreged =($this->id==0) ? $this->get_prereg_player_total($gid) : $this->getNumberOfPlayers(0);
            if((intval($this->prereg_opentoalt) == 1) || (intval($plyrnumallow) == 0)){
                $ret = FALSE;
            }
            else{
                $ret = intval($pnumreged) >= intval($plyrnumallow);
            }
            return  $ret;
    }
//------------------------
//
//------------------------                
    public function isfull($gid){
        $ci = &get_instance();
        $pn = 0;
        $this->event_init($gid);
        $numPlayers = $this->getPreregNum($gid);
        $numTotlPlayers = $this->getPlayerNum($gid, $this->max_number_of_players);
        if (is_numeric($numPlayers) && is_numeric($numTotlPlayers)){
            if (intval($numPlayers) <= intval($numTotlPlayers)){
                    $pn = (intval($numTotlPlayers) == 0) ? 0 : intval($numTotlPlayers) - intval($numPlayers);
            }
        }
        return $pn;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function isAlreadyRegisteredInSlot($playerid){
        $ci = &get_instance();
        $qry_slotchk = 'SELECT ogre_prereg_player.*, ogre_gameschedule.* FROM ogre_prereg_player, ogre_gameschedule ';
        $qry_slotchk .= ' WHERE ogre_gameschedule.gs_id = ogre_prereg_player.pp_gs_id  AND pp_delete_flag = 0 ';
        $qry_slotchk .= ' AND ogre_gameschedule.gs_slot_code = "' . $this->slot_code . '"';
        $qry_slotchk .= ' AND ogre_prereg_player.pp_player_id   = ' . $playerid . ' ';
        $qry_slotchk .= ' AND ogre_gameschedule.gs_convention_id   = ' . $this->conventionid;
        $query = $ci->db->query($qry_slotchk);
        $ret = ($query->getNumRows() > 0)?TRUE:FALSE;            
        return $ret ;
    }

//---------------------------------------------------
//
//---------------------------------------------------
    public function buildPreregPage($edit){
            $i= 0;
            $ret =  ($this->mmrpgFlag == 1) ? $this->buildRegistrationFormOP($edit) : $this->buildRegistrationFormRegular($edit);
            return $ret;
    }
                
//---------------------------------------------------
//
//---------------------------------------------------
    public function buildPreregPageX($gameid, $edit){
            $ret = (($this->mmrpgFlag == 1) ? $this->buildRegistrationFormOPX($gameid, $edit) : $this->buildRegistrationFormRegularX($gameid, $edit));                        
            return $ret;
    }                
//---------------------------------------------------
//
//---------------------------------------------------                
    public function build_reg_page($gameid){
            $ret = $this->buildRegFormRegular($gameid);
            return $ret;
    }                
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function getRPGASlot(){                                
        $sc = substr($this->slot_code,-3);                   
        $sn = (substr($sc,-1) == '0') ? substr($sc,0,2) : substr($sc,0,2) . 'MM';
        return $sn;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getSlotTime(){
        $st = $this->slot_start_time;
        $sl = $this->slot_length;
        $stime = new Time($st);
        $etime = new Time($st);
        $sa = explode('.', $sl);
        $ret='';
        if(count($sa) > 1){
            $m2 = (intval($sa[1]) > 0)?30:0;                   
            $etime->modify('+' . $sa[0] . 'hour');
            if ($m2 != 0){
                $etime->modify('+' . $m2 . 'minute');
            }
            $ret = $stime->format('h:i a') . " - " . $etime->format('h:i a');
        }
        else{
            $ret = 'ERROR - getSlotTime';
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------                
    public function getSlotTimeShort(){
        $st = $this->slot_start_time;
        $sl = $this->slot_length;
        $stime = new Time($st);
        $etime = new Time($st);
        $sa = explode('.', $sl);
        $m2 = ((intval($sa[1]) > 0) ? 30 :0);                   
        $etime->modify('+' . $sa[0] . 'hour');
        if ($m2 != 0){
            $etime->modify('+' . $m2 . 'minute');
        }
        $starttime = $stime->format('h:i a');
        $starthour = substr($starttime,0,2);
        $starthour = intval($starthour);
        $starttime = str_replace('0'.$starthour, $starthour,$starttime);
        $starttime = str_replace(':00','',$starttime);

        $endtime = $etime->format('h:i a');
        $endhour = substr($endtime,0,2);
        $endhour =intval($endhour);
        $endtime = str_replace('0'.$endhour, $endhour, $endtime);
        $endtime = str_replace(':00','',$endtime);

        $ret = $starttime . " - " . $endtime;
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------                
    public function getDaySlotTime_short(){
        $ret = $this->getSlotTimeShort();
        return substr($this->slot_day,0,3) .' '. $ret;             
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function buildRegPageX($gameid, $opadmin=FALSE){
        $ret='';
        $ci = &get_instance();
        $this->event_init($gameid);
        $ret .= '<div class="accordion" id="reg-page-x">';
        $ret .= '<div class="accordion-item">';
        $ret .= '<h5 class="accordion-header" id="register-person">';
        $ret .= '<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#registration-form" aria-expanded="true" aria-controls="registration-form">';
        $ret .= 'Registration Form';
        $ret .= '</button>';
        $ret .= '</h5>';
        $ret .= '<div id="registration-form" class="accordion-collapse collapse show" aria-labelledby="register-person" data-bs-parent="#reg-page-x">';
        $ret .= '<div class="accordion-body">';     
        $ret .= '<ul class="list-group">';
        $ret .= '<li class="list-group-item list-group-item-action list-group-item-primary">'.'<h3><span id="gamename"> (' . str_pad($this->id,5,'0', STR_PAD_LEFT) . ') '. $this->game_name . '</span> ' . ((trim($this->game_title) !='') ? '<span id="gametitle">' . $this->game_title . '</span><h3>' : '').'</li>';
        if($opadmin===FALSE){
            $ret .= '<li class="list-group-item list-group-item-action list-group-item-light"><strong>Type: </strong>'.$this->game_type.'</li>';
        }                       
        $ret .= '<li class="list-group-item list-group-item-action list-group-item-secondary"><strong>Day/Time: </strong> '.$this->slot_day . ' , ' . $this->getSlotTime().'</li>';
        $ret .= '<li class="list-group-item list-group-item-action list-group-item-light"><strong>Affiliation: </strong>' . $this->affiliation. '</li>';
        $ret .= '<li class="list-group-item list-group-item-action list-group-item-secondary"><strong>Location: </strong>'.$this->location_name.'</li>';
        $ret .= '<li class="list-group-item list-group-item-action list-group-item-light"><strong>Table: </strong>'. $this->table_number.'</li>';      
        $ret .= '</ul>';
        $ret .= '<form id="regform" name="regform" action="">'; 
        $ret .= '<div class="border p-4"><p>Search By:</p>';
        $ret .= '<label for="pemail" class="form-label">Player E-mail: </label>';
        $emaction=site_url("ogrex/checkUserEmail",'https');
        $emdivid='emvalid';
        $ret .= '<input type="text" class="form-control form-control-sm" id="pemail" name="pemail" value="" onblur="checkUserEmail(this, '."'".$emaction."','".$emdivid."'".');"/>';
        $ret .= '<label for="ogreidnum" class="form-label">OGRE ID Number: </label>';
        $action = site_url("ogrex/checkOgreID",'https');
        $divid = 'oidvalid';
        $ret .= '<input type="text" class="form-control form-control-sm" id="ogreidnum" name="ogreidnum" value="" onblur="checkOgreID(this, '."'".$action."','".$divid."'".')" /><span id="oidvalid"></span>&nbsp;&nbsp;';
        $ret .= '</div>';
        $ret .= '<div class="alert alert-secondary" role="alert">';
        $ret .= '<label for="pnamefirst" class="form-label">Name:</label>';
        $ret .= '<div class="input-group mb-3">';
        $ret .= '<input type="text" placeholder="First Name" class="form-control form-control-lg" id="pnamefirst" name="pnamefirst" value="" />';  
        $ret .= '<input type="text" placeholder="Last Name" class="form-control form-control-lg" id="pnamelast" name="pnamelast" value="" />';
        $ret .= '</div>';
        $ret .= '<span id="emvalid"></span>';
        $ret .= '</div>';
        $ret .= '<input type="hidden" id="preregid" name="preregid" value="" />';
        $vmode = $ci->session->viewmode;
        $ret .= '<input type="hidden" id="vmode" name="vmode" value="'.$vmode.'" />';
        $ret .= (($opadmin === TRUE) ? $this->addPlayerGMButtons($gameid) : '');
        $ret .= '</form>';   
        $ret .= '</div></div></div>';
        // PLAYER LIST
        $ret .= '<div class="accordion-item">';
        $ret .= '<h5 class="accordion-header" id="current-reg">';
        $ret .= '<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#current-reg-lilst" aria-expanded="false" aria-controls="current-reg-lilst">';
        $ret .= 'Current Registations';
        $ret .= '</button>';
        $ret .= '</h5>';
        $ret .= '<div id="current-reg-lilst" class="accordion-collapse collapse" aria-labelledby="current-reg" data-bs-parent="#reg-page-x">';
        $ret .= '<div class="accordion-body">  ';      
        $ret .= '<div class="border p-4">';
        $ret .= $this->onsiteGamePlayerAdmin($gameid);                   
        $ret .= '</div>';
        $ret .= '</div></div></div>';
        return $ret;
    }                
//---------------------------------------------------
//
//---------------------------------------------------
    private function buildRegFormRegular($gameid){
        $this->event_init($gameid);                           
        $ret = '<h2>' . $this->game_name;
        if (trim($this->game_title) !=''){
            $ret .= '<br /><br /><em>' .$this->game_title . '</em>';
        }
        $ret .= '</h2>';
        $ret .= '<div id="results" class="results"></div>';
        $ret .= '<table width="99%" cellpadding="5">';
        $ret .= '<tr>';
        $ret .= '<td width="33%">';
        $ret .= '&nbsp;';
        $ret .= '</td>';
        $ret .= '<td  width="33%">';
        $ret .= '</td>';
        $ret .= '<td align="right" width="33%">';
        $ret .= '<input type="button"  class="btn btn-secondary" name="btnReturn" value="   Close   " onclick="close_window();"/></td>';
        $ret .= '</table>';

        $ret .= '<table border="1" width="99%">';
        $ret .= '<tr>';
        $ret .= '<td style="padding:10px;">';

        $ret .= '<table width="95%" cellpadding="5" cellspacing="0">';
        $ret .= '<tr>';
        $ret .= '<td width="15%">';
        $ret .= '<strong>Type:</strong></td>';
        $ret .= '<td width="35%">';
        $ret .= $this->game_type;
        $ret .= '</td>';
        $ret .= '<td width="15%">';
        $ret .= '&nbsp;';
        $ret .= '</td>';
        $ret .= '<td width="35%"> ';
        $ret .= '&nbsp;';
        $ret .= '</td>';
        $ret .= '</tr><tr>';
        $ret .= '<td width="15%">';
        $ret .= '<strong>Day/Time:</strong>';
        $ret .= '</td>';
        $ret .= '<td width="35%"> ' . $this->slot_day . ' , ' . $this->getSlotTime() . '</td>';
        $ret .= '<td width="15%">';
        $ret .= '<strong>Affiliation:</strong>';
        $ret .= '</td>';
        $ret .= '<td width="35%">';
        $ret .= $this->affiliation . '</td>';
        $ret .= '</tr>';
        $ret .= '</table>';

        $ret .= '<form method="POST" id="regform" name="regform">'; 
        $ret .= '<table cellpadding="5" width="99%">';
        $ret .= '<tr>';
        $ret .= '<td>';
        $ret .= 'Player Name (First, Last):';
        $ret .= '</td>';
        $ret .= '<td>';
        $ret .= 'Contact E-mail:';
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '<tr>';
        $ret .= '<td>';
        $ret .= '<input type="text" id="pnamefirst" name="pnamefirst" value="" />&nbsp;&nbsp;';
        $ret .= '<input type="text" id="pnamelast" name="pnamelast" value="" />';
        $ret .= '</td>';
        $ret .= '<td>';
        $ret .= '<input type="text" id="pemail" name="pemail" value="" />';
        $ret .= '</td>';
        $ret .= '</tr>';

        $ret .= '<tr>';
        $ret .= '<td colspan="2">';
        $ret .= 'OGRE ID Number:';
        $ret .= '</tr>';                    

        $ret .= '<tr>';
        $ret .= '<td colspan="2">';
        $ret .= '<input type="text" id="ogreidnum" name="ogreidnum" value="" /><span id="oidvalid"></span>&nbsp;&nbsp;';
        $ret .= '</td>';
        $ret .= '</tr>';

        $ret .= '<tr colspan="2">';
        $ret .= '<td>';
        $ret .= '<input type="hidden" id="preregid" name="preregid" value="" />';
        $ret .= '<input type="button"  class="btn btn-secondary" name="Submit" value="Register" onclick="addPlayerRegOnsite(' . "'" . site_url('ogrex/regaction/' . $this->id,'https') . "'" . ',' .  $this->id . ',' .  $this->max_number_of_players . ');" /> ';
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '</table>';
        $ret .= '</form>';                    
        $ret .= $this->onsiteGamePlayerAdmin($gameid);
        return $ret;

    }
//---------------------------------------------------
//
//---------------------------------------------------
    private function buildRegistrationFormRegular($edit){
        $ci = &get_instance();
        
        $curr_userid = $ci->session->ogre_user_ID;
        $ret='';
        if ($curr_userid != 0){
                $ci->person->init($ci->session->ogre_conid, '', $curr_userid);
        }
        $ret . $this->buildRegistrationFormHeader();
        if(trim($this->prereg_notes) != ""){
            $ret .= '<tr>';
            $ret .= '<td>';
            $ret .= '<strong>Pre-Registration Instructions/Information:</strong>';
            $ret .= $this->prereg_notes;
            $ret .= '</td>';
            $ret .= '</tr>';
        }
        $ret .= '</table>';
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '</table>';

        $ret .= '<form action="' . site_url('ogrex/preregAction/' . $this->id,'https') . '" method="POST" name="prform">';
        $ret .= '<table class="regform">';
        $ret .= '<tr>';
        $ret .= '<td colspan="2">';
        //%RegularRegInstructions%
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '<tr>';
        $ret .= '<td>';
        $ret .= 'Player Name:';
        $ret .= '</td>';
        $ret .= '<td>';
        $ret .= 'Player E-mail:';
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '<tr>';
        $ret .= '<td>';
        $pname = ($edit == TRUE)?$ci->person->getRegistrationInfo($this->id, 'pp_player_name'):$ci->person->fullname;
        $ret .= '<input type="text" name="pname" size="25" value="' . $pname . '" />';
        $ret .= '</td>';
        $ret .= '<td>';
        $pemail = ($edit == TRUE)?$ci->person->getRegistrationInfo($this->id, 'pp_player_email'):$ci->person->email;
        $ret .= '<input type="text" name="pemail" size="25" value="' . $pemail . '" />';
        $ret .= '</td>';
        $ret .='</tr>';

        $ret .= '<tr>';
        $ret .='<td colspan="2">';
        $ret .= 'Players Notes:<br />';
        $ret .= '<textarea name="pnotes" rows="5" cols="55">';
        if ($edit == TRUE){
            $ret .= $ci->person->getRegistrationInfo($this->id, 'pp_player_notes');
        }
        $ret .= '</textarea>';
        $ret .= '</tr>';
        $ret .='</td>';
        $ret .= '</table>';
        $ret .= '<table class="regform">';
        $ret .= '<tr>';
        $ret .='<td>';

        $ret .='<input type="button" class="btn btn-secondary" name="close" id="close" value=" Close " onclick="window.close()" />';

        $ret .= '</td>';                   
        $ret .='<td>';
            if ($edit == TRUE){
                $ret .='<input type="button" class="btn btn-secondary" name="remove" id="removebutton" value="  Remove Me From Game  " onclick="delconfirm(' . "'" . site_url('ogrex/preregAction/' . $this->id . '/regular/TRUE/TRUE','https') . "'" . ');" />';
            }
        $ret .= '</td>';
        $ret .= '<td class="rightsidebutton">';
        $prgid = ($edit == TRUE)?$ci->person->getRegistrationInfo($this->id, 'pp_player_prereg_id'): "-9999";
        $ret .= '<input type="hidden" name="preregid" value="'.$prgid.'" />';
        $ret .= '<input class="btn btn-secondary" type="submit" id="Submit" name="Submit" value="Submit Pre-Reg" /> ';
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '</table>';
        $ret .= '</form>';
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------               
    public function buildRegistrationFormRegularX($gameid, $edit){
        $ci = &get_instance();
        $ci->session->set(array('viewmode' => 'MAIN'));
        $curr_userid = $ci->session->ogre_user_ID;
        $ret = '<div id="prereg-edit-tabs">';
        $ret .= '<ul>';
        $ret .= '<li><a href="#tabs-1">Edit Player Info</a></li>';
        $ret .= '<li><a href="#tabs-2">Leave Comment</a></li>';
        $ret .= '</ul>';
        $ret .= '<div id="tabs-1">';
        $ret .= $this->buildRegistrationFormRegularBasicX($gameid, $edit);
        $ret .= '</div>';
        $ret .= '<div id="tabs-2">';
        $ret .= $this->buildRegistrationFormRegularCommentsX($gameid, $edit);
        $ret .= '<div id="prereg-edit-comments-'.$gameid.'">';
        $ret .= $this->getEventComments($gameid);
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '<script>$( function() { $( "#prereg-edit-tabs" ).tabs();} );</script>';        
        return $ret;                    
    }
//---------------------------------------------------
//
//---------------------------------------------------               
    public function buildRegistrationFormRegularBasicX($gameid, $edit){
        $ci = &get_instance();
        $ci->session->set(array('viewmode' => 'MAIN'));
        $curr_userid = $ci->session->ogre_user_ID;
        if ($curr_userid != 0){
            $ci->person->init($ci->session->ogre_conid, '', $curr_userid);
        }
        $prgid = ($edit == TRUE)? $ci->person->getRegistrationInfo($this->id, 'pp_player_prereg_id'): "-9999";
        $ret = $this->buildRegistrationFormHeader($gameid);
        $ret .= '<form action="" name="prform" id="prform">';
        $ret .= '<div id="reg-form-player-info">';
        $ret .= '<input type="hidden" id="preregid" name="preregid" value="'.$prgid.'" />';
        $ret .= '<input type="hidden" id="player-id" name="player-id" value="'.$curr_userid.'" />';
        $ret .= '<input type="hidden" id="ogreidnum" name="ogreidnum" value="'.$this->id.'" />';
        $ret .= '<input type="hidden" id="pnotes" name="pnotes" value="" />'; 
        $ret .= '<label for="pname" class="form-label">Player Name:</label>';
        $pname = (($edit == TRUE)? $ci->person->getRegistrationInfo($this->id, 'pp_player_name') : $ci->person->fullname);
        $ret .= '<input type="text" class="form-control" id="pname" name="pname" value="' . $pname . '" />';
        $ret .= '<input type="hidden" id="vmode" name="vmode" value="' . $ci->session->viewmode . '"/>';
        $ret .= '<label for="pemail" class="form-label">Player E-mail:</label>';                  
        $pemail = (($edit == TRUE)? $ci->person->getRegistrationInfo($this->id, 'pp_player_email') : $ci->person->email);
        $ret .= '<input type="text" class="form-control" id="pemail" name="pemail" value="' . $pemail . '" />';
        $ret .= '</div>';
        $ret .= '</form>';     
        $action= site_url('ogrex/preregActionX').'/'.$gameid.'/TRUE';
        $footer = '<div class="d-grid gap-2"><button type="button" class="btn btn-primary mb-3" id="update-player-info" name="update-player-info" onclick="updtPlayerPrereg('."'".$action."'".');" >Save</button></div><div id="results" class="text-success"></div>';
        return $ci->ogre_lib->bootCard('',$ret, 'reg-form-player-info-card', 'Player Info', '', $footer);                  
    }
//---------------------------------------------------
//
//---------------------------------------------------               
    public function buildRegistrationFormRegularCommentsX($gameid, $edit){
        $ci = &get_instance();
        $ci->session->set(array('viewmode' => 'MAIN'));
        $curr_userid = $ci->session->ogre_user_ID;
        if ($curr_userid != 0){
            $ci->person->init($ci->session->ogre_conid, '', $curr_userid);
        }
        $ret = '<div id="results-comments-'.$gameid.'" class="results-comments-'.$gameid.'"></div>';
        $ret = '<form action="" name="pr-comment-'.$gameid.'" id="pr-comment-'.$gameid.'">';        
        $ret .= '<div id="reg-form-player-comment-'.$gameid.'">';
        $ret .= '<label for="pnotes-comments-'.$gameid.'" class="form-label">Comments:</label>';                 
        $ret .= '<textarea class="form-control" id="pnotes-comments-'.$gameid.'" name="pnotes-comments-'.$gameid.'" placeholder="Leave a comment or question here. GM will be notified" ></textarea>';
        $prgid = ($edit == TRUE)?$ci->person->getRegistrationInfo($this->id, 'pp_player_prereg_id'): "-9999";
        $ret .= '<input type="hidden" id="preregid-'.$gameid.'" name="preregid-'.$gameid.'" value="'.$prgid.'" />';
        $ret .= '<input type="hidden" id="ogreidnum-'.$gameid.'" name="ogreidnum-'.$gameid.'" value="'.$this->id.'" />';                    
        $ret .= '</div>';
        $ret .= '</form>';
        $div = 'prereg-edit-comments-';
        $frm = 'pr-comment-';
        $action = site_url('ogrex/addGameComment/'.$gameid);
        $footer = '<div class="d-grid gap-2"><button type="button" class="btn btn-secondary mb-3" id="leave-comment" name="leave-comment" onclick="leaveComment('.$gameid.','.$curr_userid.",'".$action."','".$div."','".$frm."'".');" >Leave Comment</button></div>';
        return $ci->ogre_lib->bootCard('',$ret, 'reg-form-player-comments-card-'.$gameid, 'Comments', '',$footer);                  
    }    
//---------------------------------------------------
//
//---------------------------------------------------
    public function getEventComments($gameid,$userid=0){
        $ci = &get_instance();
        $ret = '';
        $conid = $ci->session->ogre_conid;
        
        $qry = 'SELECT * FROM ogre_messages ';
        $qry .= ' WHERE msg_gsid = ' . $gameid;
        $qry .= ' AND msg_replyid = 0 ';
        if($userid !== 0){
            $qry .= ' AND msg_userid = ' . $userid;
        }
        $qry .= ' ORDER BY msg_datecreated DESC';
        $rs = $ci->db->query($qry);
        if ($rs->getNumRows() > 0){
            foreach ($rs->getResult() as $row){
                $msg = $row->msg_message . $this->getReply($row->msg_id);
                $ci->person->get($row->msg_userid,$conid);
                $ret .= $ci->ogre_lib->commentCard($msg, $ci->person->fullname. ' ['.str_pad($ci->person->user_id_num,6,'0',STR_PAD_LEFT) .']', $row->msg_datecreated, $row->msg_dateread);
            }
        }
        return $ret;        
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getEventCommentReply($cid){
        $ci = &get_instance();
        $ret = '';
        $conid = $ci->session->ogre_conid;
        
        $qry = 'SELECT * FROM ogre_messages ';
        $qry .= ' WHERE msg_replyid = ' . $cid;
        $qry .= ' ORDER BY msg_datecreated DESC';
        $rs = $ci->db->query($qry);
        if ($rs->getNumRows() > 0){
            foreach ($rs->getResult() as $row){
                $msg = $row->msg_message;
                $ci->person->get($row->msg_userid,$conid);
                $ret .= $ci->ogre_lib->commentCard($msg, $ci->person->fullname. ' ['.str_pad($ci->person->user_id_num,6,'0',STR_PAD_LEFT) .']', $row->msg_datecreated, $row->msg_dateread);
            }
        }
        return $ret;        
    }   
//---------------------------------------------------
//
//---------------------------------------------------     
    public function getEventCommentsGMView($gameid, $reply=TRUE){
        $ci = &get_instance();
        $ret = '';
        $conid = $ci->session->ogre_conid;
         
        $qry = 'SELECT * FROM ogre_messages ';
        $qry .= ' WHERE msg_gsid = ' . $gameid;
        $qry .= ' AND msg_replyid = 0 ';
        $qry .= ' ORDER BY msg_datecreated DESC';
        $rs = $ci->db->query($qry);
        
        if ($rs->getNumRows() > 0){
            foreach ($rs->getResult() as $row){
                $ci->person->get($row->msg_userid, $conid);
                $msg = $row->msg_message . $this->getReply($row->msg_id);
                $ret .= $this->commentCard2($gameid, $row->msg_id, $msg, $ci->person->fullname,$row->msg_datecreated,$row->msg_dateread,$row->msg_userid, $reply);
            }
        }
        return $ret;        
    }
//---------------------------------------------------
//
//--------------------------------------------------- 
    public function commentCard2($gameid, $cid, $text='Test', $name='NAME', $date=NULL, $rdate=NULL, $pid=0, $reply=TRUE){
        $ci=&get_instance();
        $ret = '';
        $ci->person->get($pid);
        $userid = $ci->session->ogre_user_ID;
        $cdate = strtotime($date); 
        $rrdate = strtotime($rdate);        
        $ret .= '<section style="background-color: #eee;">';
        $ret .= '<div class="container my-1 py-1">';
        $ret .= '<div class="card" id="comment-'.$cid.'">';
        $ret .= '<div class="card-body">';
        $ret .= '<p class="fw-bold text-primary mb-1">'. $ci->person->fullname.'</p>';
        $ret .= '<p class="text-muted small mb-1">' . (($date !== NULL)? 'Created - ' . date('M-d-Y', $cdate) : '') .' '.(($rdate !== NULL)? '<br />Read - ' . date('M-d-Y', $rrdate) : '') .'</p>';
        $ret .= '<p class="my-1 mb-1 pb-1">'. $text . '</p>';
        $ret .= '<div class="card-footer py-1 border-0" style="background-color: #f8f9fa;" id="reply-body-'.$cid.'">';
        $ret .= (($reply===TRUE)? $this->commentReplyCard($gameid,$userid, $cid) : '');
        $ret .= '</div>';             
        $ret .= '</div>';
        $ret .= '</div></div>';     
        $ret .= '</section>';
        
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------    
    public function commentReplyCard($gid,$pid,$cid){  
        $ci=&get_instance();
        $ret = '';     
        $raction = site_url('ogrex/addGameCommentReply/'.$gid,'https');
        $div = 'reply-body-';
        $frm = 'gm-reply-form-';
        if (($this->repliedTo($cid) == FALSE) &&($ci->event->markedRead($cid) == FALSE)){
            $ci->person->get($pid);
            $ret .= '<form id="gm-reply-form-'.$cid.'">';
            $ret .= '<textarea class="form-control bg-light" placeholder="Reply Here" id="gm-reply-'.$cid.'" rows="4"></textarea>';
            $ret .= '<div class="float-end my-1 pt-1">';
            $ret .= '<button type="button" class="btn btn-primary btn-sm" onclick="leaveReplyComment('."'".$raction."',".$cid.','.$pid.",'".$div."','".$frm."'".');">Reply</button>';
            $ret .= '<button type="button" class="btn btn-outline-primary btn-sm" onclick="markRead('.$cid.');">Mark Unread</button>';
            $ret .= '</form>';
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------      
    public function addComments($gid, $msg, $pid=0, $replyid=0){
        $ci = &get_instance();
        $ret = 
        $ins = '';
        $ins .= 'INSERT INTO ogre_messages(';
        $ins .= ' msg_replyid,';
        $ins .= ' msg_userid,';
        $ins .= ' msg_gsid,';
        $ins .= ' msg_message,';
        $ins .= ' msg_datecreated';
        $ins .= ') ';
        $ins .= ' VALUES (';
        $ins .= $replyid .',';
        $ins .= $pid .',';
        $ins .= $gid .',';
        $ins .= '"' .addslashes($msg) .'",';
        $ins .= 'NOW()';
        $ins .= ");";
        $ci->db->query($ins);                                
        $ret = ($ci->db->affectedRows() > 0)? TRUE : FALSE;  
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------    
    public function repliedTo($cid){
        $ci = &get_instance();
        $ret = '';
        $qry = 'SELECT * FROM ogre_messages ';
        $qry .= ' WHERE msg_replyid = ' . $cid;
//        $qry .= ' AND msg_replyid <> 0 ';
        $rs = $ci->db->query($qry);
        $ret = (($rs->getNumRows() > 0) ? TRUE : FALSE);
        return $ret;          
    }
//---------------------------------------------------
//
//---------------------------------------------------    
    public function markedRead($cid){
        $ci = &get_instance();
        $ret = '';
        $qry = 'SELECT * FROM ogre_messages ';
        $qry .= ' WHERE msg_id = ' . $cid;
        $qry .= ' AND msg_dateread <> NULL ';
        $rs = $ci->db->query($qry);
        $ret = (($rs->getNumRows() > 0) ? TRUE : FALSE);
        return $ret;          
    }    
//---------------------------------------------------
//
//---------------------------------------------------    
    public function getReply($cid){
        $ci = &get_instance();
        $ret = '';
        $qry = 'SELECT * FROM ogre_messages ';
        $qry .= ' WHERE msg_replyid = ' . $cid;
        $rs = $ci->db->query($qry);
        if ($rs->getNumRows() > 0){
            foreach ($rs->getResult() as $row){
                $ci->person->get($row->msg_userid);
                $ret .= $ci->ogre_lib->commentCard($row->msg_message, $ci->person->fullname . '['.$ci->person->user_id_num .']', $row->msg_datecreated, $row->msg_dateread);
            }
        }
        return $ret;          
    }    
//---------------------------------------------------
//
//---------------------------------------------------                
    public function buildRegistrationFormHeader($gid=0){
        $ret='';
        $ci = &get_instance();
        $ret .= $ci->schedule_lib->gameDescBoot($gid);
        return $ret;            
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getGMPlayerList($gid=0){
            if($gid !=0){
                $this->event_init($gid);  
            }    
            $ret='';
            $ret .= '<table class="regform">';
            $ret .= '<tr>';
            $ret .= '<td>';
            $ret .= '<strong>GM(s):</strong>';
            $ret .= '</td>';
            $ret .= '<td id="gmlist">';
            $gm_list = $this->getPlayerList(1);
            $i=0;
            $lst='';
            foreach ($gm_list as $gm)
            {
                if((trim($gm[1])!="") && (trim($gm[1])!="-"))
                {
                    $lst .= $gm[1] . ', ';
                }
                $i++;
            }

            $ret .= substr($lst,0,strlen($lst)-2);
            $ret .= '</td>';
            $ret .= '</tr>'; 

            $ret .= '<tr>';
            $ret .= '<td>';
            $ret .= '<strong>Player(s):</strong>';
            $ret .= '</td>';

            $ret .= '<td id="playerlist">';
            $p_list = $this->getPlayerList(0);
            $i=0;
            $lst='';
            foreach ($p_list as $p)
            {
                if((trim($p[1])!="") && (trim($p[1])!="-"))
                {
                    $lst .= $p[1] . ', ';
                }
                $i++;
            }
            $ret .= substr($lst,0,strlen($lst)-2);
            $ret .= '</td>';
            $ret .= '</tr>'; 
            $ret .= '</table>';    
            return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function buildRegistrationFormOP($edit){
        $ret='';    
        $ci = &get_instance();
        $curr_userid = $ci->session->ogre_user_ID;    
        if ($curr_userid != 0){
                $ci->person->init($ci->session->ogre_conid, '', $curr_userid);
                $jflag = $ci->person->getRegistrationInfo($this->id, 'pp_gm_judge_flag');                                
        }                                                            
        $ret .= $this->buildRegistrationFormHeader();
        if(trim($this->prereg_notes) != "")
        {
            $ret .= '<table id="prereginstructions">';
            $ret .= '<tr>';
            $ret .= '<td><strong>Pre-Registration Instructions/Information:</strong>';
            $ret .= '<p>' . $this->prereg_notes . '</p>';
            $ret .= '</td>';
            $ret .= '</tr>';
            $ret .= '</table>';
        }
        $ret .= '<form action="' . site_url('ogrex/preregAction/' . $this->id . '/rpga','https') .'" method="POST" id="prform">';
        $ret .= '<table class="prereginfo">';
        $ret .= '<tr>';
        $ret .= '<td>';
        $ret .= 'Player Name:';
        $ret .= '</td>';
        $ret .= '<td>';
        $ret .= 'Player E-mail:';
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '<tr>';
        $ret .= '<td>';
        $ret .= '<input type="text" id="pname" name="pname" size="25" value="' . $ci->person->fullname  . '"/>';
        $ret .= '</td>';
        $ret .= '<td>';
        $ret .= '<input type="text" id="pemail" name="pemail" size="25" value="' . $ci->person->email . '"/>';
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '</table>';
        $ret .= '<table class="prereginfo2">';
        $ret .= '<tr>';
        $ret .= '<td>';
        $ret .= '<table id="oppcinfo">';
        $ret .= '<tr>';
        $ret .= '<td>';                        
        $ret .=  (($edit == TRUE) && (intval($jflag) <= 0)) ? '<input type="radio" id="activity2" name="activity2" value="Player" checked="checked" /> Player' : '<input type="radio" id="activity2" name="activity2" value="Player"  checked="checked"  /> Player';
        $ret .= '</td>';
        $ret .= '<td> ';
        $ret .= 'Combat Role<br />';
        $ret .= $this->combatRoleSelect($edit);
        $ret .= '</td>';
        $ret .='<td>';
        $ret .='Level<br />';
        $ret .= $this->d20LevelSelect($edit);
        $ret .= '</td>';
        $ret .='<td>';
        $ret .='Level Pref:<br />';
        $ret .= ($edit == TRUE) ? '<input name="playerAPL" id="playerAPL" type="text" value="' . $ci->person->getRegistrationInfo($this->id, 'pp_rpga_player_apl') . '" size="15"/>' : '<input name="playerAPL" id="playerAPL" type="text" value="" size="15"/>';
        $ret .='</td>';
        $ret .= '</tr>';
        $ret .= '</table>';
        $ret .='<table id="opjudgeinfo">';
        $ret .='<tr>';
        $ret .='<td>';
        $ret .= (($edit == TRUE) && (abs(intval($jflag)) == 1)) ? '<input type="radio" id="activity2" name="activity2" value="Judge" checked="checked" /> Judge' : '<input type="radio" id="activity2" name="activity2" value="Judge" /> Judge';
        $ret .='</td>';
        $ret .='<td>';
        $ret .='Level Pref: ';
        $ret .= ($edit == TRUE) ? '<input name="judgeAPL" id="judgeAPL" type="text" value="' . $ci->person->getRegistrationInfo($this->id, 'pp_rpga_judge_apl') . '"  size="15" />' : '<input name="judgeAPL" id="judgeAPL" type="text" value=""  size="15" />';
        $ret .='</td>';
        $ret .='</tr>';
        $ret .='</table>';
        $ret .='<table id="opjudgeopgtion">';
        $ret .='<tr>';
        $ret .='<td>';
        $otg = $ci->person->getRegistrationInfo($this->id, 'pp_rpga_open_to_judging');
        $ret .= (($edit == TRUE) && ($otg == "1")) ? '<input type="checkbox" id="playgm" name="playgm" checked="checked" />' : '<input type="checkbox" id="playgm" name="playgm" />';
        $ret .='</td>';
        $ret .='<td>';
        $ret .='Play, but Open to GM';
        $ret .='<input type="hidden" id="pnotes" name="pnotes" value=""/>';
        $ret .='<input type="hidden" id="preregid" name="preregid" value="';
        $ret .= ($edit == TRUE) ? $ci->person->getRegistrationInfo($this->id, 'pp_player_prereg_id') : "-9999";
        $ret .= '" />';
        $ret .='</td>';
        $ret .='</tr>';
        $ret .='</table>';
        $ret .='<tr>';
        $ret .='<td>';
        $ret .='<table id="preregbuttons">';
        $ret .='<tr>';
        if ($edit == TRUE){
            $ret .='<td>';
            $ret .='<div id="rembutton">';
            $ret .='<input type="button"  class="btn btn-secondary" class="btn btn-secondary" name="remove" id="removebutton" value="Drop Out" onclick="delconfirm(' . "'" . site_url('ogrex/preregAction/' . $this->id . '/rpga/TRUE/TRUE','https') . "'" . ');" />';
            $ret .='</div>';
            $ret .='</td>';
        }
        $ret .='<td>';
        $ret.='<table id="preregbuttons2">';
        $ret .='<tr>';
        $ret .='<td class="leftsidebutton">';
        $ret .='<input class="btn btn-secondary" type="submit" id="Submit" name="Submit" class="btn btn-secondary" value="   Preregister   " />&nbsp;';
        $ret .='</td>';
        $ret .='<td class="rightsidebutton">';
        $ret .= '<input class="btn btn-secondary" type="button"  class="btn btn-secondary" id="btnReturn" name="btnReturn" value="   Close   " onclick="close_window();" />';  
        $ret .='</td>';
        $ret .='</tr>';
        $ret .='</table>';
        $ret .='</td>';
        $ret .='</tr>';
        $ret .='</table>';
        $ret .='</td>';
        $ret .='</tr>';
        $ret .='</table>';
        $ret .='</form>';
        return $ret;
    }
                
//---------------------------------------------------
//
//---------------------------------------------------
    function buildRegistrationFormOPX($gameid, $edit){
        $ret='';    
        $ci = &get_instance();
        $conid = $ci->session->ogre_conid;
        $orgid = $ci->session->ogre_orgid;
        $curr_userid = $ci->session->ogre_user_ID;
        $now_date = new Time();
//                    $close_date =  ;
        $close_date = new Time($ci->ogre_lib->getConGamingInfoKey($conid, 'con_gaming_reg_close_date'));                    
        $jflag = 0;
        $rowid=$this->slot_day.$this->row_enum;

        if ($curr_userid != 0){
            $ci->person->init($ci->session->ogre_conid, '', $curr_userid);
            $jflag = $ci->person->getRegistrationInfo($this->id, 'pp_gm_judge_flag');    
        }                   
        $ret .= '<div id="results" class="results"></div>';     
        $ret .= $this->buildRegistrationFormHeader();
        if(trim($this->prereg_notes) != ""){
//<regnotes>
            $ret .= '<table id="prereginstructions">';
            $ret .= '<tr>';
            $ret .= '<td>';
            $ret .= '<p><strong>Pre-Registration Instructions/Information:</strong></p>';
            $ret .= '' . txt2html(strip_tags($this->prereg_notes)) . '';
            $ret .= '</td>';
            $ret .= '</tr>';
            $ret .= '</table>';
//</regnotes>                            
        }

//<form>                
        $ret .= '<div id="results" class="results"></div>';
        $ret .= '<div id="preregisterform">';
        $ret .= '<form action="" method="POST" id="prform">';
//<prereginfo>                        
        $ret .= '<table class="prereginfo">';
        $ret .= '<tr>';
        $ret .= '<td colspan="2">';
        $ret .= '<strong>Player Information</strong>';
        $ret .= '</td>';
        $ret .= '</tr>';                        

        $ret .= '<tr>';
        $ret .= '<td>';
        $ret .= 'Player Name:';
        $ret .= '</td>';
        $ret .= '<td>';
        $ret .= 'Player E-mail:';
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '<tr>';
        $ret .= '<td>';
        $ret .= '<input type="text" id="pname" name="pname" value="' . $ci->person->fullname  . '"/>';
        $vmode = $ci->session->viewmode;
        $ret .= '<input type="hidden" id="vmode" name="vmode" value="' . $vmode . '"/>';
        $ret .= '</td>';
        $ret .= '<td>';
        $ret .= '<input type="text" id="pemail" name="pemail" value="' . $ci->person->email . '"/>';
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '</table>';
//</prereginfo>
        $ret .= '<table class="prereginfo">';
        $ret .= '<tr>';
        $ret .= '<td>';
//<oppcinfo>
        $ret .= '<table id="oppcinfo">';
        $ret .= '<tr>';
        $ret .= '<td class="oppcinfo_label"> ';
        $ret .= 'Player or Judge?  ';
        $ret .= '</td>';
        $ret .= '<td class="oppcinfo_select">';
        $ret .= $this->preRegRole($edit);
        $ret .= '</td>';
        $ret .= '<td class="oppcinfo_check">';
        $ret .= (abs(intval($jflag)) == 1) ?  '<div id="opentogm" style="display:none">' : '<div id="opentogm" style="display:block">';
        $otg = $ci->person->getRegistrationInfo($this->id, 'pp_rpga_open_to_judging');
        $ret .= (($edit == TRUE) && ($otg == "1")) ? '<input type="checkbox" id="playgm" name="playgm" checked="checked" />' : '<input type="checkbox" id="playgm" name="playgm" />';
        $ret .=' Play, Open to GM ';
        $ret .= '</div>';
        $ret .='<input type="hidden" id="ogreidnum" name="ogreidnum" value="'.$this->id.'"/>';
        $ret .='<input type="hidden" id="pnotes" name="pnotes" value=""/>';
        $ret .='<input type="hidden" id="preregid" name="preregid" value="';
        $ret .= ($edit == TRUE) ?  $ci->person->getRegistrationInfo($this->id, 'pp_player_prereg_id') :  "-9999";
        $ret .= '" />';                        
        $ret .= '</td>';
        $ret .= '</tr>';  
        $ret .= '<tr>';
        $ret .= '<td colspan="3"> ';                          
        if($edit===FALSE){
            $ret .= '<div id="player_reginfo" style="display:block">';
        }
        else{
            $ret .= (intval($jflag) <= 0) ? '<div id="player_reginfo" style="display:block">' : '<div id="player_reginfo" style="display:none">';
        }
        $ret .= $this->playerOrJudgeRole('Player', $edit, $jflag); 
        $ret .= '</div> ';
       if($edit===FALSE){
            $ret .= '<div id="judge_reginfo" style="display:none">';
        }
        else{
            $ret .= (abs(intval($jflag)) == 1) ? '<div id="judge_reginfo" style="display:block">' : '<div id="judge_reginfo" style="display:none">';
        }                            
        $ret .= $this->playerOrJudgeRole('Judge', $edit, $jflag); 
        $ret .= '</div> ';                          
        $ret .= '</td>';
        $ret .= '</tr>';                              
        $ret .= '</table>';
//</oppcinfo>                                                              

    $ret .='</td>';
    $ret .='</tr>';
    $ret .='</table>';
//</oppcinfo>                           
    $ret .='</form>';
    $ret .='</div>';
    return $ret;
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function playerOrJudgeRole($role='Player', $edit=FALSE, $jflag=0){      
        $ci = &get_instance();
        $curr_userid = $ci->session->ogre_user_ID;
        if ($curr_userid != 0){
                $ci->person->init($ci->session->ogre_conid, '', $curr_userid);
        }
        $ret='';
        switch ($role){
            case 'Player':
                $ret .= '<table id="oppcinfo_player">';
                $ret .= '<tr>';
                $ret .= '<td> ';
                $ret .= 'Player Character<br />Combat Role<br />';
                $ret .= $this->combatRoleSelect($edit);
                $ret .= '</td>';
                $ret .='<td>';
                $ret .='Player Character<br />Level<br />';
                $ret .= $this->d20LevelSelect($edit);
                $ret .= '</td>';
                $ret .='<td>';
                $ret .='Party<br />Level Pref/Tier:<br />';
                $ret .= ($edit == TRUE) ?  '<input name="playerAPL" id="playerAPL" type="text" value="' . $ci->person->getRegistrationInfo($this->id, 'pp_rpga_player_apl') . '" size="15"/>' : '<input name="playerAPL" id="playerAPL" type="text" value="" size="15"/>';
                $ret .='</td>';
                $ret .='</tr>';
                $ret .= '</table>';
             break;
           case 'Judge':                         
                $ret .='<table id="oppcinfo_judge">';
                $ret .='<tr>';
                $ret .='<td>';
                $ret .='Judge Level Pref: ';
                $ret .='</td>';
                $ret .='<td>';
                $ret .= ($edit == TRUE) ?  '<input name="judgeAPL" id="judgeAPL" type="text" value="' . $ci->person->getRegistrationInfo($this->id, 'pp_rpga_judge_apl') . '"  size="15" />' : '<input name="judgeAPL" id="judgeAPL" type="text" value=""  size="15" />';
                $ret .='</td>';
                $ret .='</tr>';
                $ret .='</table>';
             break;                                                
        }
        return $ret;
    }            
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function combatRoleSelect($edit=FALSE){
            $ci = &get_instance();
            $sql = 'SELECT * FROM ogre_misccontent  WHERE mc_id= 8';
            $query = $ci->db->query($sql);
            if($query->getNumRows() != 0){
                foreach ($query->getResult() as $row){
                    $rc = $row->mc_content;
                }

            }
            $croles = explode(',',$rc);
            sort($croles);
            if ($edit == TRUE){
                $cr = $ci->person->getRegistrationInfo($this->id, 'pp_rpga_combat_role');
            }
            else{
                $cr='';
            }
            $ret = '<select id="combatrole" name="combatrole" >'; //onChange="changeActivity(0)"
            $ret .='<option value="0" selected="selected">- SELECT -</option>';
            foreach($croles as $ccr){
                if($ccr!=''){
                     $ret .= ($cr == $ccr) ? '<option value="' . $ccr . '" selected="selected">' . $ccr . '</option>' : '<option value="' .  $ccr  . '">' .  $ccr  . '</option>';
                }
             }
        $ret .='</select>';
        return $ret;
    }
    //---------------------------------------------------
    //
    //
    //
    //---------------------------------------------------                
    public function preRegRole($edit=FALSE){
        $ci = &get_instance();
        $conid = $ci->session->ogre_conid;
        $curruserid = $ci->session->ogre_user_ID;
        $ci->person->init($conid, '', $curruserid);

        $ret = '<select id="activity2" onchange="prereg_activity(this.options[this.selectedIndex].value)">'; //onChange="changeActivity(0)"
        if ($edit != TRUE){                          
            $ret .='<option value="Player" selected="selected"> Player    </option>';
            $ret .='<option value="Judge"> Judge    </option>';
        }
        else{                       
            $gmflag = $ci->person->getRegistrationInfo($this->id, 'pp_gm_judge_flag');
            if (abs(intval($gmflag)) == 1){
                $ret .='<option value="Player"> Player    </option>';
                $ret .='<option value="Judge" selected="selected"> Judge    </option>';
            }
            else{
                $ret .='<option value="Player" selected="selected"> Player    </option>';
                $ret .='<option value="Judge"> Judge    </option>';
            }
        }
        $ret .='</select>';
        return $ret;                    
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function d20LevelSelect($edit=FALSE){                      
        $ci = &get_instance();
        $pl =  ($edit == TRUE) ?  $ci->person->getRegistrationInfo($this->id, 'pp_rpga_level') : $pl=0;
        $ret = '<select id="charlevel" name="charlevel" >'; //onChange="changeActivity(0)"
        $ret .='<option value="0" selected="selected">(Level)</option>';
        $sql = 'SELECT * FROM ogre_misccontent  WHERE mc_code= "%ADDCHARLEVELS%"';
        $query = $ci->db->query($sql);
        if($query->getNumRows() != 0){
            foreach ($query->getResult() as $row){
                $rc = $row->mc_content;
            }

        }
        $clevels = explode(',',$rc);                    
        foreach($clevels as $clvls){
            if($clvls!=''){
                 $ret .= ((string)$pl == $clvls) ?  '<option value="' . $clvls . '" selected="selected">' . $clvls . '</option>' : '<option value="' .  $clvls  . '">' .  $clvls  . '</option>';
            }
         }                    
        for ( $i = 1; $i <=20; $i++ ){
            $ret .= (intval($pl) == $i) ?  '<option value="' . $i . '" selected="selected">' . $i . '</option>' : '<option value="' . $i . '">' . $i . '</option>';
        }
        $ret .='</select>';
        return $ret;
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function getPlayerList($gm, $gid=0, $conf=''){
        $ci = &get_instance();
        $this->id = ($gid != 0) ? $gid : $this->id;
        $gmflag = intval($gm);
        $sql = 'SELECT ogre_users.user_rpga_number, ';
        $sql .= ' ogre_prereg_player.pp_player_prereg_id, ';
        $sql .= ' ogre_prereg_player.pp_player_id, ';
        $sql .= ' ogre_prereg_player.pp_player_name, ';
        $sql .= ' ogre_prereg_player.pp_player_notes, ';
        $sql .= ' ogre_prereg_player.pp_player_email, ';
        $sql .= ' ogre_prereg_player.pp_rpga_judge_apl, ';
        $sql .= ' ogre_prereg_player.pp_rpga_player_apl, ';
        $sql .= ' ogre_prereg_player.pp_player_confirmed, ';
        $sql .= ' ogre_prereg_player.pp_gm_judge_flag, ';
        $sql .= ' ogre_prereg_player.pp_player_name ';
        $sql .= ' FROM ogre_prereg_player ';
        $sql .= ' ogre_prereg_player ';
        $sql .= ' LEFT JOIN ogre_users ';
        $sql .= ' ON ogre_prereg_player.pp_player_id = ogre_users.user_index_id ';
        $sql .= ' WHERE pp_gs_id = ' . $this->id;
        $sql .= (($gmflag == 0) ? ' AND pp_gm_judge_flag <= ' . $gm : ' AND ABS(pp_gm_judge_flag) = ' . $gm);
        $sql .= ' AND pp_delete_flag = 0 ';
        $sql .= ($conf != '') ? ' AND pp_player_confirmed = ' . $conf : '';
        $sql .= ' ORDER BY pp_player_prereg_id ';
        $query = $ci->db->query($sql);
        $pl_names = array();
        $pl_names[1][0]="-";
        $pl_names[1][1]="-";
        $pl_names[1][2]="-";
        $pl_names[1][3]="-";
        $pl_names[1][4]="-";
        $pl_names[1][5]="-";
        $pl_names[1][6]="-";
        $pl_names[1][7]="-";
        $pl_names[1][8]="1";
        $pl_names[1][9]="-";
        $i = 1;
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $pl_names[$i][0] = $row->pp_player_prereg_id ;
                $pl_names[$i][1] = $row->pp_player_name;
                $pl_names[$i][2] = $row->pp_player_notes;
                $pl_names[$i][2] = str_replace('/', '', $pl_names[$i][2]);
                $pl_names[$i][3] = $row->pp_player_email;
                $pl_names[$i][4] = $row->user_rpga_number;
                $pl_names[$i][5] = $row->pp_rpga_judge_apl;
                $pl_names[$i][6] = $row->pp_rpga_player_apl;
                $pl_names[$i][7] = $row->pp_player_id ;
                $pl_names[$i][8] = $row->pp_player_confirmed;
                $pl_names[$i][9] = $row->pp_gm_judge_flag;
                $i++;
            }
        }
        return $pl_names;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getNumberOfPlayers($gm, $gid=0, $conf=''){
        $ci = &get_instance();
        $sql='SELECT ogre_prereg_player.pp_player_prereg_id ';
        $sql.= ' FROM ogre_prereg_player ';
        $sql.= ($gid!=0) ?  ' WHERE pp_gs_id = ' . $gid : ' WHERE pp_gs_id = ' . $this->id;
        $sql.= ' AND ' . ((intval($gm) ===0) ? ' pp_gm_judge_flag <= ' . $gm : ' ABS(pp_gm_judge_flag) = ' . $gm);
        $sql.= ' AND pp_delete_flag = 0';                  
        $sql.= ($conf!='') ? ' AND ABS(pp_player_confirmed) = ' . $conf : '';
        $query = $ci->db->query($sql);
        $num = $query->getNumRows();
        return $num;
    }
                
//---------------------------------------------------
//
//---------------------------------------------------
    public function getNumberOfSeats($gid=0){
        $ci = &get_instance();
        $num = -1;
        $sql='SELECT ';
        $sql.= ' ogre_gameschedule.gs_max_number_of_players, ';
        $sql.= ' ogre_preregistergamelist.pgl_number_of_preregs_allowable ';
        $sql.= ' FROM ogre_gameschedule,  ogre_preregistergamelist';
        $sql.= ' WHERE gs_id = pgl_gs_id ';
        $sql.= ' AND gs_id = ' . $gid;
        $query = $ci->db->query($sql);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                if(intval($row->pgl_number_of_preregs_allowable) > 0){
                    $num = (intval($row->gs_max_number_of_players) > intval($row->pgl_number_of_preregs_allowable)) ? $row->pgl_number_of_preregs_allowable : $row->gs_max_number_of_players;
                } else {
                    $num = -1;
                }
            }   
        }
        return $num;
    }    
    
    
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
    public function getNumberOfTables($id){		
        $ci = &get_instance();        

        $qry = 'SELECT ogre_rpga_game_setup.rgs_number_of_tables, ';
        $qry .= ' ogre_rpga_game_setup.rgs_max_players_per_table ';
        $qry .= ' FROM ogre_rpga_game_setup ';
        $qry .= ' WHERE ogre_rpga_game_setup.rgs_gs_id  = ' . $id .';';
        $rs = $ci->db->query($qry);
        $tables = 1;
        if ($rs->getNumRows() > 0){
            foreach ($rs->getResult() as $row){
                $tables = $row->rgs_number_of_tables;
            }
        }
        return $tables;
    }               
                
//---------------------------------------------------
//
//  
//
//---------------------------------------------------               
    public function getOpenSeats($gsid=0){
        $ret='';
        if($this->id==0){
            $this->event_init($gsid);
        }
        $numPlayers1 = $this->getPreregNum($this->id);     
        $numTotlPlayers1 = $this->getPlayerNum($this->id, $this->prereg_players_allowed);
        if (is_numeric($numPlayers1) && is_numeric($numTotlPlayers1)){  
            $numPlayers = intval($numPlayers1);
            $numTotlPlayers = intval($numTotlPlayers1);
            if ($numTotlPlayers == 0){
                    $ret = '-';
            }
            else{
                $ret = ($numPlayers == 0) ?  $numTotlPlayers :  (($numPlayers > $numTotlPlayers) ? '0' . " (+".($numPlayers - $numTotlPlayers).")" :  $numTotlPlayers - $numPlayers);
            }
        }
        return $ret;
    }     
//---------------------------------------------------
//  REGULAR EVENTS PREREG NUMBER
//---------------------------------------------------		
    public function getPreregNum($id, $gm='0'){
        $ci = &get_instance();			
        $qry ='SELECT ogre_prereg_player.pp_player_prereg_id ';
        $qry .= ' FROM ogre_prereg_player ';
        $qry .= ' WHERE ogre_prereg_player.pp_gs_id = ' . $id;
        $qry .= ' AND  ' . ((intval($gm) == 0) ? ' ogre_prereg_player.pp_gm_judge_flag <= '. $gm : ' ABS(ogre_prereg_player.pp_gm_judge_flag) = '. $gm);
        $qry .= ' AND ogre_prereg_player.pp_delete_flag = 0;';		    	  
        $query = $ci->db->query($qry);
        return $query->getNumRows();
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getPlayerNum($id, $numOP=0){		
        $ci = &get_instance(); 
            
        $qry1 = 'SELECT ogre_gameschedule.gs_mmrpgFlag ';
        $qry1 .= ' FROM ogre_gameschedule ';
        $qry1 .= ' WHERE ogre_gameschedule.gs_id = ' . $id .';';
        $query1 = $ci->db->query($qry1);      
        $gamePlayers = 0;
        if ($query1->getNumRows() > 0){
            foreach ($query1->getResult() as $rows1){
                if($rows1->gs_mmrpgFlag != 1){
                    $gamePlayers =  $numOP;
                }
                else{
                    $qry2 = 'SELECT ogre_rpga_game_setup.rgs_number_of_tables, ';
                    $qry2 .= ' ogre_rpga_game_setup.rgs_max_players_per_table ';
                    $qry2 .= ' FROM ogre_rpga_game_setup ';
                    $qry2 .= ' WHERE ogre_rpga_game_setup.rgs_gs_id  = ' . $id .';';
                    $query2 = $ci->db->query($qry2);                    
                    foreach ($query2->getResult() as $row2){
                        $gamePlayers = $row2->rgs_number_of_tables * $row2->rgs_max_players_per_table;

                    }  
                }
            }
        }
        return $gamePlayers;
    }            
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function buildAddJudgePlayerAdmin($gid=0, $edit=FALSE){
        $ci = &get_instance();    
        $conid = $ci->session->ogre_conid;
        $this->event_init($gid);
        $ci->scenario->init($this->rpga_scenario_id, $conid);

        $ret = '<form action="' . site_url('ogrex/preregAction/' . $this->id . '/rpga','https') .  '" method="POST" id="prform" name="prform">';
        $ret .= '<table cellpadding="2" border="1" width="100%">';
        $ret .= '<tr>';
        $ret .= '<td>';                      
        $ret .= '<table cellpadding="2" width="100%">';
        $ret .= '<tr>';
        $ret .= '<td colspan="2"><strong>Add Judge Or Player</strong></td></tr>';
        $ret .= '<tr>';
        $ret .= '<td width="25%">Select Player:</td>';
        $ret .= '<td width="75%">';
        $ret .= $this->listPlayersAdmin($conid);
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '</table>';                      
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '<tr>';
        $ret .= '<td>';                      
        $ret .= '<table border="0" cellspaceing="0" cellpadding="5" width="100%">';
        $ret .= '<tr bgcolor="#CDCDCD">';
        $ret .= '<td width="15%">';
        $ret .= '<input type="radio" id="activity2_Player" name="activity2" value="Player" checked="checked"/> Player</td>';
        $ret .= '<td width="28%">';
        $ret .= 'Combat Role<br />';
        $ret .= $this->combatRoleSelect();
        $ret .= '</td>';
        $ret .= '<td  width="28%">';
        $ret .= 'Level<br />';
        $ret .= $this->d20LevelSelect();
        $ret .= '</td>';
        $ret .= '<td  width="29%">';
        $ret .= 'Level Pref.<br />';                     
        $ret .= '<input type="text" id="playerAPL" name="playerAPL" value="" />';
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '</table>';
        $ret .= '<table cellpadding="2" width="100%">';
        $ret .= '<tr><td width="15%" >';
        $ret .= '<input type="radio" name="activity2" id="activity2_Judge" value="Judge" /> Judge';
        $ret .= '</td><td width="85%">';
        $ret .= 'Level Pref.<br />';                        
        $ret .= '<input type="text" id="judgeAPL" name="judgeAPL" value="" />';
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '</table>';
        
        $ret .= '<table cellpadding="2" width="100%">';
        $ret .= '<tr>';
        $ret .= '<td bgcolor="#CDCDCD">';
        $ret .= '<input type="checkbox" id="playgm" name="playgm" /> Play, but Open to GM<br />';
        $ret .= '<input type="hidden" id="pnotes" name="pnotes" value=""/>';

        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '<tr><td>';
        $ret .= '<input type="hidden" name="preregid" value="';
        $ret .= ($edit == TRUE) ? $ci->person->getRegistrationInfo($this->id, 'pp_player_prereg_id') :  '-9999';
        $ret .= '" />';
        $addplayer=  site_url('ogrex/adminInsertPlayer/1','https');
        $ret .= '<input type="button"  class="btn btn-secondary" id="Submitplayer" name="Submitplayer" value="  Add  " onclick="addplayer('."'".$addplayer."'".');" />&nbsp;';
        $ret .= '</td></tr></table></td></tr></table>';
        $ret .= '</form>';
        return $ret;
    }
                
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    private function listPlayersAdmin($conid){
        $ci = &get_instance();
        $qry='';
        $qry .= '(SELECT ogre_users.user_index_id, ';
        $qry .= ' ogre_users.user_full_name, ';
        $qry .= ' ogre_users.user_email ';
        $qry .= ' FROM ogre_users ';
        $qry .= ' WHERE ogre_users.user_access_rating2 >=90)'; 
        $qry .= ' UNION (SELECT ';
        $qry .= ' ogre_users.user_index_id, ';
        $qry .= ' ogre_users.user_full_name, ';
        $qry .= ' ogre_users.user_email ';                 
        $qry .= ' FROM ogre_users, ogre_user_verified  ';
        $qry .= ' WHERE ogre_users.user_index_id  = ogre_user_verified.uv_user_id  ';
        $qry .= ' AND ogre_user_verified.uv_con_id = ' . $conid .')';
        $qry .= ' ORDER BY user_full_name ';
        $rs = $ci->db->query($qry);
        $code = '<select size="1" name="userID" id="userID">';
        $code .='<option value="0" selected>-Please Select-</option>';
        if ($rs->getNumRows() > 0){
                foreach ($rs->getResult() as $row){
                    $code .= "<option value='" . $row->user_index_id . "'>" . $row->user_full_name . " ~ (" . $row->user_email . ")</option>";
                }
        }
        $code .= "</select>";
        $code .= "<br /><input type='hidden' name='pname' value=''><br /><input type='hidden' name='pemail' value=''/>";
        return $code;
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function modifyOPGame($p, $gid=0){
        $ci = &get_instance();
        if($gid!==0){
            $this->event_init($gid);
        }
        $qry = "UPDATE ogre_rpga_game_setup ";
        $qry .= " SET rgs_number_of_tables = " . $p["gameNumTables"] . ", ";
        $qry .= " rgs_max_players_per_table = " . $p["gameNumPerTable"] . ", ";
        $qry .= " rgs_active = " . $p["gameActivity"] . " ";
        $qry .= " WHERE rgs_gs_id = " .  $this->id;
        $ci->db->query($qry);
        $ret = ($ci->db->affectedRows() > 0) ? TRUE : FALSE;
        return $ret;
    }

//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function removeOPGames($gameid){
        $ci = &get_instance();
        $conid = $ci->session->ogre_conid;
        $ci->convention->init($conid);
//      VERIFIED REMOVE GAME - REMOVE WITH REMOVING PREREGS -----
            if ($gameid != 0){
                $this->event_init($gameid);
                $ret = $this->removeGame();
                if ($this->rpga_number_of_slots > 1){
                    $gameid2 = $this->findOPMultiRoundChild();
                    foreach($gameid2 as $gid2){
                        $this->event_init($gid2);
                        $ret1 = $this->removeGame();
                    }
                }
            }
        return $ret && $ret1;
    }

    //---------------------------------------------------
    //
    //
    //
    //---------------------------------------------------
    public function removeGame(){
        $ci = &get_instance();
        $qry = 'UPDATE ogre_gameschedule ';
        $qry .= " SET gs_cancelled = 1, ";
        $qry .= " gs_date_last_modified = NOW() ";
        $qry .= " WHERE ogre_gameschedule.gs_id = " . $this->id;
        $ci->db->query($qry);
        $ret = ($ci->db->affectedRows() > 0)?TRUE:FALSE;			
        $ret1 = $this->markOPPlayerDeleted();
        return $ret;
    }
    //---------------------------------------------------
    //
    //
    //
    //---------------------------------------------------
    public function markOPPlayerDeleted(){
        $ci = &get_instance();
            $qry2 = "UPDATE ogre_prereg_player ";
            $qry2 .= " SET pp_delete_flag = 1, ";
            $qry2 .= " pp_datemodified = NOW() " ;
            $qry2 .= " WHERE ogre_prereg_player.pp_gs_id = " . $this->id;
            $ci->db->query($qry2);
            $ret = ($ci->db->affectedRows() > 0)?TRUE:FALSE;
            return $ret;
    }
    //---------------------------------------------------
    //
    //
    //
    //---------------------------------------------------
    public function newOPGameSlot($nscode, $sl){
        $ci = &get_instance();
        $conid = $ci->session->ogre_conid;
        $ret = TRUE;
        $ret1 = TRUE;
        $slots_array = $ci->RPGA_lib->buildOPSlotArray($this->conventionid, $sl);
        $slot_code = '';
        $slot_date = '';
        $slot_day = '';
        $slot_start_time = '';
        $slot_length = 0;
        $slot_number = '';
        $slot_time = '';
        $base_slot = 0;
        $late_night = 0;

        foreach ($slots_array as $slot){
            if ($slot[2] == $nscode){
                $slot_code = $slot[2];
                $slot_date = $slot[10];
                $slot_day = $slot[9];
                $slot_start_time = $slot[4];
                $slot_length = $slot[5];
                $slot_number = $slot[2];
                $slot_time = $slot[3];
                $base_slot = $slot[11];
                $late_night = $slot[7];
            }
        }
        $qry = 'UPDATE ogre_gameschedule SET ';
        $qry .= ' ogre_gameschedule.gs_slot_date = "' . $slot_date . '", ';
        $qry .= ' ogre_gameschedule.gs_slot_day = "' . $slot_day . '", ';
        $qry .= ' ogre_gameschedule.gs_slot_start_time =  "' . $slot_start_time . '", ';
        $qry .= ' ogre_gameschedule.gs_slot_length = ' . $slot_length . ', ';
        $qry .= ' ogre_gameschedule.gs_slot_number = "' . $slot_number . '", ';
        $qry .= ' ogre_gameschedule.gs_slot_code = "' . $slot_code . '", ';
        $qry .= ' ogre_gameschedule.gs_slot_time = "' . $slot_time . '", ';
        $qry .= ' ogre_gameschedule.gs_base_slot = ' . $base_slot . ', ';
        $qry .= ' ogre_gameschedule.gs_late_night = ' . $late_night . ', ';
        $qry .= " ogre_gameschedule.gs_date_last_modified = NOW() ";
        $qry .= "  WHERE ogre_gameschedule.gs_id = " . $this->id;
        $ci->db->query($qry);
        $ret =($ci->db->affectedRows() > 0)?TRUE:FALSE;  
        $ret1 = $ci->RPGA_lib->reset_enums($conid);
        $ret1 = $this->markOPPlayerDeleted();
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function checkScenarioExistsInSlot($sn){                    
        $ci = &get_instance();                    
        $qry = 'SELECT ogre_rpga_game_setup.*, ogre_gameschedule.* ';
        $qry .= ' FROM ogre_rpga_game_setup, ogre_gameschedule  ';
        $qry .= ' WHERE ogre_rpga_game_setup.rgs_gs_id = ogre_gameschedule.gs_id ';
        $qry .= ' AND ogre_rpga_game_setup.rgs_scenario_id  = ' . $this->rpga_scenario_id;
        $qry .= ' AND ogre_rpga_game_setup.rgs_game_round = ' . $this->rpga_game_round;
        $qry .= ' AND ogre_gameschedule.gs_slot_code = "' . $sn .'"';
        $qry .= ' AND ogre_gameschedule.gs_cancelled = 0 ';
        $qry .= ' AND ogre_gameschedule.gs_convention_id = ' . $this->conventionid .';';
        $query = $ci->db->query($qry);
        $ret =($query->getNumRows() > 0)?TRUE:FALSE;
        return $ret;
    }

//---------------------------------------------------
//
//---------------------------------------------------
    public function findOPMultiRoundChild(){			
        $ci = &get_instance();                   
        $qry = "SELECT rgs_gs_id FROM ogre_rpga_game_setup ";
        $qry .= " WHERE ";
        $qry .= " rgs_2slot_gs_id = " . $this->id;
        $query = $ci->db->query($qry);
        $i=0;
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                    $ret[$i]=$row->rgs_gs_id;
                    $i++;
            }
        }
        else{
                $ret[0] = -1;
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function isParticipant($pid, $gid=0){
        $ci = &get_instance();             
        //--------------------------
        //  -1,0  Participating GM, Alternate (not possible)
        //   0,0  Player, Alternate
        //   1,0  GM, Alternate (no possible)
        //  -1,1  Participating GM,Confirmed
        //   0,1  Player, Confirmed
        //   1,1  GM, Confirmed
        //  -1,-1 Participating GM, unconfirmed onsite (not possible)
        //   0,-1 Player, unconfirmed onsite 
        //   1,-1 GM, unconfirmed onsite
        //--------------------------
        $sql = "SELECT ogre_prereg_player.pp_gm_judge_flag, ogre_prereg_player.pp_player_confirmed  ";
        $sql .= " FROM ogre_prereg_player ";
        $sql .= " WHERE ogre_prereg_player.pp_player_id = " . $pid . " ";
        $sql .= ($gid==0) ? ' AND pp_gs_id = ' . $this->id : " AND pp_gs_id = " . $gid;                       
        $sql .= " AND pp_delete_flag = 0";
        $query = $ci->db->query($sql);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                    $ret = $row->pp_gm_judge_flag.",".$row->pp_player_confirmed;
            }
        }
        else{
                $ret = -999;
        }
        return $ret;

    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function isPlayerGM($pid, $gid=0){
        $ci = &get_instance();                   
        $sql = "SELECT ogre_prereg_player.* ";
        $sql .= " FROM ogre_prereg_player ";
        $sql .= " WHERE ogre_prereg_player.pp_player_id = " . $pid . " ";
        $sql .= (($gid==0) ? ' AND pp_gs_id = ' . $this->id : " AND pp_gs_id = " . $gid);                       
        $sql .= " AND pp_delete_flag = 0";
        $query = $ci->db->query($sql);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                    $ret = $row->pp_gm_judge_flag;
            }
        }
        else{
                $ret = -999;
        }
        return $ret;

    }
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function saveGameEvent($p){
        $ret = ($p["gameid"] ==="0") ? $this->insertRegularGame($p) : $this->updateGameInfo($p);
        if(is_numeric($ret)){
            $p["gameid"] = $ret;
        }
        if ($p["gameid"] !=="0") {
            if($p["open2prereg"] === "0"){
                $dval = $this->delete_prereg_info($p["gameid"]);
            }else{
                $allowalt = $p["allowalts"];
                $numberofplayers = $p["maxnumofplayers"];
                $id = $p["gameid"];
                $r = $this->updatePlayerPrereg($id, $numberofplayers, $allowalt);
            }
        }
        return $ret; 
    }    
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function updateGameInfo($p){                    
        $ci = &get_instance();                                     
        $this->event_init($p['gameid']);
        // ------------------------------------------->
        $qry = "UPDATE ogre_gameschedule SET ";
// WHAT
        $qry .= ' ogre_gameschedule.gs_gn_id = ' . $p["gs_gn_id"] . ', ';
        $qry .= ' ogre_gameschedule.gs_game_name =  "' . $p["gamesystem"] . '", ';
        $qry .= ' ogre_gameschedule.gs_game_title = "' . $p["gametitle"] . '",';
        $qry .= ' ogre_gameschedule.gs_game_type = "' . $this->getDescriptor($p["gametype"]) . '", ';
        $qry .= ' ogre_gameschedule.gs_event_type = "' . $p["eventtype"] . '",';
        $qry .= ' ogre_gameschedule.gs_game_desc = "' . quotes_to_entities($p["gamedesc"]) . '", ';
        $qry .= ' ogre_gameschedule.gs_game_notes = "'.quotes_to_entities($p["gamenotes"]).'",';
        $qry .= ' ogre_gameschedule.gs_min_num_of_players = ' . $p["minnumofplayers"] . ', ';
        $qry .= ' ogre_gameschedule.gs_max_number_of_players = ' . $p["maxnumofplayers"] . ', ';       
// WHEN      
        $qry .= ' ogre_gameschedule.gs_slot_date = "' . $p['slot_date'] . '", ';
        $qry .= ' ogre_gameschedule.gs_slot_day = "' . $p['slot_day'] . '", ';
        $starttime = new Time($p['slot_starttime']);
        $qry .= ' ogre_gameschedule.gs_slot_start_time =  "' . $starttime->format('H:i:s') . '", ';
        $qry .= ' ogre_gameschedule.gs_slot_length = ' . $p['slot_length'] . ', ';
        $slot_code = (trim($p['slot_code']) == "" ? $this->genSlotCode($p['slot_starttime'], $p['slot_length'], $p['slot_date']): $p['slot_code']);
        $slotnum = ((intval(substr($p['slot_code'],-3,2)) == 0) ? $slot_code : intval(substr($p['slot_code'],-3,2)) . '.' . intval($p["slot_length"]));
        $qry .= ' ogre_gameschedule.gs_slot_number = "' . (trim($p['slotnumber']!='') ? $p['slotnumber'] : $slotnum) . '", ';
        $qry .= ' ogre_gameschedule.gs_slot_code = "' . trim($slot_code) . '", ';
        $qry .= ' ogre_gameschedule.gs_slot_time = "' . $ci->convention->makeSlotTime($p['slot_date'], $p['slot_starttime'], number_format($p['slot_length'],1)) . '", ';
        $qry .= ' ogre_gameschedule.gs_base_slot = ' . $p['baseslot'] . ', ';
        $qry .= ' ogre_gameschedule.gs_late_night = ' . $p['slot_latenight'] . ', ';       
// WHERE                 
        $qry .= ' ogre_gameschedule.gs_table_number = "' . $p["table_number"] . '", ';
        $qry .= ' ogre_gameschedule.gs_table_placeholder_virtual = ' . $p["table_placeholder_virtual"] . ', ';
        $qry .= ' ogre_gameschedule.gs_location_name =  "' . $p["location_name"] . '", ';
        $qry .= ' ogre_gameschedule.gs_tbl_id = ' . $p['tbl_id'] . ', ';            
            
        $qry .= 'ogre_gameschedule.gs_maturity = "' . $p["matrate"] . '",';
        $qry .= 'ogre_gameschedule.gs_roleplaying = ' . $p["rprating"] . ',';
        $qry .= 'ogre_gameschedule.gs_puzzle_solving = ' . $p["psrating"] . ',';
        $qry .= 'ogre_gameschedule.gs_action = ' . $p["actrating"] . ',';
        $qry .= 'ogre_gameschedule.gs_complexity = ' . $p["cmplxrating"] . ',';        
        if(isset($p["affiliation"])){
            $qry .= 'ogre_gameschedule.gs_affiliation = "' . $p["affiliation"] . '",';                    
            $qry .= 'ogre_gameschedule.gs_displaymode = "' . $p["displaymode"] . '",';
            $qry .= 'ogre_gameschedule.gs_editable = ' . $p["editable"] . ',';
            $qry .= 'ogre_gameschedule.gs_lockgmsignup = ' . $p["lock-gm-sign-up"] . ',';
        }
        $qry .= ' ogre_gameschedule.gs_date_last_modified = NOW(), ';
        $qry .= ' ogre_gameschedule.gs_game_fee = ' . $p["fee"] . ' ';
        $qry .= ' WHERE gs_id = ' . $p["gameid"]; 
        $ci->db->query($qry);
        $ret = ($ci->db->affectedRows() == 0)? FALSE:TRUE;
        
        return $ret;
    }                
//---------------------------------------------------
//  BASIC GM UPDATE (non-Admin)
//---------------------------------------------------
    public function updateGameDesc($p){                    
        $ci = &get_instance();                                   
        $this->event_init($p['gameid']);
        $p = $this->cleanGameInfoPost($p);
        try{
            $ci->db->transStart();
// ------------------------------------------->
            $qry = "UPDATE ogre_gameschedule SET ";
            $qry .= "gs_game_title = '" . $p["gametitle"] . "',";
            $qry .= "gs_game_type = '" . $ci->proposal->getDescriptor($p["gametype"])  . "',";
            $qry .= "gs_game_notes = '" . $p["gamenotes"] . "',";
            $qry .= "gs_maturity = '" . $p["matrate"] . "',";
            $qry .= "gs_roleplaying = " . $p["rprating"] . ",";;
            $qry .= "gs_puzzle_solving = " . $p["psrating"] . ",";
            $qry .= "gs_action = " . $p["actrating"] . ",";;
            $qry .= "gs_complexity = " . $p["cmplxrating"] . ",";
            $qry .=  (isset($p["gamedesc"])) ? "gs_game_desc = '" . $p["gamedesc"] . "'," : '';
            $qry .= "gs_event_type = '" . $p["eventtype"] . "',";
            $qry .= "gs_max_number_of_players = " . $p["maxnumofplayers"] . ",";
            $qry .= "gs_min_num_of_players = " . $p["minnumofplayers"] . ",";
            if(isset($p["affiliation"])){
                $qry .= "gs_affiliation = '" . $p["affiliation"] . "',";                    
                $qry .= "gs_displaymode = '" . $p["displaymode"] . "',";
                $qry .= "gs_editable = " . $p["editable"] . ",";
            }
            $qry .= "gs_date_last_modified = NOW(),";
            $qry .= "gs_game_fee = " . $p["fee"] . " ";
            $qry .= " WHERE gs_id = " . $this->id;     
            $ci->db->query($qry);
            $ret1 = ($ci->db->affectedRows() == 0)? FALSE:TRUE;
//------------------------------------------>
            $ret2 = ((intval($this->prereg_players_allowed) > 0) ? ((intval($this->prereg_players_allowed) != intval($p["maxnumofplayers"])) ?  $this->updatePlayerPrereglist($p['gameid'], $p["maxnumofplayers"]) : TRUE) : TRUE);
//------------------------------------------>
            $qry = "SELECT ogre_game_description.* FROM ogre_game_description WHERE gd_gs_id = " . $this->id;
            $query = $ci->db->query($qry);
            if ($query->getNumRows() > 0){
                    $qry = 'UPDATE ogre_game_description SET ';                         
                    $qry .= 'ogre_game_description.gd_game_name = "' . $p["gamesystem"] .  '", ';
                    $qry .= 'ogre_game_description.gd_game_title = "' . $p["gametitle"] .  '", ';
                    $qry .= 'ogre_game_description.gd_player_min = ' . $p["minnumofplayers"] . ', ';
                    $qry .= 'ogre_game_description.gd_player_max = ' . $p["maxnumofplayers"] . ', ';
                    $qry .= 'ogre_game_description.gd_play_length = ' . $p["slot_length"] . ', ';
                    $qry .= 'ogre_game_description.gd_description1 = "' . $p["gamenotes"] . '", ';
                    $qry .= 'ogre_game_description.gd_othernotes = "' . $p["othernotes"] . '", ';
                    $qry .=  (isset($p["gamedesc"])) ? 'ogre_game_description.gd_description2 = "' . $p["gamedesc"] . '", ' : '';
                    $qry .= 'ogre_game_description.gd_maturity = "' . $p["matrate"] . '", ';
                    $qry .= 'ogre_game_description.gd_roleplay_rating = ' . $p["rprating"] . ', ';
                    $qry .= 'ogre_game_description.gd_action_rating = ' . $p["actrating"] . ', ';
                    $qry .= 'ogre_game_description.gd_puzzles_rating =  ' . $p["psrating"] . ', ';
                    $qry .= 'ogre_game_description.gd_complexity = ' . $p["cmplxrating"] . ', ';
                    $qry .= 'ogre_game_description.gd_date_updated = NOW(), ';
                    $qry .= 'ogre_game_description.gd_event_type = "'  . $p["eventtype"] . '", ';
                    $qry .= 'ogre_game_description.gd_processed = 0, ';
                    $qry .= 'ogre_game_description.gd_game_type = "'  . $ci->proposal->getDescriptor( $p["gametype"]) . '" ';
                    $qry .= 'WHERE ogre_game_description.gd_gs_id = ' . $this->id;
            }
            else{
                    $qry = 'INSERT INTO ogre_game_description ';
                    $qry .= '(gd_gs_id, ';
                    $qry .= 'gd_schedule_id, ';
                    $qry .= 'gd_game_name, ';
                    $qry .= 'gd_game_title, ';
                    $qry .= 'gd_player_min, ';
                    $qry .= 'gd_player_max, ';
                    $qry .= 'gd_play_length, ';
                    $qry .= 'gd_othernotes, ';
                    $qry .= 'gd_description1, ';
                    $qry .= 'gd_description2, ';
                    $qry .= 'gd_maturity, ';
                    $qry .= 'gd_roleplay_rating, ';
                    $qry .= 'gd_action_rating, ';
                    $qry .= 'gd_puzzles_rating, ';
                    $qry .= 'gd_complexity, ';
                    $qry .= 'gd_date_updated, ';
                    $qry .= 'gd_event_type, ';
                    $qry .= 'gd_processed, ';
                    $qry .= 'gd_game_type )';
                    $qry .= ' VALUES ';
                    $qry .= '( ' . $this->id . ',';
                    $qry .= $this->schedule_id . ', ';
                    $qry .= '"' . $p["gamesystem"] .  '", ';
                    $qry .= '"' . $p["gametitle"] .  '", ';
                    $qry .= $p["minnumofplayers"] . ', ';
                    $qry .= $p["maxnumofplayers"] . ', ' ;
                    $qry .= $p["slot_length"] . ', ';
                    $qry .= '"' . $p["othernotes"] . '",';
                    $qry .= '"' . $p["gamenotes"] . '",';
                    $qry .=  (isset($p["gamedesc"]))? '"' . $p["gamedesc"] . '", ' : '"", ';
                    $qry .= '"' . $p["matrate"] . '", ';
                    $qry .= $p["rprating"] . ', ';
                    $qry .= $p["actrating"] . ', ';
                    $qry .= $p["psrating"] . ', ';
                    $qry .= $p["cmplxrating"] . ', ';
                    $qry .= 'NOW(),';
                    $qry .= '"' . $p["eventtype"] . '", ';
                    $qry .= '0, ';
                    $qry .= '"' . $ci->proposal->getDescriptor( $p["gametype"]) . '" )';
            }
            $ci->db->query($qry);       
            $ret3 = ($ci->db->affectedRows() == 0)? FALSE:TRUE; 
            $ci->db->transComplete();
            $ret =  ($ci->db->transStatus() === FALSE) ? FALSE : TRUE; 
        }
        catch(Exception $e){
            $ret = FALSE;  /// 'Caught exception: ',  $e->getMessage(), "\n";
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------                  
    private function cleanGameInfoPost($p){
//                    $data = urldecode($data);
//                    $data = html_entity_decode($data);
//                    $data = str_replace('"', '&quot;', $data);
//                    $data = str_replace("'", '&#39;', $data);
        $p["gameid"] = isset($p["gameid"])? $this->clean_text($p["gameid"]): '0';
        $p["gamesystem"] = isset($p["gamesystem"])? $this->clean_text($p["gamesystem"]): '';
        $p["gametitle"] = isset($p["gametitle"])? $this->clean_text($p["gametitle"]): '';
        $p["gametype"] = isset($p["gametype"])? $this->clean_text($p["gametype"]): '';
        $p["gamenotes"] = isset($p["gamenotes"])? $this->clean_text($p["gamenotes"]): '';
        $p["gamedesc"] = isset($p["gamedesc"])? $this->clean_text($p["gamedesc"]): '';
        $p["othernotes"] = isset($p["othernotes"])? $this->clean_text($p["othernotes"]): '';
        $p["matrate"] = isset($p["matrate"])? $this->clean_text($p["matrate"]): '0';
        $p["rprating"] = isset($p["rprating"])? $this->clean_text($p["rprating"]): '0';
        $p["psrating"] = isset($p["psrating"])? $this->clean_text($p["psrating"]): '0';
        $p["actrating"] = isset($p["actrating"])? $this->clean_text($p["actrating"]): '0';
        $p["cmplxrating"] = isset($p["cmplxrating"])? $this->clean_text($p["cmplxrating"]): '0';
        $p["eventtype"] = isset($p["eventtype"])? $this->clean_text($p["eventtype"]): '';
        $p["numofplayers"] = isset($p["numofplayers"])? $this->clean_text($p["numofplayers"]): '0';
        $p["minnumofplayers"] = isset($p["minnumofplayers"])? $this->clean_text($p["minnumofplayers"]): '0';
        $p["affiliation"] = isset($p["affiliation"])? $this->clean_text($p["affiliation"]): 'None';
        $p["displaymode"] = isset($p["displaymode"])? $this->clean_text($p["displaymode"]): 'P';
        $p["editable"] = isset($p["editable"])? $this->clean_text($p["editable"]): '0';
        $p["fee"]  = isset($p["fee"])? $this->clean_text($p["fee"]): '0';           
        return $p;
    }
//---------------------------------------------------
//
//---------------------------------------------------    
    
    private function clean_text($stxt=''){
        return str_replace("`", '&#39;',str_replace("'", '&#39;', str_replace('"', '&quot;',html_entity_decode(urldecode($stxt)))));
        
    }
//---------------------------------------------------
//
//---------------------------------------------------                
    public function updatePlayerPrereglist($gid, $players){
        $ci = &get_instance();          
        $qry = "UPDATE ogre_preregistergamelist SET ";
        $qry .= " pgl_number_of_preregs_allowable= " . $players;
        $qry .= " WHERE pgl_gs_id = " . $gid;
        $ci->db->query($qry);
        $ret = ($ci->db->affectedRows() > 0)? TRUE:FALSE;

        return $ret;
    }

//---------------------------------------------------
//
//---------------------------------------------------
    public function addRegGameEvent($p, $gslot=0){
            $ret = $this->add_regular_event($p);
            return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function addOOPGamEvent($p, $gslot=0){
            // addOPevent returns array
            $ret = $this->addOPevent($p, $gslot);
            return $ret;
    }
//------------------------
//
//------------------------
    public function add_regular_event($step=1, $p){                    
        $ret='Feature Pending';
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function addOPEventValidate($scen, $scenid, $gslot){
        $ci=&get_instance();
        $p=array();
        $p['gameScenario'] = $scenid;
        $conid = $ci->session->ogre_conid;
        $ci->convention->init($conid);
        $bValid= array();
        $bValid["good"] = TRUE;
        $bValid["msg"] = '';
        $rslots = $ci->convention->buildOPSlotArray(-1, $scen->slot_length);
        $bValid["good"] = (trim($scenid) != '0') ? TRUE : FALSE;
        $bValid["msg"] .= ($bValid["good"]===FALSE) ? ' No Scenario Selected.' : '';                          
        $x = $ci->convention->slot_array_search($rslots, trim($gslot));
        $scenchck = $this->checkScenarioGameSlot($p, $conid, $gslot, 1);
        // Already Exists for this Slot
        if ($scenchck != TRUE){
            $bValid["good"] = FALSE;
            $bValid["msg"] .= '<em>'.$scen->scenario_name.'</em>'.' <strong>already exists</strong> in that slot '.$rslots[$x][1] .'<br />';
        }
        return $bValid;
    }
                
    //---------------------------------------------------
    //
    //
    //
    //---------------------------------------------------
    public function addOPevent($p, $gslot){
        $ci=&get_instance();    
        $conid = $ci->session->ogre_conid;
        $ci->convention->init($conid);
        $ci->scenario->init($p["gameScenario"], $conid);  
//  PLAYER PREREG RETURN        
        $ppret = FALSE;    
//  GAME ADD  PREREG RETURN        
        $addret = -1;               
        $slotcount = 0;
        $parent_gs_id = 0;
        $ret = array();
        $ret['results'] = '';
        $ret['done'] = TRUE;
        $ret['msg'] = '';
        $rslots = $ci->convention->buildOPSlotArray(-1, $ci->scenario->slot_length);
        foreach ($p["gameSlot"] as $gameslot){
            $slotvalid = $this->addOPEventValidate($ci->scenario, $p["gameScenario"], $gameslot);
            if($slotvalid["good"] === TRUE){      
                $x = $ci->convention->slot_array_search($rslots, trim($gameslot));
                $slotcount = $ci->scenario->number_of_slots;
                for($s = $gslot; $s<=$slotcount; $s++){
                    if ($ci->scenario->number_of_slots > 1){
                        $gt = $ci->scenario->scenario_name . " (Round " . $s . " of ".$slotcount.")";
                    }
                    else{
                        $gt = $ci->scenario->scenario_name;
                        $parent_gs_id= 0;
                    }                    
                    try{
                        $ci->db->transStart();
                        $addret = $this->insertLivingGame($p["gameScenario"], $gt, $rslots[$x+($s-1)]);
                        $numofplayers1 = $this->calcNumberOfPlayers($p);
                        if($p["open2prereg"] == "1"){
                            $ppret = $this->updateOPPlayerPrereg($addret, $s, $numofplayers1, $p["allowalts"]);                                                 
                        }
                        $setret = $this->updateOPGameInfo($p["gameScenario"], $p, $addret, $parent_gs_id, $s);
                        if($s == 1){
                            $parent_gs_id = $addret;
                        }                
                        $ci->db->transComplete(); 
                        $ret["msg"] .= '<em>'.$gt.'</em>'. ' <strong>added</strong> in '.$rslots[$x+($s-1)][0] .'<br />';
                    }
                    catch(Exception $e){
                        $ret['results'] .= $e->getMessage();
                    }
                    
                }
            }
            else{
                $ret['msg'] .= $slotvalid['msg'];
            }
        }	  // FOREACH LOOP 
        $ret['results'] .= $ci->db->transStatus();
        return $ret;
    }
    //---------------------------------------------------
    //
    //
    //
    //---------------------------------------------------    
    function calcNumberOfPlayers($p){
        $numTables1 = intval($p["gameNumTables"]);
        $numperTables = intval($p["gameNumPerTable"]);
        $numofplayers1 = $numTables1 * $numperTables;        
        return $numofplayers1;
    }
    
    
    //---------------------------------------------------
    //
    //
    //
    //---------------------------------------------------
    private function checkScenarioGameSlot($p, $conid, $slotcode, $gslot){
        $ci=&get_instance();                   
        $qry = 'SELECT ogre_rpga_game_setup.*, ogre_gameschedule.* ';
        $qry .= ' FROM ogre_rpga_game_setup, ogre_gameschedule  ';
        $qry .= ' WHERE ogre_rpga_game_setup.rgs_scenario_id  = ' . $p["gameScenario"];
        $qry .= ' AND ogre_rpga_game_setup.rgs_game_round = ' . $gslot;
        $qry .= ' AND ogre_rpga_game_setup.rgs_gs_id = ogre_gameschedule.gs_id ';
        $qry .= ' AND ogre_gameschedule.gs_slot_code = "' . trim($slotcode) .'"';
        $qry .= ' AND ogre_gameschedule.gs_cancelled = 0 ' ;
        $qry .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid .';';
        $query = $ci->db->query($qry);
        $ret= ($query->getNumRows() != 0)?FALSE:TRUE;
        return $ret;
    }
    //---------------------------------------------------
    //
    //
    //
    //---------------------------------------------------
    private function updatePlayerPrereg($id, $numberofplayers=100, $allowalt="1"){	
        return $this->updateOPPlayerPrereg($id, 1, $numberofplayers, $allowalt);
    }
    //---------------------------------------------------
    //
    //
    //
    //---------------------------------------------------
    private function updateOPPlayerPrereg($id, $gslot=1, $numberofplayers=100, $allowalt="1"){		
        $ci=&get_instance();                    
        $orgid = $ci->session->ogre_orgid;
        $pemail = $ci->session->ogre_user_email;
        $qry = 'SELECT ogre_preregistergamelist.pgl_prereg_id ';
        $qry .= ' FROM ogre_preregistergamelist ';
        $qry .= ' WHERE ogre_preregistergamelist.pgl_gs_id = ' . $id;

        $query = $ci->db->query($qry);
        if ($query->getNumRows() == 0){
            if ($gslot > 1){
                $ins = 'INSERT INTO ogre_preregistergamelist (pgl_gs_id, pgl_number_of_preregs_allowable, pgl_prereg_notes, pgl_contact_email, pgl_opentoalt) ';
                $ins .= ' VALUES (' . $id .', 0, "", "' . $pemail . '",' . $allowalt .")";
            }
            else{
                $ins = "INSERT INTO ogre_preregistergamelist (pgl_gs_id, pgl_number_of_preregs_allowable, pgl_prereg_notes, pgl_contact_email, pgl_opentoalt) ";
                $ins .= " VALUES (" . $id .", " . $numberofplayers . ", '', '" . $pemail . "'," . $allowalt .")";
            }
            $ci->db->query($ins);
            $ret = ($ci->db->affectedRows() > 0)? TRUE: FALSE;
        }
        else{
            foreach ($query->getResult() as $row){
                  $qry2 = "UPDATE ogre_preregistergamelist SET ";
                  $qry2 .= " pgl_gs_id = " . $id . ", ";
                  $qry2 .= " pgl_number_of_preregs_allowable= " . $numberofplayers . ", ";
                  $qry2 .= " pgl_prereg_notes= '', ";
                  $qry2 .= " pgl_opentoalt = ". $allowalt .", ";                  
                  $qry2 .= " pgl_contact_email= '" . $pemail . "' ";
                  $qry2 .= " WHERE pgl_prereg_id = " . $row->pgl_prereg_id;
           }
            $ci->db->query($qry2);
            $ret = ($ci->db->affectedRows() > 0)? TRUE:FALSE;
        }
        return $ret;
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    private function updateOPGameInfo($modid, $p, $id, $parent_gs_id, $gslot){
        $ci=&get_instance();                   
        $conid = $ci->session->ogre_conid;
        $ci->convention->init($conid);
        $ci->scenario->init($modid, $conid);
        $qry = "SELECT ogre_rpga_game_setup.rgs_game_setup_id ";
        $qry .= " FROM ogre_rpga_game_setup ";
        $qry .= " WHERE ogre_rpga_game_setup.rgs_gs_id = " . $id;
        $query = $ci->db->query($qry);
        if ($query->getNumRows() == 0){
            $ins = 'INSERT INTO ';
            $ins .= 'ogre_rpga_game_setup ';
            $ins .= '(rgs_gs_id, ';
            $ins .= 'rgs_number_of_tables, ';
            $ins .= 'rgs_max_players_per_table, ';
            $ins .= 'rgs_active, ';
            $ins .= 'rgs_slot_zero, ';
            $ins .= 'rgs_scenario_id, ';
            $ins .= 'rgs_game_round, ';
            $ins .= 'rgs_2slot_gs_id) ';
            $ins .= ' VALUES (' . $id . ', ';
            $ins .= '"' . $p["gameNumTables"] . '", ';
            $ins .= '"' . $p["gameNumPerTable"] . '", ';
            $ins .= $p["gameActivity"]. ', ';
            $ins .= '0, ';
            $ins .= $modid . ', ';
            $ins .= $gslot . ', ';
            $ins .= $parent_gs_id;
            $ins .= ');';
            $ci->db->query($ins);
            $ret = ($ci->db->affectedRows() > 0)? TRUE:FALSE;
        }
        else{
            foreach ($query->getResult() as $row){
                $qry2 = "UPDATE ogre_rpga_game_setup ";
                $qry2 .= " SET rgs_gs_id = " . $id . ", ";
                $qry2 .= " rgs_number_of_tables = " . $p["gameNumTables"] . ", ";
                $qry2 .= " rgs_max_players_per_table = " . $p["gameNumPerTable"] . ", ";
                $qry2 .= " rgs_active = " . $p["gameActivity"] . ", ";
                $qry2 .= " rgs_scenario_id = " . $modid . ", ";
                $qry2 .= " rgs_game_round = " . $gslot . " ";
                $qry2 .= " WHERE ogre_rpga_game_setup.rgs_game_setup_id = " . $row->rgs_game_setup_id;
            }
            $ci->db->query($qry2);
            $ret = ($ci->db->affectedRows() > 0)?TRUE:FALSE;
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    private function insertNewOPGame($modid, $gt, $slotinfo){                  
        $ci=&get_instance();
        $ret = FALSE;
        $sstarttime = new Time($slotinfo[4]);
        $orgid = $ci->session->ogre_orgid;
        $conid = $ci->session->ogre_conid;
        $ci->convention->init($conid);
        $ci->scenario->init($modid, $conid);
        $ci->game->init($ci->scenario->game_id);
        $defoploc = $ci->ogre_lib->getConfigKey('DEFAULT.OP.LOCATION',$orgid, $conid);    
        $insrt = 'INSERT ogre_gameschedule ( ';
        $insrt .= 'gs_slot_date, ';
        $insrt .= 'gs_slot_day, ';
        $insrt .= 'gs_slot_start_time, ';
        $insrt .= 'gs_slot_length, ';
        $insrt .= 'gs_table_number, ';
        $insrt .= 'gs_table_placeholder_virtual, ';
        $insrt .= 'gs_msa_conid, ';
        $insrt .= 'gs_convention_id, ';
        $insrt .= 'gs_convention_name, ';
        $insrt .= 'gs_slot_number, ';
        $insrt .= 'gs_slot_time, ';
        $insrt .= 'gs_affiliation, ';
        $insrt .= 'gs_descriptorlist, ';
        $insrt .= 'gs_game_name, ';
        $insrt .= 'gs_gn_id, ';
        $insrt .= 'gs_gn_msa_id, ';
        $insrt .= 'gs_game_title, ';
        $insrt .= 'gs_game_type, ';
        $insrt .= 'gs_event_type, ';
        $insrt .= 'gs_location_name, ';
        $insrt .= 'gs_base_slot, ';
        $insrt .= 'gs_late_night, ';
        $insrt .= 'gs_mmrpgFlag, ';
        $insrt .= 'gs_slot_enum, ';
        $insrt .= 'gs_row_enum, ';
        $insrt .= 'gs_date_created, ';
        $insrt .= 'gs_date_last_modified, ';
        $insrt .= 'gs_max_number_of_players, ';
        $insrt .= 'gs_min_num_of_players, ';
        $insrt .= 'gs_slot_code ';
        $insrt .= ') ';
        $insrt .= 'VALUES (' ;
        $insrt .= '"' . $slotinfo[11] . '",' ;
        $insrt .= '"' . $slotinfo[8] . '", ' ;
        $insrt .= '"' . $sstarttime->format('H:i:s') . '", ' ;
        $insrt .= $slotinfo[5] . ', ';
        $insrt .= '"TBA",' ;
        $insrt .= '1,' ;
        $insrt .= $ci->convention->msa_conid  . ', ';
        $insrt .= $conid . ', ';
        $insrt .= '"' . $ci->convention->name . '", ' ;
        $insrt .= '"' . $slotinfo[6] . '", ' ;
        $insrt .= '"' . $slotinfo[3] . '", ' ;
        $insrt .= '"RPGA", ' ;
        $insrt .= '"' . $ci->game->game_types . '", ' ;
        $insrt .= '"' . $ci->game->game_name . '", ' ;
        $insrt .= '' . $ci->game->gameid . ', ' ;
        $insrt .= '' . $ci->game->msa_id . ', ' ;
        $insrt .= '"' . $gt . '", ' ;
        $insrt .= '"RPG", ' ;
        $insrt .= '"RPGA Event", ' ;
        $insrt .= ($defoploc==''?'"Org. Play Game Room", ': '"'.$defoploc.'",') ;
        $insrt .= '1, ';
        $insrt .= $slotinfo[7] . ', ' ;
        $insrt .= $slotinfo[12] . ', ' ;
        $insrt .= $slotinfo[9] . ', ';
        $insrt .= intval($slotinfo[9]) + 1 . ', ' ;
        $insrt .= 'CURDATE(), ' ;
        $insrt .= 'CURDATE(), ' ;
        $insrt .= '6, ' ;
        $insrt .= '1, ' ;
        $insrt .= '"' . $slotinfo[2] . '" ' ;                    
        $insrt .= ');';
        $ci->db->query($insrt);
        $ret=($ci->db->affectedRows() > 0)? $ci->db->insertID():FALSE;
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    private function insertLivingGame ($modid, $gt, $slotinfo){
        $ci=&get_instance();                   
        $starttime = new Time($slotinfo[4]);
        $orgid = $ci->session->ogre_orgid;
        $conid = $ci->session->ogre_conid;
        $ci->convention->init($conid);
        $ci->scenario->init($modid, $conid);
        $ci->game->init($ci->scenario->game_id);
        $insrt = 'INSERT ogre_gameschedule ( ';
        $insrt .= 'gs_slot_date, ';
        $insrt .= 'gs_slot_day, ';
        $insrt .= 'gs_slot_start_time, ';
        $insrt .= 'gs_slot_length, ';
        $insrt .= 'gs_table_number, ';
        $insrt .= 'gs_table_placeholder_virtual, ';
        $insrt .= 'gs_msa_conid, ';
        $insrt .= 'gs_convention_id, ';
        $insrt .= 'gs_convention_name, ';
        $insrt .= 'gs_slot_number, ';
        $insrt .= 'gs_slot_time, ';
        $insrt .= 'gs_affiliation, ';
        $insrt .= 'gs_descriptorlist, ';
        $insrt .= 'gs_game_name, ';
        $insrt .= 'gs_gn_id, ';
        $insrt .= 'gs_gn_msa_id, ';
        $insrt .= 'gs_game_title, ';
        $insrt .= 'gs_game_type, ';
        $insrt .= 'gs_event_type, ';
        $insrt .= 'gs_location_name, ';
        $insrt .= 'gs_base_slot, ';
        $insrt .= 'gs_late_night, ';
        $insrt .= 'gs_mmrpgFlag, ';
        $insrt .= 'gs_slot_enum, ';
        $insrt .= 'gs_row_enum, ';
        $insrt .= 'gs_date_created, ';
        $insrt .= 'gs_date_last_modified, ';
        $insrt .= 'gs_max_number_of_players, ';
        $insrt .= 'gs_min_num_of_players, ';
        $insrt .= 'gs_slot_code, ';
        $insrt .= 'gs_lockgmsignup ';
        $insrt .= ') ';
        $insrt .= 'VALUES (' ;
        $insrt .= '"' . $slotinfo[11] . '",' ;
        $insrt .= '"' . $slotinfo[8] . '",' ;
        $insrt .= '"' . $starttime->format('H:i:s') . '",' ;
        $insrt .= $slotinfo[5] . ', ';
        $insrt .= '"TBA",' ;
        $insrt .= '1,' ;
        $insrt .= $ci->convention->msa_conid  . ', ';
        $insrt .= $conid . ', ';
        $insrt .= '"' . $ci->convention->name . '", ' ;
        $insrt .= '"' . $slotinfo[6] . '", ' ;
        $insrt .= '"' . $slotinfo[3] . '", ' ;
        $insrt .= '"' . $ci->scenario->affiliation . '", ' ;
        $insrt .= '"' . $ci->game->game_types . '", ' ;
        $insrt .= '"' . $ci->game->game_name . '", ' ;
        $insrt .= '' . $ci->game->gameid . ', ' ;
        $insrt .= '' . $ci->game->msa_id . ', ' ;
        $insrt .= '"' . $gt . '", ' ;
        $insrt .= '"' . $ci->game->game_type . '", ' ;
        $insrt .= '"' . $ci->scenario->affiliation . ' Event", ' ;
        $defoploc = $ci->ogre_lib->getConfigKey('DEFAULT.OP.LOCATION',$orgid, $conid);  
        $insrt .= ($defoploc==''?'"Organized Play Room", ':'"'.$defoploc.'",') ;
        $insrt .= '1, ';
        $insrt .= $slotinfo[7] . ', ' ;
        $insrt .= '1, ' ;
        $insrt .= $slotinfo[9] . ', ';
        $insrt .= intval($slotinfo[9]) + 1 . ', ' ;
        $insrt .= 'CURDATE(), ' ;
        $insrt .= 'CURDATE(), ' ;
        $insrt .= '6, ' ;
        $insrt .= '1, ' ;
        $insrt .= '"' . $slotinfo[2] . '", ' ;  
        $insrt .= '0 ' ;
        $insrt .= ');';
        $ci->db->query($insrt);
        $ret =($ci->db->affectedRows() > 0)?$ci->db->insertID():-1;
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function insertRegularGame($ge){
        $ci=&get_instance();      
        $starttime = new Time($ge['slot_starttime']);
        $conid = $ci->session->ogre_conid;
        $ci->convention->init($conid);
        $ci->game->init($ge['gs_gn_id']);                   
        $insrt = 'INSERT ';
        $insrt .= 'ogre_gameschedule ( ';
        $insrt .= 'gs_msa_conid, ';
        $insrt .= 'gs_convention_id, ';
        $insrt .= 'gs_convention_name, ';
        $insrt .= 'gs_slot_number, ';
        $insrt .= 'gs_slot_time, ';                    
        $insrt .= 'gs_slot_date, ';
        $insrt .= 'gs_slot_day, ';
        $insrt .= 'gs_slot_start_time, ';
        $insrt .= 'gs_slot_length, ';
        $insrt .= 'gs_base_slot, ';
        $insrt .= 'gs_late_night, ';
        $insrt .= 'gs_slot_code, ';
        $insrt .= 'gs_code, ';
        $insrt .= 'gs_location_name, ';                   
        $insrt .= 'gs_table_number, ';
        $insrt .= 'gs_table_placeholder_virtual, ';
        $insrt .= 'gs_tbl_id, ';
        $insrt .= 'gs_gn_id, ';
        $insrt .= 'gs_gn_msa_id, ';
        $insrt .= 'gs_game_name, ';                    
        $insrt .= 'gs_game_title, ';
        $insrt .= 'gs_affiliation, ';
        $insrt .= 'gs_mmrpgFlag, ';                    
        $insrt .= 'gs_descriptorlist, ';
        $insrt .= 'gs_game_notes, ';
        $insrt .= 'gs_game_desc, ';
        $insrt .= 'gs_maturity, ';
        $insrt .= 'gs_roleplaying, ';
        $insrt .= 'gs_puzzle_solving, ';
        $insrt .= 'gs_action, ';
        $insrt .= 'gs_complexity, ';
        $insrt .= 'gs_max_number_of_players, ';
        $insrt .= 'gs_min_num_of_players, ';
        $insrt .= 'gs_game_type, ';
        $insrt .= 'gs_event_type, ';
        $insrt .= 'gs_game_list, ';
        $insrt .= 'gs_editable, ';
        $insrt .= 'gs_lockgmsignup, ';
        $insrt .= 'gs_displaymode, ';
        $insrt .= 'gs_slot_enum, ';
        $insrt .= 'gs_row_enum, ';
        $insrt .= 'gs_date_created, ';
        $insrt .= 'gs_date_last_modified ';
        $insrt .= ') ';
        $insrt .= 'VALUES (' ;
        $insrt .= $ci->convention->msa_conid  . ', ';
        $insrt .= $conid . ', ';
        $insrt .= '"' . $ci->convention->name . '", ' ;
        $slot_code = (trim($ge['slot_code']) == "" ? $this->genSlotCode($ge['slot_starttime'], $ge['slot_length'], $ge['slot_date']): $ge['slot_code']);
        $slotnum = ((intval(substr($ge['slot_code'],-3,2)) == 0) ? $slot_code : intval(substr($ge['slot_code'],-3,2)) . '.' . intval($ge["slot_length"]));
        $insrt .= '"' . (trim($ge['slotnumber']!='') ? $ge['slotnumber'] : $slotnum). '", ' ;                    
        $insrt .= '"' . ((trim($ge['slottime']) != '') ? $ge['slottime'] : $this->genSlotTime($ge, $starttime->format('i'), $starttime->format('H'))) . '", ' ;
        $insrt .= '"' . $ge["slot_date"] . '",' ;
        $insrt .= '"' . $ge["slot_day"] . '",' ;
        $insrt .= '"' . $starttime->format('H:i:s') . '",' ;
        $insrt .= $ge["slot_length"] . ', ';
        $insrt .= (isset($ge['baseslot']) ? $ge['baseslot'] : '0') . ', ';
        $insrt .= (isset($ge['latenight']) ? $ge['latenight'] : '0') . ', ';
        $insrt .= '"' .(isset($ge['slot_code']) ? $ge['slot_code'] : '""') . '"' . ', ';
        $insrt .= '0,' ;
        if(intval($ge['locationid']) != 0){
            if(is_numeric($ge['locationid'])){
                $insrt .= '"'. $this->getDataByID('ogre_location', 'loc_location_name', 'loc_locationid', $ge['locationid']) . '", ' ;                        
            } else {
                $insrt .= '"TBA",';
            } 
            if(intval($ge['tbl_id']) != 0){
                if(is_numeric($ge['tbl_id']) && is_numeric($ge['locationid'])){
                    $insrt .= '"' . $this->getDataByID('ogre_location', 'loc_table_prefix', 'loc_locationid', $ge['locationid']).'-'.$this->getDataByID('ogre_tables', 'tbl_number', 'tbl_id', $ge['tbl_id']) . '",' ;
                    $insrt .= $this->getDataByID('ogre_tables', 'tbl_placeholder', 'tbl_id', $ge['tbl_id']) . ',' ;
                } else {
                    $insrt .= '"TBA",';
                    $insrt .= '0,';
                }
            } else{
                $insrt .= '"TBD",';
                $insrt .= '0,';                            
            }
        }
        else{
            $insrt .= 'NULL,0,0,' ;
        }
        $insrt .= ((is_numeric($ge['tbl_id'])) ? $ge['tbl_id'] . ' ': '0') . ', ';  

        $insrt .= '' . $ci->game->gameid . ', ' ;
        $insrt .= '' . $ci->game->msa_id . ', ' ;
        $insrt .= '"' . $ci->game->game_name . '", ' ;
        $insrt .= '"' . $ge["gametitle"] . '",' ;

        $insrt .= '"'.(trim($ge['affiliation']) == "" ? (trim($ci->game->game_orgtype) != "" ?$ci->game->game_orgtype : "None") : $ge['affiliation']) .'", ' ;

        $insrt .= ($ci->game->game_orgtypeid > 0 ? '1' : '0'). ', ' ;
        $insrt .= '"' . $ci->game->game_types . '", ' ;
        $insrt .= '"' . $ge['gamenotes'] . '", ' ;
        $insrt .= '"' . $ge['gamedesc'] . '", ' ;
        $insrt .= '"' . $ge['matrate'] . '", ' ;
        $insrt .= '"' . $ge['rprating'] . '", ' ;
        $insrt .= '"' . $ge['psrating'] . '", ' ;
        $insrt .= '"' . $ge['actrating'] . '", ' ;
        $insrt .= '"' . $ge['cmplxrating'] . '", ' ;

        $insrt .=  $ge['maxnumofplayers'] . ', ' ;
        $insrt .=  $ge['minnumofplayers'] . ', ' ;

        $insrt .= '"' . $ci->game->game_type . '", ' ;
        $insrt .= '"'. $ge['eventtype'] .'", ' ;

        $insrt .= ''. $ci->game->group_flag .', ';
        $insrt .= ''. $ge['editable'] .', ' ;
        $insrt .= ''. $ge['lock-gm-sign-up'] .', ' ;
        $insrt .= '"'. $ge['displaymode'] .'", ' ;
        $insrt .= '0, ';
        $insrt .= '0, ';                    
        $insrt .= 'CURDATE(), ' ;
        $insrt .= 'CURDATE() ' ;
        $insrt .= ');';
        $ci->db->query($insrt);
        return (($ci->db->affectedRows() > 0) ? $ci->db->insertID() : FALSE); 
    }      
//---------------------------------------------------
//
//---------------------------------------------------                    
    private function genSlotTime($ge, $min, $hr){
        $ci=&get_instance();
        $p = array();
        $p['slot_date'] = $ge['slot_date'];
        $p['slot_length'] = $ge['slot_length'];
        $p['slot_start_time_min'] = $min;

        return $ci->convention->genSlotTime($p, $hr);
    }
//---------------------------------------------------
//
//---------------------------------------------------                
    public function saveRegularInitGameInfo($p){
        $ci=&get_instance();
        $conid = $ci->session->ogre_conid;
        $ci->convention->init($conid);                    
        $geventinfo['gameid'] = $p["gs_gn_id"];                    
        $geventinfo['tableid'] = $p["tableid"];

        $geventinfo['locationid']=$p["locid"];
        if($p["timeslottypeval"]=="1"){              
            $geventinfo['slotstarttime']=$ci->convention->slotInfoByCode($p["gameslot"],'slot_start_time');
            $geventinfo["slotdate"] = $ci->convention->slotInfoByCode($p["gameslot"],'slot_date');
            $geventinfo["slotday"] = $ci->convention->slotInfoByCode($p["gameslot"],'slot_day');
            $geventinfo["slotlength"]  = $ci->convention->slotInfoByCode($p["gameslot"],'slot_length');                                    
            $geventinfo['slotnumber'] = $ci->convention->slotInfoByCode($p["gameslot"],'slot_number');
            $geventinfo['slottime'] = $ci->convention->slotInfoByCode($p["gameslot"],'slot_time');
            $geventinfo['baseslot'] = $ci->convention->slotInfoByCode($p["gameslot"],'slot_baseslot');
            $geventinfo['latenight'] = $ci->convention->slotInfoByCode($p["gameslot"],'slot_latenight');
            $geventinfo['mmrpg'] = $ci->convention->slotInfoByCode($p["gameslot"],'slot_RPGA');
            $geventinfo['slotcode'] = $p["gameslot"];
        }
        else{                                              
            $sdate = new Time($p["event_date"]);
            $sday=$sdate->format('l');
            $hr=($p["start_time_AMPM"]=='AM' ?  intval($p["start_time_hour"]) : intval($p["start_time_hour"])+12);
            $start =  str_pad($hr,2,'0',STR_PAD_LEFT) . substr($p["start_time_min"],0,1);

            $geventinfo['slotstarttime']=$p["start_time_hour"].':'.$p["start_time_min"].' '.$p["start_time_AMPM"];
            $geventinfo["slotdate"]=$p["event_date"];
            $geventinfo["slotday"]=$sday;
            $geventinfo["slotlength"] =$p["slot_length"];                                   
            $geventinfo['slotnumber']=$ci->convention->genSlotCode($sday,$start,$p["slot_length"]);

            $q['slot_date']=$p["event_date"];
            $q['slot_start_time_min']=$p["start_time_min"];
            $q['slot_length']=$p["slot_length"];

            $geventinfo['slottime']= $ci->convention->genSlotTime($q, $hr);
            $geventinfo['baseslot']='0';
            $geventinfo['latenight']='0';
            $geventinfo['mmrpg']='0';
            $geventinfo['slotcode']=$ci->convention->genSlotCode($sday,$start,$p["slot_length"]);                        
        }

        return $geventinfo;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getGMNames($gsid, $count=0){
        $ci=get_instance();
        if($this->id == 0) {
            $this->event_init($gsid);
        }
        $qry = 'SELECT ogre_prereg_player.pp_player_name FROM ogre_prereg_player  ';
        $qry .= ' WHERE ogre_prereg_player.pp_gs_id= ' . $this->id;
        $qry .= ' AND ogre_prereg_player.pp_gm_judge_flag = 1 ';
        $qry .= ' AND pp_delete_flag = 0';
        $qry .= ($count !== 0)? ' LIMIT ' . $count : '';
        $query = $ci->db->query($qry);
        $ret = '';
        if($query->getNumRows() != 0){
            foreach ($query->getResult() as $row){
                $ret .= $row->pp_player_name . (($count > 1) ? ';' : '');
            }
        }
        return $ret;
    }                
//---------------------------------------------------
//
//---------------------------------------------------
    public function get_gmcontact($gsid, $count=0){
        $ci=get_instance();
        if($this->id == 0) {
            $this->event_init($gsid);
        }
        $qry = 'SELECT ogre_prereg_player.pp_player_email FROM ogre_prereg_player  ';
        $qry .= ' WHERE ogre_prereg_player.pp_gs_id= ' . $this->id;
        $qry .= ' AND ogre_prereg_player.pp_gm_judge_flag = 1 ';
        $qry .= ' AND pp_delete_flag = 0';
        $qry .= ($count !== 0)? ' LIMIT ' . $count : '';

        $query = $ci->db->query($qry);
        $ret = '';
        if($query->getNumRows() != 0){
            foreach ($query->getResult() as $row){
                $ret .= $row->pp_player_email . (($count > 1) ? ';' : '');
            }
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------                
                public function delete_prereg_info($id=0){
                    $ci=get_instance();
                    $del = "DELETE ogre_preregistergamelist.* FROM ogre_preregistergamelist WHERE pgl_gs_id = " . $id;                    
                    $ci->db->query($del);
                    $ret=($ci->db->affectedRows() > 0)?TRUE:FALSE;         
                    return $ret;
                }
		//---------------------------------------------------
		//
		//
		//
		//---------------------------------------------------
		public function save_prereg_info($p, $quick=FALSE){
                    $ci=get_instance();
                    $dval = TRUE;
                    $this->event_init($p['gameid']);
                    $ci->db->transStart();
                    if($this->prereg_id!=0){
                        $dval = $this->delete_prereg_info($this->id);
                    }
                    if ($quick == TRUE){
                        $p['NumberofPreRegs'] = $p['pallowed'];
                        $p['PreRegNotes'] = '';
                        $p['ContactEmail'] = $this->get_gmcontact($p['gameid']);
                    }
                    $ins = "INSERT INTO ogre_preregistergamelist (pgl_gs_id, pgl_number_of_preregs_allowable, pgl_prereg_notes, pgl_contact_email) ";
                    $ins .= " VALUES (" . $this->id . ", " . $p["NumberofPreRegs"] .  ", '" . $p["PreRegNotes"]  .  "', '" . $p["ContactEmail"] . "')";
                    $ci->db->query($ins);
                    $ci->db->transComplete();
                    $ret = ($ci->db->transStatus() !== FALSE)? TRUE : FALSE;      
                    return $ret;
		}
//---------------------------------------------------
//
//---------------------------------------------------
    public function modifyOPGamesX($p){
        $ret='';
        $keys=array_keys($p);
        $ids=array();
        $i=0;
        foreach($keys as $key){                            
            if(strpos($key, 'scheduleID') !== FALSE){
                $ids[$i]=$p[$key];
                $i++;
            }
        }
        for($i=0;$i<=count($ids)-1;$i++){   
            if($p["changed".$ids[$i]]=="Yes"){                                             
                $ret.=$this->xmodifyOPGamesSlots($p, $ids, $i).'^';
                if (substr($ret, 0, 1)=='1'){
                    $ret.=$this->xmodifyOPGamesTables($p, $ids, $i).'^';
                }                    
                $this->event_init($p["scheduleID".$ids[$i]]);                    
                $ret=str_replace('%GAME_TITLE%', $this->game_title, $ret);
            }
        }
        if(isset($p['aff'])){
            $ret.=$this->gameAdminOPSCurrentSchedule(0,$p['aff']);
        }
        else{
            $ret.=$this->gameAdminOPSCurrentSchedule();
        }
        return $ret;
    }

        //---------------------------------------------------
        //
        //
        //
        //---------------------------------------------------
        public function xmodifyOPGamesTables($p, $ids, $i){
            $goodsave = TRUE;
            $goodsave2 = TRUE;
            $ret="";
            $ci=get_instance();           
                $this->event_init($p["scheduleID".$ids[$i]]);
                if (($this->rpga_number_of_tables != $p["numTables_game".$ids[$i]]) || ($this->rpga_max_players_per_table != $p["numPerTable_game".$ids[$i]])){
                    $q["gameNumTables"] = $p["numTables_game".$ids[$i]];
                    $q["gameNumPerTable"] = $p["numPerTable_game".$ids[$i]];
                    $q["gameActivity"] = $this->rpga_active;
                    $q["gameType"] = $this->rpga_slot_zero;

                    $goodsave = $this->modifyOPGame($q);
                    if($goodsave===TRUE){
                        if ($this->rpga_number_of_slots > 1){
                            $gameid2 = $this->findOPMultiRoundChild();
                            foreach($gameid2 as $gid2){
                                $this->event_init($gid2);
                                $goodsave2 = $this->modifyOPGame($q);
                            }
                        }
                        $ret = $goodsave && $goodsave2;
                    }
                    if ($ret===TRUE){
                        $ret="1~<em>%GAME_TITLE%</em> Table Information Saved~".$p["scheduleID".$ids[$i]];
                    }
                    else
                    {
                        $ret="0~<em>%GAME_TITLE%</em> Error in Saving Table Information~".$p["scheduleID".$ids[$i]];
                    }               
                }                    

            return $ret;
        }
        //---------------------------------------------------
        //
        //
        //
        //---------------------------------------------------
        public function xmodifyOPGamesSlots($p){            
            $goodsave=TRUE;
            $goodsave2=TRUE;
            $exists=FALSE;
            $ret=array();
            $ret['valid']=TRUE;
            $ret['msg']='';
            $ret['value']='0';
            $ci=get_instance();           
            $conid = $ci->session->ogre_conid;
            $ci->convention->init($conid);
            $this->event_init($p["id"]);             
            if ($this->slot_code != $p["newslot"]){
                $rslots = $ci->RPGA_lib->buildOPSlotArray($conid, $this->slot_length);
                $x = $ci->RPGA_lib->slot_array_search($rslots, trim($p["newslot"]));
                if ($this->rpga_number_of_slots > 1 && $this->rpga_game_round == 1){ 
                    // First Round can not be last session
                    if ($x == count($rslots)){
                        $ret['valid'] = FALSE;
                        $ret['msg'] .= '<em>%GAME_TITLE%</em> First Round Can not be Last Session';
                        $ret['value']='0';
                    }                           
                }              
                if($ret['valid']===TRUE){
                    $exists=$this->checkScenarioExistsInSlot($p["newslot"]);
                    if ($exists != TRUE){                         
                        $goodsave = $this->newOPGameSlot($p["newslot"], $this->slot_length);
                        if($goodsave===TRUE){
                            if ($this->rpga_number_of_slots > 1){
                                $nextslot = $rslots[$x + 1][2];
                                $gameid2 = $this->findOPMultiRoundChild();
                                foreach($gameid2 as $gid2){                                            
                                    $this->event_init($gid2);
                                    $goodsave2 = $this->newOPGameSlot($nextslot, $this->slot_length);
                                }
                                $goodsave = $goodsave && $goodsave2;
                            }                                       
                        }
                        if($goodsave===TRUE){
                            $ret['msg'] = '%GAME_TITLE%: Game Slot Changed.';
                            $ret['valid'] = TRUE;
                            $ret['value']=$p["newslot"];
                        }
                        else{
                            $ret['msg']= '%GAME_TITLE%: Error in Saving Game Slot Change';
                            $ret['valid'] = FALSE; 
                            $ret['value']=$p["id"];
                        }                                                                                                            
                    }
                            else{
                                $ret = '%GAME_TITLE%: Scenario Seems to already exist for this slot~';
                                $ret['value']=$p["id"];
                                $ret['valid'] = FALSE; 
                            }
                        }
                    } 
                    else{
                        $ret = '~'.$p["id"];
                        $ret['valid'] = FALSE; 
                        $ret['value']=$p["id"];
                    }                   
            return $ret;
        }        
        //---------------------------------------------------
        //
        //
        //
        //---------------------------------------------------
        public function xmodifyOPGamesSlotsOld($p, $ids, $i){
            $bValid=TRUE;
            $goodsave=TRUE;
            $goodsave2=TRUE;
            $exists=FALSE;
            $errmsg = "";
            $ret='';
            $ci=get_instance();
            $conid = $ci->session->ogre_conid;
                
    //          ----------------------------------------
    //          CHECK FOR SLOT CHANGE...  USE EXISTING CODE TO FIND OPEN SLOT IN NEW SLOT.  THEN SWAP SLOT AND TABLE DATA BETWEEN THE TWO
    //          ----------------------------------------
                $this->event_init($p["scheduleID".$ids[$i]]);             
                if ($this->slot_code != $p["slotNum".$ids[$i]]){
                    $rslots = $ci->RPGA_lib->buildOPSlotArray($conid, $this->slot_length);
                    $x = $ci->RPGA_lib->slot_array_search($rslots, trim($p["slotNum".$ids[$i]]));

                    if ($this->rpga_number_of_slots > 1 && $this->rpga_game_round == 1){
// First Round can not be Late night                        
                            if ($rslots[$x][7] == '1' ){
                                $bValid = FALSE;
                                $errmsg .= '<em>%GAME_TITLE%</em> First Round Can not be Late Night';
                            }
// First Round can not be last session                            
                            if ($x == count($rslots)){
                                $bValid = FALSE;
                                $errmsg .= '<em>%GAME_TITLE%</em> First Round Can not be Last Session';
                            }
                            if ($bValid ===FALSE){
                                $ret = '0~' . $errmsg;
                            }                            
                         }
               
                         if($bValid===TRUE){
                            $exists=$this->checkScenarioExistsInSlot($p["slotNum".$ids[$i]]);
                            if ($exists != TRUE){
                                    $conid = $this->conventionid;
                                    $ci->convention->init($conid);
                                    $goodsave = $this->newOPGameSlot($p["slotNum".$ids[$i]], $this->slot_length);
                                    if($goodsave===TRUE){
                                        if ($this->rpga_number_of_slots > 1)
                                        {
                                            $nextslot = $rslots[$x + 1][2];
                                            $gameid2 = $this->findOPMultiRoundChild();
                                            foreach($gameid2 as $gid2){                                            
                                                $this->event_init($gid2);
                                                $goodsave2 = $this->newOPGameSlot($nextslot, $this->slot_length);
                                            }
                                            $goodsave = $goodsave && $goodsave2;
                                        }                                       
                                    }
                                    if($goodsave===TRUE){
                                        $ret = '1~%GAME_TITLE%: Game Slot Changed~'.$p["scheduleID".$ids[$i]];
                                    }
                                    else{
                                        $ret = '0~%GAME_TITLE%: Error in Saving Game Slot Change~'.$p["scheduleID".$ids[$i]];
                                    }                                                                                                            
                            }
                            else{
                                $ret = '0~%GAME_TITLE%: Scenario Seems to already exist for this slot~'.$p["scheduleID".$ids[$i]];
                            }
                         }
                    } 
                    else
                    {
                        $ret = '1~~'.$p["scheduleID".$ids[$i]];
                    }
                    

            return $ret;
        }        
//---------------------------------------------------
//
//
//
//---------------------------------------------------
        public function modifyOPGames($p){              
            $ci=get_instance();           
            $conid = $ci->session->ogre_conid;
            $ci->convention->init($conid);
                $bValid = TRUE;
                $errmsg = '';
                $i = 0;
                $gi = count($p["changed"]);
                $ret = TRUE;
                $ret1 = FALSE;
//                 LOOP THROUGH POST DATA
                foreach ($p["changed"] as $changed){
                    if ($changed == "Yes"){
//                  ----------------------------------------
//                  CHECK IF THE TABLE OR PLAYERS CHANGED.  IF SO SET UP $P array and use Object update method
//                  ----------------------------------------
                        $this->event_init($p["scheduleID"][$i]);

                        if (($this->rpga_number_of_tables != $p["numTables_game"][$i]) || ($this->rpga_max_players_per_table != $p["numPerTable_game"][$i])){
                            $q["gameNumTables"] = $p["numTables_game"][$i];
                            $q["gameNumPerTable"] = $p["numPerTable_game"][$i];
                            $q["gameActivity"] = $this->rpga_active;
                            $q["gameType"] = $this->rpga_slot_zero;

                            $ret = $this->modifyOPGame($q);
                            if($ret===TRUE){
                                if ($this->rpga_number_of_slots > 1){
                                    $gameid2 = $this->findOPMultiRoundChild();
                                    foreach($gameid2 as $gid2){         
                                        $this->event_init($gid2);
                                        $ret = $this->modifyOPGame($q);
                                    }
                                }
                            }
                        }
//                  ----------------------------------------
//                  CHECK FOR SLOT CHANGE...  USE EXISTING CODE TO FIND OPEN SLOT IN NEW SLOT.  THEN SWAP SLOT AND TABLE DATA BETWEEN THE TWO
//                  ----------------------------------------
                        $this->event_init($p["scheduleID"][$i]);

                        if ($this->slot_code != $p["slotNum"][$i])
                        {
                            $rslots = $ci->RPGA_lib->buildOPSlotArray($conid, $this->slot_length);

                            $x = $ci->RPGA_lib->slot_array_search($rslots, trim($p["slotNum"][$i]));
                            
                            if ($p["slotNum"][$i] != "DEL"){
                                if ($this->rpga_number_of_slots > 1 && $this->rpga_game_round == 1){
                                    if ($rslots[$x][7] == '1' )  // First Round can not be Late night
                                    {
                                        $bValid = FALSE;
                                        $errmsg .= 'First Round Can not be Late Night';
                                    }

                                    if ($x == count($rslots)) // First Round can not be last session
                                    {
                                        $bValid = FALSE;
                                        $errmsg .= 'First Round Can not be Last Session';
                                    }

                                    $ret = $bValid;
                                }


                                if (($this->checkScenarioExistsInSlot($p["slotNum"][$i]) != TRUE) && ($bValid != FALSE))
                                {
                                    $conid = $this->conventionid;

                                    $ci->convention->init($conid);

                                    $ret1 = $this->newOPGameSlot($p["slotNum"][$i], $this->slot_length);

                                    if ($this->rpga_number_of_slots > 1)
                                    {

                                        $nextslot = $rslots[$x + 1][2];

                                        $gameid2 = $this->findOPMultiRoundChild();
                                        foreach($gameid2 as $gid2)
                                        {       
                                            $this->event_init($gid2);
                                            $ret2 = $this->newOPGameSlot($nextslot, $this->slot_length);
                                        }
                                        $ret1 = $ret1 && $ret2;
                                    }

                                    $ret = $ret1;
                                }
                                else
                                {
                                    $ret = FALSE;
                                }

                            }
//                  ----------------------------------------
//
//                  ----------------------------------------                            
                            else{
                                $ret = $this->removeGame();
                                if ($this->rpga_number_of_slots > 1)
                                {
                                    $gameid2 = $this->findOPMultiRoundChild();
                                    foreach($gameid2 as $gid2)
                                    {       
                                        $this->event_init($gid2);
                                        $ret = $this->removeGame();
                                    }
                                }

                            }
                        }
                    }

                    $i++;
                }
            return $ret;
        }
        
        private function getGameAdminHeader(){
            $ci=get_instance();
            $action =  site_url('ogrex/gameEdit/0/','https'); 
            $ret ='';            
            $ret .= '<div class="row  my-1">';
            $ret .= '<div class="col">';           
            $ret .= '<div id="results"  class="results"></div>';
            $ret .= $ci->ogre_lib->getMiscContent('%EDITGAMEINSTRUCTIONS%', 0, TRUE);
            $ret .= '</div>';
            $ret .= '</div>';
            $ret .= '<div class="row my-1">';              
            $ret .= '<div class="col">';
            $ret .= $this->getCurrentOpenRequests();    
            $ret .= '</div>';   
            $ret .= '<div class="col">';
            $ret .= '<div class="d-grid gap-2"><button class="btn btn-primary btn-sm my-1" id="addnewgame" name="addnewgame" onclick="editGame('."'" . $action.'VOL' ."'" .',0);" />Add Vol. Shift</button></div>';
            $ret .= '<div class="d-grid gap-2"><button class="btn btn-primary btn-sm my-1" id="addnewgame" name="addnewgame" onclick="editGame('."'" . $action.'PAN' ."'" .',0);" />Add Panel</button></div>';            
            $ret .= '<div class="d-grid gap-2"><button class="btn btn-primary btn-sm my-1" id="addnewgame" name="addnewgame" onclick="editGame('."'" . $action.'GAME' ."'" .',0);" />Add Game</button></div>';                   
            $ret .= '</div>';   
            $ret .= '</div>';
            return $ci->ogre_lib->bootCard('',$ret);
        }
//---------------------------------------------------
//
//---------------------------------------------------
        public function preregisterEdit($gmid=0, $gid=0){ 
            $ret =''; 
            $ret .= '<div id="edit-admin-games-list-form" style="display:none"></div>';
            $ret .= '<div id="edit-admin-games-list">';
            $ret .= $this->getGameAdminHeader();
            $ret .= '<div class="row my-1">';
            $ret .= '<div class="col">';
            $ret .= $this->getGameAdminFilterType();
            $ret .= '</div>';
            $ret .= '</div>';
            $ret .= '<div class="row my-1">';          
            $ret .= '<div class="col">';
            $ret .= '<div class="input-group mb-3" id="gamemasterfilter" style="display: none;">';
            $ret .= $this->buildGamemasterList($gmid);
            $ret .= '<input class="btn btn-primary"  type="button" class="btn btn-sm btn-secondary" id="refreshgms" name="refreshgms" value="Refresh" onclick="refresh_gms_games(1);");">';
            $ret .= '</div>';
            $ret .= '<div class="input-group my-3" id="gamefilter">';            
            $ret .= $this->buildGameList($gid, -1);
            $ret .= '<input class="btn btn-primary btn-sm" type="button" class="btn btn-sm btn-secondary" id="refreshgs" name="refreshgs" value="Refresh" onclick="refresh_gms_games(0);">';
            $ret .= '</div>';            
            $image_properties = array('src' =>'images/ajax-loader.gif','alt'=>'ajax-loader.gif'); 
            $ret .= '<span id="admin_ge_wait2" style="display: none">' . img($image_properties) . '</span>';
            $ret .= '</div>';
            $ret .= '</div>';
            $ret .= '</div>';
            $ret .= '<div id="edit-admin-games-list-main">';
            $ret .= $this->preregisterEditList($gid, $gmid);
            $ret .= '</div>';
            return $ret;
        }
//---------------------------------------------------
//
//---------------------------------------------------         
        private function getGameAdminFilterType(){
            $ret = '<select class="form-control my-2" id="filterby" name="filterby" size="1" onchange="changefilterselect();">';
            $ret .= '<option value="game" selected="selected" >Filter by Game: </option>';
            $ret .= '<option value="gm">Filter by Game Master: </option>';
            $ret .= '</select>';
            return $ret;
        }
//---------------------------------------------------
//
//---------------------------------------------------         
        private function getCurrentOpenRequests(){
            $ci = &get_instance();
            $ret = '';
            $attention = $ci->schedule_lib->gsItemsNeedsAttention();
            $ret .= '<ul class="list-group">';
            $ret .= '<li class="list-group-item d-flex justify-content-between align-items-center">';
            $ret .= 'Pending Proposals:';
            $ret .= '<h6><span class="badge '.((intval($attention['proposals']) > 0 ) ? 'bg-danger' : 'bg-primary') .'">'.$attention['proposals'].'</span></h6>';
            $ret .= '</li>';
            $ret .= '<li class="list-group-item d-flex justify-content-between align-items-center">';
            $ret .= 'Pending Game Libraries:';
            $ret .= '<h6><span class="badge '.((intval($attention['libraries']) > 0) ? 'bg-danger' : 'bg-primary') .'"">'.$attention['libraries'].'</span></h6>';
            $ret .= '</li>';
            $ret .= '</ul>';
            return $ret;
        }
//---------------------------------------------------
//
//---------------------------------------------------        
        public function preregisterEditList($gmid=0, $gid=0){
            $ci=get_instance();
            $ret ='';
            $conid = $ci->session->ogre_conid;
            $ci->convention->init($conid);
            $p["gameslot"] = 0;
            $p["keyword"] = '';
            $p["gamename"] = ($gid !=0 ) ? $gid : 0;
            $p["affiliation"] = 0;
            $p["gametype"] = 0;                
            $gameid = ($gmid != 0)? $this->getgmgameidlist($gmid):-1;
            $qry = ($gmid !=0 || $gid !=0) ? $ci->schedule_lib->buildGamingScheduleSQL(FALSE, $p, $gameid, FALSE, '', $conid, '', '', '', -1) : '';
            $ret .= '<table  class="table table-hover">';
            $ret .= '<thead>';
            $ret .= '<th>Game/Title (GMs/Players/Max Players)</th>';
            $ret .= '</thead>';
            $lastsc = '';
            if(trim($qry) !=''){
                $query = $ci->db->query($qry);
                if ($query->getNumRows() > 0){
                    foreach ($query->getResult() as $row){
                        $this->event_init($row->gs_id);
                        
                        if($lastsc !== $this->slot_code){
                            
                            $ret .= '<tr>';
                            $ret .= '<th><h4>';
                            $ret .= substr($row->gs_slot_day,0,3) . ' - ' . $row->gs_slot_time;
                            $ret .= '</h4></th>';
                            $ret .= '</tr>';
                        }

                        $ret .= '<tr '. $this->game_admin_row_type($this->gameid, $this->cancel, $this->prereg_id, $this->displaymode).'>';
                        
//                        $ret .= ((intval($this->cancel) == 1) ? ' class="table-danger" >' : ($this->prereg_id != 0) ? '<tr>' : '<tr class="table-warning">');
                        
                        $glink = '<strong>'.$row->gs_game_name.'</strong>';  
                        $glink .= (trim($row->gs_game_title) != "") ? ' - <i>' . $row->gs_game_title . '</i>' : '';
                        $ret .= '<td>' ;
                        $ret .= ($this->mmrpgFlag!='1') ? '<a href="#" id="gameEdit'.$row->gs_id.'" '. ((intval($this->cancel) == 1) ? ' disabled=disabled ' : '') .' onclick="editGame('."'". site_url('ogrex/gameEdit','https')."'".', '.$row->gs_id.')">' : ' <a href="#" id="gameEdit'.$row->gs_id.'" '. ((intval($this->cancel) == 1) ? ' disabled=disabled ' : '') . '  onclick="oMsgBox('."'".'Please use OP Admin to edit this game.'."'".');" />';
                        $ret .= $glink;
                        $ret .= '</a>  (';                       
                        $ret .= 'G:'.$this->getNumberOfPlayers('1');
                        $ret .= ' ';
                        $ret .= 'P:'.$this->getNumberOfPlayers('0');                        
                        $ret .= ' of '.$row->gs_max_number_of_players;
                        $ret .= (intval($this->prereg_players_allowed) != intval($row->gs_max_number_of_players)) ? ' ['.$this->prereg_players_allowed.']':'';
                        $ret .= ') <input name="gameid" type="hidden" value="' . $row->gs_id . '" /></td>';             
                        $ret .= '</tr>';
                        $lastsc = $this->slot_code;
                    }
                }
                else
                {
                    $ret .= '<p>None</p>';
                }
            }
            $ret .= '</table>';
            
            return $ret;
        }
//---------------------------------------------------
//
//
//
//---------------------------------------------------        
        private function game_admin_row_type($id, $cancel, $prereg_id, $displaymode){
            $ret='';
            
            if($id == PERSONAL_LIBRARY_ID){
                if (intval($displaymode) == 'R') {
                    $ret .= ' class="table-warning" ';
                } else {
                    $ret .= (((intval($cancel) == 1) ? ' class="table-danger" ' : ((intval($this->prereg_id) != 0) ? '' : ' class="table-warning" ')));
                }
            }else {
                $ret .= ((intval($cancel) == 1) ? ' class="table-danger" ' : ((intval($this->prereg_id) != 0) ? '' : ' class="table-warning" '));
            }

            return $ret;
        }
//---------------------------------------------------
//
//
//
//---------------------------------------------------        
        private function isPersonalLibraryRequest($gid, $displaymode){
            $ret=FALSE;
            if(($gid == PERSONAL_LIBRARY_ID) && ($displaymode == 'R')){
                $ret = TRUE;
            } else {
                $ret = FALSE;
            }
            return $ret;
        }        
//---------------------------------------------------
//
//
//
//---------------------------------------------------
        public function build_displaymodeswitch($action, $gid, $gsid){
            $ret = '';
            if(($gid === PERSONAL_LIBRARY_ID) && ($this->displaymode==='R')){
                $ret .= '<div class="form-group"><div class="custom-control custom-switch"><input type="checkbox" class="material-switch-control-input"><span class="material-switch-control-indicator"></span></div></div>';
            }
            return $ret;
        }        
//---------------------------------------------------
//
//
//
//---------------------------------------------------
        public function buildGamemasterList($gmid=0){
            $ci=get_instance();
            $conid = $ci->session->ogre_conid;
            $ci->convention->init($conid);            
            $qry = 'SELECT DISTINCT ogre_prereg_player.pp_player_id, ogre_users.user_last_name,ogre_users.user_first_name, ogre_users.user_access_rating2 ';
            $qry .= ' FROM (ogre_gameschedule INNER JOIN ogre_prereg_player ON ogre_gameschedule.gs_id = ogre_prereg_player.pp_gs_id)  ';
            $qry .= ' INNER JOIN ogre_users ON ogre_prereg_player.pp_player_id = ogre_users.user_index_id';
            $qry .= ' WHERE ABS(ogre_prereg_player.pp_gm_judge_flag) = 1  ';
            $qry .= ' AND ogre_gameschedule.gs_convention_id=' . $conid;
            $qry .= ' OR ogre_users.user_access_rating2 >= ' . CONADMIN;
            $qry .= ' ORDER BY ogre_users.user_last_name,ogre_users.user_first_name ;';        
            
            $query = $ci->db->query($qry);

            $ret = "";
            $action=site_url('ogrex/getGameEditListByGM','https');
            $ret .= '<select class="form-control my-2" id="gm-id-list" name="gm-id-list" onchange="get_filteredgameadmineeditlist(' ."'". $action."'," . 'this.options[this.selectedIndex].value)">';   // onchange="self.location = this.options[this.selectedIndex].value;"
            
            $ret .= '<option value="0" hidden="hidden">-SELECT ONE-</option>';

            if ($query->getNumRows() > 0){
                    foreach ($query->getResult() as $row){
                        if($row->pp_player_id!=$gmid){
                            $ret .= '<option value="' . $row->pp_player_id . '">'.$row->user_last_name.', ' . $row->user_first_name .'</option>';
                        }
                        else{
                            $ret .= '<option value="' . $row->pp_player_id . '" selected="selected">'.$row->user_last_name.', ' . $row->user_first_name .'</option>';
                        }
                    }
            }
            $ret .= '</select>';
            return $ret;
        }
//---------------------------------------------------
//
//
//
//---------------------------------------------------        
        public function buildGameList($gid=0, $cancelled=0){
            $ci=get_instance();
            $conid = $ci->session->ogre_conid;
            $ci->convention->init($conid);            
            $qry  =  'SELECT DISTINCT ';
            $qry .=  ' ogre_gameschedule.gs_game_name, ';
            $qry .=  ' ogre_gameschedule.gs_gn_id ';
            $qry .=  ' FROM ogre_gameschedule ';
            $qry .=  ' WHERE ';
            $qry .=  ' ogre_gameschedule.gs_displaymode = "P"';
            $qry .=  ($cancelled != -1) ? ' AND ogre_gameschedule.gs_cancelled = ' . $cancelled : '';
            $qry .=  ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
            $qry .=  ' ORDER BY ogre_gameschedule.gs_game_name;';      
            $query = $ci->db->query($qry);
            $ret = "";
            $action=site_url('ogrex/getGameEditListByGame','https');
            $ret .= '<select class="form-control" id="gidlist" name="gidlist" onchange="get_filteredgameadmineeditlist(' ."'". $action."'," . 'this.value)">';   
            $ret .= '<option value="0" hidden="hidden">-SELECT ONE-</option>';
            $ret .= '<option value="'.PERSONAL_LIBRARY_ID.'">(Personal Game Library)</option>';
            if ($query->getNumRows() > 0){
                    foreach ($query->getResult() as $row){
                        if($row->gs_gn_id == $gid){
                            $ret .= '<option value="' . $row->gs_gn_id . '" selected="selected">'.$row->gs_game_name.'</option>';
                        }
                        else{
                            $ret .= '<option value="' . $row->gs_gn_id . '">'.$row->gs_game_name.'</option>';
                        }
                    }
            }
            $ret .= '</select>';
            return $ret;            
        }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
        public function getgmgameidlist($gmid){
            $ci=&get_instance();                       
            $conid = $ci->session->ogre_conid;
            $i = 0;
            $qry = 'SELECT ogre_prereg_player.pp_gs_id ';
            $qry .= ' FROM ogre_gameschedule, ogre_prereg_player ';
            $qry .= ' WHERE ogre_gameschedule.gs_schedule_id = ogre_prereg_player.pp_schedule_id ';
            $qry .= ' AND pp_player_id = ' . $gmid . ' AND ABS(pp_gm_judge_flag) = 1 AND pp_delete_flag = 0 ';  
            $qry .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
            $query = $ci->db->query($qry);
            $gamesid = array();
            $gamesid[0]=0;
            if ($query->getNumRows() > 0) {
                foreach ($query->getResult() as $row){
                        $gamesid[$i] = $row->pp_gs_id;
                        $i++;
                }
            }
           return $gamesid;
        }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
        public function preregEditForm($gsid=0){
                $ret = '';
                $this->event_init($gsid);
                $action=site_url('ogrex/preRegEditIn','https');
                $ret .='<h2 style="color:#0000FF">'.$this->slot_time.': '.$this->game_name.'</h2>';
                $ret.='<br /><br />';
                $ret.='<br /><br />';
                $ret.='<div id="results" class="results"></div>';
                $ret .= '<table cellspacing="10" cellpadding="10" bordercolor="#FFFFFF" border="0" width="99%">';
                $ret .= '<tr><td>';                              
                $ret .= '<form action="" method="post" name="preregeditInfo" id="preregeditInfo">';
                $ret .= '<table border="0" width="100%">';
                $ret .= '<tr>';
                $ret .= '<td><p><strong>Num of Allowable Preregs:</strong></p></td>';
                $ret .= '<td>';
                $ret .= '<p><input type="text" id="NumberofPreRegs" name="NumberofPreRegs" value="'. $this->prereg_players_allowed.'" size="3" /> of ' . $this->max_number_of_players . ' per game</p>';
                $ret .= '</td>';
                $ret .= '</tr>';
                $ret .= '<tr>';
                $ret .= '<td>';
                $ret .= '<p><strong>Preregistration Contact E-mail</strong></p></td>';
                $ret .= '<td>';
                $ret .= '<p><input type="text" size="35" name="ContactEmail" id="ContactEmail" value="'. $this->prereg_contact . '" /></p>';
                $ret .= '</td>';
                $ret .= '</tr>';
                $ret .= '<tr><td colspan="2">';               
                $ret .= '<p><strong>Preregisrtration Notes</strong></p>';
                $ret .= '</td></tr>';
                $ret .= '<tr><td colspan="2">';
                $ret .= '<textarea id="PreRegNotes" name="PreRegNotes" cols="50" rows="5">';
                $ret .= $this->prereg_notes;
                $ret .= '</textarea>';
                $ret .= '</td></tr>';
                $ret .= '<tr>';
                $ret .= '<td colspan="2">';
                $ret .= '<input type="hidden" name="gameid" id="gameid" value="'. $gsid . '" />';
                $ret .= '<input type="button"  class="btn btn-secondary" id="preregmodify1"name="preregmodify1" value="  Save  " onclick="savePrereg(' . "'".$action."'" . ')" />';
//                $ret .= '<input type="button"  class="btn btn-secondary" name="cancel1" value="Cancel" onclick="history.back();" />';
                $ret .= '</td>';
                $ret .= '</tr>';
                $ret .= '</table>';
                $ret .= '</form>';

                $ret .= '</td>';
                $ret .= '</tr>';
                $ret .= '</table> ';
                return $ret;
        }
//---------------------------------------------------

//---------------------------------------------------
    public function gameAdminOP($gameid=0, $aff=''){
        $ci=get_instance();                
        $j = 1;
        $ret = '';
        if ($gameid != 0 ){
            $this->event_init($gameid);
        }
        $action = site_url("ogrex/gamesIn/rpga/add",'https');
        $schedulerefresh=site_url('ogrex/currentSchedule','https');
        $divid = 'game-admin-list';
        $conid = $ci->session->ogre_conid;
        $ci->convention->init($conid);
        $ret .= '<div id="game-admin-op">';
        $ttl = ($gameid==0)?'OP Game Event Scheduler':'OP Game Event Editor';
        $ret .= '<div id="results" class="results"></div>';                       
        $ret .= '<div class="op-game-scheduler" id="op-game-scheduler">';
//              -- ADD/EDIT GAME  --
        if ($gameid == 0 ){                        
            $ret .= '<form name="add-game" id="add-game">';
            $ret .= '<div id="op-game-scheduler-inner">';
            $ttl .= ': Add Game';
            $ret .= '<input type="hidden" name="gameid" id="gameid" value="0" />';
        }
        else{
            $ret .= '<form name="edit-game" id="edit-game">';
            $ret .= '<div id="op-game-scheduler-inner">';
            $ttl .= ': Modify Game';
            $ret .= '<input type="hidden" name="gameid" id="gameid" value="' . $gameid . '" />';
        }

        $ret .= '<div id="op-game-scheduler-inner2">';                
        $ret .= '<div  id="scenario-select">';
        $ret .= '<label for="gameScenario">Scenario:</label>';

        if ($gameid == 0 ){
            $ret1 = $ci->convention->getScenarioSelect($conid, 'gameScenario', $aff);
            $ret .= str_replace('<select', '<select class="form-control my-2" onchange="loadslots(this.options[this.selectedIndex].value, ' ."'". site_url('ogrex/getSlots','https') ."'". ')" ', $ret1);                      
        }
        else{
            $ret .= '<div id="scheduler-scenario-name">';
            $ret1 = $ci->convention->getScenarioSelect($conid, 'gameScenario', '', $this->rpga_scenario_id);
            $ret .= str_replace('<select', '<select class="form-control my-2" disabled="disabled" onchange="loadslots(this.options[this.selectedIndex].value, ' ."'". site_url('ogrex/getSlots','https') ."'". ')" ', $ret1);
            $ret .= '</div>';
        }
        $ret .= '</div>';


        if ($gameid == 0){
            $ret .= '<label for="gameNumTables">Number of tables</label>';
            $ret .= '<input class="form-control my-2" type="text" class="number_text" id="gameNumTables" name="gameNumTables" value="1" />';
        }
        else{
            $ret .= '<label for="gameNumTables">Number of tables</label>';
            $ret .= '<input class="form-control my-2" type="text" class="number_text" id="gameNumTables" name="gameNumTables" value="' . $this->rpga_number_of_tables . '" />';
        }
        $ret .= '<input hidden="text" id="gameActivity" name="gameActivity" value="1" />';

        if ($gameid == 0){
            $ret .= '<label for="gameNumPerTable"># of Players/Table</label>';
            $ret .= '<input class="form-control my-2" type="text" class="number_text" id="gameNumPerTable" name="gameNumPerTable" value="6"  />';
        }
        else{
            $ret .= '<label for="gameNumPerTable"># of Players/Table</label>';
            $ret .= '<input class="form-control my-2" type="text" class="number_text" id="gameNumPerTable" name="gameNumPerTable" value="' . $this->rpga_max_players_per_table . '" />';
        }
        $ret .= '<label for="gameSlot">Game Slots (NOTE: (#.# = [Slot #].[Length in hours]))</label>';
        $ret .= '<div  id="game-slot-edit-display">';
        if ($gameid == 0){
            $ret .= $this->getOPGameAdminSlotSelect();                    
            $instr = $ci->ogre_lib->getMiscContent('%MULTISLOTINSTRUCTIONS%');
            $ret .= $instr['content'];

        }
        else{
            $ret .= (substr($this->slot_code,-1,1) == "5") ?  '<div>Slot ' . substr($this->slot_code,-2,1) . 'MM</div>' :  '<div class="gameslot_editdisplay">Slot ' . substr($this->slot_code,-2,1) . '</div>';
        }         
    $ret .= '<label for="opentoprereg">Preregistration?:</label><br />';
    $ret .= '<select class="form-control my-2" size="1" name="open2prereg" id="open2prereg" onchange="">';
    if ($gameid==0) {
        $ret .= '<option value="1"  selected="selected"> Open </option>';
        $ret .= '<option value="0">  Close </option>';
    }else{
        if($this->prereg_id > 0){
            $ret .= '<option value="1"  selected="selected"> Open </option>';
            $ret .= '<option value="0">  Closed </option>';  
        }
        else{
          $ret .= '<option value="1" > Open </option>';
           $ret .= '<option value="0" selected="selected" >  Closed </option>';                     
        }
    }
    $ret .= '</select>' ;
        $ret .= '<label for="allowalt">';
        $tagaction = site_url("ogrex/closedMsg/110",'https');
        $taginfo = $ci->ogre_lib->getMiscContent(110);
        $ret .= '<a href="#" onclick="return getTagInfo('."'".$tagaction."',"."'".$taginfo['title']."'".')" >Alternates?:</a>';
        $ret .= '</label>';
        $ret .= '<select class="form-control my-2" size="1" name="allowalts" id="allowalts" onchange="">';
        if ($gameid==0) {
            $ret .= '<option value="1"  selected="selected"> Open to Alternates during Preregistration </option>';
            $ret .= '<option value="0">  Close once game is Full </option>';
        }else{
            if($this->prereg_opentoalt > 0){
                $ret .= '<option value="1"  selected="selected"> Open to Alternates during Preregistration </option>';
                $ret .= '<option value="0">  Close once game is Full </option>';  
            }
            else{
              $ret .= '<option value="1" > Open to Alternates during Preregistration </option>';
               $ret .= '<option value="0" selected="selected" >  Close once game is Full </option>';                     
            }
        }
        $ret .= '</select>';

                 
        if ($gameid == 0){
            $ret .= '<div class="d-grid gap-2" id="op-game-scheduler-button">';
            $ret .= '<button class="btn btn-success mb-3" name="game_add" type="button" onClick="return addOPGame('."'".$action."','".$schedulerefresh."','".$divid."'".')">+ Schedule Games + </button>';
            $ret .= '<input name="mode" type="hidden" value="addgame" />';
            $ret .= '</div>';
        }

        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</form>';

        $ret .= '</div>';                  
        $ret .= '</div>';
        $image_properties = array('src' =>'images/ajax-loader.gif','alt'=>'ajax-loader.gif');
        $ret .= '<div id="op-admin-wait">' . img($image_properties) . '</div>'; 
        return $ci->ogre_lib->bootCard('', $ret, 'op-scheduler-card', $ttl);
        //$type, $text='', $id='', $title='', $stitle=''
    }
//***********************************
//
//***********************************        
        public function gameAdminOPTabForm($gameid=0){
            $ret = '';
            $ci=&get_instance();
            $ret .= '<div id="opgatabs">';          
            $ret .= '<ul>';                   
            $ret .= '<li>';
            $ret .= '<a href="#opgatab-1">Edit Game</a>';
            $ret .= '</li>';
            $ret .= '<li>';
            $ret .= '<a href="#opgatab-2">Players/Judges</a>';
            $ret .= '</li>';
            $ret .= '</ul>';
            $ret .= '<div id="opgatab-1">';
            $ret .= $this->gameAdminOP($gameid);
            $ret .= '</div>';            
            $ret .= '<div id="opgatab-2">';
            $ret .= $this->buildRegPageX($gameid, TRUE);
            $ret .= '</div>';           
            $ret .= '</div>';      
            return $ret;        
        }         
//---------------------------------------------------
//
//---------------------------------------------------
         public function getOPGameAdminSlotSelect($sl=4){
            $ci=&get_instance();         
            $conid = $ci->session->ogre_conid;
            $orgid = $ci->session->ogre_orgid;
            $ret='';
            $sl = ($sl==0) ? $ci->ogre_lib->getConfigKey('DEFAULT.SLOTLENGTH',$orgid) : $sl;
            $qry  = "SELECT * ";
            $qry  .= " FROM ogre_gameslots";
            $qry  .= " WHERE ogre_gameslots.slot_RPGA = 1 ";
            $qry  .= " AND slot_conid = " . $conid;
            $qry  .= " AND slot_length = " . $sl;
            $qry  .= " ORDER BY ogre_gameslots.slot_code;";
            var_dump($qry);
            $rs = $ci->db->query($qry);
            $ret .= '<select class="form-control my-2" id="gameSlot" name="gameSlot[]" multiple="multiple" size="9">';  //id="gameSlotaffiliation_filter"
            if($rs->getNumRows() != 0){
               foreach ($rs->getResult() as $slot){
                   if ($slot->slot_latenight == 1) {
                       $ret .= '<option value="' . $slot->slot_code . '">' . 'Slot ' . $slot->slot_rpga_number . "." . $slot->slot_length . 'MM ('.$slot->slot_number.')' .  '</option>';
                   }
                   else{
                       $ret .= '<option value="' . $slot->slot_code . '"> Slot ' . $slot->slot_rpga_number . "." . $slot->slot_length . ' ('.$slot->slot_number.')'. '</option>';
                   }
               }
            }
            $ret .= '</select>';      
            return $ret;
         }
         
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function onsiteGamePlayerAdmin($gameid=0){
             $ci = &get_instance();

// Player Array             
            $plyr[1][0]="-"; // pp_player_prereg_id
            $plyr[1][1]="-"; // pp_player_name
            $plyr[1][2]="-"; // pp_player_notes with no '/'
            $plyr[1][3]="-"; // pp_player_email
            $plyr[1][4]="-"; // user_rpga_number
            $plyr[1][5]="-"; // pp_rpga_judge_apl
            $plyr[1][6]="-"; // pp_rpga_player_apl
            $plyr[1][7]="0"; // pp_player_id
            $plyr[1][8]="1"; // pp_player_confirmed (0 = Alernate)  
            $plyr[1][9]="0"; // pp_gm_judge_flag (-1 = Particpating GM)           
//Judge/GM array             
            $jdgs[1][0]="-"; // pp_player_prereg_id
            $jdgs[1][1]="-"; // pp_player_name
            $jdgs[1][2]="-"; // pp_player_notes with no '/'
            $jdgs[1][3]="-"; // pp_player_email
            $jdgs[1][4]="-"; // user_rpga_number
            $jdgs[1][5]="-"; // pp_rpga_judge_apl
            $jdgs[1][6]="-"; // pp_rpga_player_apl
            $jdgs[1][7]="0"; // pp_player_id
            $jdgs[1][8]="0"; // pp_player_confirmed (0 = Alernate) 
            $jdgs[1][9]="1"; // pp_gm_judge_flag (-1 = Particpating GM)          
            $vmode = $ci->session->viewmode;           
            $editview="player-admin-view";
            $rowrefresh="";
            $divid="";
            switch($vmode){
                case 'MAIN':
                    $divid ='gsrow'.$gameid;
                    $rowrefresh = site_url('ogrex/regularRowRefresh/' . $gameid,'https');                             
                    break;
                case 'OP':
                    $divid ='opgicell'. $gameid;
                    $rowrefresh = site_url('ogrex/opCellRefresh/' . $gameid,'https');                         
                    break;
                default:
                    $divid ='';
                    $rowrefresh = '';                               
                    break;   
            }     
            if($gameid!=$this->id){
               $this->event_init($gameid);
            }
            $gmtitle = ($this->mmrpgFlag=='1')?"Judge":"GM";            
            $action=site_url('ogrex/removePlayerOnsite','https');
            $ret = '';
            $ret .= '<div id="player-admin-view">';
            $ret .= '<table class="table">';
            $ret .= '<tr>';
            $ret .= '<td>';                 
             if($this->mmrpgFlag=='1'){
                $ret .= '<table class="table table-striped">';
                $ret .= '<tr>';
                $ret .= '<td class="playercount">';                 
                $num_of_judges = $this->getNumberOfPlayers('1');
                $extraJudges = ($this->rpga_number_of_tables) - $num_of_judges;                 
                if ($extraJudges >= 0){
                       $ret .= '<strong>'. $gmtitle . 's</strong> ' . $extraJudges . ' needed';
                   }
                elseif ($extraJudges < 0){
                       $extraJudges = $extraJudges * -1;
                       $ret .= '<strong>'. $gmtitle . 's</strong> ' . $extraJudges . ' extra';
                }
                else{
                       $ret .= '<strong>'. $gmtitle . 's</strong>';
                }
                $ret .= '</td>';            
                $ret .= '</tr>';
                $ret .= '</table>';                
             }
             else{
                    $num_of_judges = $this->getNumberOfPlayers('1');
                    $extraJudges = 1 - $num_of_judges;
             }               
             $ret .= '<table class="table">';
             $ret .= '<tr>';
             $ret .= '<td>';
                
                $ret .= '<table class="table table-striped">';
                $ret .= '<tr>';
                $ret .= '<td class="premove">';
                $ret .= 'Remove';
                $ret .= '</td>';
                $ret .= '<td class="pnumber">';
                $ret .= '#';
                $ret .= '</td>';                
                $ret .= '<td class="pname">';
                $ret .= '<strong>'. $gmtitle . '</strong>';
                $ret .= '</td>';    
                $ret .= '</tr>';                                
                $jdgs = $this->getPlayerList('1');
                $i = 1;
                foreach ($jdgs as $jdg){
                    $ret .= '<tr>';
                    $ret .= '<td>';
                    if ($jdg[1] != "-"){
                        $ret .= '<input name="remove_judge' . $jdg[0] . '" type="checkbox" ';
                        $ret .= ' id="remove_judge' . $jdg[0] . '" value="' . $jdg[7] . '"  ';
                        $ret .= ' onclick="removeJudgePlayerOnsite(1,' . $jdg[0] . ", " . $this->id . ", " . "'" . $action . "'" . ", " . "'" . $editview . "'". ", " . "'".$vmode."'" .", " . "'".$rowrefresh."', '" . $divid ."'".')" />'; 
                    }
                    $ret .= '</td>';
                    $ret .= '<td>';
                    $ret .= ($jdg[1] != "-") ? '('.$i.')' : '';
                    $ret .= '</td>';                    
                    $ret .= '<td>';
                    $ret .= mailto($jdg[3], $jdg[1]);
                    $ret .= ($jdg[7]!=0) ? ' (' . str_pad($jdg[7],6,"0",STR_PAD_LEFT) . ')' : '';
                    $ret .= ($this->mmrpgFlag=='1' && trim($jdg[5]!='-')) ? ' (Level Pref: '. $jdg[5] .')' : '';
                    $ret .= $this->change_participant_status($jdg, 'GM');
                    $ret .= '</td>';
                    $ret .= '</tr>';
                    $i++;
                }
                
                $ret .= '<tr>';
                $ret .= '<td colspan="3">';
                $ret .= '<input type="hidden" name="numofjudges" id="numofjudges" value="'. count($jdgs) .'" />';
                $ret .= '</td>';
                $ret .= '</tr>';               
                $ret .= '</table>';
                
                $ret .= '</td>';
                $ret .= '</tr>';
                $ret .= '</table>';

                $ret .= '<table class="table table-striped">';
                $ret .= '<tr>';
                $ret .= '<td class="playercount">';
                if($this->mmrpgFlag=='1'){
                    $num_of_plyrs = $this->getNumberOfPlayers('0');
                    $NumofSeats = ($this->rpga_number_of_tables) * ($this->rpga_max_players_per_table);
                    $totalseats = $NumofSeats;
                    $extraSeats = $NumofSeats - $num_of_plyrs;
                }
                else{
                    $num_of_plyrs = $this->getNumberOfPlayers('0');
                    $NumofSeats = $this->prereg_players_allowed;
                    $totalseats = $this->max_players;
                    $extraSeats = $NumofSeats - $num_of_plyrs;
                }
                $pseats = (intval($NumofSeats) < intval($totalseats)) ? $NumofSeats." of ".$totalseats.'*': $NumofSeats;
                
                if ($extraSeats >= 0){
                    $ret .= '<strong>Players</strong> ' . $pseats  . ' seats; ' . $extraSeats . ' open';
                }
                elseif ($extraSeats < 0){
                    $extraSeats = abs($extraSeats);
                    $ret .= '<strong>Players </strong> ' . $pseats . ' seats; ' . $extraSeats . ' extra ';
                }
                $ret .= (intval($this->max_players) > intval($this->prereg_players_allowed)) ? '&nbsp;&nbsp;&nbsp;(* - A seat may be reserved for the Host).' : '';
                $ret .= '</td>';
                $ret .= '<td>';
                $ret .= '</td>';
                $ret .= '</tr>';
                $ret .= '</table>';

                $ret .= '<table class="table table-striped">';
                $ret .= '<tr>';
                $ret .= '<td>';

                $ret .= '<table class="table table-striped">';
                $ret .= '<tr>';
                $ret .= '<td class="premove">';
                $ret .= 'Remove';
                $ret .= '</td>';
                $ret .= '<td class="pnumber">';
                $ret .= '<strong>#</strong>';
                $ret .= '</td>';                
                $ret .= '<td class="pname">';
                $ret .= '<strong>Player</strong>';
                $ret .= '</td>';                          
                $ret .= '</tr>';         
                $plyr = $this->getPlayerList('0');
                $i = 1;
                foreach ($plyr as $ply){
                    $ret .= '<tr>';
                    $ret .= '<td>';
                    if ($ply[1] != "-"){
                        $ret .= '<input name="removePlayer' . $ply[0] .'" ';
                        $ret .= ' type="checkbox" id="removePlayer' . $ply[0].'" ';
                        $ret .= ' value="' . $ply[0] . '"';
                        $ret .= ' onclick="removeJudgePlayerOnsite(0,' . $ply[0] . ", " . $this->id . ", " . "'" . $action . "'". ", " . "'" . $editview . "', '" . $vmode . "', '" . $rowrefresh . "', '" . $divid ."'" . ')" />'; 
                    }

                    $ret .= '</td>';
                    $ret .= '<td>';
                    if ($ply[1] != "-"){
                        $ret .= (intval($ply[8]) == 1) ? '('.$i.')' : ' ? ';
                    }
                    $ret .= '</td>';                      
                    $ret .= '<td>';
                    $ret .= mailto($ply[3], $ply[1]);
                    if(intval($ply[7]) != 0){
                        $ret .= ' (' . str_pad($ply[7],6,"0",STR_PAD_LEFT) . ')';
                    }
                    if($ply[8]=='0'){
                        $ret .= ' (A)';
                    }                  
                    if($this->mmrpgFlag=='1' && trim($ply[2]!='-')){ 
                        $ret .= ' (Level Pref: '. $ply[2] .')';
                    }                    
                    $ret .= $this->change_participant_status($ply, 'PL');
                    $ret .= '</td>';                    
                    $ret .= '</tr>';
                    $i++;
                }
                $ret .= '</table>';
                
                $ret .= '<input type="hidden" name="numofplayers" id="numofplayers" value="'. count($plyr) .'" />';
                $ret .= '<input type="hidden" name="numofseats" id="numofseats" value="'. $NumofSeats .'" />';
                
                $ret .= '</td>';
                $ret .= '</tr>';

                $ret .= '</table>';
                $ret .= '</td>';
                $ret .= '</tr>';

                $ret .= '</table>';
                $ret .= '</form>';
                $ret .= '</div>';

                return $ret;
        }         
//---------------------------------------------------
//
//
//
//---------------------------------------------------
        private function change_participant_status($p, $loc='GM'){
            $ci=get_instance();
            $curr_userid = $ci->session->ogre_user_ID;
            $isloggedin = $ci->session->ogre_logged_in;
            $orgid = $ci->session->ogre_orgid;
            $accessrating = $ci->session->get('ogre_user_accesslevel_' . $orgid);            
            $ret ='';
            $action = site_url('ogrex/changeGMStatus/'. $p[0],'https');
            $refresh = base_url();
            if (($isloggedin===TRUE) && ((intval($p[0]) == intval($curr_userid)) || ($accessrating >= REGVOL))){
                switch (intval($p[9])){
                    case -1:
                        $ret = ($loc=='PL') ? ' <span class="changepgm"><input type="checkbox" id="pgm'.$p[0].'" name="pgm'.$p[0].'" onclick="changeGMstatus('."'".$action .'/1'."'".')" /> Change to GM only.</span>' : '';
                    break;
                    case 0:
                        $ret = '';
                    break;
                    case 1:
                        $ret = ($loc=='GM') ? '<span class="changepgm"><input type="checkbox" id="pgm'.$p[0].'" name="pgm'.$p[0].'" onclick="changeGMstatus('."'".$action . '/-1'."'".')" /> Change to Participating GM.</span>' : '';
                    break;
                    default:
                        $ret = '';
                    break;
                } 
            }
            return $ret;
        }
        
        
        //---------------------------------------------------
        //
        //
        //
        //---------------------------------------------------
         public function game_admin_rpga_playeradmin($gameid=0){
             if($gameid!=$this->id){
                $this->event_init($gameid);
             }
             $gmtitle= ($this->mmrpgFlag=='1') ?  "Judge" : "GM";
                $action = site_url('ogrex/removePlayer','https');
                $action2 = site_url('ogrex/gmplayer_admin_search/'.$this->id,'https');
                $ret = '';
                $ret .= '<div id="player-admin-view">';
                $ret .= '<form action="" name="plyrjdg" id="plyrjdg">';
                $ret .= '<table id="plyrjdg_table" class="plyrjdg_table">';
                $ret .= '<tr><td>';
                
                $ret .= '<table cellpadding="0" cellspacing="0" border="0" width="100%">';
                $ret .= '<tr><td>';
                if($this->mmrpgFlag=='1')
                {
                    $num_of_judges = $this->getNumberOfPlayers('1');
                    $extraJudges = ($this->rpga_number_of_tables) - $num_of_judges;
                }
                else
                {
                    $num_of_judges = $this->getNumberOfPlayers('1');
                    $extraJudges = 1 - $num_of_judges;
                }
                if ($extraJudges >= 0)
                {
                    $ret .= '<strong>'. $gmtitle . 's</strong> ' . $extraJudges . ' needed';
                }
                elseif ($extraJudges < 0)
                {
                    $extraJudges = $extraJudges * -1;
                    $ret .= '<strong>'. $gmtitle . 's</strong> ' . $extraJudges . ' extra';
                }
                else
                {
                    $ret .= '<strong>'. $gmtitle . 's</strong>';
                }
                $ret .= '</td>';

                $lclpreregReport = site_url('ogre/preregReport','https');
                if($this->mmrpgFlag==1){
                    $rtype='RPGA';
                }
                else{
                    $rtype='None';
                }
                $ret .= '<td align="right"><br />';
                $ret .= anchor($lclpreregReport . '/' . $gameid . '/'. $rtype . '/0/1', 'print', array('target' =>'_blank'));
  
                $ret .= '</td></tr></table>';

                $ret .= '<table cellpadding="1" cellspacing="0" border="1" width="100%">';
                $ret .= '<tr><td>';

                $ret .= '<table cellpadding="3" cellspacing="1" border="0" width="100%">';
                $ret .= '<tr>';
                $ret .= '<td valign="bottom">';
                $ret .= 'Remove';
                $ret .= '</td>';
                $ret .= '<td  valign="bottom">';
                $ret .= '<strong>'. $gmtitle . '</strong>';
                $ret .= '</td>';

                $ret .= '<td  valign="bottom">';
                if($this->mmrpgFlag=='1')
                { 
                    $ret .= '<strong>Level Pref.</strong>';
                }
                $ret .= '</td>';
                $ret .= '</tr>';
                $jdgs = $this->getPlayerList('1');

                if (count($jdgs) == 0)
                {
                    $jdgs[1][1]="-";
                    $jdgs[1][2]="-";
                    $jdgs[1][3]="-";
                    $jdgs[1][4]="-";
                    $jdgs[1][5]="-";
                    $jdgs[1][6]="-";
                    $jdgs[1][7]="0";
                    $jdgs[1][8]="0";
                }

                for ($i = 1; $i <= count($jdgs); $i++)
                {
                    $ret .= '<tr><td>';
                    if ($jdgs[1][1] != "-")
                    {
                        $ret .= '<input name="remove_judge" type="checkbox" id="remove_judge" value="' . $jdgs[$i][7] . '"  onclick="removeJudge(' . $jdgs[$i][7] . ", " . $this->id . ", " . "'" . $action . "'," . $this->mmrpgFlag.",'".$action2."'" . ')" />'; //onchange="flagremovejudge();"
                    }
                    $ret .= '</td>';
                    $ret .= '<td>';
                    $ret .= $jdgs[$i][1];
                    $ret .= '</td>';

                    $ret .= '<td>';
                    $ret .= $jdgs[$i][5];
                    $ret .= '</td></tr>';
                }
                $ret .= '</table>';
                $ret .= '<input type="hidden" name="numofjudges" id="numofjudges" value="'. count($jdgs) .'" />';
                $ret .= '</td></tr></table>';

                $ret .= '<table cellpadding="0" cellspacing="0" border="0" width="100%">';
                $ret .= '<tr><td>';
                if($this->mmrpgFlag=='1')
                {
                    $num_of_plyrs = $this->getNumberOfPlayers('0');
                    $NumofSeats = ($this->rpga_number_of_tables) * ($this->rpga_max_players_per_table);
                    $extraSeats = $NumofSeats - $num_of_plyrs;
                }
                else
                {
                    $num_of_plyrs = $this->getNumberOfPlayers('0');
                    $NumofSeats = ($this->max_players);
                    $extraSeats = $NumofSeats - $num_of_plyrs;
                }
                if ($extraSeats >= 0)
                {
                    $ret .= '<strong>Players</strong> ' .  $NumofSeats . ' seats; ' . $extraSeats . ' open';
                }
                elseif ($extraSeats < 0)
                {
                    $extraSeats = $extraSeats * -1;
                    $ret .= '<strong>Players </strong> ' . $NumofSeats . ' seats; ' . $extraSeats . ' needed ';
                }

                $ret .= '</td>';
                $ret .= '<td align="right">';
                $ret .= '<br />';
                $ret .= anchor($lclpreregReport . '/' . $gameid . '/'. $rtype . '/0/0', 'print', array('target' =>'_blank'));
                $ret .= '</td></tr>';
                $ret .= '</table>';

                $ret .= '<table cellpadding="1" cellspacing="0" border="1" width="100%">';
                $ret .= '<tr><td>';

                $ret .= '<table cellpadding="3" cellspacing="1" border="0" width="100%">';
                $ret .= '<tr>';
                $ret .= '<td  valign="bottom" width="15%">';
                $ret .= 'Remove';
                $ret .= '</td>';
                $ret .= '<td  valign="bottom">';
                $ret .= '<strong>Player</strong>';
                $ret .= '</td>';

                $ret .= '<td  valign="bottom">';
                if($this->mmrpgFlag=='1')
                {                 
                    $ret .= '<strong>Type Level/Pref.</strong>';
                }
                $ret .= '</td></tr>';
                $plyr = $this->getPlayerList('0');
                if (count($plyr) == 0)
                {
                    $plyr[1][1]="-";
                    $plyr[1][2]="-";
                    $plyr[1][3]="-";
                    $plyr[1][4]="-";
                    $plyr[1][5]="-";
                    $plyr[1][6]="-";
                    $plyr[1][7]="0";
                    $plyr[1][8]="0";
                }

                for ($i = 1; $i <= count($plyr); $i++)
                {
                    $ret .= '<tr><td>';
                    if ($plyr[1][1] != "-")
                    {
                        $ret .= '<input name="removePlayer" type="checkbox" id="removePlayer"  value="' . $plyr[$i][7] . '"   onclick="removePlayer(' . $plyr[$i][7] . ", " . $this->id . ", " . "'" . $action . "'," . $this->mmrpgFlag.",'".$action2."'" . ')" />'; //onchange="flagremoveplayer();" 
                    }

                    $ret .= '</td>';
                    $ret .= '<td>';
                    $ret .= $plyr[$i][1];
                    $ret .= '</td>';

                    $ret .= '<td>';
                    $ret .= $plyr[$i][2];
                    $ret .= '</td></tr>';
                }
                $ret .= '</table>';
                $ret .= '<input type="hidden" name="numofplayers" id="numofplayers" value="'. count($plyr) .'" />';
                $ret .= '</td></tr>';

                $ret .= '</table><br /><br />';

                $ret .= '</td></tr>';

                $ret .= '</table>';
                $ret .= '</form>';
                $ret .= '</div>';

                return $ret;
        }
//---------------------------------------------------
//
//---------------------------------------------------
    public function gameAdminOPSCurrentSchedule($gameid=0, $aff=""){           
       $ci=get_instance();
       $orgid = $ci->session->ogre_orgid;
       $conid = $ci->session->ogre_conid;            
       $ret='';
       $lastaff ='';
       $rcolor = '';
       $ci->convention->init($conid);              
       $qry = 'SELECT ogre_gameschedule.*, ogre_preregistergamelist.*, ogre_rpga_game_setup.* ';
       $qry .= ' FROM ogre_rpga_game_setup RIGHT JOIN (ogre_preregistergamelist ';
       $qry .= ' RIGHT JOIN ogre_gameschedule ON ogre_preregistergamelist.pgl_gs_id = ogre_gameschedule.gs_id) ';
       $qry .= ' ON ogre_rpga_game_setup.rgs_gs_id = ogre_gameschedule.gs_id ';
       $qry .= ' WHERE ogre_gameschedule.gs_mmrpgFlag = 1 ';
       $qry .= ' AND trim(ogre_gameschedule.gs_game_title) <> "" AND ogre_gameschedule.gs_cancelled = 0 ';
       $qry .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
       $qry .= ($gameid!=0) ? ' AND ogre_gameschedule.gs_id=' . $gameid : "";
       $qry .= ($aff!="" && $aff!="0")? ' AND ogre_gameschedule.gs_affiliation="' . $aff . '"' : "";                
       $qry .= ' ORDER BY ogre_gameschedule.gs_affiliation, ';
       $qry .= ' ogre_gameschedule.gs_slot_code, ';
       $qry .= ' ogre_gameschedule.gs_game_title ';
       $rs = $ci->db->query($qry);
       $ret .= '<div id="current-game-admin-list">'; 
       $ret .= '<p class="printreport">';
       $ret .= '<div class="d-grid gap-2 mb-5">';
       $listlinkj = site_url('ogre_pdf/pdfOPPlayerList/' . $aff.'/1','https');
       $ret .= '<button type="button" class="btn btn-primary" onclick="self.location='."'".$listlinkj."'".'">Print Judge List</button>';
       $listlinkp = site_url('ogre_pdf/pdfOPPlayerList/' . $aff .'/0','https');
       $ret .= '<button type="button" class="btn btn-primary" onclick="self.location='."'".$listlinkp."'".'">Print Player List</button>';
       $ret .= '</div>';
       $lastslot = $ci->admin_lib->getFirstSlotCode($conid);
       $i = 1;
       $j = 0;
       if ($rs->getNumRows() > 0){
           foreach ($rs->getResult() as $row){
               $this->event_init($row->gs_id);                   
               if($lastslot != $row->gs_slot_code){
                       if ($i !== 1){
                           $ret .= $this->buildGameAdminFooter($lastslot);
                           $ret .= ($lastaff !== $row->gs_affiliation) ? '<h2>'.$row->gs_affiliation.'</h2>' : '';
                       }
                       else{
                           $ret .= '<h2>'.$row->gs_affiliation.'</h2>';
                       }
                       $ret .= $this->buildGameAdminHdr($row);                                                       
                       $ret .= $this->buildGameAdminRow($row, $j, $rcolor);                           
                   }
                   else{
                       $ret .= ($i == 1) ? $this->buildGameAdminHdr($row) :'';                           
                       $ret .= $this->buildGameAdminRow($row, $j, $rcolor);
                   }
                   if ($this->rpga_game_round == 1){
                       $j++;
                   }
                   $i++;
                   $lastslot = $row->gs_slot_code;
                   $lastaff=$row->gs_affiliation;
               }
               $ret .= $this->buildGameAdminFooter($lastslot);
           }
           $ret .= '</div>';
           return $ret;
    }
//------------------------
//
//------------------------
    public function buildGameAdminHdr($row){
        $ret = '';           
        $this->event_init($row->gs_id);          
        $ret .= '<div id="'.$row->gs_slot_code.'">';      
        $ret .= '<form action="" id="game-modify-' . $row->gs_slot_code . '" name="game-modify-' . $row->gs_slot_code . '">';
        $ret .= '<h3>Session ' . $row->gs_slot_number . ' (' . $row->gs_slot_length . ' hrs)' . '</h3>';        
        $ret .= '<table class="table table-striped">';
        $ret .= '<thead>';
        $ret .= '<th>Slot</th>';
        $ret .= '<th>Scenario</th>';
        $ret .= '<th>Tbls</th>';
        $ret .= '<th>Per<br/>Tbl</th>';
        $ret .= '<th>Plyrs</th>';
        $ret .= '<th>Wait<br/>List</th>';
        $ret .= '<th>Open<br/>Seats</th>';
        $ret .= '<th>Judges</th>';
        $ret .= '<th>Judgs Needed</th>';
        $ret .= '<th>Judges Xtra</th>';
        $ret .= '</thead>' ;
        return $ret;
    }
//------------------------
//
//------------------------
    public function buildGameAdminFooter($lastslot){        
            $ret = '<tr><td colspan="12">';
            $ret .= '</td></tr>';            
            $ret .= '</table>';
            $ret .= '</form>'; 
            $ret.='</div>';
        return $ret;
    }
//------------------------
//
//------------------------
    public function buildGameAdminRow($row, $i=0, $rcolor=''){
        $ci=get_instance();
        $this->event_init($row->gs_id);
        $ret = '';                
        $ret .= '<tr id="op-game-row-' . $row->gs_id . '">';
        $ret .= '<td>';
        $opadmingamesmodify = site_url("ogre/games/rpga",'https');
        $csaction = site_url('ogrex/opAdminSlotChange','https');
        $chkaction = site_url('ogrex/opadmin_slotcheck','https');
        $remaction= site_url('ogrex/delete_game/' . $row->gs_id,'https');                
        $refreshaction=site_url('ogrex/currentSchedule','https');
        $saveaction=site_url('ogrex/gamesIn/rpgax/msg','https');
        $remchkaction=site_url('ogrex/gotPlayers','https');
        $regaction=site_url('ogrex/regaction/' . $row->gs_id,'https');
        $divid='game-admin-list';
        if (intval($this->rpga_game_round) <= 1){                                      
            $ret .= '<input type="hidden" id="scheduleID'. $row->gs_id . '" name="scheduleID'. $row->gs_id . '" value="' . $row->gs_id . '" />';              
            $ret .= '<div id="op-game-' . $row->gs_id . '">';
            $ret .= '<select class="form-select form-select-sm" id="slot-Num-' . $row->gs_id . '" name="slot-Num-'. $row->gs_id . '" ';
            $ret .= 'onchange="changeSlotcode(this.options[this.selectedIndex].value' . "," . $row->gs_id . ",'". $csaction."','". $chkaction."','". $remaction."','". $remchkaction."','". $refreshaction."','". $divid."'".'); ';
            $ret .= '">';                
            $ret .= $ci->admin_lib->getGameSlotSelect($this->slot_code, $this->slot_length);
            $ret .= '</select>';
            $ret .= '</div>';
        }
        else{                 
            $sc = substr($this->slot_code,-2,2);
            $ret .= ($this->late_night == 0) ? substr($sc,0,1) : substr($sc,0,1) . " MM";
        }
        $ret .= '</td>';
        $ret .= '<td class="ga_scenario">';
        $stitle = $row->gs_game_title;
        $ret .= (intval($this->rpga_game_round) <= 1) ? '<a href="#" title="'.$row->gs_game_title.'" onclick="return editOPgame('.$this->id.",'".$opadmingamesmodify . '/' . $row->gs_id."','".$saveaction."','".$refreshaction."','". $divid."','".$remaction."','".$remchkaction."','".$regaction."'".');">' : '<a href="#" title="'.$row->gs_game_title.'" onclick="return editOPgame('.$this->rpga_2slot_gs_id.",'".$opadmingamesmodify . '/' . $this->rpga_2slot_gs_id."','".$saveaction."','".$refreshaction."','". $divid."','".$remaction."','".$remchkaction."','".$regaction."'".');">';
        $ret .= $stitle;
        $ret .= '</a>';
        $ret .= '</td>';
        $ret .= '<td class="ga_oftables">';
        $onclk1 = ' onclick="return editOPgame('.$this->id.",'".$opadmingamesmodify . '/' . $row->gs_id."','".$saveaction."','".$refreshaction."','". $divid."','".$remaction."','".$remchkaction."','".$regaction."'".');" ';
        $onclk2 = ' onclick="return editOPgame('.$this->rpga_2slot_gs_id.",'".$opadmingamesmodify . '/' . $this->rpga_2slot_gs_id."','".$saveaction."','".$refreshaction."','". $divid."','".$remaction."','".$remchkaction."','".$regaction."'".');" ';
        $onclck = (intval($this->rpga_game_round) <= 1) ? $onclk1 : $onclk2;
        $ret .= '<div id="notbl" ' . $onclck . '>';
        $ret .= (intval($this->rpga_game_round) <= 1) ? '<input disabled="disabled" type="text" class="form-control form-control-sm" name="numTables_game'. $row->gs_id . '" value="' . $this->rpga_number_of_tables . '" size="2"  />' : '<input disabled="disabled" type="text" class="form-control form-control-sm" name="numTables_game'. $row->gs_id . '" value="' . $this->rpga_number_of_tables . '" size="2"  />'; //$this->rpga_number_of_tables;  onchange="flagchange(' . "'" . $this->slot_code . "'," . $row->gs_id . ');"
        $ret .= '</div>';
        $ret .= '</td>';
        $ret .= '<td class="ga_pertable">';
        $ret .= '<div id="notbl" ' . $onclck . '>';
        $ret .= (intval($this->rpga_game_round) <= 1) ? '<input disabled="disabled" type="text" class="form-control form-control-sm" name="numPerTable_game'. $row->gs_id . '" value="'. $this->rpga_max_players_per_table . '" size="2" />' : $this->rpga_max_players_per_table; //onchange="flagchange(' . "'" . $this->slot_code . "'," . $row->gs_id . ');"               
        $ret .= '</div>';
        $ret .= '</td>';
        $ret .= '<td class="ga_players">';
        $num_of_players = $this->getNumberOfPlayers('0');
        $ret .= $num_of_players;
        $ret .= '</td>';
        $ret .= '<td class="ga_waitlist">';
        $waitList= $num_of_players - ($this->rpga_number_of_tables * $this->rpga_max_players_per_table);
        $ret .= ($waitList >= 0 ) ? $waitList :  "0";
        $ret .= '</td>';
        $ret .= '<td class="ga_openseats">';
        $openSeats = ($this->rpga_number_of_tables * $this->rpga_max_players_per_table) - $num_of_players;
        $ret .= ($openSeats >= 0) ? $openSeats : '0';
        $ret .= '</td>';
        $ret .= '<td class="ga_judges">';
        $num_of_judges = $this->getNumberOfPlayers('1');
        $ret .= $num_of_judges;
        $ret .= '</td>';
        $ret .= '<td class="ga_judgesneed">';
        $neededJudges = intval($this->rpga_number_of_tables) - intval($num_of_judges);
        $ret .=  ($neededJudges >= 0) ? $neededJudges : '0';
        $ret .= '</td>';
        $ret .= '<td class="ga_judgesxtra">';
        $eJudges1 =  ($this->rpga_max_players_per_table > 0) ? intval($num_of_players) / intval($this->rpga_max_players_per_table) : 0;
        $eJudges1 = ((intval($eJudges1)) >= 0 && ($this->rpga_number_of_tables > 0 )) ? 1 : 0;
        if ($this->rpga_max_players_per_table >= 0){
            if (intval($this->rpga_max_players_per_table) != 0 ){
                $eJudges2 = intval($num_of_players) % intval($this->rpga_max_players_per_table);
            }
            else{
                $eJudges2 = 0;
            }                    
        }
        else{
            $eJudges2 = 0;
        }
        $eJudges2 = ($eJudges2 > 0) ? 1: 0;
        $eJudges1 = intval($eJudges1) + intval($eJudges2);
        $extraJudges = intval($num_of_judges) - intval($eJudges1);
        $ret .= ($extraJudges >= 0) ? $extraJudges : '0';
        $ret .= '</td>';
        $ret .= '</tr>';               
        return $ret;
    }
        
//------------------------
//
//
//
//------------------------       
        public function gamesAdminOPGetRow($gid){
            $ci=get_instance();    
            $conid = $ci->session->ogre_conid;
            $qry = 'SELECT ogre_gameschedule.*, ogre_preregistergamelist.*, ogre_rpga_game_setup.* ';
            $qry .= ' FROM ogre_rpga_game_setup RIGHT JOIN (ogre_preregistergamelist ';
            $qry .= ' RIGHT JOIN ogre_gameschedule ON ogre_preregistergamelist.pgl_gs_id = ogre_gameschedule.gs_id) ';
            $qry .= ' ON ogre_rpga_game_setup.rgs_gs_id = ogre_gameschedule.gs_id ';
            $qry .= ' WHERE ogre_gameschedule.gs_mmrpgFlag = 1 ';
            $qry .= ' AND trim(ogre_gameschedule.gs_game_title) <> "" AND ogre_gameschedule.gs_cancelled = 0 ';
            $qry .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
            $qry .= ' AND ogre_gameschedule.gs_id=' . $gid;
            $rs = $ci->db->query($qry);
            if ($rs->getNumRows() > 0){
                foreach ($rs->getResult() as $row){                
                    $ret=$row;
                }
            }
            return $ret;
        }

//------------------------
//
//------------------------
    public function gamesAdminOPIn($act, $gameid, $p){
        $ret = FALSE;
        $ci=&get_instance();
        $conid = $ci->session->ogre_conid;
        switch ($act){
            case 'add':    
                $ret = $this->addOPevent($p, 1);
                break;
            case 'msg':         // modify single game
                $ret = $this->gamesAdminOPModifyGame($p);
                break;
            case 'pjr':         // modify single game
                   if ($p["rmvpflag"] == "Yes"){
                        $ret = $this->gamesAdminOPRemovePlayer($gameid, $p);
                    }
                    if ($p["rmvjflag"] == "Yes"){
                        $ret = $this->gamesAdminOPRemoveJudge($gameid, $p);
                    }
                break;
            case 'mmg':         // modify multi games
                $ret = $this->modifyOPGames($p);
                break;
            case 'rem':         // remove game
                $ret = $this->removeOPGames($gameid);
                break;
            case 'rpgax':
                $ret = $this->modifyOPGamesX($p);
                break;                
        }
//        $ret1 = $ci->RPGA_lib->reset_enums($conid);                                    
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
        public function gamesAdminOPModifyGame($p, $gid=0){
            $gameid = (isset($p['gameid']) ? $p['gameid'] : $gid);
            $ppret = TRUE;
            $this->event_init($gameid);
            $i=1;
            $ret = $this->modifyOPGame($p);   
            $numofplayers1 = $this->calcNumberOfPlayers($p);
            if($p["open2prereg"] == "1"){
                $ppret = $this->updateOPPlayerPrereg($gameid, $i, $numofplayers1, $p["allowalts"]);                                                 
            } else{
                $ppret = $this->delete_prereg_info($gameid);
            }                
            if ($this->rpga_number_of_slots > 1){
                $childid = $this->findOPMultiRoundChild();        
                foreach($childid as $child){ 
                    $i++;
                    $this->event_init($child);
                    $ret = $this->modifyOPGame($p);
                    if($p["open2prereg"] == "1"){
                        $ppret = $this->updateOPPlayerPrereg($child, $i, $numofplayers1, $p["allowalts"]);                                                 
                    } else {
                        $ppret = $this->delete_prereg_info($child);
                    }                              
                }
            }
            return $ret || $ppret;
        }

//---------------------------------------------------
//
//---------------------------------------------------
        public function gamesAdminOPRemovePlayer($gameid, $p)
        {
            $ci = &get_instance();
            $conid = $ci->session->ogre_conid;
            foreach ($p["removePlayer"] as $player){
                $ci->person->init($conid, '', $player);
                $gl[1] = $gameid;
                $ret = $ci->person->removeFromGame($gl, $this);
            }
            return $ret;
         }

//---------------------------------------------------
//
//---------------------------------------------------
        public function gamesAdminOPRemoveJudge($gameid, $p){
            $ci = &get_instance();
            $conid = $ci->session->ogre_conid;
                foreach ($p["remove_judge"] as $judge){
                    $ci->person->init($conid, '', $judge);
                    $gl[1] = $gameid;
                    $ret = $ci->person->removeFromGame($gl);
                }
            return $ret;
        }
        
//------------------------
//
//
//
//------------------------
    public function buildOPGameInfo($gameid, $accessrating=0, $verified=0, $em='', $printver=FALSE){
        $ci=&get_instance();
        $lvlr = '';            
        $this->event_init($gameid);            
        $ret = '';
        $ci->session->set(array('viewmode' => 'OP'));
        $dayid = substr($this->slot_day,0,3);
        $subid = $this->slot_enum . $dayid . $this->slot_enum . $this->row_enum . $this->id;
        $regbuttons = 'ogrex/gameRegDialog/' . $gameid;
        $ret .= '<div id="op_gametitle' . $this->id . '" >';
        $ginfo = site_url('ogrex/getGameInformation','https');
        $ret .= '<a href="#ID' . $subid . '"  onclick="return openGIDialog('.$ci->event->id .",'".$ginfo."',"."'".site_url('ogrex/gameEditInx','https') ."','','','','','OP','P','".site_url($regbuttons,'https')."'".')" name="opgameid' . $subid . '" id="opgameid' . $subid . '">';
        $ret .= $this->game_title;
        if ((trim($this->rpga_exp_level) != '-') && (trim($this->rpga_exp_level) != '')){
            $lvlr = ' (' . $this->rpga_exp_level . ')';
            if (!strpos($this->game_title, $lvlr)){
                $ret .= $lvlr;
            }
        }
        $ret .= '</a></div>';
        $ret .= '<table class="op_gameinfocell" id=opgamesubcell>';
        $ret .= '<tr>';
        $ret .= '<td class="op_tableplayercount">';
        $ret .= $this->rpga_number_of_tables . ' Tables,<br />'.'<br />'.$this->getPreregNum($this->id,'1').' GM(s) / '. $this->getPreregNum($this->id,'0') . ' Player(s)';
        $ret .= '</td>';           
        $retarry['basic'] = $ret;
        $retarry['basic'] .= '<td class="op_signup"></td></tr></table>';           
        $ret .= '<td class="op_signup">';
        $ret .= '<div class="op_signupbutton">';
        if (intval($this->rpga_game_round) > 1){
           $preregLink = '-';
        }
        else{                   
           $preregLink = $ci->schedule_lib->getPreregLinkReg($this->prereg_players_allowed, $this->id, $this->mmrpgFlag, $accessrating, $verified, 0, 'PL');
        }
        $ret .= $preregLink;
        $ret .= '</div>';
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '<tr>';
        $ret .= '<td class="op_tableplayercount">';
        $ret .= '&nbsp;';
        $ret .= '</td>';     
        $ret .= '<td class="op_signup">';
        $ret .= '<div class="op_signupbutton">';
        if (intval($this->rpga_game_round) > 1){
           $preregLink = '-';
        }
        else{                   
           $preregLink = $ci->schedule_lib->getPreregLinkReg($this->prereg_players_allowed, $this->id, $this->mmrpgFlag, $accessrating, $verified, 1, 'GM');
        }
        $ret .= $preregLink;
        $ret .= '</div>';
        $ret .= '</td>';
        $ret .= '</tr>';            
        $ret .= '<tr id="partlist'.$gameid.'" style="display:table-row;">';
        $ret .= '<td colspan="2">';
        $ret .= '<p><span class="op_gameinfocell_label">Judge:</span></p>';
        $ret .= '<div id="gmlist'.$gameid.'" class="gmplayerlist" >';
        $gm_list = $this->getPlayerList(1);
        $ret .= $this->preregModifyLink($gm_list, $gameid, 1, $em, $printver);
        $ret .= '</div>';
        $ret .= '<p><span class="op_gameinfocell_label">Players:</span></p>';
        $ret .= '<div id="playlist'.$gameid.'" class="gmplayerlist" >';
        $ListOfPlayers = $this->getPlayerList(0);
        $ret .= $this->preregModifyLink($ListOfPlayers, $gameid, 0, $em, $printver);
        $ret .= '</div>';
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '</table>';
        $retarry["detail"] = $ret;
        return $retarry;
    }        
//------------------------
//
//
//
//------------------------
    public function buildOPGameInfoBoot($gameid, $accessrating=0, $verified=0, $em='', $printver=FALSE){
            $ci=&get_instance();
            $lvlr = '';            
            $this->event_init($gameid);            
            $ret = '';
            $ci->session->set(array('viewmode' => 'OP'));
            $dayid = substr($this->slot_day,0,3);
            $subid = $this->slot_enum . $dayid . $this->slot_enum . $this->row_enum . $this->id;
            $regbuttons = 'ogrex/gameRegDialog/' . $gameid;           
            $ret .= '<div class="card border-info h-100">';
            $ret .= '<p class="card-header font-weight-bold">'; 
            $ret .= substr($this->slot_day,0,3) . ' ' . str_replace(":00", "",$this->slot_time) ;
            $ret .= '</p>';            
            $ret .= '<div class="card-body">';
            $ret .= '<h6 class="card-title" id="op_gametitle' . $this->id . '" >';
            
            $ginfo = site_url('ogrex/getGameInformation','https');
            $ret .= '<a href="#ID' . $subid . '"  onclick="return openGIDialog('.$ci->event->id .",'".$ginfo."',"."'".site_url('ogrex/gameEditInx','https') ."','','','','','OP','P','".site_url($regbuttons,'https')."'".')" name="opgameid' . $subid . '" id="opgameid' . $subid . '">';
            $ret .= '<span id="'.$this->id.'">'.$this->game_title.'</span>';
            if ((trim($this->rpga_exp_level) != '-') && (trim($this->rpga_exp_level) != '')){
                $lvlr = ' (' . $this->rpga_exp_level . ')';
                if (!strpos($this->game_title, $lvlr)){
                    $ret .= $lvlr;
                }
            }
            $ret .= '</a></h6>';

            $ret .= '<p class="card-text">';  
            $ret .= $this->rpga_number_of_tables . ' Tables, '.''.$this->getPreregNum($this->id,'1').' GM(s), '. $this->getPreregNum($this->id,'0') . ' Player(s)';
            $ret .= '</p>';
            $retarry['basic'] = $ret;
         

            $ret .= $this->buildPlayerJudgeBoxBoot($gameid, $em, $printver);
            $ret .= '</div>';
            
            $ret .= '<div class="card-footer">'; 
            $ret .= '<div class="op_signupbutton">';
            if (intval($this->rpga_game_round) > 1){
               $ret .= '-';
            }
            else{                   
               $ret .= str_replace('class="playgmbutton"', 'class="btn btn-primary btn-block" role="button"',str_replace('class="regbutton"', 'class="btn btn-primary" role="button"',$ci->schedule_lib->getPreregLinkReg($this->prereg_players_allowed, $this->id, $this->mmrpgFlag, $accessrating, $verified, 0, 'PL')));
               
            }
            $ret .= '</div>';
            $ret .= '<div class="op_signupbutton">';
            $ret .= (intval($this->rpga_game_round) > 1) ?  '-' : str_replace('class="playgmbutton"', 'class="btn btn-primary btn-block" role="button"',str_replace('class="regbutton"', 'class="btn btn-primary" role="button"', $ci->schedule_lib->getPreregLinkReg($this->prereg_players_allowed, $this->id, $this->mmrpgFlag, $accessrating, $verified, 1, 'GM')));
            $ret .= '</div>';
            $ret .= '</div>';
            $ret .= '</div>';
            $retarry["detail"] = $ret;
            return $retarry;
        }        
//------------------------
//
//------------------------
        private function buildPlayerJudgeBoxBoot($gameid, $em, $printver){
            $ret = '<p class="card-text">Judge:</p>';
            $ret .= '<div id="gmlist'.$gameid.'" class="gmplayerlist" >';
            $gm_list = $this->getPlayerList(1);
            $ret .= $this->preregModifyLink($gm_list, $gameid, 1, $em, $printver);
            $ret .= '</div>';
            $ret .= '<p class="card-text">Players:</p>';
            $ret .= '<div id="playlist'.$gameid.'" class="gmplayerlist" >';
            $players = $this->getPlayerList(0);
            $ret .= $this->preregModifyLink($players, $gameid, 0, $em, $printver);
            $ret .= '</div>'; 
            return $ret;
        }
        
        
//------------------------
//
//
//
//------------------------
        public function buildOPGameInfoOLD($gameid, $accessrating=0, $verified=0, $em='', $printver=FALSE, $ajax=FALSE, $schedview='schedule-view'){
            $ci=&get_instance();
            $lvlr = '';            
            $this->event_init($gameid);            
            $ret = '';
            $opgrid=TRUE;
            $dayid = substr($this->slot_day,0,3);
            $subid = $this->slot_enum . $dayid . $this->slot_enum . $this->row_enum . $this->id;
            $rowid = $this->slot_day.$this->row_enum;
            $mode=($ajax==TRUE?'allx':'all');
            $ret .= '<div id="op_gametitle' . $this->id . '" style="">';
            $ret .= '<a href="#ID' . $subid . '"  onclick="return overlay(this, ' . "'" . 'subcontent' . $subid . "'" . ', ' . "'" . 'rightbottom' . "'" . ')" name="ID' . $subid . '" id="ID' . $subid . '">';
            $ret .= $this->game_title;
            if ((trim($this->rpga_exp_level) != '-') && (trim($this->rpga_exp_level) != '')){
                $lvlr = ' (' . $this->rpga_exp_level . ')';
                if (!strpos($this->game_title, $lvlr)){
                    $ret .= $lvlr;
                }
            }
            $ret .= '</a></div>';
                    $ret .= '<div id="subcontent' . $subid . '"';
                    $ret .= ' style="position:absolute; display: none; border: 4px solid black; background-color: #CCCCCC;';
                    $ret .= ' width: 400px; padding: 4px; color:#000000">';
                    $ret .= '<div  style="text-align: right">';
                    $ret .= '<a href="#' . $this->id . '" onclick="overlayclose(' . "'" . 'subcontent' . $subid . "'" . '); return false" style="color:#0000FF"">Close</a></div>';
                    $ret .= '<strong><i>' . $this->game_title . '</i>' . $lvlr  . '<br />';
                    $ret .= $this->game_name;
                    $ret .= '</strong><br />';
                    $ret .= '<br />';
                    $ret .= 'Day/Time: <strong>' . $this->slot_day . ' ' . $this->getSlotTime() . '</strong><br />';
                    $ret .= ' <br />';
                    if (trim($this->game_notes) != ""){
                        if ($this->game_type == "RPG"){
                            $ret .= '<p><strong>Event Information</strong>: ' . nl2br(ascii_to_entities($this->game_notes)) . '</p>';
                        }else{
                            $ret .= '<p><strong>Information</strong>: ' . nl2br(ascii_to_entities($this->game_notes)) . '</p>';
                        }                       
                    }
                    $ret .= '<br />';
                    if (trim($this->game_desc) != ""){
                        $ret .= '<p><strong>' . $this->game_name . '</strong>: ' . nl2br(strip_tags(ascii_to_entities($this->game_desc))) . '</p><br />';
                    }

                    if ((trim($this->rpga_rss_scenario_desc) != '') && (trim($this->game_notes) =='')) 
                    {
                        if ($this->game_type == "RPG"){
                            $ret .= '<strong>Scenario/Adventure Desc.</strong>: ' . nl2br(trim(ascii_to_entities($this->rpga_rss_scenario_desc))) . '</p>';                      
                        }else{
                            $ret .= '<strong>Additional Information</strong>: ' . nl2br(trim(ascii_to_entities($this->rpga_rss_scenario_desc))) . '</p>';
                        }
                    }
                    $ret .= '</div>';
                    /* END DROP DOWN  */
            $ret .= '<table class="op_gameinfocell">';
            $ret .= '<tr>';
            $ret .= '<td class="op_tableplayercount">';
            $ret .= $this->rpga_number_of_tables . ' Tables, <br/>' . $this->getPreregNum($this->id) . ' Players.';
            $ret .= '</td>';
            
            $retarry['basic'] = $ret;
            $retarry['basic'] .= '<td class="op_signup"></td></tr></table>';
           
            $ret .= '<td class="op_signup">';
            if (intval($this->rpga_game_round) > 1){
               $preregLink = '-';
            }
            else{ 
                  
               $preregLink = $ci->schedule_lib->getPreregLinkReg($this->prereg_players_allowed, $this->id, $this->mmrpgFlag, $accessrating, $verified);
            }
            $ret .= $preregLink;
            $ret .= '</td>';
            $ret .= '</tr>'; 
            $ret .= '<tr id="partlist'.$gameid.'" style="display:table-row;">';
            $ret .= '<td colspan="2">';
            $ret .= '<p><span class="op_gameinfocell_label">Judge:</span></p>';
            $ret .= '<div id="gmlist'.$gameid.'">';
            $gm_list = $this->getPlayerList(1);
            $ret .= $this->preregModifyLink($gm_list, $gameid, 1, $em, $printver, $ajax);
            $ret .= '</div>';
            $ret .= '<p><span class="op_gameinfocell_label">Players:</span></p>';
            $ret .= '<div id="playlist'.$gameid.'" >';
            $ListOfPlayers = $this->getPlayerList(0);
            $ret .= $this->preregModifyLink($ListOfPlayers, $gameid, 0, $em, $printver, $ajax);
            $ret .= '</div>';
            $ret .= '</td>';
            $ret .= '</tr>';
            $ret .= '</table>';        
            $retarry["detail"] = $ret;
            
            return $retarry;
        }
//------------------------
//
//
//
//------------------------
    public function preregModifyLink($list, $gid, $gm, $em='', $printver=FALSE){
        $ci = &get_instance();
        $conid  = $ci->session->ogre_conid;
        $userid = $ci->session->ogre_user_ID;
        if ($gid != 0){
            $this->event_init($gid);
        }
        if (intval($userid) > 0){
            $lclpreregmodify = 'ogrex/preregForm/';
        }
        $ret = '';
        $i = 1;
        $ovflw_gm = intval($this->rpga_number_of_tables);
        $ovflw_ply = intval($this->rpga_number_of_tables) * intval($this->rpga_max_players_per_table) ;
        $ret .= '<table class="gmplayertable">';
        foreach ($list as $plyr){
            $ret .= '<tr>';
            $ret .= '<td class="gmplayertable_num">';

            if ($gm == 1){
                $ovrflw_mark = ($i > intval($ovflw_gm)) ? '<span style="color:red">?</span>':  '';
            }
            else{
                $ovrflw_mark = ($i > intval($ovflw_ply)) ? '<span style="color:red">?</span>' : '';
            }

            if ($gm == 1){
                $notes = '';
            }
            else{
                $notes = (trim($plyr[2]) != '')? " <span><em>" . $plyr[2] . '</em></span> ':"";
            }
            $logged_in = $ci->session->ogre_logged_in;
            $act = $ci->session->get('ogre_user_activated_' . $conid);
            $pname = explode(' ', $plyr[1]);
            if($logged_in == FALSE){                
                if(count($pname) > 1){
                    $plyr[1] = $pname[0] . ' ' . substr($pname[1], 0, 1) . '.';
                }      
            }
            else{            
                if($act == 0){                
                    if(count($pname) > 1){
                        $plyr[1] = $pname[0] . ' ' . substr($pname[1], 0, 1) . '.';
                    }      
                }
            }                
            if ($plyr[1] != "-"){
                if($em == $plyr[3] ){                      
                    $ret .= (trim($ovrflw_mark) == '') ? '(' . $i . ')' : '(' . $ovrflw_mark . ')';
                    $ret .= '</td>';
                    $ret .= '<td class="gmplayertable_name">';
                    $schedview = $this->generate_opgridid();
                    $rowid = $this->slot_day.$this->row_enum;
                    $ret .=  $ci->schedule_lib->preregisterEditx('ogrex/preRegFormX/TRUE', $gid, $plyr[1]);                           
                    if (trim($notes) != ""){
                        if($printver==FALSE){
                            $ret .= ' <a href="#" id="drilldown' . $gid.$i . '" onclick="return show_charinfo(' . $gid.$i . ')">[+]</a>';
                        }
                    }
                    if (trim($notes) != ""){
                        $ret .= '</td>';
                        $ret .= '</tr>';
                        $ret .= '<tr>';
                        $ret .= '<td>';
                        $ret .= '</td>';
                        $ret .= '<td>';                            
                        $ret .= '<div id="charinfo' . $gid.$i . '"';
                        if($printver==FALSE){
                            $ret .= ' style="display:none;"';
                        }
                        $ret .= '>';                                    
                        $ret .= '<ul style="list-style-type:none;"><li>' . $notes . '</li></ul>';
                        $ret .= '</div>';
                    }                        
                }
                else{
                    if(trim($ovrflw_mark) == ''){
                        $ret .= '(' . $i . ')';
                    }
                    else{
                        $ret .= '(' . $ovrflw_mark . ')';
                    }                        
                    $ret .= '</td><td>';
                    $ret .= $plyr[1]. ' ' . $ovrflw_mark;
                    if (trim($notes) != ""){
                        if($printver==FALSE){
                            $ret .= ' <a href="#" id="drilldown' . $gid.$i . '" onclick="return show_charinfo(' . $gid.$i . ')">[+]</a>';
                        }
                    }
                    if (trim($notes) != ""){
                        $ret .= '</td>';
                        $ret .= '</tr>';
                        $ret .= '<tr>';
                        $ret .= '<td>';
                        $ret .= '</td>';
                        $ret .= '<td>';
                        $ret .= '<div id="charinfo' . $gid.$i . '"';
                        if($printver==FALSE){
                            $ret .= ' style="display:none;"';
                        }
                        $ret .= '>';                                    
                        $ret .= '<ul style="list-style-type:none;"><li>' . $notes . '</li></ul>';
                        $ret .= '</div>';
                    }
                }

            }
            $i++;
            $ret .= '</td></tr>';
        }

        $ret .= '</table>';

        return $ret;
    }
        //------------------------
        //
        //
        //
        //------------------------
        public function findCellInfo($i, $j, $aff, $d, $late, $slotlen){
            $ci=&get_instance();
            
            $conid = $ci->session->ogre_conid;
            $qry_rpga = 'SELECT ogre_gameschedule.gs_id';
            $qry_rpga .= ' FROM ((ogre_preregistergamelist RIGHT JOIN ogre_gameschedule ';
            $qry_rpga .= ' ON ogre_preregistergamelist.pgl_gs_id = ogre_gameschedule.gs_id) ';
            $qry_rpga .= ' LEFT JOIN ogre_rpga_game_setup ';
            $qry_rpga .= ' ON ogre_gameschedule.gs_id = ogre_rpga_game_setup.rgs_gs_id) ';
            $qry_rpga .= ' LEFT JOIN ogre_rpga_scenario_setup ON ';
            $qry_rpga .= ' ogre_rpga_game_setup.rgs_scenario_id = ogre_rpga_scenario_setup.rss_scenario_id ';
            $qry_rpga .= ' WHERE ogre_rpga_game_setup.rgs_active = 1 ';
            $qry_rpga .= ' AND ogre_gameschedule.gs_cancelled = 0 ';
            $qry_rpga .= ' AND TRIM(ogre_gameschedule.gs_game_title) <> ""  ';
            $qry_rpga .= ' AND ogre_gameschedule.gs_mmrpgFlag = 1 ';
            $qry_rpga .= ' AND ogre_gameschedule.gs_late_night = ' . $late;
            $qry_rpga .= ' AND gs_convention_id = ' . $conid;
            $qry_rpga .= ' AND gs_affiliation = "' . $aff . '"';
            $qry_rpga .= ' AND gs_slot_enum = ' . $j;
            $qry_rpga .= ' AND gs_row_enum = ' . $i;
            $qry_rpga .= ' AND gs_slot_day = "' . $d . '" ';
            $qry_rpga .= ' AND gs_slot_length = ' . $slotlen . ';';
            $query = $ci->db->query($qry_rpga);
            if ($query->getNumRows() != 0){
                foreach ($query->getResult() as $row){
                    $ret = $row->gs_id;
                }
            }
            else{
                $ret = -9999;
            }

            return $ret;
        }
//------------------------------------------------
//
//
//
//------------------------------------------------
    public function gameEditForm($gameid=0, $type='GAME', $admin=FALSE){
        $ci=&get_instance();
        $conid = $ci->session->ogre_conid;
        $saveaction = site_url('ogrex/gamesIn','https');
        $editaction =  site_url('ogrex/gameEdit','https');
        $this->event_init($gameid);        
        $ret = '';
        switch ($type){
            case 'GAME':
                $buttonval = 'Game Event';
                $label[$type] = 'Game ';
                $dmode= "P";
                break;
            
            case 'VOL':
                $buttonval = 'Shift';
                $label[$type] = 'Volunteer Shift ';
                $dmode= "R";
                break;

            case 'PAN':
                $buttonval = 'Con Event';
                $label[$type] = 'Con Event or Panel ';
                $dmode= "N";
                break;
        }  
//  INSTRUCTIONS         
        if($admin===TRUE){
            $txt = $ci->ogre_lib->getMiscContent('%ADDGAMEINSTRUCTIONS%');
            $ret .= $txt['content'];    
        }
//  RESULTS 
        $ret .= '<div class="row">';
        $ret .= '<div class="col">';
        $ret .= '<div id="game_edit_results_outer" style="display:none">';

        $ret .= '<div id="game-edit-results" class="results"></div>';
        $ret .= '<input class="btn btn-secondary" type="button" name="back" id="back" value=" OK " onclick="toggleGameEdit(' .  "'"  . 'on'  . "'," . $gameid . ');" />';
        $ret .= '</div>'; 
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '<div id="game-edit-main">';       
        $ret .= '<h2 id="game-edit-title">'. $this->game_name .'</h2>';                            
        $ret .= '<form id="game-edit-form" name="game-edit-form"><div class="form-group">';     
        $ret .= '<div id="editgame_acc">';
        if($admin===FALSE){
            $ret .= '<h3>Instructions/Notes</h3>';
            $ret .= '<div>'; 
            $ttxt = $ci->ogre_lib->getMiscContent('%GAMEEDIT_INTRO%',$conid);
            $ret .= $ttxt['content']; 
            $ret .= '</div>';                   
        } 
//  BASIC INFO             
        $ret .= '<h3>Basic Info</h3>';
        $ret .= '<div>';             
        $ret .= '<div>';
        switch ($type){
            case 'GAME':
                $ret .= '<div class="row"><div class="col">';
                $ret .= '<input type="hidden" id="gamesystem" name="gamesystem" value="'. $this->game_name . '" />';
                $ret .= '<input type="hidden" id="gameid" name="gameid" value="'. $this->id .'"/>';
                $ret .= '<input type="hidden" id="gs_gn_id" name="gs_gn_id" value="'. $this->gameid .'"/>';
                $ret .= '<input type="hidden" id="gametype" name="gametype" value="' . $ci->game->getDescriptorID($this->game_type) . '" />';      
                $ret .= '</div></div>';
                $ret .= '<div class="row"><div class="col">' ; // class="gameedit_field"
                $ret .= ($admin===FALSE) ? '<label class="form-label" for="gameedit_name"><span id="gameedit_name_label">Game/System:</span></label>' : '<label class="form-label" for="gameedit_name">Game/System:</label>';
                $ret .= '<div class="form-group"><div class="input-group mb-3">';
                $ret .= '<input class="form-control" readonly type="text" id="gameedit_name" name="gameedit_name" value="'. (($gameid !=0 ) ? $this->game_name . ' (' . $this->game_type . ')' : '') .'" />';
                $ret .= ($admin===TRUE) ? '<input class="btn btn-secondary btn-sm" value="..." title="Change Game" type="button" id="changeGame" name="changeGame" onclick="changeEditMode('."'". site_url('ogrex/changeGame/' . $this->id .'/1','https')."'".','.$gameid.',6,'."'".site_url('ogrex/getGameDescription','https')."','". site_url('ogrex/getGamePlayers','https')."'".');" />' : '';             
                $ret .= '</div></div>';
                $ret .= ' <span id="gameedit_name_alert"></span>';
                $ret .= '</div></div>';
               
                break;
            case 'VOL':
                $ret .= '<h2>Volunteer Shift</h2>';               
                $ret .= '<div class="row"><div class="col">';
                $ret .= '<input type="hidden" id="gamesystem" name="gamesystem" value="'. $this->game_name . '" />';
                $ret .= '<input type="hidden" id="gameid" name="gameid" value="'. $this->id .'"/>';
                $ret .= '<input type="hidden" id="gs_gn_id" name="gs_gn_id" value="'. $this->gameid .'"/>';
                $ret .= '<input type="hidden" id="gametype" name="gametype" value="' . $ci->game->getDescriptorID($this->game_type) . '" />';
                $ret .= '</div></div>';
                $ret .= '<div class="row"><div class="col">';
                $ret .= ($admin===FALSE) ? '<label for="gameedit_name"><span id="gameedit_name_label">Vol. Shift Type:</span></label> ' : '<label for="gameedit_name">Shift Type:</label> ';
                $ret .= '<div class="form-group"><div class="input-group mb-3">';
                $ret .= '<input disabled="disabled" class="form-control" type="text" id="gameedit_name" name="gameedit_name" value="'. (($gameid!=0) ? $this->game_name . ' (' . $this->game_type . ')' : "") .'" /> ';
                $ret .= ($admin===TRUE) ? '<input class="btn btn-secondary btn-sm" value="..." title="Change Vol" type="button" id="changeGame" name="changeGame" onclick="changeEditMode('."'". site_url('ogrex/changeGame/' . $this->id.'/0','https')."'".','.$gameid.',8,'."'".site_url('ogrex/getGameDescription','https')."','". site_url('ogrex/getGamePlayers','https')."'".');" />' : '';             
                $ret .= '</div></div>';
                $ret .= ' <span id="gameedit_name_alert"></span>';
                $ret .= '</div></div>';                
                break;
            case 'PAN':
                $ret .= '<h2>Panel/Con Event</h2>';
                $ret .= '<div class="row"><div class="col">';
                $ret .= ($admin===FALSE) ? '<label for="gameedit_name"><span id="gameedit_name_label">Con Event Type:</span></label> ' : '<label for="gameedit_name">Con Event Type:</label> ';
                $ret .= '<input type="hidden" id="gamesystem" name="gamesystem" value="'. $this->game_name . '" />';
                $ret .= '<input type="hidden" id="gameid" name="gameid" value="'. $this->id .'"/>';
                $ret .= '<input type="hidden" id="gs_gn_id" name="gs_gn_id" value="'. $this->gameid .'"/>';
                $ret .= '<input type="hidden" id="gametype" name="gametype" value="' . $ci->game->getDescriptorID($this->game_type) . '" />';
                $ret .= '</div></div>';
                $ret .= '<div class="row"><div class="col">';
                $ret .= '<div class="form-group"><div class="input-group mb-3">';
                $ret .= '<input disabled="disabled" class="form-control" type="text" id="gameedit_name" name="gameedit_name" value="'. (($gameid!=0) ? $this->game_name . ' (' . $this->game_type . ')' : "") .'" /> ';
                $ret .= ($admin===TRUE) ? 
                        '<input class="btn btn-secondary btn-sm" value="..." title="Change Panel"  type="button" id="changeGame" name="changeGame" onclick="changeEditMode('."'". site_url('ogrex/changeGame/' . $this->id.'/2','https')."'".','.$gameid.',9,'."'".site_url('ogrex/getGameDescription','https')."','". site_url('ogrex/getGamePlayers','https')."'".');" />' 
                        : '';             
                $ret .= '</div></div>';
                $ret .= ' <span id="gameedit_name_alert"></span>';
                $ret .= '</div></div>';                
                break;
        }
        $ret .= '<div class="row"><div class="col">'; 
        $ret .= '<label for="gametitle">Scenario Title:</label>';
        $ret .= '<input placeholder="(if applicable)" class="form-control my-2" type="text" id="gametitle" name="gametitle" value="' . $this->game_title . '" maxlength="150" />';
        $ret .= '</div></div>';     
        $ret .= '<div class="row"><div class="col">';
        
        $ret .= '<input type="hidden" id="slot_length" name="slot_length" value="' . $this->slot_length . '"/>';
        $ret .= '<input type="hidden" id="slot_day" name="slot_day" value="'.  $this->slot_day . '"/>';
        $ret .= '<input type="hidden" id="slot_date" name="slot_date" value="'.  $this->slot_date . '"/>';
        $ret .= '<input type="hidden" id="slot_starttime" name="slot_starttime" value="'.  $this->slot_start_time . '"/>';
        $ret .= '<input type="hidden" id="slot_code" name="slot_code" value="'.  $this->slot_code . '">';          
        $ret .= '<input type="hidden" id="slot_latenight" name="slot_latenight" value="'.  $this->late_night . '"/>';  
        $ret .= '<input type="hidden" id="baseslot" name="baseslot" value="'.  $this->baseslot . '"/>'; 
        $ret .= '<input type="hidden" id="slotnumber" name="slotnumber" value=""/>';
        $ret .= '<input type="hidden" id="slottime" name="slottime" value="" />';
        $ret .= ($admin===FALSE) ? '<label for="gameedit_gametime" id="gameedit_time_label">Slot Time:</label>' : '<label for="gameedit_time_val">Slot Time:</label>'; 
        $ret .= '<div class="form-group"><div class="input-group">';
        $ret .= '<input disabled="disabled" class="form-control my-2" type="text" id="gameedit_gametime" name="gameedit_gametime" value="'. (($gameid!=0) ? $this->slot_day .' '.$this->getSlotTime() :"") .'" />';
        $ret .= ($admin===TRUE) ? '<input class="btn btn-secondary btn-sm my-2" value="..." title="Change Game Slot" type="button" id="changeTime" name="changeTime" onclick="changeEditMode('."'". site_url('ogrex/changeslot/'.$gameid,'https')."'".','.$gameid.',5,'."''".');" />' : '';            
        $ret .= '</div></div>';
        $ret .= ' <span id="gameedit_time_alert"></span>';
        $ret .= '</div></div>';
        $ret .= '<div class="row"><div class="col">';
        $ret .= ($admin===FALSE) ? '<label id="gameedit_loc_label">Location:</label>' : '<label>Location:</label>';
        $ret .= '<div class="form-group"><div class="input-group mb-3">';
        $ret .= '<input disabled="disabled" class="form-control" type="text" id="gameedit_loc" name="gameedit_loc" value="'. $this->location_name . ' ' . (trim($this->table_number) != "" ? ': '.$this->table_number : "") .'" />';
        $ret .= ($admin===TRUE) ? '<input class="btn btn-secondary btn-sm" value="..." title="Change Location" type="button" id="changeLoc" name="changeLoc" onclick="changeEditMode('."'". site_url('ogrex/changeLocation/'.$gameid,'https')."'".','.$gameid.',7,'."''".');" />' : ''; //               
        $ret .= '</div></div>';
        $ret .= ' <span id="gameedit_loc_alert"></span>';
        $ret .= '<input type="hidden" id="location_name" name="location_name" value="'.  $this->location_name . '">';
        $ret .= '<input type="hidden" id="table_number" name="table_number" value="'.  $this->table_number . '">';
        $ret .= '<input type="hidden" id="table_placeholder_virtual" name="table_placeholder_virtual" value="'.  $this->table_placeholder_virtual . '">';          
        $ret .= '<input type="hidden" id="tbl_id" name="tbl_id" value="'.  $this->table_id . '">';
        $ret .= '<input type="hidden" id="locationid" name="locationid" value="0">';
        $ret .= '</div></div>';          
        $ret .= '<div class="row"><div class="col">';
        $ret .= '<label for="eventtype">Event Type:</label>';
        $ret .= '<select class="form-control my-2" size="1" id="eventtype" name="eventtype">';
        $ret .=  $ci->proposal->eventTypeSelect($this->event_type, $dmode);
        $ret .= '</select>';            
        $ret .= '</div></div>';      
        $disable = ' disabled ';       
        switch($type){
            case 'GAME':
                $ret .= '<div class="row"><div class="col">';
                $ret .= '<label for="minnumofplayers"># of Players:</label>';
                $ret .= '<div class="form-group"><div class="input-group my-1">';
                $ret .= '<input  class="form-control my-2" type="number" id="minnumofplayers" placeholder="0" name="minnumofplayers" value="'. $this->min_num_of_players . '" />';
                $ret .= '<label class="label" for="maxnumofplayers"> to </label>';
                $ret .= '<input class="form-control my-2" type="number" placeholder="0" id="maxnumofplayers" name="maxnumofplayers" value="'. $this->max_number_of_players . '" />';            
                $ret .= '</div></div>';            
                $ret .= '</div></div>';
                $ret .= '<div class="row"><div class="col">';
                $ret .= '<label class="label" for="fee">Fee to play (if applicable, in dollars)?: </label> ';
                $ret .= '<input '. (($type !== 'GAME') ? $disable : '') .' type="number" class="form-control my-2" id="fee" name="fee" value="'. $this->game_fee.'" />';
                $ret .= '</div></div>'; 
                $ret .= '<div class="row"><div class="col">';
                $ret .= '<label class="label" for="opentoprereg">Preregistration Stastus?:</label>';
                $ret .= '<select '. (($type !== 'GAME') ? $disable : '') .' class="form-control my-2" size="1" name="open2prereg" id="open2prereg" onchange="">';

                if ($gameid==0) {
                    $ret .= '<option value="1" selected="selected"> Open To Preregistration </option>';
                    $ret .= '<option value="0">  Closed To Preregistration </option>';
                }else{
                    if($this->prereg_id > 0){
                        $ret .= '<option value="1"  selected="selected"> Open To Preregistration </option>';
                        $ret .= '<option value="0">  Closed To Preregistration </option>';  
                    }
                    else{
                      $ret .= '<option value="1" > Open To Preregistration </option>';
                       $ret .= '<option value="0" selected="selected" >  Closed To Preregistration </option>';                     
                    }
                }
                $ret .= '</select>';  
                $ret .= '</div></div>';

                $ret .= '<div class="row"><div class="col">';
                if ($admin===TRUE){
                    $ret .= '<label class="label" for="allowalt">';
                    $tagaction = site_url("ogrex/closedMsg/110",'https');
                    $taginfo = $ci->ogre_lib->getMiscContent(110);
                    $ret .= '<a href="#" onclick="return getTagInfo('."'".$tagaction."',"."'".$taginfo['title']."'".')" >';
                    $ret .= 'Allow for Alternates? (if open to preregistration):';
                    $ret .= '</a>';
                    $ret .= '</label>';
                }else{
                    $ret .= '<label class="label" for="allowalt">';
                    $ret .= 'Allow for Alternates? (if open to preregistration):';
                    $ret .= '</label>';                
                }
                $ret .= '<select class="form-control my-1"  size="1" name="allowalts" id="allowalts" onchange="">';
                if ($gameid==0) {
                    $ret .= '<option value="1"  selected="selected"> Yes. Open to Alternates</option>';
                    $ret .= '<option value="0"> No. Close once game is Full </option>';
                }else{
                    if($this->prereg_opentoalt > 0){
                        $ret .= '<option value="1" selected="selected">Yes. Open to Alternates</option>';
                        $ret .= '<option value="0"> No. Close once game is Full </option>';  
                    }
                    else{
                      $ret .= '<option value="1" > Yes. Open to Alternates</option>';
                      $ret .= '<option value="0" selected="selected" >No. Close once game is Full </option>';                     
                    }
                }            
            break;
            case 'PAN':
                $ret .= '<div class="row"><div class="col">';
                $ret .= '<div class="form-group"><div class="input-group mb-3 my-3">';
                $ret .= '<label for="minnumofplayers"># of Participants: (Leave 0s if unlimited)</label>';
                $ret .= '<input class="form-control my-2" type="number" id="minnumofplayers" placeholder="0" name="minnumofplayers" value="'. $this->min_num_of_players . '" />';
                $ret .= '<label for="maxnumofplayers"> to </label>';
                $ret .= '<input class="form-control my-2" type="number" placeholder="0" id="maxnumofplayers" name="maxnumofplayers" value="'. $this->max_number_of_players . '" />';            
                $ret .= '</div></div>';            
                $ret .= '</div></div>'; 
                $ret .= '<div class="row"><div class="col">';
                $ret .= '<label for="fee">Fee to participate (if applicable, in dollars)?: </label> ';
                $ret .= '<input type="number" class="form-control my-2" id="fee" name="fee" value="'. $this->game_fee.'" />';
                $ret .= '</div></div>'; 
                $ret .= '<div class="row"><div class="col">';
                $ret .= '<label for="opentoprereg">Preregistration (Open or Closed)?:</label>';
                $ret .= '<select class="form-control my-2" size="1" name="open2prereg" id="open2prereg" onchange="">';

                if ($gameid==0) {
                    $ret .= '<option value="1"  selected="selected"> Open To Preregistration </option>';
                    $ret .= '<option value="0">  Closed To Preregistration </option>';
                }else{
                    if($this->prereg_id > 0){
                        $ret .= '<option value="1"  selected="selected"> Open To Preregistration </option>';
                        $ret .= '<option value="0">  Closed To Preregistration </option>';  
                    }
                    else{
                      $ret .= '<option value="1" > Open To Preregistration </option>';
                       $ret .= '<option value="0" selected="selected" >  Closed To Preregistration </option>';                     
                    }
                }
                $ret .= '</select>';  
                $ret .= '</div></div>';             
                $ret .= '<div class="row"><div class="col">';
                if ($admin===TRUE){
                    $ret .= '<label for="allowalt">';
                    $tagaction = site_url("ogrex/closedMsg/110",'https');
                    $taginfo = $ci->ogre_lib->getMiscContent(110);
                    $ret .= '<a href="#" onclick="return getTagInfo('."'".$tagaction."',"."'".$taginfo['title']."'".')" >';
                    $ret .= 'Allow for Alternates? (if open to preregistration):';
                    $ret .= '</a>';
                    $ret .= '</label>';
                }else{
                    $ret .= '<label for="allowalt">';
                    $ret .= 'Allow for Alternates? (if open to preregistration):';
                    $ret .= '</label>';                
                }
                $ret .= '<select class="form-control my-2" size="1" name="allowalts" id="allowalts" onchange="">';
                if ($gameid==0) {
                    $ret .= '<option value="1"  selected="selected"> Yes. Open to Alternates</option>';
                    $ret .= '<option value="0"> No. Close once game is Full </option>';
                }else{
                    if($this->prereg_opentoalt > 0){
                        $ret .= '<option value="1" selected="selected">Yes. Open to Alternates</option>';
                        $ret .= '<option value="0"> No. Close once game is Full </option>';  
                    }
                    else{
                      $ret .= '<option value="1" > Yes. Open to Alternates</option>';
                      $ret .= '<option value="0" selected="selected" >No. Close once game is Full </option>';                     
                    }
                }
            
            break;
            case 'VOL':
            $ret .= '<div class="invisible">' ;    
            $ret .= '<div class="row"><div class="col">';
            $ret .= '<div class="form-group"><div class="input-group mb-3 my-3">';
            $ret .= '<label for="minnumofplayers"># of Players:</label>';
            $ret .= '<input class="form-control my-2" type="number" id="minnumofplayers" placeholder="0" name="minnumofplayers" value="'. $this->min_num_of_players . '" />';
            $ret .= '<label for="maxnumofplayers"> to </label>';
            $ret .= '<input class="form-control my-2" type="number" placeholder="0" id="maxnumofplayers" name="maxnumofplayers" value="'. $this->max_number_of_players . '" />';            
            $ret .= '</div></div>';            
            $ret .= '</div></div>';    
            $ret .= '<div class="row"><div class="col">';
            $ret .= '<label for="fee">Fee to play (if applicable, in dollars)?: </label> ';
            $ret .= '<input type="number" class="form-control my-2" id="fee" name="fee" value="'. $this->game_fee.'" />';
            $ret .= '</div></div>';            
            $ret .= '<div class="row"><div class="col">';
            $ret .= '<label for="opentoprereg">Preregistration (Open or Closed)?:</label>';
            $ret .= '<select  class="form-control my-2" size="1" name="open2prereg" id="open2prereg" onchange="">';

            if ($gameid==0) {
                $ret .= '<option value="1"  selected="selected"> Open To Preregistration </option>';
                $ret .= '<option value="0">  Closed To Preregistration </option>';
            }else{
                if($this->prereg_id > 0){
                    $ret .= '<option value="1"  selected="selected"> Open To Preregistration </option>';
                    $ret .= '<option value="0">  Closed To Preregistration </option>';  
                }
                else{
                  $ret .= '<option value="1" > Open To Preregistration </option>';
                   $ret .= '<option value="0" selected="selected" >  Closed To Preregistration </option>';                     
                }
            }
            $ret .= '</select>';  
            $ret .= '</div></div>'; 
            $ret .= '<div class="row"><div class="col">';
            if ($admin===TRUE){
                $ret .= '<label for="allowalt">';
                $tagaction = site_url("ogrex/closedMsg/110",'https');
                $taginfo = $ci->ogre_lib->getMiscContent(110);
                $ret .= '<a href="#" onclick="return getTagInfo('."'".$tagaction."',"."'".$taginfo['title']."'".')" >';
                $ret .= 'Allow for Alternates?:';
                $ret .= '</a>';
                $ret .= '</label>';
            }else{
                $ret .= '<label for="allowalt">';
                $ret .= 'Allow for Alternates?:';
                $ret .= '</label>';                
            }
            $ret .= '<select class="form-control my-2"  size="1" name="allowalts" id="allowalts" onchange="">';
            if ($gameid==0) {
                $ret .= '<option value="1"  selected="selected"> Yes. Open to Alternates during Preregistration </option>';
                $ret .= '<option value="0"> No. Close once game is Full </option>';
            }else{
                if($this->prereg_opentoalt > 0){
                    $ret .= '<option value="1" selected="selected">Yes. Open to Alternates during Preregistratio </option>';
                    $ret .= '<option value="0"> No. Close once game is Full </option>';  
                }
                else{
                  $ret .= '<option value="1" > Yes. Open to Alternates during Preregistratio </option>';
                  $ret .= '<option value="0" selected="selected" >No. Close once game is Full </option>';                     
                }
            }            
            break;
        
        }   

        $ret .= '</select>';  
        $ret .= '</div></div>';              
        $ret .= (($type == 'VOL') ? '</div>' : '') ;
        $ret .= '</div>';
        $ret .= '</div>';  

// GAME DESCRIPTION            
        $ret .= '<h3>Descriptions</h3>';
        $ret .= '<div>';  
        $ret .= (($type !== 'GAME') ? '' : '<p>Description of the speific game (board/carde/minis) or game system/setting (RPGs/LARPs).  This is usually drawn from our games on file, but can be modified for your needs.</p>');
        $ret .= '<div id="gameedit_description">';
        $ret .= '<label for="gamedesc"><strong>'.(($type == 'GAME') ? 'Game/System Description' : $label[$type]. ' Decription') . '</strong></label>';
        $ret .=  '<textarea id="gamedesc" name="gamedesc">';
        $ret .=  $this->game_desc;
        $ret .=  '</textarea>';
        $ret .= '</div>';
        $ret .= (($type !== 'GAME') ? '<div class="invisible">' : '') ;
        $ret .= '<div id="gameedit_descriptions">';
        $ret .= '<label for="gamenotes"><strong>Event/Adventure Description</strong></label>';
        $ret .= '<div id="gamenotes_edit"></div>';
        $ret .= '<textarea id="gamenotes" name="gamenotes" class="gamenotes" style="display: none;">';   
        $ret .= $this->game_notes;
        $ret .= '</textarea>';
        $ret .= '</div>';        
        $ret .= '</div>'; 
        $ret .= (($type !== 'GAME') ? '</div>' : '') ;
// RATINGS
        $ret .= '<h3>Ratings/Maturity</h3>';
        $ret .= '<div>';  
        $btxt = $ci->ogre_lib->getMiscContent('%GAMEEDITTEXTBOTTOM%');
        $ret .= '<div class="row mb-3"><div class="col">';
        $ret .= '<label for="matrate" >Maturity:</label>';
        $ret .= '<input ';
        $ret .= '  data-placement="top" title="'.$btxt['content'].'" ';
        $ret .= ' class="form-control my-2" type="text" id="matrate" name="matrate" value="'. (($gameid == 0) ? "PG" : $this->maturity_rate).'" />';
        $ret .= '<input type="hidden" id="othernotes" name="othernotes" value="" />';
        $ret .= '</div></div>';
        $ret .= '<div class="row mb-3"><div class="col">';
        $ret .= '</div></div>';        
        
        $ret .= (($type !== 'GAME') ? '<div class="invisible">' : '') ;
        $ret .= '<div id="gameedit_gameinfo2">';      
        $ret .= '<div class="row mb-3"><div class="col">';
        $ret .= '<label for="rprating">Roleplaying</label>';
        $ret .= '<select title="Primarily RPGs only" class="form-control my-2" size="1" id="rprating" name="rprating">';
        $ret .= $this->rating_select($this->roleplaying_rate);
        $ret .= '</select>';
        $ret .= '</div></div>';
        
        $ret .= '<div class="row mb-3"><div class="col">';
        $ret .= '<label for="psrating">Puzzle Solving </label>';
        $ret .= '<select class="form-control my-2" size="1" id="psrating" name="psrating">';
        $ret .= $this->rating_select($this->puzzlesolving_rate);
        $ret .= '</select>';
        $ret .= '</div></div>';
        
        $ret .= '<div class="row mb-3"><div class="col">';
        $ret .= '<label for="actrating">Action </label>';
        $ret .= '<select class="form-control my-2" size="1" id="actrating" name="actrating">';
        $ret .= $this->rating_select($this->action_rate);
        $ret .= '</select>';
        $ret .= '</div></div>';
        
        $ret .= '<div class="row mb-3"><div class="col">';
        $ret .= '<label for="cmplxrating">Complexity</label>';
        $ret .= '<select class="form-control my-2"  size="1" id="cmplxrating" name="cmplxrating">';
        $ret .= $this->rating_select($this->complexity_rate);
        $ret .= '</select>';
        $ret .= '</div></div>';

        $ret .= (($type !== 'GAME') ? '</div>' : '') ;
        $ret .= '</div>';  
            
        if($admin === TRUE){ 
            $ret .= '</div>';                
//  ADVANCED OPTIONS             
            $ret .= '<h3>Advanced Properties</h3>';
            $ret .= '<div>';
            $ret .= '<div id="gameedit_advanced">';
            $ret .= '<div class="row">';
            $ret .= '<div class="col">';            
            $btxt = $ci->ogre_lib->getMiscContent('%ADVANCED_PROPERTIES%');
            $ret .= $btxt['content'];  
            $ret .= '</div>';
            $ret .= '</div>';            
            $ret .= '<div class="row">';
            $ret .= '<div class="col">';
            $ret .= '<label for="displaymode">Display Mode</label>';
            $dmode = (trim($this->displaymode) == '' ? $dmode : $this->displaymode);
            $ret .= $this->displaymode_select($dmode);               
            $ret .= '</div>';
            $ret .= '</div>';

            $ret .= '<div class="row">';
            $ret .= '<div class="col">';
            $ret .= '<label for="affiliation">Primary Filter Tag</label>';
            $ret .= '<input class="form-control my-3" type="text" id="affiliation" name="affiliation" value="'.$this->affiliation.'" />';
            $ret .= '</div>';
            $ret .= '</div>';
            
            $ret .= '<div class="row">';
            $ret .= '<div class="col">';
            $ret .= '<label for="editable">Edittable by GM</label>';
            $ret .= '<select class="form-control my-3" size="1" id="editable" name="editable">'; 
            if ($this->id != 0){
                $ret .= (intval($this->editable)== 1) ? '<option value="1" selected="selected">Yes</option>' . '<option value="0">No </option>' : '<option value="1">Yes</option>' . '<option value="0" selected="selected">No </option>';
            }
            else
            {
                $ret .= '<option value="1" selected="selected">Yes</option>' . '<option value="0">No </option>';                     
            }
            $ret .= '</select>'; 

            $ret .= '</div>';
            $ret .= '</div>';    
            
            $ret .= '<div class="row">';
            $ret .= '<div class="col">';
            $ret .= '<label for="lock-gm-sign-up">Lock GM Sign Up</label>';
            $ret .= '<select class="form-control my-3" size="1" id="lock-gm-sign-up" name="lock-gm-sign-up">'; 
            if ($this->id != 0){
                $ret .= ($this->lockgmsignup=='1') ? '<option value="1" selected="selected">Yes</option>' . '<option value="0">No </option>' : '<option value="1">Yes</option>' . '<option value="0" selected="selected">No </option>';               

            } else {
                $ret .= '<option value="1" selected="selected">Yes</option>' . '<option value="0">No </option>';                    
            }
            $ret .= '</select>';                       
            $ret .= '</div>';
            $ret .= '</div>';  
            $ret .= '</div>';   
            $ret .= '</div>';
            $ret .= '</form>';
//  GM and Players                
            $ret .= '<h3>GMs &amp; Players</h3>';
            $ret .= ($gameid!=='0') ? $this->buildRegPageX($gameid, TRUE)  : '<p>Game Event Must Exist on the schedule to add GMs or Players.</p>';
// Players Choice                
            if((intval($gameid) !== 0) && (intval($this->group_flag) == 1)){
                $ret .= '<h3>Game Library/Demo List/Player&#39;s Choice</h3>';
                $ret .= '<div>';
                $ret .= '<div><p><input type="button"  class="btn btn-secondary" value="Add New PC Game" onClick="addPCGame('. "'" . site_url('ogrex/addPCgame','https') . "'," . $gameid . ',' . "'".site_url('ogrex/gameGroupIn','https')."'" . ',' . "'" . site_url('ogrex/gameGroup_refresh','https') . "'" .');" /></p></div>';                          
                $ret .= $this->getPlayersChoiceForm($gameid);
                $ret .= '</div>';    
            }       
                
        }       
        else{
            $ret .= '<input type="hidden" id="affiliation" name="affiliation" value="'.$this->affiliation.'" />';
            $ret .= '<input type="hidden" id="displaymode" name="displaymode" value="'.$this->displaymode.'" />';
            $ret .= '<input type="hidden" id="editable" name="editable" value="'.$this->editable.'" />';
            $ret .= '<input type="hidden" id="gmlock" name="gmlock" value="'.$this->lockgmsignup.'" />';
            $ret .= '</div>';
        }
        $ret .= '</div>'; // end accordian
        $ret .= '</div>';        
        
//  BUTTONS        
        if($admin===TRUE){
            $ret .= '<div class="row">';
            $ret .= '<div class="col text-center">';
            $ret .= '<div id="edit-admin-games-list-save" style="display:none">';
            $ret .=  ($gameid!=0) 
                    ? '<div class="d-grid gap-2"><button type="button" class="btn btn-success my-1" id="save-game" name="save-game" onclick="updateAdminGameEdit('."'" . $saveaction.'/update'."',''" .');" />* Save Changes *</button></div>' 
                    : '<div class="d-grid gap-2"><button type="button" class="btn btn-success my-1" id="save-game" name="save-game" onclick="addAdminGameNew('."'" . $saveaction.'/add'. "','" . $editaction."'" .');" >+ Schedule +</button></div>';
            $div = 'edit-admin-games-list-main';
            $ret .= '</div>';
            $ret .= '</div>';    
            $ret .= '</div>';
            $ret .= '<div class="row">';
            $ret .= '<div class="col text-center">';        
            $ret .= '<div class="d-grid gap-2"><button type="button" class="btn btn-danger my-1" id="cancel-game" name="cancel-game" onclick="cancelGame('."'". site_url('ogrex/game_cancel' . '/' . $this->id . '/1','https')."'".', '.$this->id.",'".$div."'".'); closeAdminGameEdit();" >Cancel '.$buttonval.'</div>';
            $ret .= '</div>';     
            $ret .= '</div>';
            $ret .= '<div class="row">';   
            $ret .= '<div class="col text-center">';
            $ret .= '<div class="d-grid gap-2"><button type="button" class="btn btn-secondary my-1" id="close-edit-game" name="close-edit-game" onclick="closeAdminGameEdit();" >Close Edit</button></div>';
            $ret .= '</div>';           
            $ret .= '</div>';
            $pgl_approval = $this->isPersonalLibraryRequest($this->gameid, $this->displaymode);
            if($pgl_approval=== TRUE){
                $div1 = 'edit-admin-games-list-form';
                $ret .= '<div class="row">';
                $ret .= '<div class="col text-center">';        
                $ret .= '<input type="button"  class="btn btn-success btn-block my-1" id="approve-game" name="approve-game" value="Approve '.$buttonval.'" onclick="approveGame('."'". site_url('ogrex/gameApprove' . '/' . $this->id . '/P','https')."'".', '.$this->id.",'".$div1."'".');" />';
                $ret .= '</div>';       
                $ret .= '</div>';  
            }
        }        
        return $ret;
    }
//------------------------------------------------
//
//
//
//------------------------------------------------          
        public function addPlayerGMButtons($gid){
            $ci = &get_instance();
            $ret='';
            $reg_action = site_url('ogrex/regaction/' . $this->id,'https');
            $rowrefresh = '';
            $rowdivid = '';
            $vmode = '';
            $ret.='<div class="row my-3" id="add-gm-play-buttons">';
            $ret.='<div class="col">';
            $ret.='<div class="d-grid gap-2"><button class="btn btn-secondary" type="button" onclick="addPlayerRegOnsite('. "'" . $reg_action ."/0'," . $gid . ','. "'" . $rowrefresh . "'" . ',' . "'" . $rowdivid. "'" . ','. "'". $vmode . "'" .');" >Register as Player</button></div>';
            $ret.='<div class="d-grid gap-2"><button class="btn btn-secondary" type="button" onclick="addGMRegOnsite('. "'" . $reg_action ."/1'," . $gid . ','. "'" . $rowrefresh . "'" . ',' . "'" . $rowdivid. "'" . ','. "'". $vmode . "'" .');" >Register as Host/GM</button></div>';
            $ret.='</div>';
            $ret.='</div>';   
            return $ret;
            
        }
        //------------------------
        //
        //
        //
        //------------------------           
        public function displaymode_select($dm=''){
            $ci = &get_instance();
            $ret='';
            $sql = 'SELECT * FROM ogre_displaymode ORDER BY dm_mode;';
            $ret.='<select class="form-control my-3" name="displaymode" id="displaymode" size="1">';
            $ret.='<option  value="-" selected="selected" hidden="hidden">-Select One-</option>';
            $query = $ci->db->query($sql);            
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                    if(trim($row->dm_mode) !== ''){
                        switch($dm){
                            case 'P':
                                $ret.= ($row->dm_modecode !== 'N') ? (($dm===$row->dm_modecode) ? '<option value="' . $row->dm_modecode . '" selected="selected">' . $row->dm_mode . '</option>':'<option value="' . $row->dm_modecode . '">' . $row->dm_mode . '</option>') : '';
                                break;
                            case 'R':
                                $ret.= ($row->dm_modecode == 'R') ? (($dm===$row->dm_modecode) ? '<option value="' . $row->dm_modecode . '" selected="selected">' . $row->dm_mode . '</option>':'<option value="' . $row->dm_modecode . '">' . $row->dm_mode . '</option>') : '';
                                break;
                            case 'N':
                                $ret.= ($row->dm_modecode !== 'P') ? (($dm===$row->dm_modecode) ? '<option value="' . $row->dm_modecode . '" selected="selected">' . $row->dm_mode . '</option>':'<option value="' . $row->dm_modecode . '">' . $row->dm_mode . '</option>') : '';
                                break;                            
                            }
                            
                        }
                        
                }
            }
            $ret.='</select>';
            return $ret;
        }
        //------------------------
        //
        //
        //
        //------------------------
        public function rating_select($val=0){
            $ret = '';
            for ($i=0;$i<=10;$i++){
                $ret .=  (intval($val) == $i) ? '<option selected="selected">' . $i . '</option>' :  '<option>' . $i . '</option>';               
            }
            return $ret;
        }

        //------------------------
        //
        //
        //
        //------------------------
        public function game_desc_email($p){
            $ci = &get_instance();    
            $orgid = $ci->session->ogre_orgid;
            $conid = $ci->session->ogre_conid;
            $ci->convention->init($conid);
            $curr_userid = $ci->session->ogre_user_ID;               
            if ($curr_userid != 0){
                    $ci->person->init($conid, '', $curr_userid);
            }
            $ret['from_eaddress'] = $ci->person->email;
            $ret['to_eaddress1'] = $ci->ogre_lib->getConGamingInfoKey($conid, "con_gamingcoordinatoremail");
            $ret['cc_eaddress1'] = $ci->person->email;
            $ret['subject'] = $ci->convention->name . ' Game Description';
            $msg = "Game Description:<br /><br />";
            $msg .= "Sytem: " . $p["gamesystem"] . '<br /><br />' ;
            $msg .= "Game Title: " . $p["gametitle"] . '<br /><br />' ;
            $msg .= "Game Type:  " . $this->getDescriptor($p["gametype"])  . '<br /><br />' ;
            $msg .= "Event Type: " . $p["eventtype"] . '<br /><br />' ;
            $msg .= "Game Master: " . $ci->person->fullname . '<br /><br />' ;
            $msg .= "E-mail: " . $ci->person->email . '<br /><br />' ;
            $msg .= "Min. Number of Players: " . $p["minnumofplayers"] . '<br /><br />' ;
            $msg .= "Number of Players: " . $p["numofplayers"] . '<br /><br />' ;
            $msg .= "Game Length of Time: " . $p["slot_length"] . '<br /><br />' ;
            $msg .= "Day: " . $this->slot_day . '<br /><br />' ;
            $msg .= "Time of Day: " . $this->getSlotTime() . '<br /><br />' ;
            $msg .= "Event Description: " . htmlspecialchars(ascii_to_entities($p["gamenotes"]), ENT_QUOTES) . '<br /><br />' ;
            $msg .= "Game Description: " . htmlspecialchars(ascii_to_entities($p["gamedesc"]), ENT_QUOTES) . '<br /><br />' ;
            $msg .= "Game Fee: " . $p["fee"] . '<br /><br />' ;
            $msg .= "Roleplaying Rating: " . $p["rprating"] . '<br /><br />' ;
            $msg .= "Action Rating " . $p["actrating"] . '<br /><br />' ;
            $msg .= "Puzzle Solving Rating: " . $p["psrating"] . '<br /><br />' ;
            $msg .= "Complexity Rating: " . $p["cmplxrating"] . '<br /><br />' ;
            $msg .= "Maturity: " . $p["matrate"] . '<br /><br />' ;
            $msg .= "Notes to the Coordinator: " . ascii_to_entities($p["othernotes"]) . '<br /><br />' ;
            $msg .= "E-mail me at ". 	$ci->ogre_lib->getConGamingInfoKey($conid, "con_gamingcoordinatoremail");
            $msg .= " if you have any questions." . '<br /><br />' ;
            $ret['body'] = $msg;
            $ret['sent_errmsg'] = 'Error.  Email Not sent.';
            $ret['sent_msg'] = 'Gaming Coorinator Email Sent';
            $ret = $ci->ogre_lib->emailMessageArray($data);
            return $ret;
        }
        //------------------------
        //
        //
        //
        //------------------------
        public function preregReport($gameid=0, $aff='None', $slotnum='0', $gm=0, $gmid=0){
            $ci = &get_instance();
            $orgid = $ci->session->ogre_orgid;
            $conid = $ci->session->ogre_conid;
            $ci->convention->init($conid);
            if ($gmid != 0){
                $ci->person->init($conid, '', $gmid);
                $gameid = $ci->person->gamegm_id_list;
            }
            $ret='';
            $qry_prereg_namelist = 'SELECT ogre_gameschedule.*, ogre_prereg_player.* ';
            $qry_prereg_namelist .= ' FROM ogre_prereg_player, ogre_gameschedule ';
            $qry_prereg_namelist .= ' WHERE ogre_prereg_player.pp_gs_id = ogre_gameschedule.gs_id ';
            $qry_prereg_namelist .= ' AND ogre_prereg_player.pp_gm_judge_flag  = ' . $gm;
            $qry_prereg_namelist .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
            $qry_prereg_namelist .= ' AND ogre_prereg_player.pp_delete_flag = 0';   
            if($aff !="None"){
                $qry_prereg_namelist .= ' AND ogre_gameschedule.gs_affiliation="' . $aff . '"';
            }               
            $qry_prereg_namelist .= ' ORDER BY ogre_gameschedule.gs_slot_code, ogre_gameschedule.gs_id, ogre_gameschedule.gs_table_number, ';
            $qry_prereg_namelist .= ' ogre_gameschedule.gs_affiliation, ogre_prereg_player.pp_player_prereg_id ';

            if ( $gameid != 0 ){
                $gameids = explode(',',$gameid);
                $qry_prereg_namelist = 'SELECT ogre_gameschedule.*, ogre_prereg_player.* ';
                $qry_prereg_namelist .= ' FROM ogre_prereg_player, ogre_gameschedule ';
                $qry_prereg_namelist .= ' WHERE ogre_prereg_player.pp_gs_id = ogre_gameschedule.gs_id ';
                $qry_prereg_namelist .= " AND (";
                $i=1;
                
                foreach ($gameids as $gid){
                    if (trim($gid) != ""){
                        $qry_prereg_namelist .= ($i > 1) ? ' OR ogre_gameschedule.gs_id = ' . $gid : ' ogre_gameschedule.gs_id = ' . $gid ;
                    }
                    $i++;
                }
                $qry_prereg_namelist .= ')';
                $qry_prereg_namelist .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
                $qry_prereg_namelist .= ' AND ogre_prereg_player.pp_gm_judge_flag  = ' . $gm;
                $qry_prereg_namelist .= ' AND ogre_prereg_player.pp_delete_flag = 0';
                if($aff !="None"){
                    $qry_prereg_namelist .= ' AND ogre_gameschedule.gs_affiliation="' . $aff . '"';
                }
                $qry_prereg_namelist .= ' ORDER BY ogre_gameschedule.gs_slot_code, ogre_gameschedule.gs_id, ogre_gameschedule.gs_table_number, ';
                    
                $qry_prereg_namelist .= ' ogre_gameschedule.gs_affiliation, ogre_prereg_player.pp_player_prereg_id ';
            }
            
            if ($slotnum != '' && $slotnum != '0'){
                $qry_prereg_namelist = 'SELECT ogre_gameschedule.*, ogre_prereg_player.* ';
                $qry_prereg_namelist .= ' FROM ogre_prereg_player, ogre_gameschedule ';
                $qry_prereg_namelist .= ' WHERE ogre_prereg_player.pp_gs_id = ogre_gameschedule.gs_id ';
                $qry_prereg_namelist .= ' AND ogre_prereg_player.pp_gm_judge_flag  = ' . $gm;
                $qry_prereg_namelist .= ' AND ogre_prereg_player.pp_delete_flag = 0';
                $qry_prereg_namelist .= ' AND ogre_gameschedule.gs_slot_code="' . $slotnum . '"';
                $qry_prereg_namelist .= ' AND ogre_gameschedule.gs_affiliation="' . $aff . '"';                  
                $qry_prereg_namelist .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
                $qry_prereg_namelist .= ' ORDER BY ogre_gameschedule.gs_slot_code, ogre_gameschedule.gs_id, ogre_gameschedule.gs_table_number, ';
                $qry_prereg_namelist .= ' ogre_gameschedule.gs_affiliation, ogre_prereg_player.pp_player_prereg_id ';
            }
            
            $query = $ci->db->query($qry_prereg_namelist);
            $lastgameid = 0;
            if ($query->getNumRows() > 0) {
                    
                    $ret .= '<table class="preregreport">';
                    $ret .= '<tr>';
                    $ret .= '<th>Day/Time</th>';
                    $ret .= '<th>Game/Title</th>';
                    $ret .= '<th>Pre-Reg Name</th>';
                    $ret .= '</tr>';
                    foreach ($query->getResult() as $row){
                        if($lastgameid != $row->gs_id){
                            $ret .= '<tr>';
                            $ret .= '<td colspan="3" class="prdivider">';
                            $ret .= '&nbsp;';
                            $ret .= '</td>';
                            $ret .= '</tr>';
                        }                              
                        $ret .= '<tr>';
                        $ret .= '<td>' . strtoupper(substr($row->gs_slot_day,0,3)) . " - " . $row->gs_slot_time . '</td>';
                        $ret .= '<td>';
                        $ret .=  (($row->gs_mmrpgFlag != 1) ? '<strong>' . $row->gs_game_name . '</strong>' . ((trim($row->gs_game_title) != '') ? '- <i>' . $row->gs_game_title . '</i>' : '') : '<i>' . $row->gs_game_title . '</i> ('. $row->gs_affiliation . ')');
                        $ret .= '</td>';
                        $ret .= '<td><a href="mailto:' . $row->pp_player_email . '">' . $row->pp_player_name . '</a></td>';
                        $ret .= '</tr>';
                        $lastgameid = $row->gs_id;
                    }
                $ret .= '</table>';
                }
            else
            {

                 $ret .= '<p>None</p>';
            }

            $ret .= 'TOTAL: ' . $query->getNumRows();

            return $ret;
        }
        //------------------------
        //
        //
        //
        //------------------------
        public function preRegReportOP($gameid=0, $aff='', $slotnum='', $gm=0){
            $ci=&get_instance();
                $conid = $ci->session->ogre_conid;
                $ci->convention->init($conid);
                
                $qry_prereg_namelist = 'SELECT ogre_gameschedule.*, ogre_prereg_player.* ';
                $qry_prereg_namelist .= ' FROM ogre_prereg_player, ogre_gameschedule ';
                $qry_prereg_namelist .= ' WHERE ogre_prereg_player.pp_gs_id = ogre_gameschedule.gs_id ';
                $qry_prereg_namelist .= ' AND ogre_prereg_player.pp_gm_judge_flag  = ' . $gm;
                $qry_prereg_namelist .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
                $qry_prereg_namelist .= ' AND ogre_gameschedule.gs_mmrpgFlag = 1 ';
                if ($aff != '')
                {
                    $qry_prereg_namelist .= ' AND ogre_gameschedule.gs_affiliation =  "' . $aff . '" ';
                }
                $qry_prereg_namelist .= ' AND ogre_prereg_player.pp_delete_flag = 0 ';
                $qry_prereg_namelist .= ' AND ogre_gameschedule.gs_cancelled = 0 ';
                if ($slotnum != '')
                {
                    $qry_prereg_namelist .= ' AND ogre_gameschedule.gs_slot_code="' . $slotnum . '"';
                }
                if ( $gameid != 0)
                {
                    $gameids = explode(',',$gameid);
                    $qry_prereg_namelist .= " AND (";
                    $i=0;
                    foreach ($gameids as $gid)
                    {
                        if (trim($gid) != "")
                        {
                            if ($i > 1){
                                $qry_prereg_namelist .= ' OR ogre_gameschedule.gs_id = ' . $gid ;
                            }
                            else{
                                $qry_prereg_namelist .= ' ogre_gameschedule.gs_id = ' . $gid ;
                            }
                        }

                    }

                    $qry_prereg_namelist .= ')';
                }
                $qry_prereg_namelist .= ' ORDER BY ogre_prereg_player.pp_player_name, ogre_gameschedule.gs_slot_code, ogre_gameschedule.gs_table_number, ';
                $qry_prereg_namelist .= ' ogre_gameschedule.gs_affiliation, ogre_prereg_player.pp_player_prereg_id ';

                $query = $ci->db->query($qry_prereg_namelist);

                if ($query->getNumRows() > 0)
                {
                    $ret = '';
                    $header = '<table width="99%" cellpadding="5" border="0">';
                    $header .=  '<tr>';
                    $header .=  '<td>Slot</td>';

                    $header .=  '<td>Judge Name</td>';
                    $header .=  '<td>Game/Title</td>';
                    $header .=  '</tr>';
                    $name = '';
                    $gamecount = 0;
                    $rowcoiunt = 0;
                    foreach ($query->getResult() as $row){
                        if ($name ==  $row->pp_player_name){
                            $ret .= '<tr><td>' . substr($row->gs_slot_code,-2,1) .  '</td>';
                            $ret .= '<td>' . safe_mailto($row->pp_player_email, $row->pp_player_name) . '</a></td>';
                            $ret .= '<td><b>' . $row->gs_game_name . '</b>';

                            if (trim($row->gs_game_title) != '')
                            {
                                $ret .= '- <i>' . $row->gs_game_title . '</i>';
                            }
                            $ret .= '</td>';

                            $ret .= '</tr>';
                            $gamecount++;
                        }
                        else{
                            if ($rowcoiunt != 0){
                                $ret .= '<tr><td colspan="3"> <h3>TOTAL: ' . $gamecount  . '</h3></td></tr>';
                                $ret .= '</table>';
//                                $ret .= '<hr size="2" color="#c0c0c0">';
                                $ret .= '<br /><br /><br />';
                                $gamecount = 0;
                            }

                            $ret .= '<h2>' . $row->pp_player_name .  '</h2>';
                            $ret .= $header;
                            $ret .= '<tr><td>' . substr($row->gs_slot_code,-2,1) . '</td>';

                            $ret .= '<td>' . safe_mailto($row->pp_player_email, $row->pp_player_name) . '</a></td>';
                            $ret .= '<td><b>' . $row->gs_game_name . '</b>';

                            if (trim($row->gs_game_title) != "")
                            {
                                $ret .= '- <i>' . $row->gs_game_title . '</i>';
                            }
                            $ret .= '</td>';
                            $ret .= '</tr>';
                            $gamecount++;
                        }

                        $name = $row->pp_player_name;
                        $rowcoiunt++;

                    }

                    $ret .= '</table>';
                    $ret .= '<br /><br /><br />';
                }
                else
                {
                    $ret = '<p>None</p>';
                }

                $ret .= 'TOTAL: ' . $query->getNumRows() ;

                $ret .= '<p></p>';

                return $ret;
        }
//---------------------------------------------------
//
//---------------------------------------------------
        public function addPCgame($gid=0, $propid=0){         
            $ci=&get_instance();
            $ret = $ci->game->getWhatGameForm(TRUE, $gid, $propid);
            return $ret;
        }        
        
        
        //---------------------------------------------------
	//
	//
	//
	//---------------------------------------------------
        public function addWhatGame($gid=0, $propid=0, $stype=1){         
            $ci=&get_instance();
            $ret = '';
            $gamenametitle='';
            switch($stype){
                    case 1:
                        $title = 'Add Game';
                        break;
                    case 0:
                        $title = 'Add Shift';
                        break;
                    case 2:                  
                        $title = 'Add Panel/Con Event';                      
                        break;                        
                    default:
                        $ret .= '<p><strong>Error</strong> ';
                        $ret .= '</p>'; 
            }
            if($gid==0){
                $ret .= '<div id="dialog-subtitle" class="visually-hidden">'.$title.'</div>';
                $ret .= '<div class="gamewhat_hdr"><span id="selectedgame"> ';
                $ret .= '</span> &nbsp;&nbsp; <span id="newselectedgame"> <span id="newselectedgame_val"></span></span></div>'; 
            }
            else{
                $this->event_init($gid);
                $gamenametitle=$this->game_name . ' (' . $this->game_type . ')';
                $ret .= '<div class="game-what-hdr">';
                $ret .= '<div class="row"><div class="col">';
                $ret .= '<h5><span class="badge bg-primary">Current Game: </span> ';
                $ret .= '<span class="badge bg-secondary"><span id="selectedgame">' . $gamenametitle . '</span></span></h5>';  
                $ret .= '</div><div class="col text-end">';
                $ret .= '<h5><span class="badge bg-primary"> Change to: </span>';
                $ret .= '<span class="badge bg-light text-dark" id="new-selected-game"> ';
                $ret .= '<span id="new-selected-game-val"></span>';
                $ret .= '</span></h5>';
                $ret .= '</div>'; 
                $ret .= '</div>'; 
                $ret .= '</div>'; 
                          
            }
            $ret .= $ci->game->getWhatGameForm(FALSE, $gid, $propid, $stype);
            
            return $ret;
        }
        //---------------------------------------------------
	//
	//
	//
	//---------------------------------------------------
        public function addGameWhen($gid=0, $propid=0){        
            $ci=&get_instance();    
            $ret = '';
            $reset = site_url('ogrex/getSlotSelectInfo','https');
            if($gid!=0){
                $this->event_init($gid);
            }
            if($gid==0){
                $ret .= '<div class="gamewhen_hdr">Time slot: <span id="whentime">';
                $ret .= '</span><span id="whentime_new"></span></div>';                        
            }else{
                $ret .= '<div class="gamewhen_hdr">Current Time slot: <span id="whentime">';
                $ret .= ($gid!=0) ? $this->slot_day . ' ' . $this->slot_time . ' (' . floatval($this->slot_length) . ' hrs)': '';
                $ret .= '</span>&nbsp;&nbsp;&nbsp;&nbsp;Change to: <span id="whentime_new"></span></div>';                           
            }

            $ret .='<div id="when">';
            if($propid!=0){
                $ret .= $ci->proposal->proposalWhen($propid);
            }            
            $ret .= '<p><strong>When do you wish to schedule this Game?: </strong>';
            $ret .= ' Select either one of the Base Slots or Select a Day, Start Time and Length of time</p>';
            $ret .='<input type="hidden" name="timeslottypeval" id="timeslottypeval" value="0" />';
            $ret .='<input type="hidden" name="gameid" id="gameid" value="' .$gid . '" />';

            $ret .= '<div id="results" class="results"></div>';
            $ret .='<form>';
            $ret .='<table class="changeslot_table">';
            $ret .='<tr bgcolor="#CDCDCD">';
            $ret .='<td width="10%">';
            $ret .='<input type="radio" name="timeslottype" id="timeslottype1" value="1" onclick="controlsDisable(this.value, '."'".$reset."'".');" />';
            $ret .='</td>';       
            $ret .='<td>';
            $ret .='<label for="timeslottype1">Fixed Base Slots</label>';
            $ret .='</td>';                              
            $ret .='</tr>';
            $ret .='<tr id="fixed1">';
            $ret .='<td colspan="2">';
            
            $ret .='<table class="changeslot_table_fixed" id="fixed" style="display:none">';  //
            $ret .='<tr>';
            $ret .='<td>';
            $ret .= '<p><strong>Existing/Base Slots</strong><br />';
            $ret .= '<span id="fixedslotselect">';
            $ret .= $this->build_slot_select();    
            $ret .= '</span>';                
            $ret .= '</p>';                
            $ret .='</td>';
            $ret .='</tr>';
            $ret .='</table>';                

            $ret .='</td>';
            $ret .='</tr>';

            $ret .='<tr>';                              
            $ret .='<td colspan="2">';
            $ret .='<p><strong>-OR-</strong></p>';                
            $ret .='</td>';
            $ret .='</tr>';
            
            $ret .='<tr bgcolor="#CDCDCD">';
            $ret .='<td width="10%">';
            $ret .= '<input type="radio" name="timeslottype" id="timeslottype0" value="0" onclick="controlsDisable(this.value, '."'".$reset."'".');" />';
            $ret .='</td>';                  
            $ret .='<td>';
            $ret .='<label for="timeslottype0">Custom Time Slot</label>';
            $ret .='</td>';
            $ret .='</tr>';
            
            $ret .='<tr id="custom1">';               
            $ret .='<td colspan="2">';
            
            $ret .='<table class="changeslot_table_custom" id="custom" style="display:none">'; 
            $ret .='<tr>';
            $ret .='<td>';
            $ret .= '<p>Set your own Time</p>';
            $ret .= '<span id="customslotselect">';
            $ret .= $this->build_nonbase_slot_form();
            $ret .= '</span>';
            $ret .='</td>';
            $ret .='</tr>';
            $ret .='</table>';   
            $ret .='</form>';
            $ret .='</td>';
            $ret .='</tr>';
            $ret .='</table>';

            $ret .='</div>';
            if($gid!=0){
                $warn=$ci->ogre_lib->getMiscContent('%SLOT_CHANGE_WARNING%');
                if(is_array($warn)){
                    if(isset($warn['content'])){
                        $ret .= $warn['content'];
                    }
                }
            }
            return $ret;
        }        
        //------------------------
        //
        //
        //
        //------------------------
        public function gameadd_where($geid=0, $propid=0){
            $ci=&get_instance();
            $ret = '';
            if($geid!=0){
                $this->event_init($geid);
            }
            $ret .= '<div class="gamewhere_hdr">Current Location: <span id="whereplace">';
            $ret .= ($geid!=0) ? $this->location_name . ': ' . $this->table_number : '';
            $ret .= '</span>&nbsp;&nbsp;&nbsp;&nbsp;Change to: <span id="whereplace_new"></span></div>';                
      
            $ret .= '<div id="results" class="results"></div>';
            
            $ret .= '<input type="hidden" name="gameid" id="gameid" value="'. $geid . '" />';
            $ret .='<div id="where">';
            if($propid!=0){
                $ret .= $ci->proposal->proposalWhere($propid);
            }
            $mc=$ci->ogre_lib->getMiscContent('%GAMEEVENTLOC_INTRO%');
            $ret .= $mc['content'];
            $ret .= '<table class="changeloc_table">';
            $ret .= '<tr>';
            $ret .= '<td>';
            $ret .= 'Room/Location: ';
            $ret .= '</td>';
            $ret .= '<td>';
            $ret .=  $ci->location->get_location_select();
            $ret .= '</td>';
            $ret .= '</tr>';
            $ret .= '<tr>';
            $ret .= '<td>';
            
            $ret .= 'Tables: ';
            $ret .= '</td>';
            $ret .= '<td>';    
            $ret .= '<div id="tablelist">';
            $ret .=  $ci->location->get_tableselect();
            $ret .= '</div>';
            $ret .= '</td>';
            $ret .= '</tr>';              

            $ret .= '</table>';                

            $ret .='</div>';
            return $ret;            
        }
        
        public function gameadd_final($propid=0)
        {
            $ci=&get_instance();
            $mc=$ci->ogre_lib->getMiscContent('%GAMEEVENTFINAL_INTRO%');
            $ret ='<div id="final" style="background-color:#D5D5D5; display:none;">';
            $ret .= '<h2>Final Check</h2>';
            $ret .= $mc['content'];
            $ret .= '<table width="100%" border="0" cellspacing="8" cellpadding="8">';
            $ret .= '<tr>';
            $ret .= '<td>';     
            $ret .= '<input type="button"  class="btn btn-secondary" name="back" id="back" value=" Back5 " onclick="backtoWhere()" />';
            $ret .= '</td>';
            $ret .= '<td align="right">';
            
            $ret .= '<input class="btn btn-secondary" type="submit" name="submit" id="submit" value="    Save   " />';
            $ret .= '</td>';
            $ret .= '</tr>';
            $ret .= '</table>';                

            $ret .='</div>';     
            
            return $ret;
        }
        //------------------------
        //
        //
        //
        //------------------------
        public function build_slot_array($conid ,$late=-1, $day=''){
            $ci = &get_instance();
            $qry = 'SELECT * FROM ogre_gameslots WHERE slot_conid = ' . $conid ;
            $qry .= ($late >= 0) ? ' AND ogre_gameslots.slot_latenight = ' . $late : '';
            $qry .= ($day != '') ?  ' AND ogre_gameslots.slot_day = "' . $day . '"' : '';
            $qry .= ' ORDER BY slot_code;';
            $query = $ci->db->query($qry);
            $i = 1;
            $arySlots = array();
            $arySlots[1][1] = "";
            if ($query->getNumRows() > 0){
		foreach ($query->getResult() as $row){
                    $arySlots[$i]['slot_code'] =  $row->slot_code;
                    $arySlots[$i]['slot_time'] =  $row->slot_time;
                    $arySlots[$i]['slot_start_time'] =  $row->slot_start_time;
                    $arySlots[$i]['slot_length'] =  $row->slot_length;
                    $arySlots[$i]['slot_number'] =  $row->slot_number;
                    $arySlots[$i]['slot_latenight'] =  $row->slot_latenight;
                    $arySlots[$i]['slot_rpga_number'] =  $row->slot_rpga_number;
                    $arySlots[$i]['slot_day'] =  $row->slot_day;
                    $arySlots[$i]['slot_date'] =  $row->slot_date;
                    $arySlots[$i]['slot_baseslot'] =  $row->slot_baseslot;
                    $i++;
                }
            }
            return $arySlots;
        }
        
        
        //------------------------
        //
        //
        //
        //------------------------
        public function build_slot_select($late=-1, $day=''){
            $ci=&get_instance();
            $orgid = $ci->session->ogre_orgid;
            $conid = $ci->session->ogre_conid;
            $action = site_url('ogrex/getSlotSelectInfo','https');
            $ci->convention->init($conid);   
            $slots = $this->build_slot_array($conid ,$late, $day);
            $ret ='';
            $ret .= '<select id="gameslot" name="gameslot" size="9" onclick="newtime_header(this.options[this.selectedIndex].text,this.options[this.selectedIndex].value,'.$conid.','."'".$action."'".');">';

            if(count($slots) != 0)
            {
                foreach ($slots as $slot)
                {
                    $ret .= '<option value="' . $slot['slot_code'] . '">' . $slot['slot_day'] . ' - ' . $slot['slot_time']  . ' ('. $slot['slot_length'] .' hrs) </option>';
                }
            }
            $ret .= '</select>';
            return $ret;
        }

          
//------------------------
//
//
//
//------------------------      
        public function build_nonbase_slot_form($slot=NULL){
            $ci=&get_instance();
            $conid = $ci->session->ogre_conid;
            $ci->convention->init($conid);   
            if($slot===NULL){
                $slot['slotstarttime']='';
                $slot["slotdate"] = '';
                $slot["slotday"] = '';
                $slot["slotlength"]  = '';                                    
                $slot['slotnumber'] = '';
                $slot['slottime'] = '';
                $slot['baseslot'] = '0';
                $slot['latenight'] = '0';
                $slot['mmrpg'] = '0';
                $slot['slotcode'] = ''; 
                $h = '';
                $m = '';
                $ampm = '';        
            }
            $ret ='';
            $action = site_url('ogrex/customTime','https');
            $scaction = site_url('ogrex/generate_slotecode'.'/'.$conid,'https');
            $ret .= '<table class="custom_slot_table">';
            $ret .= '<tr>';
            $ret .= '<td>Date <sup>*</sup></td>';
            $ret .= '<td>';
            $sel = $ci->convention->date_select('event_date',$slot["slotdate"]);
            $ret .= str_replace('<select', '<select onchange="update_newcustomtimehdr('."'".$action."','".$scaction."'".');"', $sel);
            $ret .= '<input type="hidden" id="slot_day" name="slot_day" value="'.$slot["slotday"].'">';
            $ret .= '<input type="hidden" id="slot_number" name="slot_number" value="'.$slot["slotnumber"].'">';
            $ret .= '<input type="hidden" id="slot_time" name="slot_time" value="'.$slot["slottime"].'">';
            $ret .= '<input type="hidden" id="slot_baseslot" name="slot_baseslot" value="'.$slot["baseslot"].'">';
            $ret .= '<input type="hidden" id="slot_latenight" name="slot_latenight" value="'.$slot["latenight"].'">';
            $ret .= '<input type="hidden" id="slot_rpga" name="slot_rpga" value="'.$slot["mmrpg"].'">';
            $ret .= '<input type="hidden" id="slot_code" name="slot_code" value="'.$slot["slotcode"].'">';
            $ret .= '</td>';
            $ret .= '</tr>';
            $ret .= '<tr>';
            $ret .= '<td>Start Time <sup>*</sup></td>';
            $ret .= '<td>';
            if($slot['slotstarttime']!=''){
                $stime = new Time($slot['slotstarttime']);
                $h = $stime->format('h'); 
                $m = $stime->format('i'); 
                $ampm = $stime->format('A'); 
            }
            $sel = $ci->convention->timeSelect_hour('start_time_hour', $h);
            $ret .= str_replace('<select', '<select onchange="update_newcustomtimehdr('."'".$action."','".$scaction."'".');"', $sel);
            $ret .= ':';
            $sel = $ci->convention->timeSelect_min('start_time_min', $m);
            $ret .= str_replace('<select', '<select onchange="update_newcustomtimehdr('."'".$action."','".$scaction."'".');"', $sel);
            $ret .= '&nbsp;';
            $sel = $ci->convention->timeSelect_AMPM('start_time_AMPM', $ampm);
            $ret .= str_replace('<select', '<select onchange="update_newcustomtimehdr('."'".$action."','".$scaction."'".');"', $sel);
            $ret .= '</td>';
            $ret .= '</tr>';
            $ret .= '<tr>';
            $ret .= '<td>Length (in Hours) <sup>*</sup></td>';
            $ret .= '<td>';
            $sel = $ci->convention_lib->slotLengthSelect("slot_length", $slot["slotlength"]);
            $ret .= str_replace('<select', '<select onchange="update_newcustomtimehdr('."'".$action."','".$scaction."'".');"', $sel);
            $ret .= '</td>';
            $ret .= '</tr>';
            $ret .= '</table>';   
            
            return $ret;
        }
//------------------------
//
//------------------------              
        public function getSlotCode($gid=0){
            $ci=&get_instance();
            if ($gid == 0){
                $gid = $this->id;
            }
            $qry_pgl = "SELECT gs_slot_code FROM ogre_gameschedule WHERE gs_id = " . $gid ;
            $query = $ci->db->query($qry_pgl);
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){            
                    $ret = $row->gs_slot_code;
                }
            }
            return $ret;
        }          
//------------------------
//
//------------------------      
        public function getSlotLengthSelect($slot=0, $enabled=TRUE){
            $ci=&get_instance();         
            $orgid = $ci->session->ogre_orgid;
            $conid = $ci->session->ogre_conid;
            $ci->convention->init($conid); 
            $slotlengths=[];
            $slotlist = $ci->ogre_lib->getMiscContent("%SLOT_LENGTH_LIST%");
            $slotlengths=  explode(',', $slotlist['content']);
            if($slot===0){
                $defsl=$ci->ogre_lib->getConfigKey('DEFAULT.SLOTLENGTH',$orgid);
                if($defsl=='0'){
                    $defsl=='4';
                }
            }
            else{
                $defsl=$slot;
            }
            $ret ='';
            $ret .= '<select class="form-control my-2" id="gameslotlength" name="gameslotlength" size="1"';
            $ret .= ($enabled!==TRUE) ? ' disabled="disabled" ': '';
            $ret .= '>';
            if(count($slotlist) != 0){
                foreach ($slotlengths as $slotlen){
                    $ret .= (($defsl==$slotlen) ? '<option value="' . $slotlen . '" selected="selected">' . $slotlen .  '</option>' : '<option value="' . $slotlen . '">' . $slotlen .  '</option>');
                }
            }
            $ret .= '</select>';
            return $ret;            
        } 
//---------------------------------------------------
//
//---------------------------------------------------   
        public function timegenSlotCode(){
            $ci=&get_instance();
            $conid = $ci->session->ogre_conid;
            $ci->convention->init($conid);

            $st = $this->slot_start_time;
            $len = $this->slot_length;
            $stime = new Time($this->slot_start_time);
            $i = 1;
            $dtenum = substr($this->slot_code, 0, 2);
            $lenenum = $len/0.5;
            $ret = '';
            for($i=1; $i<=$lenenum; $i++){
                $ret .= $dtenum . substr($st,0,2) . substr($st,3,1) . ',';
                $stime->modify("+30 minute");
                $st = $stime->format("H:i:s");
            }
            $ret = substr($ret,0,strlen($ret)-1);
            return $ret;
        }             
//---------------------------------------------------
//
//---------------------------------------------------   */  
        public function genSlotCode($starttime, $timelength, $eventdate){
            $ci=&get_instance();  
            $st = $starttime;
            $ret = '';
            $conid = $ci->session->ogre_conid;            
            $ci->convention->init($conid);
            $len = $timelength;
            $stime = new Time($starttime);
            $cdates = $ci->convention->dateArray();
            for($i=1;$i<=count($cdates);$i++){
                if($eventdate == $cdates[$i]){
                    $dtenum = $i;
                    
                }
            }
            $lenenum = intval($len/0.5);
            for($i=1;$i<=$lenenum;$i++){
                $ret .= $dtenum . substr($st,0,2) . substr($st,3,1) . ',';
                $stime->modify("+30 minute");
                $st = $stime->format("H:i:s");
            }
            
            $ret = substr($ret,0,strlen($ret)-1);
            
            return $ret;
        }                          
//---------------------------------------------------
//
//  
//
//---------------------------------------------------   */  
    public function getEventAffiliationFilter($aff, $conid=0){
        $ci = &get_instance();
        $ret = '';
        if(is_numeric($aff)){
            if(intval($aff) != 0){
                $conid = (($conid == 0) ? $ci->session->ogre_conid: $conid);
                $ci->game->init($aff, $conid);
                $aff = $ci->game->game_affiliation;
            }
        }        
        $qry = 'SELECT ogre_games_descriptor.*, ogre_games_descriptor_type.* ';
        $qry .= ' FROM ogre_games_descriptor,  ogre_games_descriptor_type ';
        $qry .= ' WHERE ogre_games_descriptor.gd_descriptor_type = ogre_games_descriptor_type.gdt_id ';
        $qry .= ' AND ogre_games_descriptor_type.gdt_id = 5';
        $qry .= ' ORDER BY gd_descriptor;';
        $query = $ci->db->query($qry);
        $action= site_url('ogrex/currentSchedule','https');
        $saction= site_url('ogrex/currentScenarioList','https');
        $scenaction= site_url('ogrex/scenarioList','https');
        if ($query->getNumRows() > 0){
            $ret = '<select class="form-control my-2" id="affiliation" name="affiliation" size="1" onchange="getCurrentSchedule(this.options[this.selectedIndex].value, ' ."'". $action ."','". $saction ."','". $scenaction ."'". ');">';
            if($aff==='0'){
                $ret .= '<option value="0" selected="selected" hidden="hidden">(SELECT ONE)</option>';
            }
            foreach ($query->getResult() as $row){
                $ret .= ($aff == $row->gd_descriptor) ?  '<option value="' . $row->gd_descriptor . '" selected="selected">' . $row->gd_descriptor . '</option>' : '<option value="' . $row->gd_descriptor . '">' . $row->gd_descriptor . '</option>';
            }
            $ret .= '</select>';    
        }

        return $ret;
    }        
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function getDataByID($table, $field, $idfield, $idvalue){
        $ci=get_instance();
        $qry = 'SELECT ' . $field . ' FROM ' . $table . '  WHERE ' . $idfield . '=' . $idvalue;
        $query = $ci->db->query($qry);
        $ret = '';
        if($query->getNumRows() != 0){
            foreach ($query->getResult() as $row){
                $ret .= $row->$field;
            }
        }
        return $ret;
    }   
//---------------------------------------------------
//
//---------------------------------------------------
    public function getGMEditForm($p,$conid,$admin=FALSE){   
        $ret='';
        $this->event_init($p['gid']);
        $ret .='<h2 style="color:#0000FF">'.$this->slot_time.': '.$this->game_name.'</h2>';
        $ret .= $this->game_admin_rpga_playeradmin($this->id);
        $ret .= $this->admin_lib->userAdmin($p,$conid,$this->id);
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getPlayersChoiceForm($gid){
        $ci=get_instance();
        $this->event_init($gid);
        $ret='';
        $ret .= '<div id="results" class="results"></div>';
        $ret .= '<div id="pclist">';
        $ret .= $this->playerschoice_list($gid);
        $ret .= '</div>';
        return $ret;
    }
         //---------------------------------------------------
        //
        //
        //
        //---------------------------------------------------
        public function playerschoice_list($gid){
            $ci=get_instance();
            $ret = '';
            $qry = 'SELECT * FROM ogre_playerschoicelist WHERE pc_gs_id = '.$gid;
            $query = $ci->db->query($qry);
            $ret .= '<table class="pctable">';               
            $ret .= '<tr>';
            $ret .= '<th>';
            $ret .= 'Game';
            $ret .= '</th>';
            $ret .= '<th>';
            $ret .= 'Remove';
            $ret .= '</th>';                    
            $ret .= '</tr>';       
            $i = 0;
            if($query->getNumRows() != 0){
                foreach ($query->getResult() as $row){
//                    $ret .= ($i%2==1) ? '<tr>' : '<tr bgcolor="#CDCDCD">';  
                    $ret .= '<tr>';
                    $ret .= '<td style="padding:5px;">';
                    $ret .= $row->pc_game_name;
                    $ret .= '</td>';
                    $ret .= '<td width="10%" style="padding:5px;">';
                    $ret .= '<input type="checkbox" id="remove_PC'.$row->pc_game_id.'" name="remove_PC'.$row->pc_game_id.'" onclick="removePC('.$row->pc_game_id.','."'".site_url('ogrex/gameGroupDel','https')."'".')" />';
                    $ret .= '</td>';                    
                    $ret .= '</tr>';
                    $i++;
                }
            }               
            $ret .='</table>';           
            return $ret;         
        }       
        
        //---------------------------------------------------
        //
        //
        //
        //---------------------------------------------------
        public function playersChoiceIn($p){
            $ci = &get_instance();
            $gl = explode(",",$p['glist']);
            $conid = $ci->session->ogre_conid;              

            foreach ($gl as $g){  
                if ($g != ''){
                    $ci->game->init($g);
                    $ins = 'INSERT ogre_playerschoicelist  ( ';
                    $ins .= 'pc_gs_id,';
                    $ins .= 'pc_game_name,';
                    $ins .= 'pc_num_of_players,';                            
                    $ins .= 'pc_game_desc,';
                    $ins .= 'pc_gn_id,';
                    $ins .= 'pc_game_type,';
                    $ins .= 'pc_game_genre,';
                    $ins .= 'pc_convention_id';
                    $ins .= ') ';
                    $ins .= 'VALUES (' ;	 
                    $ins .=  $p['gid'] . ', ';
                    $ins .=  '"'.$ci->game->game_name . '", ';
                    $ins .=  $ci->game->max_players . ', ';
                    $ins .=  '"'.$ci->game->game_desc . '", ';
                    $ins .=  $ci->game->gameid . ', ';
                    $ins .=  '"'.$ci->game->game_type . '", ';
                    $ins .=  '"'.$ci->game->game_types . '", ';
                    $ins .=  $conid;
                    $ins .= ');';	 
                    $ci->db->query($ins);
                }
            }
            return true;             
        }
         //---------------------------------------------------
        //
        //
        //
        //---------------------------------------------------
        public function saveMyGameLibraryEvent($p){
            $ci = &get_instance();
            $tran = TRUE;
            $conid = $ci->session->ogre_conid;
            $orgid = $ci->session->ogre_orgid;
            $slots = explode(";",$p['mybgavlist']);
            $x = 0;
            $ge = [];
            $lastid = 0;
            $ci->db->transStart();
            foreach ($slots as $slot){
//          Build array of data      
                if(trim(trim($slot)) !== ""){
                    $avail = explode(",",$slot);
                    $ge['gs_gn_id'] = PERSONAL_LIBRARY_ID;
                    $ge["slot_date"] = $avail[0];
                    $day = date('w',strtotime($ge["slot_date"]));
                    $ge["slot_day"] = $ci->ogre_lib->dateOfTheWeek($day);
                    $ge['slot_starttime'] = date("H:i:s", strtotime($avail[1]));
                    $ge['slottime'] = '';
                    $ge['slot_length'] = (float)$avail[2];
                    $hr = date("H",strtotime($avail[1]));
                    $min = date("i",strtotime($avail[1]));
                    $start =  str_pad($hr,2,'0',STR_PAD_LEFT) . substr($min,0,1);
                    $ge['slot_code'] = $ci->convention->genSlotCode($ci->ogre_lib->dateOfTheWeek($day),$start,(float)$avail[2]);
                    $ge['slotnumber'] = $ge['slot_code'];
                    $key = 'DEFAULT.OPEN.GAMING.AREA.ID';
                    $ge['locationid'] = $ci->ogre_lib->getConfigKey($key, $orgid, $conid);
                    $ge['tbl_id'] = 0;
                    $ge["gametitle"] = $p['glname'];
                    $ge['affiliation'] = 'None';
                    $ge['gamenotes'] = 'Contact the Host if you are interested in playing.';
                    $ge['gamedesc'] = '';
                    $ge['matrate'] = 'PG';
                    $ge['rprating'] = '0';
                    $ge['psrating'] = '0';
                    $ge['actrating'] = '0';
                    $ge['cmplxrating'] = '0';
                    $ge['maxnumofplayers'] = '1';
                    $ge['minnumofplayers'] = '6';
                    $ge['eventtype'] = PERSONAL_LIBRARY_TYPE;
                    $ge['editable'] = '1';
                    $ge['lock-gm-sign-up'] = '1';
                    $ge['displaymode'] = 'R';  
                    
                    if ($x == 0){
//          Add First session, get Last ID          
                        $lastid = $this->insertRegularGame($ge);
                        $bgl = $this->myGameLibraryIn($p, $lastid, 0);
                        $gm_in = $ci->person->addAsGM($ci->session->ogre_user_ID, $lastid);
                    }
                    else{
//          add game list with Last ID
                        $id = $this->insertRegularGame($ge);
                        $bgl = $this->myGameLibraryIn($p, $id , $lastid);
                        $gm_in = $ci->person->addAsGM($ci->session->ogre_user_ID, $id);
//          add subsequent sessions by copying the same list from LAST ID                          
                    }   
                    $x++;
                }
           }
            $ci->db->transComplete();
            if ($ci->db->transStatus() === FALSE){
                    $tran = FALSE;
            }           
           return $tran;
        }
        //---------------------------------------------------
        //
        //
        //
        //---------------------------------------------------
        public function myGameLibraryIn($p, $gsid, $lastid){
            $ci = &get_instance();
            $ins = '';
            $ret = '0';
            $gl = explode(",",$p['mybglist']);
            
            $conid = $ci->session->ogre_conid;
            $ci->db->transStart();
            if($lastid === 0){
                foreach ($gl as $g){
                    if (trim($g) != ''){
                            $ci->bgggame->bgg_init($g);
                            $ins = 'INSERT ogre_playerschoicelist  ( ';
                            $ins .= 'pc_gs_id,';
                            $ins .= 'pc_game_name,';
                            $ins .= 'pc_num_of_players,';                            
                            $ins .= 'pc_game_desc,';
                            $ins .= 'pc_gn_id,';
                            $ins .= 'pc_bggid,';
                            $ins .= 'pc_game_type,';
                            $ins .= 'pc_game_genre,';
                            $ins .= 'pc_convention_id';
                            $ins .= ') ';
                            $ins .= 'VALUES (' ;	 
                            $ins .=   $gsid . ', ';
                            $ins .=  '"'.$ci->bgggame->game_name . '", ';
                            $ins .=  $ci->bgggame->max_players . ', ';
                            $ins .=  '"'.$ci->bgggame->game_desc . '", ';
                            $ins .=  -1*intval($g) . ', ';
                            $ins .=  intval($g) . ', ';
                            $ins .=  '"'.$ci->bgggame->game_type . '", ';
                            $ins .=  '"'.$ci->bgggame->game_types . '", ';
                            $ins .=  $conid;
                            $ins .= ');';
                            $ci->db->query($ins);
                            $ret .= ($ci->db->affectedRows() > 0) ? ','.$ci->db->insertID():',0';
                    }
                }
            }else{
                $ins = 'INSERT ogre_playerschoicelist  ( ';
                $ins .= 'pc_gs_id,';
                $ins .= 'pc_game_name,';
                $ins .= 'pc_num_of_players,';                            
                $ins .= 'pc_game_desc,';
                $ins .= 'pc_gn_id,';
                $ins .= 'pc_bggid,';
                $ins .= 'pc_game_type,';
                $ins .= 'pc_game_genre,';
                $ins .= 'pc_convention_id';
                $ins .= ') ';
                $ins .= 'SELECT  ' ;
                $ins .=   $gsid . ', ';
                $ins .= 'pc_game_name,';
                $ins .= 'pc_num_of_players,';                            
                $ins .= 'pc_game_desc,';
                $ins .= 'pc_gn_id,';
                $ins .= 'pc_bggid,';
                $ins .= 'pc_game_type,';
                $ins .= 'pc_game_genre,';
                $ins .= 'pc_convention_id';
                $ins .= ' FROM ogre_playerschoicelist WHERE pc_gs_id = '.$lastid.';';
                $ci->db->query($ins);
                $ret .= ($ci->db->affectedRows() > 0) ? ','.$ci->db->insertID():',0';
            } 
           
            $ci->db->transComplete(); 
            return $ret;             
        }
        //---------------------------------------------------
        //
        //---------------------------------------------------
        public function playersChoiceDel($pcid){
            $ci = &get_instance();               	 
            $qry='DELETE FROM ogre_playerschoicelist WHERE pc_game_id = ' . $pcid . ';';
            $ci->db->query($qry);
            $ret=($ci->db->affectedRows() > 0)?TRUE : FALSE;  
            return $ret;            
        }
        //---------------------------------------------------
        //
        //
        //
        //---------------------------------------------------     
        public function updatewhen($p){
            $this->event_init($p["gameid"]);

            $ci=&get_instance();
            $conid = $ci->session->ogre_conid;
            $ci->convention->init($conid);                    
            $geventinfo['gameid'] = $p["gameid"];                    

            $qry = 'UPDATE ogre_gameschedule SET ';
            $qry .= ' ogre_gameschedule.gs_slot_date = "' . $geventinfo['slotdate'] . '", ';
            $qry .= ' ogre_gameschedule.gs_slot_day = "' . $geventinfo['slotday'] . '", ';
            $qry .= ' ogre_gameschedule.gs_slot_start_time =  "' . $geventinfo['slotstarttime'] . '", ';
            $qry .= ' ogre_gameschedule.gs_slot_length = ' . $geventinfo['slotlength'] . ', ';
            $qry .= ' ogre_gameschedule.gs_slot_number = "' . $geventinfo['slotnumber'] . '", ';
            $qry .= ' ogre_gameschedule.gs_slot_code = "' . $geventinfo['slotcode'] . '", ';
            $qry .= ' ogre_gameschedule.gs_slot_time = "' . $geventinfo['slottime'] . '", ';
            $qry .= ' ogre_gameschedule.gs_base_slot = ' . $geventinfo['baseslot'] . ', ';
            $qry .= ' ogre_gameschedule.gs_late_night = ' . $geventinfo['latenight'] . ', ';
            $qry .= ' ogre_gameschedule.gs_date_last_modified = NOW(), ';
            $qry .= "  WHERE ogre_gameschedule.gs_id = " . $this->id;
            $ci->db->query($qry);   
            $ret = ($ci->db->affectedRows() > 0) ? TRUE : FALSE;   
            return $ret;
        }
        
//---------------------------------------------------
//
//
//
//---------------------------------------------------     
    public function updatewhat($geid, $gameid){
        $ci=&get_instance();
        $ci->game->init($gameid);

        $qry = 'UPDATE ogre_gameschedule SET ';
        $qry .= ' ogre_gameschedule.gs_gn_id = ' . $ci->game->gameid . ', ';
        $qry .= ' ogre_gameschedule.gs_gn_msa_id = ' . $ci->game->msa_id . ', ';
        $qry .= ' ogre_gameschedule.gs_game_name =  "' . $ci->game->game_name . '", ';
        $qry .= ' ogre_gameschedule.gs_game_type = "' . $ci->game->game_type . '", ';
        $qry .= ' ogre_gameschedule.gs_game_desc = "' . quotes_to_entities($ci->game->game_desc) . '", ';
        $qry .= ' ogre_gameschedule.gs_game_notes = "",';
        $qry .= ' ogre_gameschedule.gs_game_list = ' . $ci->game->group_flag . ', ';
        $qry .= ' ogre_gameschedule.gs_min_num_of_players = ' . $ci->game->min_players . ', ';
        $qry .= ' ogre_gameschedule.gs_max_number_of_players = ' . $ci->game->max_players . ', ';
        $qry .= ' ogre_gameschedule.gs_date_last_modified = NOW() ';
        $qry .= "  WHERE ogre_gameschedule.gs_id = " . $geid;           

        $ci->db->query($qry);

        $ret = ($ci->db->affectedRows() > 0) ? TRUE : FALSE;
        return $ret;
    }   
        
//---------------------------------------------------
//
//
//
//---------------------------------------------------     
    public function cancelgame($geid, $val){
        $ci=&get_instance();
        $this->event_init($geid);
         $ret = TRUE;
        try{
//            $ci->db->transStart();
            $qry = 'UPDATE ogre_gameschedule SET ';
            $qry .= ' ogre_gameschedule.gs_cancelled = ' . $val . ', ';
            $qry .= ' ogre_gameschedule.gs_date_last_modified = NOW() ';
            $qry .= '  WHERE ogre_gameschedule.gs_id = ' . $geid;           
            $ci->db->query($qry);  
            if(intval($val) === 1){
//                $qry1 = 'UPDATE ogre_prereg_player SET pp_delete_flag = ' . $val . ' WHERE pp_gs_id = ' . $geid;
//                $ci->db->query($qry1);
                $qry1 = $this->cancelgame_players($geid, $val);
            }

//            $ci->db->transComplete(); 
        } 
        catch(Exception $e){
            $ret = FALSE;
        }
        return $ret;
    }   
//---------------------------------------------------
//
//
//
//---------------------------------------------------     
    public function cancelgame_players($geid, $val, $notify=TRUE){
        $ci=&get_instance();
        $this->event_init($geid);
         $ret = TRUE;
         $ret1 = '';
         $pe='';           
        try{

            $qry = 'SELECT ogre_prereg_player.* ';
            $qry .= ' FROM ogre_prereg_player ';
            $qry .= ' WHERE ogre_prereg_player.pp_gs_id = ' . $geid;             
            $query = $ci->db->query($qry);
            if ($query->getNumRows() > 0){ 
                foreach ($query->getResult() as $row){
                    $qry1 = 'UPDATE ogre_prereg_player SET pp_delete_flag = ' . $val . ' WHERE pp_player_prereg_id = ' . $row->pp_player_prereg_id;

                    $ci->db->query($qry1);
                    $pe .= $row->pp_player_email . ',';
                }
            }
            $ret1 .=  ($notify==TRUE)? $this->notify_player_cancel($row->pp_gs_id, $pe) : '';
        }
        catch(Exception $e){
            $ret = FALSE;
        }
        return $ret;
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------     
    public function notify_player_cancel($gid, $em){
        $ci=&get_instance();
        $conid = $ci->session->ogre_conid;
        $orgid = $ci->session->ogre_orgid;

        $ci->convention->init($conid);
        $this->event_init($gid);

        $ret['to_eaddress1'] = $ci->ogre_lib->getConfigKey('OGRE.ADMIN.EMAIL.REPLYTO', $orgid); 
        $ret['bcc_eaddress1'] = $em;
        $ret['from_eaddress'] = $ci->ogre_lib->getConfigKey('OGRE.ADMIN.EMAIL.REPLYTO', $orgid);   
        $ret['subject'] = $ci->convention->name . ' Game Cancellation Notification ';  
        $body = $ci->ogre_lib->getMiscContent('%CANCEL_NOTIFY%');
        $ret['body'] = $body['content'];
        $ret['body'] = str_replace('%CONVENTION%',$ci->convention->name,$ret['body']);
        $ret['body'] = str_replace('%SLOT%',$this->slot_time,$ret['body']);
        $ret['body'] = str_replace('%GAME%',$this->game_name,$ret['body']);
        $ret['body'] = str_replace('%TITLE%',$this->game_title,$ret['body']);
        $ret['sent'] = $ci->ogre_lib->emailMessage($ret);         
        return $ret['sent'];
        
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------     
    public function updatewhere($p){
        $ci=&get_instance();
        $tbl = $this->getDataByID('ogre_location', 'loc_table_prefix', 'loc_locationid', $p['locid']).'-'.$this->getDataByID('ogre_tables', 'tbl_number', 'tbl_id', $p['tableid']);
        $placeholder = $this->getDataByID('ogre_tables', 'tbl_placeholder', 'tbl_id', $p['tableid']);            
        $location = $this->getDataByID('ogre_location', 'loc_location_name', 'loc_locationid', $p['locid']);
        $qry = 'UPDATE ogre_gameschedule SET ';
        $qry .= ' ogre_gameschedule.gs_table_number = "' . $tbl . '", ';
        $qry .= ' ogre_gameschedule.gs_table_placeholder_virtual = ' . $placeholder . ', ';
        $qry .= ' ogre_gameschedule.gs_location_name =  "' . $location . '", ';
        $qry .= ' ogre_gameschedule.gs_tbl_id = ' . $p['tableid'] . ', ';
        $qry .= ' ogre_gameschedule.gs_date_last_modified = NOW() ';
        $qry .= "  WHERE ogre_gameschedule.gs_id = " . $p['gameid'];
        $ci->db->query($qry);
        $ret = ($ci->db->affectedRows() > 0) ? TRUE : FALSE;
        return $ret;
    }    
           
//---------------------------------------------------
//
//
//
//---------------------------------------------------        
    public function update_eventproposalInfo($geid, $propid){
            $ci=&get_instance();            
            $ci->proposal->prop_init($propid);
            $conid = $ci->session->ogre_conid;
            $qry = 'UPDATE ogre_gamerequest SET ';
            $qry .= ' ogre_gamerequest.gr_schedule_id = ' . $geid . ' ';
            $qry .= '  WHERE ogre_gamerequest.gr_id = ' . $propid; 
            $ci->db->query($qry);           
            
            $ret1 = ($ci->db->affectedRows() > 0) ? TRUE : FALSE;               
            $marerials='<p>'.str_replace('*', '', $ci->proposal->players_responsibilities).'</p>';
            $know='<p>'.str_replace('*', '',$ci->proposal->player_know).'</p>';
            $attitude='<p>'.str_replace('*', '',$ci->proposal->attitude).'</p>';           
            $qry = 'UPDATE ogre_gameschedule SET ';
            $qry .= ' ogre_gameschedule.gs_game_title = "' . quotes_to_entities($ci->proposal->game_title) . '", ';
            $qry .= ' ogre_gameschedule.gs_game_notes = "' . quotes_to_entities($ci->proposal->game_notes) . $marerials . $know . $attitude . '", ';
            $qry .= ' ogre_gameschedule.gs_min_num_of_players =  ' . $ci->proposal->min_num_of_players . ', ';
            $qry .= ' ogre_gameschedule.gs_roleplaying =  ' . $ci->proposal->rp_rating . ', ';
            $qry .= ' ogre_gameschedule.gs_action =  ' . $ci->proposal->action_rating . ', ';
            $qry .= ' ogre_gameschedule.gs_complexity =  ' . $ci->proposal->complexity_rating . ', ';
            $qry .= ' ogre_gameschedule.gs_puzzle_solving =  ' . $ci->proposal->puzzle_rating . ', ';
            $qry .= ' ogre_gameschedule.gs_max_number_of_players =  ' . $ci->proposal->max_number_of_players . ', ';
            $qry .= ' ogre_gameschedule.gs_date_last_modified = NOW() ';
            $qry .= '  WHERE ogre_gameschedule.gs_id = ' . $geid;                         
            $ci->db->query($qry);           
            $ret2 = ($ci->db->affectedRows() > 0) ? TRUE : FALSE;            
            $ci->person->init($conid, '', $ci->proposal->gm_id);            
            $p['pname']=$ci->person->fullname;
            $p['pemail']=$ci->person->email;            
            $p['userID']=$ci->person->user_id_num;
            $p["playgm"]='0';
            $p["activity2"]='Judge';
            $p["pnotes"] ='';         
            $ret3=$ci->schedule_lib->preregAction(TRUE, $p, $geid);
            $ret4=$ret1&&$ret2&&$ret3['result'];
            return $ret4;
    }      
        
        
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
    public function removePlayer($prid, $pid=0, $gid=0){  
        $ci = &get_instance();
        $ret = TRUE;                                 
        if ((trim($prid) != "0") || (trim($pid) != "0")){			
               $qry1 = ' UPDATE ogre_prereg_player ' . ' SET pp_delete_flag = 1 ';
               $qry1 .= ($prid !== 0) ? ' WHERE pp_player_prereg_id = ' . $prid : ' WHERE pp_gs_id =' . $gid . ' AND pp_player_id=' . $pid;               

               $ci->db->query($qry1);
               $ret = ($ci->db->affectedRows() > 0)?TRUE:FALSE;              
               if($ret === TRUE){
                    $sql='SELECT * ' . ' FROM ogre_prereg_multislot WHERE pms_slot1_id = ' . $prid;
                    $query = $ci->db->query($sql);
                    if ($query->getNumRows() > 0){        
                        foreach ($query->result_array() as $row){
                            for ($x = 2; $x <= 18; $x++) {
                                if($row['pms_slot'.$x.'_id'] != 0 ){
                                    $qry2 = ' UPDATE ogre_prereg_player ' . ' SET pp_delete_flag = 1, pp_datemodified = NOW() ' . ' WHERE pp_player_prereg_id = ' . $row['pms_slot'.$x.'_id'];                              
                                    $ci->db->query($qry2);                              
                                }                      
                            }
                        }                     
                    }           
               }
               $ret2 = ($ci->db->affectedRows() > 0)?TRUE:FALSE;
        }
        return $ret; 
    }   
   
   
//***********************************
//
//
//
//***********************************               
        public function promote_alternate($id){
            $ci = &get_instance();
            $plist = $this->getPlayerList(0, $id, '0');
            if($plist[1][0] != "-"){
                $qry = "UPDATE ogre_prereg_player SET ";
                $qry .= " pp_player_confirmed = 1 ";
                $qry .= " WHERE pp_player_prereg_id = " . $plist[1][0] . ";"; 
                $ci->db->query($qry);
            }
            return ($ci->db->affectedRows() > 0)? TRUE :FALSE;
        }  
        
//---------------------------------------------------
//
//  
//
//---------------------------------------------------       
    public function get_gsid_from_prereg($id){
        $ci = &get_instance();
        $sql = 'SELECT pp_gs_id FROM ogre_prereg_player ';
        $sql .= ' WHERE pp_player_prereg_id = ' . $id;
        $query = $ci->db->query($sql);
        $ret = 0;
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $ret = $row->pp_gs_id;
            }
        }
      return $ret;  
    }            
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
        public function basicinfo_array($gameid=0){            
            if($this->id==0){
                $this->event_init($gameid);
            }
            $ret=array();           
            $ret['game_name'] = $this->game_name;
            $ret['game_title'] = $this->game_title;
            $ret['slot_day'] = $this->slot_day;
            $ret['slot_time'] = $this->slot_time;
            $ret['convention_name'] = $this->convention_name;
            return $ret; 
        }        
        
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
        public function generate_opgridid($gameid=0){
            if($this->id==0){
                $this->event_init($gameid);
            }           
            $ret = $this->slot_day.$this->row_enum.$this->affiliation.$this->slot_enum;           
            return $ret;
        }

//---------------------------------------------------
//
//  
//
//---------------------------------------------------       
        public function get_gs_gn_id($gameid){
            $ci = &get_instance();
            $sql = 'SELECT gs_gn_id FROM ogre_gameschedule ';
            $sql .= ' WHERE gs_id = ' . $gameid;
            $query = $ci->db->query($sql);
            $gn='0';
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                    $gn = $row->gs_gn_id;
                }
            }
          return $gn;  
        }        
        
         
        //---------------------------------------------------
        //
        //  
        //
        //---------------------------------------------------       
        public function get_grid_neighbors($gameid){
            $ci = &get_instance();
            $conid = $ci->session->ogre_conid;
            $sql = 'SELECT gs_id FROM ogre_gameschedule ';
            $sql .= ' WHERE gs_convention_id = ' . $conid;
            $sql .= ' AND gs_cancelled = 0 ';
            $sql .= ' AND gs_row_enum = (SELECT gs_row_enum FROM ogre_gameschedule WHERE gs_id = ' . $gameid .') ';
            $sql .= ' AND gs_affiliation = (SELECT gs_affiliation FROM ogre_gameschedule WHERE gs_id = ' . $gameid . ') ';
            $sql .= ' AND gs_slot_day = (SELECT gs_slot_day FROM ogre_gameschedule WHERE gs_id = ' . $gameid . ') ';
//                    $sql .= ' AND gs_id <> ' . $gameid ;

            $query = $ci->db->query($sql);
            $gn='';
            if ($query->getNumRows() > 0)
            {
                foreach ($query->getResult() as $row)
                {
                    $gn .= $row->gs_id .',';
                }
            }
          return $gn;  
        }
        //---------------------------------------------------
        //
        //  
        //
        //---------------------------------------------------           
        public function registerPlayerFooter($admin, $gid=0){
            $ret='';           
            if($admin===FALSE){
                $ret .= '<table class="prereginfo">';
                $ret .= '<tr>';                      
                $ret .='<td class="leftsidebutton">';              
                $ret .='</td>';
                $ret .='<td class="rightsidebutton">';

                $ret .='</td>';
                $ret .='</tr>';
                $ret .='</table>';                
                
            }
//            else{
//                $rpga_addplayer  =  site_url("ogrex/adminAddPlayer");
//                $rpga_viewplayer  =  site_url("ogrex/adminViewPlayer");
//            }
            return $ret;
        }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------                
        public function getPreregPlayersAllowed($gid = 0){          
            $ci = &get_instance();
            $gid = intval($gid);
            $qry = 'SELECT * ';
            $qry .= ' FROM ogre_preregistergamelist ';
            $qry .= ' WHERE pgl_gs_id = ' . ((intval($gid) == 0)? $this->id : $gid);
            $query = $ci->db->query($qry);
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                    $this->prereg_id = $row->pgl_prereg_id;
                    $this->prereg_notes = $row->pgl_prereg_notes;
                    $this->prereg_contact = $row->pgl_contact_email;
                    $this->prereg_players_allowed = $row->pgl_number_of_preregs_allowable;
                    $this->prereg_opentoalt = $row->pgl_opentoalt;
                }
            }
            else{
                $this->prereg_id = 0;
                $this->prereg_notes = '';
                $this->prereg_contact = '';
                $this->prereg_players_allowed = 0;
                $this->prereg_opentoalt = 0;
            }      
            $ret = $this->prereg_players_allowed;
            return $ret;
        }

//---------------------------------------------------
//
//  
//
//---------------------------------------------------                
        public function is_new($gid, $days){            
            $ret = FALSE;
            $ci = &get_instance();
            $qry = "SELECT gs_id, gs_date_last_modified FROM ogre_gameschedule WHERE gs_id = " . $gid ;
            $qry .= ' AND ogre_gameschedule.gs_date_last_modified > SUBDATE(CURDATE(), INTERVAL '. $days.' DAY) ';           
            $query = $ci->db->query($qry);
            if ($query->getNumRows() > 0){
                $ret = TRUE;
            }           
            return $ret;
        }       
        
    //------------------------
    //
    //
    //
    //------------------------              
    public function get_eventinfo($gid=0, $gsfield=""){
        $ci=&get_instance();
        if ($gid == 0){
            $gid = $this->id;
        }
        $qry_pgl = "SELECT " . $gsfield .  " FROM ogre_gameschedule WHERE gs_id = " . $gid ;
        $query = $ci->db->query($qry_pgl);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){            
                $ret = $row->$gsfield;
            }
        }
        return $ret;
    }   
    //------------------------
    //
    //
    //
    //------------------------              
    public function getEventPreregInfo($gid=0, $gsfield=""){
        $ci=&get_instance();
        $ret = '';
        if ($gid == 0){
            $gid = $this->id;
        }
        $qry = "SELECT " . $gsfield .  " FROM ogre_preregistergamelist WHERE pgl_gs_id = " . $gid ;
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){            
                $ret = $row->$gsfield;
            }
        }
        return $ret;
    }         
//------------------------
//
//
//
//------------------------              
    public function getMultiSlotChildren($gid){
        $ci=&get_instance();
        $ret='';
	$qry = 'SELECT rgs_2slot_gs_id, rgs_gs_id ';
        $qry .= ' FROM ogre_rpga_game_setup ';
        $qry .= ' WHERE rgs_2slot_gs_id = ' . $gid ;
        $qry .= ' ORDER BY ogre_rpga_game_setup.rgs_game_setup_id ';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $ret .= $row->rgs_gs_id . ',';
            }
        }
        return $ret;
    }
    
//---------------------------------------------------
//
//  
//
//---------------------------------------------------		
    public function update_prereg_GMstatus($ppid, $status=1){
        $ci=&get_instance();
        $qry = ' UPDATE ogre_prereg_player ';
        $qry .= ' SET ogre_prereg_player.pp_gm_judge_flag = ' . $status . ' ';
        $qry .= ' WHERE ogre_prereg_player.pp_player_prereg_id = ' . $ppid . '; ';

        $ci->db->query($qry);
        $ret = ($ci->db->affectedRows() > 0) ? TRUE : FALSE;
        return $ret;
    } 
//---------------------------------------------------
//
//  
//
//---------------------------------------------------		
    public function update_displaymode($gsid, $dmode="P"){
        $ci=&get_instance();
        $qry = ' UPDATE ogre_gameschedule ';
        $qry .= ' SET ogre_gameschedule.gs_displaymode = "' . $dmode . '" ';
        $qry .= ' WHERE ogre_gameschedule.gs_id = ' . $gsid . '; ';

        $ci->db->query($qry);
        $ret = ($ci->db->affectedRows() > 0) ? TRUE : FALSE;
        return $ret;
    }       
    
//---------------------------------------------------
//
//  
//
//---------------------------------------------------		
    public function uniqueinstance_gm($pid, $gid){
//        $ci=&get_instance();
        $ret = FALSE;
        if($this->id == 0){
            $this->event_init($gid);
        }
        $gm = $this->isPlayerGM($pid, $gid);
        $op = $this->mmrpgFlag;
        if((intval($gm)==1) && (intval($op)==0)){
            $ret = TRUE;
        }
        return $ret;
    }
}  /*  END GAME_EVENT CLASS */