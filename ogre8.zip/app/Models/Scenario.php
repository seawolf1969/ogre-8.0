<?php 
namespace App\Models;
use CodeIgniter\Model;
use CodeIgniter\I18n\Time;

    class Scenario extends Model{
        var $id=0;
        var $scenario_name='';
        var $apl_low=0; 
        var $apl_high=0; 
        var $level_range='';
        var $explevel=''; 
        var $scenario_author=''; 
        var $scenario_desc=''; 
        var $pregens=0; 
        var $convention_id=0; 
        var $affiliation='';
        var $number_of_slots=0;
        var $slot_length;
        var $game_name='';
        var $game_id=0;
        
//------------------------------------------------
//
//------------------------------------------------ 
    public function __construct()
    {

    }	        
        		
//---------------------------------------------------
//
//---------------------------------------------------
    public function init($scenarioid, $conid){
        $ret = '';
        if ($scenarioid > 0){
            $ret = $this->getScenarioData($scenarioid, $conid);
        }                   
        return $ret;
    }
//------------------------------------------------
//
//------------------------------------------------   
    private function getScenarioData($scenid, $conid){
        $ci = &get_instance();
        $qry = "SELECT ogre_rpga_scenario_setup.*";
        $qry .= " FROM ogre_rpga_scenario_setup    ";
        $qry .= " WHERE ogre_rpga_scenario_setup.rss_scenario_id = " . $scenid;
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $this->id = $row->rss_scenario_id;
                $this->scenario_name = $row->rss_scenario_name;
                $this->apl_low = $row->rss_apl_low;
                $this->apl_high = $row->rss_apl_high;
                $this->level_range = $row->rss_level_range;
                $this->explevel = $row->rss_exp_level;
                $this->scenario_author = $row->rss_scenario_author;
                $this->scenario_desc = ascii_to_entities($row->rss_scenario_desc);
                $this->pregens = $row->rss_pregens;
                $this->convention_id = $row->rss_convention_id;
                $this->affiliation = $row->rss_affiliation;
                $this->number_of_slots = $row->rss_number_of_slots;
                $this->slot_length = $row->rss_slotlength;
                $this->game_name = $row->rss_campaign_name;
                $this->game_id = $row->rss_campaign_id;
            }
        }                    
        return $query->getNumRows();
    }
//------------------------------------------------
//
//------------------------------------------------   
    public function getNumberOfPlayers($gm=0){
        $ci = &get_instance();
        $qry = "SELECT DISTINCT ogre_prereg_player.pp_player_name ";
        $qry .= " FROM ogre_gameschedule, ogre_prereg_player, ogre_rpga_scenario_setup,  ogre_rpga_game_setup ";  
        $qry .= " WHERE ogre_gameschedule.gs_id = ogre_rpga_game_setup.rgs_gs_id ";
        $qry .= " AND ogre_rpga_game_setup.rgs_scenario_id = ogre_rpga_scenario_setup.rss_scenario_id ";
        $qry .= " AND ogre_prereg_player.pp_gs_id = ogre_gameschedule.gs_id ";
        $qry .= " AND ogre_prereg_player.pp_gm_judge_flag  = " . $gm;
        $qry .= " AND ogre_prereg_player.pp_delete_flag = 0";
        $qry .= " AND ogre_rpga_game_setup.rgs_scenario_id = " . $this->id;                   
        $query = $ci->db->query($qry);
        return $query->getNumRows();
    }
//------------------------------------------------
//
//------------------------------------------------  
    public function getNumberOfTable(){
        $ci = &get_instance();
        $qry = 'SELECT Sum(ogre_rpga_game_setup.rgs_number_of_tables) AS SumOfNumberOfTables ';
        $qry .= ' FROM ogre_gameschedule, ogre_rpga_game_setup ';
        $qry .= ' WHERE ogre_gameschedule.gs_id = ogre_rpga_game_setup.rgs_gs_id AND ogre_gameschedule.gs_cancelled=0 AND ogre_rpga_game_setup.rgs_scenario_id  = ' . $this->id .';';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $ret = ((intval($this->number_of_slots)!== 0) ? intval($row->SumOfNumberOfTables) / intval($this->number_of_slots) : 0);
            }
        }
        else{
            $ret = 0;
        }	 	    
        return $ret;
    }
//------------------------------------------------
//
//------------------------------------------------               
    function scenarioAlreadyOnfile($p, $conid){
        $ci = &get_instance();
        $ret = array();
        $ret['valid'] = TRUE;
        $ret['errmsg'] = '';
        $qry = 'SELECT * ';
        $qry .= ' FROM ogre_rpga_scenario_setup ';
        $qry .= ' WHERE rss_scenario_name = "' . $p["scenarioName"] . '" ';
        $qry .= ' AND rss_convention_id = ' . $conid;
        $qry .= ' AND rss_deleteflag = 0 ';
        $qry .= '  AND rss_campaign_id = ' . $p['campaign'];
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            $ret['valid'] = FALSE;
            $ret['errmsg'] = '<br />' . $p["scenarioName"] . ': Scenario Exists on file for this con/event.';
        }
        return $ret; 
    }
//------------------------------------------------
//
//------------------------------------------------ 
    public function insertScenario($p){                   
        $ci = &get_instance();
        $conid = $ci->session->ogre_conid;  
        $ret = array();
        $ret['valid'] = TRUE;
        $ret['msg']='';
        $this->game->init($p['campaign']);
        $campaignname = $this->game->game_name;
        $gameaffiliation = $this->game->game_affiliation;                    
        $p["scenarioBlurb"] = (trim($p["scenarioBlurb"]) != '') ? $p["scenarioBlurb"] = quotes_to_entities($p["scenarioBlurb"]) : '';
        if (trim($p["scenarioName"]) === ''){
            $ret['valid'] = FALSE;
            $ret['msg'] .= "Scenario Name Required <br />";
        }

        if ($p["campaign"] === '0'){
            $ret['valid'] = FALSE;
            $ret['msg'] .= "Campaign Required <br />";
        }
        $scenonfile = $this->scenarioAlreadyOnfile($p, $conid);
        $ret['valid'] = $ret['valid'] && $scenonfile['valid'];
        $ret['msg'] .= $scenonfile['errmsg'];
        if ($ret['valid'] == TRUE){
            $qry = 'INSERT INTO ogre_rpga_scenario_setup ';
            $qry .= '(rss_scenario_name, ';
            $qry .= ' rss_scenario_desc, ';
            $qry .= ' rss_exp_level, ';
            $qry .= ' rss_affiliation, ';
            $qry .= ' rss_convention_id, ';
            $qry .= ' rss_campaign_name, ';
            $qry .= ' rss_campaign_id, ';
            $qry .= ' rss_slotlength, ';
            $qry .= ' rss_number_of_slots ) ';
            $qry .= ' VALUES (';
            $qry .= '"' . htmlspecialchars($p["scenarioName"], ENT_QUOTES) . '", ';
            $qry .= '"' . $p["scenarioBlurb"] . '", ';
            $qry .= '"' . $p["exp-level"] . '", ';
            $qry .= '"' . $gameaffiliation . '", ';
            $qry .= $conid .  ', ';
            $qry .= '"' . $campaignname . '", ';
            $qry .= '"' . $p['campaign'] . '", ';
            $qry .= '' . $p['gameslotlength'] . ', ';
            $qry .= $p["numofslots"] . ")";
            $ci->db->query($qry);
            $ret['msg'] = ($ci->db->affectedRows() > 0) ? 'Scenario Added.<br />' : 'Error in Add: ' . $qry;
            $ret['valid'] = ($ci->db->affectedRows() > 0) ? TRUE : FALSE;
        }
        return $ret;
    }
//------------------------------------------------
//
//------------------------------------------------  
        public function saveScenario($p){
            $ret = ($p['scenid'] == 0) ?  $this->insertScenario($p) :  $this->saveScenarioInfo($p);
            return $ret;
        }
//------------------------------------------------
//
//------------------------------------------------ 
    public function saveScenarioInfo($p){
        $ci = &get_instance();
                    
        $ret['valid'] = TRUE;
        $ret['msg']='';
        $p["scenarioName"] = quotes_to_entities($p["scenarioName"]);
        $this->game->init($p['campaign']);
        $campaignname = $this->game->game_name;
        $gameaffiliation = $this->game->game_affiliation;
        $scenarioBlurb = $p["scenarioBlurb"];
        if (trim($scenarioBlurb) != ''){
            $scenarioBlurb = quotes_to_entities($scenarioBlurb);  
        }
        $ret['valid'] = (trim($p["scenarioName"]) == '') ? $ret['valid'] = FALSE : $ret['valid'] = $ret['valid'];
        $bScenarioNameChange = (trim($p["scenarioName"]) != ($this->scenario_name)) ? TRUE : FALSE;
                    if ($ret['valid'] == TRUE){ 
                        $ci->db->transStart();
                        if ($bScenarioNameChange == TRUE){
                            if(intval($this->number_of_slots) === 1){
                                $qry1 = "UPDATE ogre_gameschedule ";
                                $qry1 .= ' SET ogre_gameschedule.gs_game_title = "' . $p["scenarioName"] . '",';
                                $qry1 .= ' ogre_gameschedule.gs_date_last_modified = NOW() ';
                                $qry1 .= ' WHERE ogre_gameschedule.gs_game_title ="' . $this->scenario_name .'";';
                                $ci->db->query($qry1);
                            }
                            else{
                                for($i=1;$i<=intval($this->number_of_slots);$i++){
                                    $qry2 = "UPDATE ogre_gameschedule ";
                                    $qry2 .= ' SET ogre_gameschedule.gs_game_title = "' . $p["scenarioName"] . ' (Round '.$i.')", ';
                                    $qry2 .= ' ogre_gameschedule.gs_date_last_modified = NOW() ';
                                    $qry2 .= ' WHERE ogre_gameschedule.gs_game_title ="' . $this->scenario_name .' (Round '.$i.')";';
                                    $ci->db->query($qry2);      
                                }
                            }
                        }
                    
                        $qry = "UPDATE ogre_rpga_scenario_setup ";
                        $qry .= ' SET ogre_rpga_scenario_setup.rss_scenario_name = "' . $p["scenarioName"] . '",';
                        $qry .= ' ogre_rpga_scenario_setup.rss_exp_level = "' . $p["explevel"] . '", ';
                        $qry .= ' ogre_rpga_scenario_setup.rss_scenario_desc = "' . $scenarioBlurb . '",';
                        $qry .= ' ogre_rpga_scenario_setup.rss_affiliation  = "' . $gameaffiliation . '",';
                        $qry .= ' ogre_rpga_scenario_setup.rss_campaign_name  = "' . $campaignname . '" ';
                        $qry .= ' WHERE ogre_rpga_scenario_setup.rss_scenario_id = ' . $this->id;
                        $ci->db->query($qry);
                        $ret['msg'] = ($ci->db->affectedRows() > 0) ?  '' : "Error in updateing scenario information.";
                        $ret['valid'] = ($ci->db->affectedRows() > 0) ?  TRUE : FALSE;
                        $ci->db->transComplete();
                    }
                    else{
                        $ret['valid'] = FALSE;
                        $ret['msg'] = 'Scenario Name can not be blank!';
                    }
                    return $ret;
                }
                
//------------------------------------------------
//
//------------------------------------------------
                public function removeScenario($sid=0){
                    $ci = &get_instance();
                    if($sid==0){
                        $sid = $this->id;
                    }                    
                    $qry = 'SELECT ogre_gameschedule.gs_id ';
                    $qry .= ' FROM ogre_gameschedule, ';
                    $qry .= ' ogre_rpga_game_setup  ';
                    $qry .= ' WHERE ogre_gameschedule.gs_id = ';
                    $qry .= ' ogre_rpga_game_setup.rgs_gs_id ';
                    $qry .= ' AND ogre_rpga_game_setup.rgs_scenario_id = ' . $sid;
                    $query = $ci->db->query($qry);
                    if ($query->getNumRows() > 0){
                            foreach ($query->getResult() as $row){
                                $ci->event->event_init($row->gs_id);
                                $ci->event->removeGame();
                            }
                            $ret = $this->deleteScenario();
                    }
                    else{
                        $ret = $this->deleteScenario();
                    }
                    return $ret;
                }                
//------------------------
//
//------------------------
    public function removeScenarioCheck($sid=0){
        $ci = &get_instance();
        $ret = 0;
        $sid = ($sid==0) ? $this->id : $sid;
        $qry = 'SELECT ogre_gameschedule.gs_id ';
        $qry .= ' FROM ogre_gameschedule, ';
        $qry .= ' ogre_rpga_game_setup  ';
        $qry .= ' WHERE ogre_gameschedule.gs_id = ';
        $qry .= ' ogre_rpga_game_setup.rgs_gs_id ';
        $qry .= ' AND ogre_rpga_game_setup.rgs_scenario_id = ' . $sid;
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            $ret = $query->getNumRows();
        }
        return $ret;
    }
//------------------------
//
//------------------------
    private function deleteScenario($sid=0){
        $ci = &get_instance();
        $sid = ($sid==0) ? $this->id : $sid;              
        $done = FALSE;
        $qry = 'UPDATE ogre_rpga_scenario_setup ';
        $qry .= ' SET rss_deleteflag = 1 ';
        $qry .= ' WHERE rss_scenario_id = ' . $sid;
        $ci->db->query($qry);
        if ($ci->db->affectedRows() > 0){
            $done = TRUE;
        }
        return $done;
    }
//------------------------
//
//------------------------
    public function getSlots($session){
        $ci = &get_instance();
        $orgid = $ci->session->ogre_orgid;
        $conid = $ci->session->ogre_conid;  
        $qry = "SELECT DISTINCT ogre_gameschedule.gs_slot_day, ogre_gameschedule.gs_slot_start_time, ";
        $qry .= " ogre_gameschedule.gs_slot_code, ogre_gameschedule.gs_slot_time, ogre_gameschedule.gs_slot_length ";
        $qry .= " FROM ogre_gameschedule, ogre_rpga_game_setup ";
        $qry .= " WHERE  ogre_gameschedule.gs_id = ogre_rpga_game_setup.rgs_gs_id ";
        $qry .= " AND rgs_scenario_id = " . $this->id;
        $qry .= " AND rgs_active = 1 ";
        $qry .= " AND ogre_gameschedule.gs_convention_id = " .  $conid;
        $qry .= " ORDER BY ogre_gameschedule.gs_slot_code";
        $query = $ci->db->query($qry);
        $slots = array();
        $i = 1;
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $slots[$i][1] = $row->gs_slot_code;
                $slots[$i][2] = $row->gs_slot_day;
                $slots[$i][3] = $row->gs_slot_start_time;
                $slots[$i][4] = $row->gs_slot_length;
                $slots[$i][5] = $row->gs_slot_time;
                $i++;
            }
        }
        return $slots;
    }

//------------------------
//
//------------------------
    public function getSlotsArray(){
        $ci=get_instance();
        $conid = $ci->session->ogre_conid;  
        $qry = 'SELECT DISTINCT ogre_gameschedule.gs_slot_day, ';
        $qry .= ' ogre_gameschedule.gs_slot_start_time, ';
        $qry .= ' ogre_gameschedule.gs_slot_code, ';
        $qry .= ' ogre_gameschedule.gs_slot_time, ';
        $qry .= ' ogre_gameschedule.gs_slot_length ';
        $qry .= ' FROM ogre_gameschedule, ogre_rpga_game_setup ';
        $qry .= ' WHERE  ogre_gameschedule.gs_id = ogre_rpga_game_setup.rgs_gs_id ';
        $qry .= ' AND rgs_scenario_id = ' . $this->id;
        $qry .= ' AND rgs_active = 1 ';
        $qry .= ' AND ogre_gameschedule.gs_convention_id = ' .  $conid;
        $qry .= ' AND ogre_gameschedule.gs_cancelled = 0 ';
        $qry .= ' ORDER BY ogre_gameschedule.gs_slot_code';
        $query = $ci->db->query($qry);
        $slots = array();
        $i = 1;
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $slots[$i] = $row->gs_slot_code;
                $i++;
            }
        }
        return $slots;
    }
//------------------------
//
//------------------------
    public function scenarioAdminForm($scenid=0, $copy=FALSE){
        $ci=get_instance();
        $j = 1;
        $ret = '';
        $addscenario = site_url("ogrex/scenarioIn",'https');
        $listrefresh = site_url("ogrex/scenarioList",'https');
        $refreshscen  = site_url("ogrex/currentScenarioList",'https');
        $resetform = site_url("ogrex/resetScenarioForm/",'https');
        $delscenario = site_url('ogrex/scenarioDel/','https');
        $conid = $ci->session->ogre_conid;       
        if($scenid != 0){
            $this->init($scenid, $conid);
        }      
        $refreshafffilter = site_url("ogrex/refreshGameAdminFilter",'https');
        $ret .= '<div id="add-scenario-button">';                 
        $ret .= '<input class="btn btn-primary" type="button" name="show-scenario-admin" id="show-scenario-admin" value=" * New Scenario * " onclick="showScenarioAdmin('."'".$resetform."'".');"/>';                    
        $ret .= '</div>';
        $ret .= '<div id="scenario-admin-table">';            
        $ret .= '<div id="results" class="results"></div>';
        $ret .= '<form id="scenario-admin-form" name="scenario-admin-form" method="POST" action="">';
        $ret .=  ($scenid != 0 && $copy===FALSE) ? '<p><strong>Modify a Scenario</strong>: ' : '<p><strong>Add a Scenario</strong>: ';
        $ret .= ' Use this form to add, remove and modify Organized Play Scenarios.  Click [...] to select an existing scenario.</p>';
        $ret .= '<label id="scn-label1" for="">Scenario Name</label> ';
        $existaction = 'ogrex/getExistingScenarios';
        $infoaction = 'ogrex/getScenarioInfo';
        $ret .= '<div class="input-group mb-3">';
        $ret .= (($scenid != 0) ? '<input class="form-control m-2" type="text" id="scenarioName" name="scenarioName" value="' . $this->scenario_name . '" maxlength="80">' :  '<input class="form-control m-2" type="text" id="scenarioName" name="scenarioName" value="" maxlength="80" />');
        $ret .= (($scenid != 0) ? '' : '<button type="button" class="btn btn-secondary m-2" name="open-exist-scenario" id="open-exist-scenario" onclick="openExistingScenario('."'".site_url($existaction,'https')."','".site_url($infoaction,'https')."','".site_url($resetform,'https')."'".');">...</button>');
        $ret .= '</div>';
        $ret .= '<label for="campaign" id="scn-label2">Campaign Name</label>';
        $cgn = ($scenid != 0)? $this->game_name: '~';
        $ret .= $this->getCampaignSelect($cgn);
        $ret .= '<div class="card m-2"><div class="card-body" id="scenario-description-card">';
        $ret .= '<label for="scenarioBlurb" id="scn_label2">Scenario Description</label>';            
        $ret .= ($scenid != 0) ? '<textarea id="scenarioBlurb" name="scenarioBlurb" wrap="soft">' . $this->scenario_desc . '</textarea>' : '<textarea id="scenarioBlurb" name="scenarioBlurb" wrap="soft"></textarea>';                   
        $ret .= '</div></div>';  
        $ret .= '<label for="exp-level" id="scn-label4">Experience Level</label>';                    
        if ($scenid != 0){
            $ret .= '<input class="form-control m-2" name="exp-level" id="exp-level" type="text" maxlength="50" value="' . $this->explevel . '"/>';
        }
        else{  
            $ret .= '<input class="form-control m-2" name="exp-level" id="exp-level" type="text" maxlength="50" value=" " />';
        }
        $ret .= '<label for="numofslots">Number of Slots:</label>';
        $ret .= $this->numOfSlotsSelect($scenid,$copy, $this->number_of_slots);
        $ret .= '<label for="gameslotlength">Slot Length in Hours:</label>';    
        $ret .= (($copy===FALSE) ? (($scenid != 0)? $ci->event->getSlotLengthSelect($this->slot_length, FALSE) . "*" : $ci->event->getSlotLengthSelect()) : $ci->event->getSlotLengthSelect($this->slot_length));
        if ($scenid != 0){                    
            $nslots_msg = $ci->ogre_lib->getMiscContent("%SLOT_CHANGE_NOTES%");                    
            $ret .= $nslots_msg['content'] ;
        }
        if ($scenid != 0 && $copy===FALSE){
            $ret .= '<input type="hidden" id="scenid" name="scenid" value="' . $scenid . '" />';                      
        }
        else{
            $ret .= '<div class="d-grid gap-2"><button class="btn btn-success m-2" type="button" id="Addnew" name="Addnew" onclick="addScenario('."'".$addscenario."','".$listrefresh."','".$resetform."','".$refreshscen."','".$refreshafffilter."'".');">+ Add Scenario +</button></div>';
            $ret .= '<input type="hidden" id="scenid" name="scenid" value="0" />';
        }

        $ret .= '<div class="d-grid gap-2" id="scenario-done-button">';
        $ret .= '<button class="btn btn-secondary m-2" type="button" name="hide-scenario-admin" id="hide-scenario-admin" onclick="hideScenarioAdmin('."'".$resetform."'".');">Done Adding</button>';
        $ret .= '</div>';                     
        $ret .= '</form>';
        $ret .= '</div>';
        return $ret;
    }
//------------------------
//
//------------------------
    private function numOfSlotsSelect($scenid=0,$copy=FALSE, $slotsval=0){
        $ret = '';    
        if ($scenid != 0){
            $ret .= (($copy===FALSE) ? '<select class="form-control m-2" id="numofslots" name="numofslots" disabled=""disabled> *' : '<select class="form-control m-2" id="numofslots" name="numofslots" >');
            for($i=1;$i<=3;$i++){
                if($i===intval($slotsval)){
                    $ret .= '<option selected="selected" value="'.$i.'">  '.$i.' Slots</option>';
                }else{
                    $ret .= '<option value="'.$i.'">  '.$i.' Slots</option>';
                }
            }
            $ret .= '</select>';                        
        }
        else{                        
            $ret .= '<select class="form-control m-2" id="numofslots" name="numofslots" >';
            $ret .= '<option selected="selected" value="1">  1 Slots</option>';
            $ret .= '<option value="2">  2 Slots</option>';
            $ret .= '<option value="3">  3 Slots</option>';
            $ret .= '</select>';
        }
                    
        return $ret;
    }            
                
                
//------------------------
//
//------------------------
        public function scenarioListAdmin($aff="0"){
            $ci = &get_instance();
            $conid = $ci->session->ogre_conid;  
            $lclRPGAscenadmin = site_url("ogrex/scenario_edit/",'https');
            $lclRPGAscensave = site_url("ogrex/scenarioIn/",'https');
            $lclRPGAscenreset = site_url("ogrex/resetScenarioForm/",'https');
            $listrefresh = site_url("ogrex/scenarioList",'https');
            $checkaction = site_url("ogrex/scenario_check",'https');
            $delaction = site_url('ogrex/scenarioDel/','https');
            $qry = 'SELECT ogre_rpga_scenario_setup.rss_scenario_id FROM ogre_rpga_scenario_setup ';
            $qry .= ' WHERE ogre_rpga_scenario_setup.rss_convention_id =' . $conid;
            $qry .= ' AND ogre_rpga_scenario_setup.rss_deleteflag = 0 ';
            $qry .= ' AND ogre_rpga_scenario_setup.rss_affiliation = "' . $aff . '" ';
            $qry .= ' ORDER BY ogre_rpga_scenario_setup.rss_affiliation,  ogre_rpga_scenario_setup.rss_scenario_name;';
            
            $ret='';
            if($aff !== "0"){
                $scen = $ci->db->query($qry);
                $ret .= '<div class="table-responsive">';
                $j = 0;
                $lastaff = '-1';

                $ret .= '<table class="table table-striped" id="scenario-list">';
                if ($scen->getNumRows() > 0){
                    foreach ($scen->getResult() as $row){
                        $scenid1 = $row->rss_scenario_id;
                        $this->init($scenid1, $conid);
                        if ($lastaff != trim($this->affiliation)){                             
                            $ret .= '<thead>';
                            $ret .= '<th class="" colspan="6">' . $this->affiliation . '</th>';
                            $ret .= '</thead>';
                            $ret .= '<thead>';
                            $ret .= '<th class="scenarioname"><strong>Scenario</strong></th>';
                            $ret .= '<th class="experiencelevel"><strong>Slot Length (Hrs)</strong></th>';
                            $ret .= '<th class="experiencelevel"><strong>Exp</strong></th>';
                            $ret .= '<th class="tablenumber"><strong>Num</strong><br><strong>Tables</strong></th>';
                            $ret .= '<th class="judgenumber"><strong>Num</strong><br /><strong>Judges</strong></th>';
                            $ret .= '<th class="playernumber"><strong>Num</strong><br /><strong>Players</strong></th>';
                            $ret .= '</thead>';
                        }               
                        $ret .= '<tr>';
                        $ret .= '<td>';
                        $ret .= '<p>';                                          // sid, action, saveaction, listrefresh, checkaction, deleteaction, resetaction $lclRPGAscenreset
                        $ret .= '<a href="#" onclick="return openScenarioEdit('.$this->id.",'".$lclRPGAscenadmin.'/'.$this->id ."','".$lclRPGAscensave."','".$listrefresh."','".$checkaction."','".$delaction."','".$lclRPGAscenreset."'".');">' . $this->scenario_name . '</a>';
                        $ret .= '</p>';
                        $ret .= '</td>';
                        $ret .= '<td>';
                        $ret .= $this->slot_length . ' (x' . $this->number_of_slots . ')';
                        $ret .= '</td>';                        
                        $ret .= '<td>';
                        $ret .= $this->explevel;
                        $ret .= '</td>';
                        $ret .= '<td>';
                        $ret .= $this->getNumberOfTable();
                        $ret .= '</td>';
                        $ret .= '<td>';
                        $ret .= $this->getNumberOfPlayers(1);
                        $ret .= '</td>';
                        $ret .= '<td>';
                        $ret .= $this->getNumberOfPlayers(0);
                        $ret .= '</td>';
                        $lastaff = trim($this->affiliation);
                        $j++;
                    }
                    $ret .= '</tr></table>';
                }
                $ret .= '</div>';
            }
            return $ret;
        }
        //------------------------
        //
        //
        //
        //------------------------        
        public function getAllSlotHours(){
            $ci=&get_instance();           
            $conid = $ci->session->ogre_conid;            
            $ret=array();
            $i=0;
            $qry = 'SELECT DISTINCT ogre_rpga_scenario_setup.rss_slotlength FROM ogre_rpga_scenario_setup ';
            $qry .= ' WHERE ogre_rpga_scenario_setup.rss_convention_id =' . $conid;
            $qry .= ' AND ogre_rpga_scenario_setup.rss_deleteflag = 0 ';
            $qry .= ' ORDER BY ogre_rpga_scenario_setup.rss_slotlength;';
            $query = $ci->db->query($qry);            
             if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){                  
                    $ret[$i]=$row->rss_slotlength;
                    $i++;
                }           
            }          
            return $ret;
        }        
        //------------------------
        //
        //
        //
        //------------------------               
        public function existingScenarioList($aff=''){
            $ci=&get_instance();                 
            $scenario=array();
            $ret='';
            $i=0;
            $last = '';
            $qry = 'SELECT ogre_rpga_scenario_setup.rss_scenario_id, ';
            $qry .= ' ogre_rpga_scenario_setup.rss_scenario_name ';
            $qry .= ' FROM ogre_rpga_scenario_setup ';
            if($aff != ""){
                $qry .= ' WHERE ogre_rpga_scenario_setup.rss_affiliation ="' . $aff . '" ';
            }
            $qry .= ' ORDER BY ogre_rpga_scenario_setup.rss_scenario_name, rss_scenario_id;';
            $query = $ci->db->query($qry);            
             if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                    if ($last !=$row->rss_scenario_name){
                        $scenario[$i]['id']=$row->rss_scenario_id;
                        $scenario[$i]['title']=$row->rss_scenario_name;
                    }
                    $last = $row->rss_scenario_name;
                    $i++;
                }           
            }
            $infoaction = 'ogrex/getScenarioInfo';
            $ret .= '<label for="existingscenarios">Select the Scenario from those already on file</label>';          
            $ret .= '<select class="form-select m-3" id="existingscenarios" name="existingscenarios" size="8">';
            foreach ($scenario as $scen){           
                    $ret .= '<option value="'.$scen["id"].'">'.$scen["title"].'</option>';
            }        
            $ret .= '</select>';              
            return $ret;            
        }
//------------------------
//
//------------------------               
        public function existingScenarioForm($aff=''){  
            $ci = &get_instance();
            $ret = '';
            $ret .= '<h2>Select from Existing Scenario</h2>';
            $ret .= $ci->ogre_lib->getMiscContent("%EXISTING-OP-SCENARIO-LIST%",0,TRUE);
            $ret .= '<div id="existing-scenario-table">';
            $ret .= '<label for="affiliation">Affiliation Filter</label>'; 
            $ret .= $this->getAffiliationFilter($aff);
            $ret .= '<div id="existing-scenario-select">';
            $ret .= $this->existingScenarioList();
             $ret .= '</div>';

            return $ret;
        }            
//---------------------------------------------------  
//
//---------------------------------------------------   */  
    private function getAffiliationFilter($aff=""){
            $ci = &get_instance();
            $qry = 'SELECT ogre_games_descriptor.*, ogre_games_descriptor_type.* ';
            $qry .= ' FROM ogre_games_descriptor,  ogre_games_descriptor_type ';
            $qry .= ' WHERE ogre_games_descriptor.gd_descriptor_type = ogre_games_descriptor_type.gdt_id ';
            $qry .= ' AND ogre_games_descriptor_type.gdt_id = 5';
            $qry .= ' ORDER BY gd_descriptor;';

            $query = $ci->db->query($qry);
            $action= site_url('ogrex/refreshExistingScenarios','https');
            if ($query->getNumRows() > 0){
                $ret = '<select class="form-select m-3" id="affiliation" name="affiliation" size="1" onchange="getExistingScenariosAff(this, ' ."'". $action ."'". ');">';
                $ret .= '<option value="0">(Affiliation Filter)</option>';
                foreach ($query->getResult() as $row){
                    if ($aff == $row->gd_descriptor){
                        $ret .= '<option value="' . $row->gd_descriptor . '" selected="selected">' . $row->gd_descriptor . '</option>';
                    }
                    else{
                        $ret .= '<option value="' . $row->gd_descriptor . '">' . $row->gd_descriptor . '</option>';
                    }
                }
            }
            $ret .= '</select>';
            return $ret;
    }     
        
    //------------------------
    //
    //------------------------
    public function getCampaignSelect($cgn=''){
        $ci = &get_instance();        
        $qry = 'SELECT ';
        $qry .= ' ogre_games.*, ';
        $qry .= ' ogre_games.*,  ogre_games_descriptor_xref.*,  ogre_games_descriptor.*, ogre_games_descriptor_type.* ';
        $qry .= ' FROM ((ogre_games INNER JOIN ogre_games_descriptor_xref ';
        $qry .= ' ON ogre_games.gn_game_id = ogre_games_descriptor_xref.gdx_gn_id) ';
        $qry .= ' INNER JOIN ogre_games_descriptor ';
        $qry .= ' ON ogre_games_descriptor_xref.gdx_gd_id = ogre_games_descriptor.gd_id) ';
        $qry .= ' INNER JOIN ogre_games_descriptor_type ';
        $qry .= ' ON ogre_games_descriptor.gd_descriptor_type = ogre_games_descriptor_type.gdt_id ';
        $qry .= ' WHERE ogre_games_descriptor_type.gdt_id = 5 ';
        $qry .= ' AND ogre_games.gn_game_id <> 88 ';
        $qry .= ' ORDER BY ogre_games.gn_game_name;';

        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            $refreshafffilter = site_url("ogrex/refreshGameAdminFilter",'https');
            $ret = '<div class="select-style">';
            $ret .= '<select class="form-control m-2" name="campaign" id="campaign" size="1" onchange="getAffiliation(this.options[this.selectedIndex].value,'."'".$refreshafffilter."'".');">';
            $ret .= '<option value="0">(Select Campaign)</option>';
            foreach ($query->getResult() as $row){
                $ci->game->init($row->gn_game_id);
                if ($cgn == $row->gn_game_name){
                    $ret .= '<option value="' . $row->gn_game_id . '" selected="selected">' . $row->gn_game_name . ' (' . $ci->game->game_affiliation . ')'. '</option>';
                }
                else{
                    $ret .= '<option value="' . $row->gn_game_id . '">' . $row->gn_game_name . ' (' . $ci->game->game_affiliation . ')'. '</option>';
                }
            }
        }
        $ret .= '</select>';
        $ret .= '</div>';
        return $ret;
    }
        
}  ////  end class
?>
