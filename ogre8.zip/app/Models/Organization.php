<?php
namespace App\Models;
use CodeIgniter\Model;
use CodeIgniter\I18n\Time;

class Organization extends Model{
    var $id=0;
    var $name='';
    var $contactname='';
    var $contactemail='';
    var $contactaddress='';
    var $contactcity='';
    var $contactstate='';
    var $contactzip='';
    var $contactphone='';
    var $website='';
    var $ogrecontroller='';
    var $configprefix='';


//---------------------------------------------------
//
//---------------------------------------------------	
    public function __construct(){
  
    }			
//---------------------------------------------------
//
//---------------------------------------------------
    function init($orgid=0){
        if ($orgid != 0)  {
            $this->id = 0;
            $this->name='';
            $this->contactname='';
            $this->contactemail='';
            $this->contactaddress='';
            $this->contactcity='';
            $this->contactstate='';
            $this->contactzip='';
            $this->contactphone='';
            $this->website='';
            $this->ogrecontroller='';
            $this->configprefix='';
            $this->getOrgData($orgid);
        }         
    }
//---------------------------------------------------
//
//--------------------------------------------------- 
    private function getOrgData($orgid){     
        $ci=&get_instance();
        $qry = 'SELECT * FROM ogre_organization WHERE org_id = :orgid:;';
        $query = $ci->db->query($qry,['orgid'=>$orgid]);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){ 
                $this->id = $row->org_id;
                $this->name = $row->org_name;
                $this->contactname = $row->org_contactname;
                $this->contactemail = $row->org_contactemail;
                $this->contactaddress = $row->org_contactaddress;
                $this->contactcity = $row->org_contactcity;
                $this->contactstate = $row->org_contactstate;
                $this->contactzip = $row->org_contactzip;
                $this->contactphone = $row->org_contactphone;
                $this->website = $row->org_website;
                $this->ogrecontroller = $row->org_ogrecontroller;
                $this->configprefix = $row->org_configprefix;	
            }
        }
    }


}
