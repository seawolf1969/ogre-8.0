<?php 
namespace App\Models;
use CodeIgniter\Model;
use CodeIgniter\I18n\Time;

class Location  extends Model{
    var $locationid = '0';
    var $conid = '0';
    var $location_name = '';
    var $con_location_name = '';
    var $open = '';
    var $open_date = '';
    var $open_time = '';
    var $close = '';
    var $close_date = '';
    var $close_time = '';
    var $notes = '';
    var $err_eventid='0';
    var $location_seqnum = '';
    var $table_prefix='';
    var $last_table_number=0;
    var $rpg_tables=0;
    var $bg_tables=0;
    var $mini_tables=0;
    var $ccg_tables=0;
    var $multi_tables=0;
    var $placeholder_tables=0;
   
    //---------------------------------------------------
    //
    //  
    //
    //---------------------------------------------------
    public function __construct()
    {
         parent::__construct();
    } 


    public function initialize($locid){
        if ($locid != '0'){
            $this->get_location_data($locid);
            $this->get_location_tables($locid);
        }
        return '';
    }
   
    //---------------------------------------------------
    //
    //  
    //
    //---------------------------------------------------
    private function get_location_data($locid){
            $ci=&get_instance();
            $qry = 'SELECT * FROM ogre_location WHERE loc_locationid = ' . $locid . ';';
            $query = $ci->db->query($qry);
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){ 
                    $this->conid = $row->loc_con_id;
                    $this->locationid = $row->loc_locationid;    	
                    $this->location_name = $row->loc_location_name;    	
                    $this->con_location_name = $row->loc_con_location_name; 
                    $this->open = $row->loc_open;                    
                    $xdate = new Time($row->loc_open);
                    $this->open_date = $xdate->format('Y-m-d');                   
                    $this->open_time = $xdate->format('G:i:s');;                    
                    $this->close = $row->loc_close;  
                    $ydate = new Time($row->loc_close);
                    $this->close_date = $ydate->format('Y-m-d');                   
                    $this->close_time = $ydate->format('G:i:s');;                     
                    $this->location_seqnum = $row->loc_seqnum;
                    $this->table_prefix = $row->loc_table_prefix; 
                    $this->last_table_number = $row->loc_last_table_number; 
                    $this->notes = $row->loc_notes;
                }	
              }
        }

    //---------------------------------------------------
    //
    //  
    //
    //---------------------------------------------------
    private function get_location_tables($locid){
        $ci=&get_instance();
        $qry = 'SELECT * FROM ogre_tables WHERE tbl_locationid = ' . $locid . ' AND tbl_deleteflag = 0 AND tbl_type = 1;';
        $query = $ci->db->query($qry);
        $this->rpg_tables = $query->getNumRows();
        $qry = 'SELECT * FROM ogre_tables WHERE tbl_locationid = ' . $locid . ' AND tbl_deleteflag = 0 AND tbl_type = 2;';
        $query = $ci->db->query($qry);
        $this->bg_tables = $query->getNumRows();
        $qry = 'SELECT * FROM ogre_tables WHERE tbl_locationid = ' . $locid  . ' AND tbl_deleteflag = 0 AND tbl_type = 3;';
        $query = $ci->db->query($qry);
        $this->mini_tables = $query->getNumRows();
        $qry = 'SELECT * FROM ogre_tables WHERE tbl_locationid = ' . $locid  . ' AND tbl_deleteflag = 0 AND tbl_type = 4;';
        $query = $ci->db->query($qry);
        $this->ccg_tables = $query->getNumRows();
        $qry = 'SELECT * FROM ogre_tables WHERE tbl_locationid = ' . $locid  . ' AND tbl_deleteflag = 0 AND tbl_type = 5;';
        $query = $ci->db->query($qry);
        $this->multi_tables = $query->getNumRows();
        $qry = 'SELECT * FROM ogre_tables WHERE tbl_locationid = ' . $locid  . ' AND tbl_deleteflag = 0 AND tbl_type = 6;';
        $query = $ci->db->query($qry);
        $this->placeholder_tables = $query->getNumRows();  /**/
     }  
 
 
     //---------------------------------------------------
    //
    //  
    //
    //---------------------------------------------------
    public function get_tablesnumber($locid){
        $ci=&get_instance();
        $qry = 'SELECT * ';
        $qry .= ' FROM ogre_tables ';
        $qry .= ' WHERE tbl_locationid = ' . $locid;
        $qry .= ' AND tbl_placeholder = 0 ';
        $qry .= ' AND tbl_deleteflag = 0;';
        $query = $ci->db->query($qry);
        $ret = $query->getNumRows();  
        return $ret;
     }  

    //---------------------------------------------------
    //
    //  
    //
    //--------------------------------------------------- 
    public function new_loc_data($p, $conid=0){
        $locid=$p['locationid'];     
        $ret = ($locid == 0) ? $this->save_new_loc($p, $conid) : $this->update_loc_data($p);
        return $ret;

    } 
 
 
    //---------------------------------------------------
    //
    //  
    //
    //--------------------------------------------------- 
    private function save_new_loc($p, $conid){
            $ci=&get_instance();
            $ins = 'INSERT INTO ogre_location ';
            $ins .= '(loc_location_name, ';
            $ins .= 'loc_con_id, ';
            $ins .= 'loc_con_location_name, ';
            $ins .= 'loc_open, ';
            $ins .= 'loc_close, ';
            $ins .= 'loc_seqnum, ';
            $ins .= 'loc_table_prefix, '; 
            $ins .= 'loc_last_table_number, '; 
            $ins .= 'loc_notes) ';
            $ins .= 'VALUES (';
            $ins .= '"' . $p["location_name"] . '", ';
            $ins .= '' . $conid . ', ';   
            $ins .= '"' . $p["con_location_name"] . '", ';
            $ins .= '"' . $p["open_date"] . ' ' . $p["open_time"] . '", ';
            $ins .= '"' . $p["close_date"] . ' ' . $p["close_time"] . '", ';
            $ins .= '' . $p["location_seqnum"] . ', "' . $p["table_prefix"] . '",'; 
            $ins .= $p["last_table_number"] . ', ';
            $ins .= '"' . $p["notes"] .'")';
            $ci->db->query($ins);
            $ret=($ci->db->affectedRows() > 0)?TRUE:FALSE;
            $locid = $ci->db->insertID();
            $this->initialize($locid);
            $tret = $this->add_tables($locid);
            return $ret && $tret;
     }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------  
        public function update_loc_data($p){
            $ci=&get_instance();
            $ins = 'UPDATE ogre_location SET ';
            $ins .= 'loc_location_name ="' . $p["location_name"] . '", ';
            $ins .= 'loc_con_location_name="' . $p["con_location_name"] . '", ';
            $ins .= 'loc_seqnum=' . $p["location_seqnum"] . ', ';
//            $ins .= 'loc_last_table_number="' . $p["last_table_number"] . '", ';
//            $ins .= 'loc_table_prefix="' . $p["table_prefix"] . '", ';
            $ins .= 'loc_open ="' . $p["open_date"] . ' ' . $p["open_time"] . '", ';
            $ins .= 'loc_close ="' . $p["close_date"] . ' ' . $p["close_time"] . '", ';
            $ins .= 'loc_notes="' . $p["notes"] . '" ';      
            $ins .= 'WHERE loc_locationid = ' . $p["locationid"] . ';';   
            $ci->db->query($ins);
            $ret=($ci->db->affectedRows() > 0)?TRUE:FALSE;
            return $ret;
          } 
//---------------------------------------------------
//
//  
//
//---------------------------------------------------            
          public function updateTableNumber($id){
            $ci=&get_instance();
            $this->initialize($id);
            $ins = 'UPDATE ogre_location SET ';
            $ins .= 'loc_last_table_number="' . $this->get_tablesnumber($id) . '" ';
            $ins .= 'WHERE loc_locationid = ' . $id . ';'; 
            $ci->db->query($ins);
            $ret=($ci->db->affectedRows() > 0)?TRUE:FALSE;
            return $ret;              
          }
        //---------------------------------------------------
        //
        //  
        //
        //---------------------------------------------------  
         public function tableprefix_gen($name=''){
                $ret='';
                $locname = (trim($name)=='') ?  explode(' ', $this->location_name) : explode(' ', $name);
                $x = count($locname);
                for($i=0;$i<=$x-1;$i++)
                {
                    $ret .= substr($locname[$i],0,1);                    
                }
                //check for uniqueness
                return $ret;
           }
        //---------------------------------------------------
        //
        //  
        //
        //---------------------------------------------------     
           public function change_table_prefix($tprefix){    
                $ci=&get_instance();
                $ins = 'UPDATE ogre_location SET ';
                $ins .= 'loc_table_prefix ="' . $tprefix  . '" ';
                $ins .= 'WHERE loc_locationid = ' . $this->locationid . ';';
                $ci->db->query($ins);
                $ret = ($ci->db->affectedRows() > 0) ?  TRUE : FALSE;
                if ($ret===TRUE){
                    $ret = '<p>Table Prefix Saved!</p>';
                    $this->table_prefix = $tprefix;
                }
                else{
                    $ret = 'ERROR in SQL: ' . mysql_error() . ' - ' . $ins;
                }
                return $ret;
            }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------     
   public function process_tables($p)
     {
        if ($this->table_prefix != $p["tprefix"]){
            $ret = $this->change_table_prefix($p["tprefix"]);
        }
        if ($p["table_type"] != '0'){
            if (isset($p["remove"])){
                $ret = $this->remove_tables($p["table_type"],intval($p["number_of_tables"]));
            }
            else{
                $ret = $this->add_tables($p["table_type"],intval,($p["number_of_tables"]));
            } 
        }	 
        return $ret;  	 
    } 
        //---------------------------------------------------
        //
        //  
        //
        //---------------------------------------------------  	 
        public function removeTable($tid){
            $ci=&get_instance();
            $ins = 'UPDATE ogre_tables SET ';
            $ins .= ' tbl_deleteflag = 1 ';
            $ins .= ' WHERE tbl_id = ' . $tid . ';';   
            $ci->db->query($ins);
            $ret=($ci->db->affectedRows() > 0)?TRUE:FALSE;
            return $ret;
        }
        
        //---------------------------------------------------
        //
        //  
        //
        //---------------------------------------------------  	 
        public function remove_location($locid){
            $ci=&get_instance();
            $ins = 'UPDATE ogre_location SET ';
            $ins .= ' loc_deleteflag = 1 ';
            $ins .= ' WHERE loc_locationid = ' . $locid . ';';   
            $ci->db->query($ins);
            $ret=($ci->db->affectedRows() > 0)?TRUE:FALSE;
            return $ret;
        }
        //---------------------------------------------------
        //
        //  
        //
        //---------------------------------------------------  	 
        public function remove_tables($type, $new){
            $ci=&get_instance();
            $diff = intval($new);
            $qry = 'SELECT * ';
            $qry .= ' FROM ogre_tables ';
            $qry .= ' WHERE tbl_type = ' . $type;
            $qry .= ' AND  tbl_locationid = ' . $this->locationid;
            $qry .= ' ORDER BY tbl_id DESC LIMIT ' . $diff  . ';';
            $query = $ci->db->query($qry);
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){ 
                    $ins = 'UPDATE ogre_location SET ';
                    $ins .= ' loc_deleteflag = 1';                  
                    $ins .= ' WHERE tbl_locationid = ' . $this->locationid;
                    $ins .= ' AND tbl_id = "' . $row->tbl_id . '";';
                    $ci->db->query($qry);
                     $ret = ($ci->db->affectedRows() > 0) ? TRUE: FALSE;
                }  
            }
            return $ret;  
        }
        
        
        //---------------------------------------------------
        //
        //  
        //
        //---------------------------------------------------  	  
        public function add_tables($lid=0){
            if($this->locationid===0){
                $this->initialize($lid);
            }
            $ci=&get_instance();
            // INSERT PLACEHOLDER FOR THE ROOM
            $qry='INSERT INTO ogre_tables (tbl_locationid, tbl_number, tbl_placeholder) ';
            $qry .= ' VALUES (';
            $qry .= $this->locationid . ', ';
            $qry .= '' .  -1 * $this->locationid . ', ';
            $qry .= '1 ';
            $qry .= ');';
            $ci->db->query($qry);
            $ret = ($ci->db->affectedRows() > 0) ? TRUE : FALSE;
            if($ret===TRUE){
                $start =  1;
                $end = intval($this->last_table_number);
                //1 RECORD per table.  Edit details later
                for($i=$start; $i<=$end; $i++){
                    $qry='INSERT INTO ogre_tables (tbl_locationid, tbl_number) ';
                    $qry .= ' VALUES (';
                    $qry .= $this->locationid . ', ';
                    $qry .= '' .  $i . ' ';
                    $qry .= ');';
                    $ci->db->query($qry);
                    $ret = ($ci->db->affectedRows() > 0) ?  TRUE : FALSE;
                }
             }
            return $ret;
        }	
 
 
 
//    //---------------------------------------------------
//    //
//    //  
//    //
//    //---------------------------------------------------  	  
//       public function save_last_table_number($num)
//        {
//           $ci=&get_instance(); 
//
//            $qry = 'UPDATE ogre_location SET ';
//            $qry .= 'loc_last_table_number = ' . $num . ' ';
//            $qry .= 'WHERE loc_locationid = ' . $this->locationid . ';';
//
//            $ci->db->query($qry);
//
//            if ($ci->db->affectedRows() > 0)
//            {
//                $ret = TRUE;
//            }
//            else
//            {
//                $ret = FALSE;
//            }			 
//            return $ret;
//        }

//---------------------------------------------------
//
//  
//
//---------------------------------------------------  	  
       public function add_table($locid){       
           $ci=&get_instance();
           $lastnum=$this->get_lasttablenumber($locid);
           $lastnum++;        
           $qry='INSERT INTO ogre_tables (tbl_locationid, tbl_number) ';
           $qry .= ' VALUES (';
           $qry .= $locid . ', ';
           $qry .= '' .  $lastnum . ' ';
           $qry .= ');';
           $ci->db->query($qry);
           $ret =  ($ci->db->affectedRows() > 0) ? TRUE : FALSE;
            return $ret;
        }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------  	  
       public function get_lasttablenumber($locid){
           $ci=&get_instance();
            $qry = 'SELECT Max(ogre_tables.tbl_number) AS MaxOftbl_number, ogre_tables.tbl_locationid ';
            $qry .= ' FROM ogre_tables ';
            $qry .= ' WHERE ogre_tables.tbl_locationid=' . $locid;
            $qry .= ' AND tbl_deleteflag = 0 ';
            $query = $ci->db->query($qry);
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){ 
                    $ret = $row->MaxOftbl_number;
                }
            }			 
            return $ret;
        }        
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
    public function display_location($locid=0, $conid=0){		
        $ci=&get_instance();    
        if($conid==0){
            $conid = $ci->session->userdata('ogre_$conid');
        }
        $ci->convention->init($conid);
        $ret = '';
        $ret .= ($locid == 0) ? '' : $this->initialize($locid);
        $ret .= '<div id="locaddresults" class="results"></div>';
        $ret .= '<form action="" id="locationform" name="locationform">'; 
        $ret .= '<h2 title="A location is a gaming room or area where gaming will take place.">Location Admin</h2>';              
        $ret .= ($locid == 0)? '<input type="hidden" id="locationid" name="locationid" value="0" />' : '<input type="hidden" id="locationid" name="locationid" value="' . $locid . '" />';
        $ret .= '<table class="locationtable" id="locationtable">';
        $ret .= '<tr>';
        $ret .= '<td>';
        $ret .= '<label for="location_name">Location Name *</label>';
        $ret .= '</td>';
        $ret .= '<td>';
        $ret .=  ($locid == 0) ? '<input title="As the Hotel calls it" id="location_name" name="location_name" type="text" onBlur="checkpref('. "'" . site_url('ogrex/checkprefix','https') . "'" . ');" />' : '<input title="As the Hotel calls it" id="location_name" name="location_name" type="text" value="' . $this->location_name . '" />';	
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '<tr><td>';
        $ret .= '<label for="con_location_name">Con Location Name*</label>';
        $ret .= '</td>';
        $ret .= '<td>';
        $ret .=  ($locid == 0) ? '<input title="The Event/Con Name for it i.e. Gaming Room 1" id="con_location_name"name="con_location_name" type="text" />' : '<input title="The Event/Con Name for it i.e. Gaming Room 1" id="con_location_name" name="con_location_name" type="text" value= "' . $this->con_location_name . '" />';
        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '<tr>';
        $ret .= '<td>';
        $ret .= '<label for="location_seqnum">Location Sequential Number *</label>';
        $ret .= '</td>';
        $ret .= '<td>';
        $ret .=  ($locid == 0) ? '<input title="Needed for Sequentially Identifying Each Room, Needs to be unique" id="location_seqnum" name="location_seqnum" type="text" />' : '<input title="Needed for Sequentially Identifying Each Room, Needs to be unique" id="location_seqnum" name="location_seqnum" type="text" value="' . $this->location_seqnum . '" />';
        $ret .= '</td>';
        $ret .= '</tr>';				
        $ret .= '<tr>';
        $ret .= '<td>';
        $ret .= '<label for="last_table_number">Total Number of Tables</label>';
        $title = 'Total number of individual playing tables. ';
        if($locid != 0){
            $title .= ' To Add or Remove Tables, Use the tables button.  This number will automatically be updated.';
        }
        $ret .= '</td>';
        $ret .= '<td>';
        $ret .= ($locid == 0) ? '<input title="'.$title.'" id="last_table_number" name="last_table_number" type="text"  value="0" />' : '<input title="'.$title.'" disabled="disabled" id="last_table_number" name="last_table_number" type="text" value="' . $this->last_table_number . '" />';
        $ret .= '</td>';
        $ret .= '</tr>';                

            $ret .= '<tr>';
            $ret .= '<td>';
            $ret .= '<label for="table_prefix">Location Table Prefix</label>';
            $ret .= '</td>';
            $ret .= '<td>';
            $ret .= ($locid == 0) ?  '<input title="Needed to uniquely identify each table in each room and associate each table to the room. Needs to be unique.  Will be generated if left blank.  Once created, can not be editted." size="8" id="table_prefix" name="table_prefix" type="text" onBlur="checkprefix('. "'" . site_url('ogrex/checkprefix','https') . "'" . ')" /><span id="prefmsg" style="color:#FF0000;padding: 0px 0px 0px 3px;"></span>' : '<input disabled="disabled" title="Needed to uniquely identify each table in each room and associate each table to the room. Needs to be unique.  Will be generated if left blank." size="8" id="table_prefix" name="table_prefix" type="text" value="' . $this->table_prefix . '" /><span id="prefmsg" style="display:none">Good</span>';  
            $ret .= '</td>';
            $ret .= '</tr>';                
            $ret .= '<tr>';
            $ret .= '<td>';
            $ret .= '<label for="open_date">Date/Time Open</label>';
            $ret .= '</td>';
            $ret .= '<td>';
            $ret .= '<strong>Date/Time Close</strong>';
            $ret .= '</td>';
            $ret .= '</tr>';
            $ret .= '<tr>';
            $ret .= '<td>';
            $ret .= ($locid == 0) ? $ci->convention->date_select("open_date",$ci->convention->start_date) : $ci->convention->date_select("open_date",$this->open_date);
            $ret .= '</td>';
            $ret .= '<td>';
            $ret .= ($locid == 0) ?  $ci->convention->date_select("close_date",$ci->convention->end_date) : $ci->convention->date_select("close_date",$this->close_date);
            $ret .= '</td>';
            $ret .= '</tr>';
            $ret .= '<tr>';
            $ret .= '<td>';
            $n1 = 'open_time';
            $time = ($locid == 0) ? $ci->convention->start_time : $time = $this->open_time;
            $ret .= $ci->admin_lib->timeSelect($n1, $time);  
            $ret .= '</td>';
            $ret .= '<td>';
            $n = 'close_time';
            $time = ($locid == 0) ? $ci->convention->end_time : $this->close_time;
            $ret .= $ci->admin_lib->timeSelect($n, $time);  
            $ret .= '</td>';
            $ret .= '</tr>';
            $ret .= '<tr>';
            $ret .= '<td colspan="2"> ';
            $ret .= '<label for="notes">Location Notes</label>';
            $ret .= '</td>';
            $ret .= '</tr>';
            $ret .= '<tr>';
            $ret .= '<td colspan="2"> ';
            $ret .= ($locid == 0) ?  '<textarea name="notes" id="notes"></textarea>' :  '<textarea name="notes" id="notes">' . $this->notes .'</textarea>';
            $ret .= '</td>';
            $ret .= '</tr>';
            $ret .= '</table>';
            $ret .= '</form>';
            return $ret;
        }	 
	 
    //---------------------------------------------------
    //
    //  
    //
    //---------------------------------------------------  	  
       public function view_location_tables($lid=0, $edit="no", $editpage=''){
        $ci = &get_instance();
        $qry = 'SELECT * ';
        $qry .= ' FROM ogre_tables, ogre_table_type ';
        $qry .= ' WHERE tbl_type = tt_id ';
        $qry .= ' AND tbl_locationid = ' . $lid;
        $qry .= ' AND tbl_deleteflag = 0 ';
        $qry .= ' ORDER BY tbl_number;';
        $query = $ci->db->query($qry);
        $ret = '<p><strong>Location Table List: ' . $this->location_name . ' ' . $this->con_location_name  . '</strong></p>';
//            $ret .= '<div align="right"><input name="renumber" type="button"  class="btn btn-secondary" value="Renumber Tables" onclick="gotoTblRenum(' . $this->locationid . ',' . "'" . $editpage . "'" . ');" /><br / ></div>';
        $ret .= '<table width="100%" cellspacing="0" cellpadding="5" border="1">';
        $ret .= '<tr><th>';
        $ret .= 'Table Number/Code';
        $ret .= '</th><th>';
        $ret .= 'Table Type';
        $ret .= '</th>';
            if ($edit=='yes')
            {
                $ret .= '</th><th>';	
                $ret .= '&nbsp;';
                $ret .= '</th>';	  
            }
            $i=1;	

            if ($query->getNumRows() > 0)
            {

                foreach ($query->getResult() as $row)
                { 
                     $i++;
                    $ret .= '<tr><td>';
                    $ret .= $this->table_prefix . '-' . $row->tbl_number;	   
                    $ret .= '</td><td>';
                    $ret .= $row->tt_type;
                    $ret .= '</td>';
                    if ($edit=='yes')
                    {
                        $ret .= '<td align="right">';	      
                        $ret .= '<input name="edittbl' . $i . '" type="button"  class="btn btn-secondary" value="Edit" onclick="gotoTbl(' . $this->locationid . ',' . $row->tbl_id . ','. "'" . $editpage . "'" . ');" />';  
                        $ret .= '</td>';		  
                    }
                    $ret .= '</tr>';
                }
            }
            $ret .= '</table>';
            return $ret;
    }   

    
        //---------------------------------------------------
        //
        //  
        //
        //---------------------------------------------------  	  
        public function display_tables($locid){
            $ci=&get_instance();
            $action =  site_url('ogre_admin/tablesIn','https');
            $this->initialize($locid);
            
            $qry = 'SELECT * FROM ogre_tables ';
            $qry .= ' WHERE tbl_locationid = ' . $this->locationid;
            $qry .= ' AND tbl_deleteflag = 0 ';
            $qry .= ' ORDER BY tbl_number;';
            $ret ="";
            $query = $ci->db->query($qry);
            
            $ret .= '<h2>Location Table:' . $this->location_name . ' (' . $this->con_location_name  . ')</h2>'; 
            $ret .= '<div id="loctblresults"  class="results"></div>';
            $ret .= '<form action="" name="table_edit" id="table_edit">';
            $ret .= '<input id="locid" name="locid" type="hidden" value="' . $this->locationid . '" />' ;
            $ret .= '<table class="tableedit_table" id="tableedit_table">';
            $ret .= '<tr>';
            $ret .= '<th>';
            $ret .= 'Number';
            $ret .= '</th>';
            $ret .= '<th>';
            $ret .= 'Type';
            $ret .= '</th>';
            $ret .= '<th>';
            $ret .= 'Placeholder';
            $ret .= '</th>';
            $ret .= '<th>';
            $ret .= 'Notes';
            $ret .= '</th>';
            $ret .= '<th>';
            $ret .= 'Delete';
            $ret .= '</th>';
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                    $ret .= '<tr>';
                    $ret .= '<td>';
                    $ret .= '<input type="hidden" id="tbl_id'. $row->tbl_id . '" name="tbl_id'. $row->tbl_id . '" value="' . $row->tbl_id . '" />';
                    $ret .= $row->tbl_number;
                    $ret .= '</td>';
                    $ret .= '<td>';
                    $ret .= $this->getTableTypeList($row->tbl_type, 'tabletype'.$row->tbl_id);
                    $ret .= '</td>';
                    $ret .= '<td>';
                    $ret .= '<select id="tbl_placeholder'. $row->tbl_id . '" name="tbl_placeholder'. $row->tbl_id . '" size="1">';
                    if($row->tbl_placeholder==1){
                        $ret .= '<option value="1" selected="selected">Yes</option><option value="0">No</option>';
                    }   
                    else{
                        $ret .= '<option value="0" selected="selected">No</option><option value="1">Yes</option>';
                    }
                    $ret .= '</td>';
                    $ret .= '<td>';
                    $ret .= '<input type="text" size="25" id="tbl_notes'. $row->tbl_id . '" name="tbl_notes'. $row->tbl_id . '" value="' . $row->tbl_notes . '" />';
                    $ret .= '</td>';
                    $ret .= '<td>';
                    $ret .= '<input type="checkbox" id="delete'. $row->tbl_id . '" name="delete'. $row->tbl_id . '" value="Delete" onclick="deleteTable(' . $row->tbl_id . ','. $row->tbl_locationid . ','. "'". site_url('ogrex/delTables','https')."','".site_url('ogrex/tablesList','https')."'".')" />';
                    $ret .= '</td>';
                    $ret .= '</tr>';
                }       
            
            }
            $ret .= '</table>';
            $ret .= '</form>';            
            
            return $ret;
        }    

        //---------------------------------------------------
        //
        //  
        //
        //---------------------------------------------------  	  
        public function display_tables_edit($tblid=0){
            $ci=&get_instance();
            $action='';
            if($tblid==0){
                $qry = 'SELECT * FROM ogre_tables, ogre_table_type ';
                $qry .= ' WHERE tbl_type = tt_id ';
                $qry .= ' AND tbl_locationid = ' . $this->locationid;
                $qry .= ' AND tbl_deleteflag = 0 ';
                $qry .= ' ORDER BY tbl_number;';

                $query = $ci->db->query($qry);

                $ret = '<p><strong>Location Table Renumber: ' . $this->location_name . ' ' . $this->con_location_name  . '</strong></p>'; 
                $ret .= '<form action="' . $action . '" method="post" name="table_edit">';
                $ret .= '<input id="locid" name="locid" type="hidden" value="' . $this->locationid . '" />' ;	   		 
                $ret .= '<table border="0" cellspacing="5" cellpadding="5">';

                $ret .= '<tr>';

                if ($query->getNumRows() > 0)
                {

                    foreach ($query->getResult() as $row)
                    { 
                        $ret .= '<tr>';
                        $ret .= '<td>';
                        $ret .= $this->table_prefix . '-';
                        $ret .= '<input id="number' . $row->tbl_id  .'" name="number' . $row->tbl_id  .'" type="text" value="' . $row->tbl_number . '" size="8" />' ;	   
                        $ret .= '<input id="id' . $row->tbl_id  .'" name="id' . $row->tbl_id  .'" type="hidden" value="' . $row->tbl_id . '" />' ;	   		 
                        $ret .= '</td><td>';
                        $ret .= $row->tt_type;

                        $ret .= '</td>';
                        $ret .= '</tr>';
                    }
                } 	
                $ret .= '<tr>';
                $ret .= '<td colspan="2" align="right">';
                $ret .= '<input class="btn btn-secondary" name="submit" type="submit" value=" Save " />';
                $ret .= '</td>';		
                $ret .= '</tr>';
                $ret .= '</table>';
                $ret .= '</form>';
            }
            else
            {
                $qry = 'SELECT * FROM ogre_tables, ogre_table_type ';
                $qry .= ' WHERE tbl_type = tt_id ';
                $qry .= ' AND tbl_id = ' . $tblid;
                $qry .= ' AND tbl_deleteflag = 0 ';
                $qry .= ' ORDER BY tbl_number;';

                $query = $ci->db->query($qry);
                
                if ($query->getNumRows() > 0){

                    foreach ($query->getResult() as $row){
                        $ret = '<p><strong>Table Edit: ' . $this->table_prefix . '-' . $row->tbl_number . '</strong></p>'; 
                        $ret .= '<form action="' . $action . '" method="post" name="table_edit">';
                        $ret .= '<input id="tbl_id" name="tbl_id" type="hidden" value="' . $row->tbl_id . '" />' ;	   		 
                        $ret .= '<input id="locid" name="locid" type="hidden" value="' . $this->locationid . '" />' ;	   		 
                        $ret .= '<table border="0" cellspacing="5" cellpadding="5">';

                        $ret .= '<tr>';


                        $ret .= '<tr>';
                        $ret .= '<td>';
                        $ret .= $this->getTableTypeList($row->tt_id); 
                        $ret .= '</td></tr><tr><td>';
                        $ret .= '<textarea name="notes" cols="20" rows="10">' . $row->tbl_notes . '</textarea>';	   
                        $ret .= '</td>';
                        $ret .= '</tr>';
                    }
                } 	
                $ret .= '<tr>';
                $ret .= '<td align="right">';
                $ret .= '<input class="btn btn-secondary" name="submit" type="submit" value=" Save " />';
                $ret .= '</td>';		
                $ret .= '</tr>';
                $ret .= '</table>';
                $ret .= '</form>';
            } 
            return $ret;

        }
        
//---------------------------------------------------
//
//  
//
//---------------------------------------------------  	  
        public function save_renumber_tables($p)
        {
            $ci=&get_instance();
            $qry = 'SELECT * ';
            $qry .= ' FROM ogre_tables ';
            $qry .= ' WHERE tbl_locationid = ' . $this->locationid;
            $qry .= ' AND tbl_deleteflag = 0 ';
            $qry .= ' ORDER BY tbl_number;';

            $query = $ci->db->query($qry);

            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){ 
                    $ins = 'UPDATE ogre_tables SET ';
                    $ins .= 'tbl_number =' . $p["number"] . $row->tbl_id . ' ';
                    $ins .= 'WHERE tbl_id = ' . $row->tbl_id . ';';
                    $ci->db->query($ins);
                    
                    $ret = ($ci->db->affectedRows() > 0) ?  TRUE : FALSE;
                }
            }     
            $qry = 'SELECT * ';
            $qry .= ' FROM ogre_tables ';
            $qry .= ' WHERE tbl_locationid = ' . $this->locationid;
            $qry .= ' AND tbl_deleteflag = 0 ';
            $qry .= ' ORDER BY tbl_number DESC LIMIT 1;';
            $query = $ci->db->query($qry);
            if ($query->getNumRows() > 0)
            {
                foreach ($query->getResult() as $row)
                { 
                    $ret = $this->save_last_table_number($row->tbl_number);
                }
            }	

            return $ret;

        } 
  
//***********************************
//
// 
//
//***********************************
        function getTableTypeList($ttid=0, $n='table_type'){
            $ci=&get_instance();
            $qry = 'SELECT * FROM ogre_table_type';
            $query = $ci->db->query($qry);
            $ret = '<select name="' . $n . '" id="' . $n . '" size="1">';
            if ($ttid == 0){
                $ret .= '<option value = "0" selected="selected">- SELECT TABLE TYPE - </option>';
            }
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){ 
                    if ($ttid == $row->tt_id){
                        $ret .= '<option value = "' . $row->tt_id  . '" selected="selected">' . $row->tt_type  . '</option>';
                    }
                    else{
                        $ret .= '<option value = "' . $row->tt_id  . '">' . $row->tt_type . '</option>';
                    }  
                }
            } 
            $ret .= '</select>';
            return $ret;
        }   

//---------------------------------------------------
//
//  
//
//---------------------------------------------------  	  
            public function save_table_info($p){  
                $ins = 'UPDATE ogre_tables SET ';
                $ins .= 'tbl_type =' . $p["tabletype"] . ', ';
                $ins .= 'tbl_placeholder =' . $p["tbl_placeholder"] . ', ';
                $ins .= 'tbl_notes ="' . $p["tbl_notes"] . '" ';
                $ins .= 'WHERE tbl_id = ' . $p["tbl_id"] . ';';
                $ci=&get_instance();
                $ci->db->query($ins);
                $ret =  ($ci->db->affectedRows() > 0) ?  TRUE : FALSE;
                return $ret;

            }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------  	  
            public function save_tables($p){  
                $ci = &get_instance();
                $ret = TRUE;
                $qry = 'SELECT * FROM ogre_tables ';
                $qry .= ' WHERE tbl_locationid = ' . $p['locid'];
                $qry .= ' AND tbl_deleteflag = 0';
                $qry .= ' ORDER BY tbl_number;';
                $i=0;
                $query = $ci->db->query($qry);
                if ($query->getNumRows() > 0){
                    foreach ($query->getResult() as $row)  {  
                        $np['tabletype']=$p['tabletype' . $row->tbl_id];
                        $np['tbl_placeholder']=$p['tbl_placeholder' . $row->tbl_id]; 
                        $np['tbl_notes']=$p['tbl_notes' . $row->tbl_id];
                        $np['tbl_id']=$p['tbl_id' . $row->tbl_id];
                        
                        $ret = $this->save_table_info($np);
                        if ($ret!==FALSE){
                            $i++;
                        }
                    }
                }
                return ($i > 0)?TRUE:FALSE;                                 
            }            
	
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
            public function prefix_exists($pref, $conid){
                    $ci=&get_instance();
                    $qry = 'SELECT loc_table_prefix ';
                    $qry .= ' FROM ogre_location ';
                    $qry .= ' WHERE loc_con_id = ' . $conid;
                    $qry .= ' AND loc_table_prefix = "' . $pref .'"';
                    $query = $ci->db->query($qry);
                    $ret = $query->getNumRows();
                    return $ret;  
            }
            
//---------------------------------------------------
//
//  
//
//---------------------------------------------------    
		public function schedule_code_gen($tblid, $eid=0)
		{
                    $ci=&get_instance();
                    $conid = $ci->session->ogre_conid;  
                    $ci->convention->init($conid);
                    $qry = 'SELECT * FROM ogre_gameschedule ';
                    $qry = ' WHERE ogre_gameschedule.gs_tbl_id='.$tblid;
                    if($eid != 0)
                    {
                            $qry .= ' AND gs_id <> ' . $eid;
                    }
                    $qry .= ' ORDER BY gs_slot_code; ';

                    $ret = '';
                    $ret1 = '';

                    $query = $ci->db->query($qry);

                    if ($query->getNumRows() > 0)
                    {

                        foreach ($query->getResult() as $row)
                         {
                            $ci->event->event_init($row->gs_id);

                            $sc = $ci->event->timegenSlotCode();
                            $ret .=  $sc . ';';
                            $ret .= $this->event->eventid . ';';

                         }
                    }
                    
                    $ret = substr($ret,0,strlen($ret)-1);

                    return $ret;
                }   
                            
                                 
		//---------------------------------------------------
		//
		//  
		//
		//---------------------------------------------------  
		public function event_location_ok($p, $eid='0')
		{
                    $ci=&get_instance();

                    

                    $ret = TRUE;

                    $esc = $ci->event->genSlotCode($p["starttime"], $p["timelength"], $p["eventdate"]);

                    $esc_array = explode(',',$esc);

                    $lsd = $this->schedule_code_gen($p["tbl_id"], $eid);

                    $lsc = explode(";",$lsd);

//                    $lsc_array2 = explode(',',$eids);
                    $i=0;
                    
                    foreach($esc_array as $escode)
                    {			
                       for($i=0; $i<=count($lsc); $i=$i+2) 
                       {
                            if(strpos($escode,$lsc[$i]))
                            {
                                $ret = FALSE;
                                $this->err_eventid = $lsc[$i+1];                           
                            }
                       }
                    }
                    return $ret;		
		}   
                
             
                            
                                 
		//---------------------------------------------------
		//
		//  
		//
		//---------------------------------------------------  
		public function get_location_select($locid=0)
                {
                    $ci=&get_instance();
                    $conid = $ci->session->ogre_conid;  
                    $ret ='';
                    $ret .= '<select id="locid" name="locid" size="1" onchange="loadtables(this.value,' ."'". site_url('ogrex/get_tables','https') ."'" . ', this.name)"' . '>';
                    $qry = 'SELECT * ';
                    $qry .= ' FROM ogre_location ';
                    $qry .= ' WHERE loc_con_id=' . $conid . ' ';
                    $qry .= ' AND loc_deleteflag = 0 ';
                    $qry .= ' ORDER BY loc_seqnum';
                    $query = $ci->db->query($qry);
                    
                    if ($locid == 0){
                            $ret .= '<option value = "0" selected="selected">- SELECT ROOM TYPE - </option>';
                            $ret .= '<option value = "TBD">{ Decide Later }</option>';
                    }

                    if ($query->getNumRows() > 0)
                    {
                        foreach ($query->getResult() as $row)
                        { 
                            if ($locid == $row->loc_con_id)
                            {
                                $ret .= '<option value = "' . $row->loc_locationid  . '" selected="selected">' . $row->loc_location_name . ' (' . $row->loc_con_location_name . ')'  . '</option>';
                            }
                            else 
                            {
                                $ret .= '<option value = "' . $row->loc_locationid  . '">' . $row->loc_location_name . ' (' . $row->loc_con_location_name . ')'  . '</option>';
                            }  
                        }
                    } 

                    $ret .= '</select>';
                    return $ret;                  
                }
                
                //---------------------------------------------------
		//
		//  
		//
		//---------------------------------------------------  
		public function get_tableselect($locid=0, $tblid=0){
                    $ci=&get_instance();
//                    $conid = $ci->session->ogre_conid;  
                    $ret ='';
                    $ret .= '<select id="tableid" name="tableid" size="1" onchange="update_locationheader_table();">';  
//                  this.options[this.selectedIndex].value
                    $qry = 'SELECT * FROM ogre_location, ogre_tables, ogre_table_type ';
                    $qry .= ' WHERE tbl_locationid=loc_locationid ';
                    $qry .= ' AND tt_id=tbl_type ';
                    $qry .= ' AND tbl_locationid=' . $locid . ' ';
                    $qry .= ' AND loc_deleteflag = 0 ';
                    $query = $ci->db->query($qry);
                    if ($tblid == 0){
                            $ret .= '<option value = "0" selected="selected">- SELECT TABLE TYPE - </option>';
                            $ret .= '<option value = "TBD">{ Decide Later }</option>';
                    }

                    if ($query->getNumRows() > 0){
                        foreach ($query->getResult() as $row){ 
                            if ($tblid == $row->tbl_id){
                                $ret .= ($row->tbl_number  > 0) ? '<option value = "' . $row->tbl_id  . '" selected="selected">' . $row->loc_table_prefix . '-' . $row->tbl_number . ' (' . $row->tt_code . ')'  . '</option>' : '<option value = "-' . $row->tbl_id  . '" selected="selected">' . $row->loc_location_name  . ''  . '</option>';
                            }
                            else{
                                $ret .= ($row->tbl_number  > 0) ? '<option value = "' . $row->tbl_id  . '">' . $row->loc_table_prefix . '-' . $row->tbl_number . ' (' . $row->tt_code . ')'  . '</option>' : '<option value = "-' . $row->tbl_id  . '">' . $row->loc_location_name  . ''  . '</option>';                                
                            }  
                        }
                    } 

                    $ret .= '</select>';
                    return $ret;                    
                }
                
//---------------------------------------------------
//
//  
//
//---------------------------------------------------  
    public function transfer_lastyear($from_conid,$to_conid){
            $ci=&get_instance();
            $ci->convention->init($to_conid);
            $qry = 'SELECT * ';
            $qry .= ' FROM ogre_location ';
            $qry .= ' WHERE loc_con_id = ' . $from_conid;
            $qry .= ' AND loc_deleteflag = 0';
            $ret ='';
            $query = $this->db->query($qry);
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){ 
                        $p = array( "locationid" => 0,
                            "location_name" => $row->loc_location_name, 
                            "con_location_name" => $row->loc_con_location_name,
                            "location_seqnum" => $row->loc_seqnum,
                            "table_prefix" => $row->loc_table_prefix, 
                            "last_table_number" => $row->loc_last_table_number,    
                            "open_date" => $ci->convention->start_date,
                            "open_time" => $ci->convention->start_time,
                            "close_date" => $ci->convention->end_date,
                            "close_time" => $ci->convention->end_time,
                            "notes" => $row->loc_notes);
                        $ret .= $this->save_new_loc($p, $to_conid);
                }
            }
            return $ret;	   
    }    
    
    
}  /* END CLASS */ 

?>
