<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$CI_INSTANCE = [];  # It keeps a ref to global CI instance
//---------------------------------------------------
//
//---------------------------------------------------
function register_ci_instance(\App\Controllers\BaseController &$_ci){
    global $CI_INSTANCE;
    $CI_INSTANCE[0] = &$_ci;
}

//---------------------------------------------------
//
//---------------------------------------------------
function &get_instance(): \App\Controllers\BaseController {
    global $CI_INSTANCE;
    return $CI_INSTANCE[0];
}
//---------------------------------------------------
//
//---------------------------------------------------
function debug_to_console($data){
        $output = $data;
        if (is_array($output))
            $output = implode(',', $output);
         echo "<script>console.log('Debug Objects: " . $output . "' );</script>";
}

//---------------------------------------------------
//
//---------------------------------------------------
function stri_replace( $find, $replace, $string ) {
  // Case-insensitive str_replace()
  $parts = explode( strtolower($find), strtolower($string) );
  $pos = 0;
  foreach( $parts as $key=>$part ){
       $parts[ $key ] = substr($string, $pos, strlen($part));
       $pos += strlen($part) + strlen($find);
  }
  return( join( $replace, $parts ) );
 }
//---------------------------------------------------
//
//---------------------------------------------------
function txt2html($txt) {
   // Transforms txt in html
   //Kills double spaces and spaces inside tags.
   while( !( strpos($txt,'  ') === FALSE ) ) $txt = str_replace('  ',' ',$txt);
   $txt = str_replace(' >','>',$txt);
   $txt = str_replace('< ','<',$txt);
   //Transforms accents in html entities.
   $txt = htmlentities($txt);
   //We need some HTML entities back!
   $txt = str_replace('&quot;','"',$txt);
   $txt = str_replace('&lt;','<',$txt);
   $txt = str_replace('&gt;','>',$txt);
   $txt = str_replace('&amp;','&',$txt);
   //Ajdusts links - anything starting with HTTP opens in a new window
   $txt = stri_replace("<a href=\"http://","<a target=\"_blank\" href=\"http://",$txt);
   $txt = stri_replace("<a href=http://","<a target=\"_blank\" href=http://",$txt);
   //Basic formatting
   $eol = ( strpos($txt,"\r") === FALSE ) ? "\n" : "\r\n";
   $html = '<p>'.str_replace("$eol$eol","</p><p>",$txt).'</p>';
   $html = str_replace("$eol","<br />\n",$html);
   $html = str_replace("</p>","</p>\n\n",$html);
   $html = str_replace("<p></p>","<p>&nbsp;</p>",$html);
   //Wipes <br> after block tags (for when the user includes some html in the text).
   $wipebr = Array("table","tr","td","blockquote","ul","ol","li");
   for($x = 0; $x < count($wipebr); $x++) {

       $tag = $wipebr[$x];
       $html = stri_replace("<$tag><br />","<$tag>",$html);
       $html = stri_replace("</$tag><br />","</$tag>",$html);
   }
    return $html;
}

function in_array_r($needle, $haystack, $strict = false) {
   foreach ($haystack as $item) {
       if (($strict ? $item === $needle : $item == $needle) || (is_array($item) && $in_array_r($needle, $item, $strict))) {
           return true;
       }
   }
   return false;   
}