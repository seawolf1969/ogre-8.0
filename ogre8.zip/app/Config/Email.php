<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Email extends BaseConfig
{
    //* @var string
    public $fromEmail;
    //* @var string
    public $fromName;
    //* @var string
    public $recipients;
    //* @var string
    public $userAgent = 'CodeIgniter';
    //* @var string
    public $protocol = 'mail';
    //* @var string
    public $mailPath = '/usr/sbin/sendmail';
    //* @var string
    public $SMTPHost;
    //* @var string
    public $SMTPUser;
    //* @var string
    public $SMTPPass;
    //* @var string
    public $SMTPPort = 25;
    //* @var string
    public $SMTPTimeout = 5;
    //* @var string
    public $SMTPKeepAlive = false;
    //* @var string
    public $SMTPCrypto = 'tls';
    //* @var string
    public $wordWrap = true;
    //* @var string
    public $wrapChars = 76;
    //* @var string
    public $mailType = 'html';
    //* @var string
    public $charset = 'UTF-8';
    //* @var string
    public $validate = false;
    //* @var string
    public $priority = 3;
    //* @var string
    public $CRLF = "\r\n";
    //* @var string
    public $newline = "\r\n";
    //* @var string
    public $BCCBatchMode = false;
    //* @var string
    public $BCCBatchSize = 200;
    //* @var string
    public $DSN = false;
}
