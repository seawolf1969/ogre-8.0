<?php
namespace App\Controllers;
class Justus extends Ogre{
    const ORGANIZATIONID = 1;
//---------------------------------------------------
//
//---------------------------------------------------   
   public function __construct(){
       $this->session = \Config\Services::session();
       if((!isset($this->session->ogre_orgid))){
            if($this->session->ogre_logged_in !== TRUE) { $this->session->set(['ogre_conid' => 0]);}
            $this->session->set('ogre_orgid', (self :: ORGANIZATIONID));
       } else {
           if (intval($this->session->ogre_orgid) !== intval(self :: ORGANIZATIONID)){
               $this->session->set(['ogre_conid' => 0]);
               $this->session->set('ogre_orgid', (self :: ORGANIZATIONID));
           }
           
       }
       parent::__construct();
   }
//---------------------------------------------------
//
//---------------------------------------------------
    public function index($pconid=0){
        return Ogre::homepage($pconid);
    }

}