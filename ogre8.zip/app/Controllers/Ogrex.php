<?php
namespace App\Controllers;

use DateTime;

class Ogrex extends BaseController{
//---------------------------------------------------
//
//---------------------------------------------------    
    public function __construct(){
        
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function index(){
        $data['content'] = 'Error';
        return view("ogre-ajax8", $data);          
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function login($msg='', $dest='index'){
        $data['content'] = '';
        $orgid = $this->session->get('ogre_orgid');
        $conid = $this->session->get('ogre_conid');
        $data['bc'] = 'Log In/Register';
        $logintest = $this->ogre_lib->grant_access(-1);
        $data['jscript']= [base_url() . '/' . JSCRIPT_DIR . '/ogre-login.js'];      
        if ($logintest != TRUE){
            $ret='';
            $ret .= '<div id="horizontalTab-login">';           
            $ret .= '<ul>';                   
            $ret .= '<li>';
            $ret .= '<a href="#login-tab-1" >';
            $ret .= 'Log In';
            $ret .= '</a>';
            $ret .= '</li>';
            $ret .= '<li>';
            $ret .= '<a href="#login-tab-2" >';
            $ret .= 'Make Account';
            $ret .= '</a>';
            $ret .= '</li>';
            $ret .= '</ul>';
            $ret .= '<div id="login-tab-1">';
            $ret .= '<div id="loginform">';
            $ret .= $this->ogre_lib->loginScreen($dest);
            $ret .= '</div>';
            $ret .= '<div id="forgot-password-form" style="display:none;">';
            $ret .=  $this->ogre_lib->forgotLoginScreen();
            $ret .= '</div>';
            $ret .= '</div>';
            $ret .= '<div id="login-tab-2">';
            $ret .= $this->ogre_lib->getRegisterForm($conid);
            $ret .= '</div>';
            $ret .= '</div>';
            $data['content'] .= $ret;
            
        }
         return view("ogre-ajax8", $data);
    }    
    
  
//---------------------------------------------------
//
//---------------------------------------------------
    public function forgotActx(){
        $conid = $this->session->ogre_conid;
        $this->convention->init( $conid);
        $data['content'] = '<div class="row"><div class="col m-3"><p><strong>OGRe Password Reset</strong></p>';
        if(filter_input(INPUT_POST,"user")!==NULL){
            if($this->ogre_lib->userExists(urldecode(filter_input(INPUT_POST,"user"))) == TRUE){
                $pw = $this->person_lib->getUserPassword(urldecode(filter_input(INPUT_POST,"user")));
                if(trim($pw['error']) == ''){
                    $data = $this->person->forgotPasswordEmail($data, $pw, $this->convention->gamingcoordinatoremail, filter_input(INPUT_POST,"user"));
                    $ret = $this->ogre_lib->emailMessageArray($data);
                    $msg = $this->ogre_lib->getMiscContent('%%OGRE.PASSWORD.RESET.SUCCESS%%');
                }
                else{
                    $data['content'] .= $pw['error'];
                    $msg = $this->ogre_lib->getMiscContent('%%OGRE.PASSWORD.RESET.ERROR3%%');
                }
            }
            else{
                $msg = $this->ogre_lib->getMiscContent('%%OGRE.PASSWORD.RESET.ERROR1%%');
            }
        }
        else{
            $msg = $this->ogre_lib->getMiscContent('%%OGRE.PASSWORD.RESET.ERROR2%%');
        }
        $data['content'] .= $msg['content'];
        $data['content'] .= '</div></div>';   
        return view("ogre-ajax8", $data);
    }   
          
//---------------------------------------------------
//
//---------------------------------------------------
    public function activationInX($onsite=0,$id=0){
            $conid = $this->session->ogre_conid;  
            $pid = (($id==0) ? $this->session->ogre_user_ID : $id);
            $this->person->init($conid, '', $pid);
            $logarr = ['ogre_logged_in'  => TRUE, 'ogre_loginerror' => '', 'ogre_welcome' => ' ' . $this->person->fullname . ' is Logged In. '];
            $actconid = (($onsite == 0) ? $this->person->codeActivation(urldecode(filter_input(INPUT_POST, "tranxid")), urldecode(filter_input(INPUT_POST, "emailaddress")), PLAYER) : $this->person->codeActivationOnsite(urldecode(filter_input(INPUT_POST, "tranxid"))));
            if ($actconid !== 0){
                $ret1 = $this->ogre_lib->loginUser($pid, $logarr);
                $ret2 = (($onsite == 0) ? $this->person->expireCode(urldecode(filter_input(INPUT_POST, "tranxid")), $actconid) : TRUE);
                $data = $this->person->emailActivation($actconid);
// SUCCESSFUL ACTIVATION
                $acttext = $this->ogre_lib->getMiscContent('%ACTIVATIONSUCESS%');
                $this->session->set(['ogre_user_activated_' . $conid => 1]);
                $ret = $this->ogre_lib->emailMessageArray($data);
            }
// UNSUCCESSFUL ACTIVATION            
            else{ 
                $acttext = $this->ogre_lib->getMiscContent('%ACTIVATIONFAIL%');
            }
            $contact = $this->ogre_lib->getConGamingInfoKey($conid, "con_gamingcoordinatoremail");
            $clink = mailto($contact, 'Gaming Coordinator');
            $acttext = str_replace('%_GAMING_COORDINATOR_%', $clink, $acttext);
            $data['content'] = $acttext['content'];
            return view("ogre-ajax8", $data);
    } 
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function transactionIdInX() {
        $act = $this->person->getTransactionID(filter_input(INPUT_POST, 'emailaddress'));
        $ret = '';
        $acttext = $this->ogre_lib->getMiscContent("%%ACTIVATION.CODE.NOT.FOUND%%",0,TRUE);
        if (trim($act) != ''){
            $data = $this->person->emailTransaction($act, filter_input(INPUT_POST, 'emailaddress'));
            $acttext = '<p><strong>Activation Code Found</strong></p>';
            $ret = $this->ogre_lib->emailMessageArray($data);
        }
        $data['content'] = $acttext . $ret;
        return view("ogre-ajax8", $data);
    } 
          
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function getGameList(){
        $conid = $this->session->ogre_conid;  
        $p = filter_input_array(INPUT_POST);
        $bycompany = FALSE;
        switch ($p['sort']){
            case 'gametype':
                $bycompany = FALSE; 
                break;
            case 'company':
                $bycompany = TRUE; 
                break;
        }                                   
        $data['content']=$this->schedule_lib->generalGameList($conid, $bycompany);
        return view("ogre-ajax8", $data);                
    }
          
//---------------------------------------------------
//
//
//
//---------------------------------------------------
          public function getGamePlayers($gid=0){
                $this->game->init($gid);  
                $ret = $this->game->min_players;
                $ret .= ',';
                $ret .= $this->game->max_players;
                $data['content']=$ret;
                return view("ogre-ajax8", $data);              
          }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function getGameDescription($gid=0){
          $this->game->init($gid);  
          $ret = $this->game->game_desc;
          $data['content']=$ret;
          return view("ogre-ajax8", $data);              
    }            

//---------------------------------------------------
//
//
//
//---------------------------------------------------          
    public function customTime(){
        $ret ='';
        $p=[];
        $sdate = filter_input(INPUT_POST, 'event_date');
        $starthour = filter_input(INPUT_POST, 'start_time_hour');
        $startminute = filter_input(INPUT_POST, 'start_time_min');
        $startAMPM = filter_input(INPUT_POST, 'start_time_AMPM');
        $slength = filter_input(INPUT_POST, 'slot_length');
        $p['slot_date']=$sdate;
        $p['slot_start_time_hour']=$starthour;
        $p['slot_start_time_min']=$startminute;
        $p['start_time_AMPM']=$startAMPM;
        $p['slot_length']=$slength;
        if($sdate!='0'){
            $sdate1 = new Time(trim($sdate));
            $ret .= $sdate1->format('l').' ';                    
        }
        if($starthour!='0' && $startminute!='' && $startAMPM!='0'&& $slength!='0'){
            $hr = $this->convention->process_hour($starthour,$startminute,$startAMPM);
            $ret .= $this->convention->genSlotTime($p, $hr);
        }
        $data['content']=$ret;
        return view("ogre-ajax8", $data);                
    } 
        
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function getSlotSelectInfo(){
            $p = filter_input_array(INPUT_POST);  
            if(isset($p['conid'])){
                $this->convention->init($p['conid']);
                $slot = [];
                $slot['slotstarttime']=$this->convention->slotInfoByCode(filter_input(INPUT_POST, 'slotcode'),'slot_start_time');
                $slotdate = $this->convention->slotInfoByCode(filter_input(INPUT_POST, 'slotcode'),'slot_date');
                $sdate = new Time($slotdate);
                $slot["slotdate"] = $sdate->format('Y-m-d');
                $slot["slotday"] = $this->convention->slotInfoByCode(filter_input(INPUT_POST, 'slotcode'),'slot_day');
                $slot["slotlength"]  = $this->convention->slotInfoByCode(filter_input(INPUT_POST, 'slotcode'),'slot_length');                                    
                $slot['slotnumber'] = $this->convention->slotInfoByCode(filter_input(INPUT_POST, 'slotcode'),'slot_number');
                $slot['slottime'] = $this->convention->slotInfoByCode(filter_input(INPUT_POST, 'slotcode'),'slot_time');
                $slot['baseslot'] = $this->convention->slotInfoByCode(filter_input(INPUT_POST, 'slotcode'),'slot_baseslot');
                $slot['latenight'] = $this->convention->slotInfoByCode(filter_input(INPUT_POST, 'slotcode'),'slot_latenight');
                $slot['mmrpg'] = $this->convention->slotInfoByCode(filter_input(INPUT_POST, 'slotcode'),'slot_RPGA');
                $slot['slotcode'] = filter_input(INPUT_POST, 'slotcode');       
            }
            else{
                $slot=NULL;
            }
            $data['content']=$this->event->build_nonbase_slot_form($slot);;
            return view("ogre-ajax8", $data);                  
    }   
//---------------------------------------------------
//
//
//
//---------------------------------------------------     
        public function generate_slotecode($conid=0){
            $pst = filter_input_array(INPUT_POST);   
            $this->convention->init($conid);
            $hr = $this->convention->process_hour($pst["slot_start_time_hour"],$pst["slot_start_time_min"],$pst["slot_start_time_AMPM"]);
            $start =  str_pad($hr,2,'0',STR_PAD_LEFT) . substr($pst["slot_start_time_min"],0,1);
            $ret = $this->convention->genSlotCode($pst['sday'], $start, $pst['slength']);
            $data['content']=$ret;
            return view("ogre-ajax8", $data);                     
        }     
        
//---------------------------------------------------
//
// CORE BROWSER FUNCTION
//
//---------------------------------------------------
    public function browseScheduleX($mode='', $whatsnew=FALSE, $aff='all', $late=0){
         // $aff = Affiliation if $mode = rpga
         // $aff = span if $mode = search and $whatsnew = TRUE
         // $aff = gameid if $mode = search and $aff is numeric ($whatsnew = FALSE)
        $pst = filter_input_array(INPUT_POST);

        $gid = 0;
        $gameid=0;
        $span ="";
        $whatsnew = ($whatsnew=="TRUE") ? TRUE : $whatsnew;
        $ret='';
        $conid = $this->session->ogre_conid;  
        $orgid = $this->session->ogre_orgid;
        $this->session->set(['viewmode' => 'MAIN']);
        switch ($mode){
            case 'search':
                $ret = $this->schedule_lib->gameSchedule($pst, $conid, $gameid, $whatsnew, 'P', 'allx', $span);
                break;          
            case 'panelsx':
                $whatsnew = FALSE;                       
                $ret.= $this->schedule_lib->gameSchedule($pst, $conid, 0, $whatsnew, 'N', 'allx');
                break;            
            case 'my-schedule':
                $whatsnew = FALSE;
                $curr_userid = $this->session->ogre_user_ID;
                if ($curr_userid != 0){
                    $this->person->init($conid, '', $curr_userid);
                    $accessrating = $this->person->access_rating;
                    $pst = ['gm_name'=>$curr_userid, 'my-schedule' => "TRUE",'gameslot' => "0",'affiliation' => "0", 'gametype' => "0",'keyword' => '', 'descriptor' => ''];
                    $this->session->set(['viewmode' => 'MAIN']);
                    $ret .= $this->schedule_lib->gameSchedule($pst, $conid, 0, $whatsnew, '', 'allx', $span);                             
                    $ret .= (intval($accessrating) >= GAMEMASTER) ? '<p>'. $this->schedule_lib->shareScheduleLink('p', $curr_userid) . '</p>' : '';
                }
                break; 
                
            case 'regbynumbers':
                $curr_userid = $this->session->ogre_user_ID;
                if ($curr_userid != 0){
                    $this->person->init($conid, '', $curr_userid);
                    $accessrating = $this->person->access_rating;
                }
                $ret .= '<h3>Register by the numbers</h3>';
                $ret .= '<p>You must have both the Event ID and the OGRe ID of the participant.</p>';
                $ret .= $this->schedule_lib->onsiteRegisterByNumbers($accessrating);
                break;
                
            case 'gamelistbycox':
                $bycompany = TRUE; 
                $ret .= '<h1>Game List by Company</h1>';
                $image_properties = ['src' =>'images/ajax-loader.gif','alt'=>'ajax-loader.gif']; 
                $ret .= '<div id="wait" style="display: none">' . img($image_properties) . '</div>';                           
                $ret .= '<div id="schedule-view" style="display:block;padding-top:25px;">';                         
                $ret .= $this->schedule_lib->generalGameList($conid, $bycompany);
                $ret .= '</div>';
                break;              
            
            case 'gamelistx':
                $bycompany = FALSE; 
                $ret .= '<h1>Game List</h1>';
                $image_properties = ['src' =>'images/ajax-loader.gif','alt'=>'ajax-loader.gif']; 
                $ret .= '<div id="wait" style="display: none">' . img($image_properties) . '</div>';                           
                $ret .= '<div id="schedule-view" style="display:block;padding-top:25px;">'; 
                $ret .= $this->schedule_lib->generalGameList($conid, $bycompany);
                $ret .= '</div>';
                break;
            
            case 'allx': 
                $ret .= $this->schedule_lib->gameScheduleXBody($conid, $pst, 'P');
                break;
            case 'search_whatsnew':
                if($whatsnew===TRUE){
                    $span = ($aff=='all') ? '2W' : $aff;
                    $aff = 'all';
                }
                $image_properties = array('src' =>'images/ajax-loader.gif','alt'=>'ajax-loader.gif'); 
                $ret .= '<div id="wait" style="display: none">' . img($image_properties) . '</div>';                        
                $ret .= '<div id="schedule-view" style="display:block;padding-top:25px;">';                        
                $ret .= $this->schedule_lib->gameSchedule($pst, $conid, $gameid, $whatsnew, 'P', 'allx', $span);
                $ret .= '</div>'; 
                break;  
            case 'search_gamelist':
                $this->session->set(array('viewmode' => 'MAIN'));
                if (is_numeric($aff)){
                   $gid = $aff;
                   $gameid = $this->schedule_lib->getGameListFromGameID($gid, $conid);
                } 
                $ret .= $this->schedule_lib->gameSchedule($pst, $conid, $gameid, $whatsnew, 'P', 'allx', $span);
                break;
            case 'rpga':
                $this->session->set(array('viewmode' => 'OP'));
                $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-schedule.op.js');
                $ret = $this->RPGA_lib->gen_row_enum(0, $conid);   
                $ret =  ($aff != 'all') ? $this->RPGA_lib->rpga_schedule_boot($aff, $late,'',FALSE, TRUE, TRUE) : $this->RPGA_lib->rpga_schedule_all($late, FALSE, TRUE);
                break;                      
             case 'rpgagrid':
                    $ret = $this->RPGA_lib->rpga_gridview();
                    break;      
            default:
                $ret = 'Error';
                break;                    
        }               
        $data['content']=$ret;
        return view("ogre-ajax8", $data);
    }        
//---------------------------------------------------
//
//---------------------------------------------------
     public function proposex(){
        $data['tinymce'] = 'TRUE';
        if($this->ogre_lib->grant_access(PLAYER) != TRUE){
            $login('','propose');
        }
        else{
            $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-proposal.js');
            $data['content'] = $this->propose_lib->eventProposal();
            return view("ogre-ajax8", $data);
        }
      }   
      
//---------------------------------------------------
//
//---------------------------------------------------
    public function proposeActionx(){
        $p = filter_input_array(INPUT_POST);
        $conid = $this->session->ogre_conid;     
        if($this->ogre_lib->grant_access(PLAYER) != TRUE){
            $this->login('','propose');
        }
        else{
            $ret = $this->propose_lib->proposeAction($conid, $p);
            if (is_array($ret)) {
                $data['from_eaddress']= $ret['from_eaddress'];
                $data['to_eaddress1']= $ret['to_eaddress1'];
                $data['to_eaddress2']= $ret['to_eaddress2'];
                $data['to_eaddress3']= $ret['to_eaddress3'];
                $data['cc_eaddress1']= $ret['cc_eaddress1'];
                $data['body'] = $ret['body'];
                $data['subject'] = $ret['subject'];
                $data['sent_errmsg'] = '<div class="propose_res">' . $ret['sent_errmsg'] . '</div>';
                $data['sent_msg'] = '<div class="propose_res">' . $ret['sent_msg']. '</div>';
                $data['content'] = '<div><p><input value=" Next Proposal " type="button" name="nextproposal" id="nextproposal" onclick="nextProposal('."'". site_url('ogrex/proposex', 'https') ."','".'proposal_outer'."'".');" /></p>';
                $data['content'] .= '<p>Event Proposal Submitted</p></div>';
                $data['content'] .= '<div class="propose_email">' . $ret['body']. '</div>';
                $ret = $this->ogre_lib->emailMessageArray($data);   
            }
            else{
                   $data['content'] = $ret;
            }
            return view("ogre-ajax8", $data);
        }
    }
      
//---------------------------------------------------
//
//
//
//---------------------------------------------------
     public function myProfileInX() {
        $orgid = $this->session->ogre_orgid;
        $conid = $this->session->ogre_conid;  
        $p = filter_input_array(INPUT_POST);
        
        if($this->ogre_lib->grant_access(PLAYER) !== TRUE){
            $login('','myprofile');
        }
        else{
          $this->person->init($conid, '', $this->session->ogre_user_ID);
          $res = $this->person->saveProfileInfo($p);
          $data['content'] = $res['errmsg'];
          return view("ogre-ajax8", $data);
        }
      }
      
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function register_inx(){
        if($this->ogre_lib->grant_access(PLAYER) != TRUE){
            $p = filter_input_array(INPUT_POST);
            $ret = $this->ogre_lib->registerIn($p);
            $data['content'] = $ret['results'];
            if(isset($ret["include"])){
                $data['from_eaddress']= $ret['from_eaddress'];
                $data['to_eaddress1']= $ret['to_eaddress1'];
                $data['to_eaddress2']= $ret['to_eaddress2'];
                $data['to_eaddress3']= $ret['to_eaddress3'];
                $data['body'] = $ret['body'];
                $data['subject'] = $ret['subject'];  
                $ret = $this->ogre_lib->emailMessageArray($data);
            }
            return view("ogre-ajax8", $data);
        }
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function password(){
      $orgid = $this->session->ogre_orgid;
      $conid = $this->session->ogre_conid;  
      if($this->ogre_lib->grant_access(PLAYER) == TRUE){
        $this->person->init($conid, '', $this->session->ogre_user_ID);
        $data['content'] = $this->person->changePasswordForm();
        return view("ogre-ajax8", $data);
      }
    }
//---------------------------------------------------
//
//---------------------------------------------------          
    public function gameproposal_del($propid=0){
        $ret='';
        $p = filter_input_array(INPUT_POST); 
        $ret1=$this->proposal->delGameProp($p['gpid']);
        $ret= ($ret1===TRUE) ? $this->person->displayPlayerRequests(): $ret='0';
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);          
    }    
//---------------------------------------------------
//
//---------------------------------------------------        
    public function removePlayerMyschedule(){
        $ret='';
        $p = filter_input_array(INPUT_POST); 
        $conid = $this->session->ogre_conid;            
        $curruserid = $this->session->ogre_user_ID;
        $this->person->init($conid, '', $curruserid);
        if(isset($p['pid'])){   
            $ret = $this->event->event_init($p['gid']);
            $ret = $this->event->removePlayer(0, $p['pid'], $p['gid']);
            $ret = $this->event->promote_alternate($p['gid']);
        }
        $data['content']=$ret;
        return view("ogre-ajax8", $data);                        
    }
//---------------------------------------------------
//
//---------------------------------------------------        
    public function removeAllMyschedule(){
        $ret='';
        $p = filter_input_array(INPUT_POST); 
        $conid = $this->session->ogre_conid;
        if(isset($p['pid'])){   
            $ret = $this->person->removeMeAll($p['pid'], $conid);
        }else{
            $curruserid = $this->session->ogre_user_ID;
            $ret = $this->person->removeMeAll($curruserid, $conid);
        }
        $data['content']=$ret;
        return view("ogre-ajax8", $data);                        
    }
//---------------------------------------------------
//
//---------------------------------------------------        
    public function getMySchedule(){
        $ret='';
        $conid = $this->session->ogre_conid;
        $p = filter_input_array(INPUT_POST); 
        $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-my-comments.js');
        $ret .= $this->person->displayJQUIMySchedule($p['pid'],$conid,FALSE);     
        $data['content']=$ret;
        return view("ogre-ajax8", $data);         
    }      
//---------------------------------------------------
//
//---------------------------------------------------        
    public function getMyHistory($pid=0){
        $ret='';
        $conid = $this->session->ogre_conid;
        $p = filter_input_array(INPUT_POST);
        $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-my-comments.js');
        $pid = (($p !== NULL)? $p['pid'] : $pid);
        $ret .= $this->person->displayJQUIMySchedule($pid,$conid,TRUE);
        $data['content']=$ret;
        return view("ogre-ajax8", $data);         
    }   
//---------------------------------------------------
//
//
//
//---------------------------------------------------        
    public function getDeleteProgress(){
        $ret='';
        $p = filter_input_array(INPUT_POST); 
        $conid = $this->session->ogre_conid;
        if(isset($p['pid'])){   
            $ret = $this->person->deleteFromAllProgress($p['pid'], $conid);
        }else{
            $curruserid = $this->session->ogre_user_ID;
            $ret = $this->person->deleteFromAllProgress($curruserid, $conid);
        }
        $data['content']=$ret;
        return view("ogre-ajax8", $data);              
    }    
//---------------------------------------------------
//
//
//
//---------------------------------------------------          
    public function getGameInformation($gid=0, $dmode='P'){
        $ret='';
        $p = filter_input_array(INPUT_POST);
        if ($p === NULL){
            $p['gid'] = $gid;
        }
        $ret=$this->schedule_lib->gameInfoDialogTabs($p['gid'], $dmode);
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);          
    }
//---------------------------------------------------
//
//---------------------------------------------------          
     public function gameInfoRefresh(){
         $ret='';         
         $p = filter_input_array(INPUT_POST);
         $ret = $this->schedule_lib->gameDescDialog($p['gid']);
         $data['content'] =$ret;            
         return view("ogre-ajax8", $data);          
     }    
//---------------------------------------------------
//
//---------------------------------------------------
    public function preregForm($gid, $pn=100, $edit=FALSE){
        $conid = $this->session->ogre_conid;  
        $data['title'] = 'Preregistration Form';
        $data['style'] = 'style2a.css';
        $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-prereg-form.js');
        $data['content'] = $this->schedule_lib->preregForm($gid, $conid, $edit);
        $data['norefresh']="Yes";
        return view("ogre-ajax8", $data);
    }     

//---------------------------------------------------
//
//---------------------------------------------------
    public function preRegFormX($edit=FALSE){
        $p = filter_input_array(INPUT_POST);
        $conid = $this->session->ogre_conid;  
        $gid = $p["gameid"];
        $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-prereg-form.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-games.js');
        $data['content'] = $this->schedule_lib->preRegFormX($gid, $conid, $edit);
        return view("ogre-ajax8", $data);         
      }  
        
//---------------------------------------------------
//
//---------------------------------------------------
    public function regFormX(){
        $p = filter_input_array(INPUT_POST);
        $this->session->set(array('viewmode' => $p['vmode']));       
        $gid = $p["gameid"];
        $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-prereg-form.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-games.js');
        $data['content'] = $this->schedule_lib->registerFormX($gid);
        return view("ogre-ajax8", $data);              
    } 

//---------------------------------------------------
//
//---------------------------------------------------
 public function preregAction($gid, $type="regular", $edit=FALSE, $del=FALSE){
    $conid = $this->session->ogre_conid;  
    $p = filter_input_array(INPUT_POST);
    $this->event->event_init($gid);
    $data['title'] = 'Preregistration Form';
    $data['style'] = 'style2a.css';
    $p['vmode'] = '!x';
    if($del!=FALSE){
        $del=TRUE;
        $edit=FALSE;
        $orgid=$this->session->ogre_orgid;
        $pid = $this->session->ogre_user_ID;
        $this->person->init($conid,'',$pid);
        $p['remove']='1';
        $p['pname'] = $this->person->fullname;
        $p['pemail'] = $this->person->email;
        $p["preregid"]= $this->person->getRegistrationInfo($gid, 'pp_player_prereg_id');
        $ret=$this->schedule_lib->preregAction(FALSE, $p, $gid, $conid, $pid);
        $data['content'] = $ret['resp'];
        }
        else{
            $orgid=$this->session->ogre_orgid;
            $ret=$this->schedule_lib->preregAction(FALSE, $p, $gid, $conid);
            $data['content'] = $ret['resp'];
            if(isset($ret['message'])){
                $data['from_eaddress']= array($this->convention->gamingcoordinatoremail);
                $data['to_eaddress1']= array($p['pemail']);
                $data['to_eaddress2']= array('');
                $data['to_eaddress3']= array('');
                $data['cc_eaddress1']= array('');
                $data['body'] = array($ret['message']);
                $data['subject'] = array($ret['subject']);
                $data['sent_errmsg'] = array('Error in Sending Confirmation Email');
                $data['sent_msg'] = array('Confirmation Email Sent');
                if($ret["contactGM"]==TRUE){
                    if(trim($this->event->prereg_contact) !== ''){
                        $data['from_eaddress']=  array_merge($data['from_eaddress'], array($p['pemail']));
                        $data['to_eaddress1']= array_merge($data['to_eaddress1'], array($contact));
                        $data['to_eaddress2']= array_merge($data['to_eaddress2'],array(''));
                        $data['to_eaddress3']= array_merge($data['to_eaddress3'], array(''));                                
                        $data['body'] = array_merge($data['body'], array($ret['message']));
                        $data['subject'] = array_merge($data['subject'], array('Preregistered Player Message: ' . $this->event->game_name));
                        $data['sent_errmsg'] = array_merge($data['sent_errmsg'], array('Error in Sending GM Note Email'));
                        $data['sent_msg'] = array_merge($data['sent_msg'],array('GM Note Email Sent'));                            
                    }
                }
              $ret = $this->ogre_lib->emailMessageArray($data);  
            }
        }
        return view("ogre-ajax8", $data);
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function preregActionX($gid, $edit=FALSE, $del=FALSE){
        $pst = filter_input_array(INPUT_POST);
        $conid = $this->session->ogre_conid;  
        $orgid=$this->session->ogre_orgid;
        $this->event->event_init($gid);
        $this->session->set(array('viewmode' => $pst['vmode']));
// REMOVE ME
        if($del==TRUE){ 
            $del=TRUE;
            $edit=FALSE;
            $pid = (isset($pst['pid'])) ? (($pst['pid'] != '0') ? $pst['pid']: $this->session->ogre_user_ID) : $this->session->ogre_user_ID;
            $this->person->init($conid,'',$pid);
            $p1['remove'] = '1';
            $p1['pname'] = $this->person->fullname;
            $p1['pemail'] = $this->person->email;
            $p1["preregid"] = $this->person->getRegistrationInfo($gid, 'pp_player_prereg_id');
            $p = array_merge($p1, $_POST);
            $ret = $this->schedule_lib->preregAction(FALSE, $p, $gid);
            $data['content'] = (isset($ret['resp']) ? $ret['resp'] : 'ERORR');
        }
        else{
            if(isset($pst['role']) && trim($pst['role'])!=''){
                $pst['activity2'] = $pst['role'];
            }   
            $ret = $this->schedule_lib->preregAction(FALSE, $pst, $gid);                    
            $data['content'] = $ret['resp'];
            if(isset($ret['message'])){
                $data['to_eaddress1']= $pst['pemail'];
                $data['cc_eaddress1']= $this->convention->gamingcoordinatoremail;
                $data['body'] = $ret['message'];
                $data['subject'] = $ret['subject'];
                $data['sent_errmsg'] = 'Error in Sending Confirmation Email';
                $data['sent_msg'] = 'Confirmation Email Sent';
                $ret = $this->ogre_lib->emailMessageArray($data);
                if (isset($ret["contactGM"])){
                    if($ret["contactGM"]===TRUE){
                        $contact=$this->event->prereg_contact;
                        if($contact!=''){
                            $data['from_eaddress'] = $pst['pemail'];
                            $data['replyto_eaddress'] = $pst['pemail'];
                            $data['to_eaddress1']= $contact;                              
                            $data['body'] = $ret['message'];
                            $data['subject'] = 'Preregistered Player Message: ' . $this->event->game_name;
                            $data['sent_errmsg'] = 'Error in Sending GM Note Email';
                            $data['sent_msg'] = 'GM Note Email Sent'; 
                            $ret = $this->ogre_lib->emailMessageArray($data);
                        }
                    }
                }
            }
        }
        return view("ogre-ajax8", $data);
    }

//---------------------------------------------------
//
//---------------------------------------------------
    public function autoPreregActionX($gid){
        $pst = filter_input_array(INPUT_POST);
        $p = array();
        $this->event->event_init($gid);
        $this->session->set(array('viewmode' => $pst['vmode']));
        $vmode = $pst['vmode'];
        $conid = $this->session->ogre_conid;
        $role = $pst['role'];
        if (($role !== FALSE) && (trim($role) !== '')){
            $p['activity2'] = (intval($role) == 0) ? "Player" : "Judge";
        }
        $p["vmode"] = $vmode;
        $p["preregid"] = '-9999';
        $p["pnotes"] = '';
        $p["playgm"] = '0';
        $p['combatrole'] = '';
        $p["playerAPL"] = '';
        $p["charlevel"] = ''; 
        $p["judgeAPL"] = '';      
        $p['userID'] = $pst['pid']; 
        $this->person->init($conid, '', $pst['pid']);
        $p['pname'] = $this->person->fullname;
        $p['pemail'] = $this->person->email;                                              
        $ret = $this->schedule_lib->preregAction(FALSE, $p, $gid);       
        if(isset($ret['message'])){
            $data['content'] = ($vmode === 'MAIN') ? $this->schedule_lib->buildGameScheduleRowRefresh($gid) : ((trim($vmode) !== '') ? $this->RPGA_lib->build_rpga_cellx($gid) : 'ERROR');
//EMAIL            
            $data['from_eaddress']= $this->convention->gamingcoordinatoremail;
            $data['to_eaddress1']= $p['pemail'];
            $data['cc_eaddress1']= $this->convention->gamingcoordinatoremail;
            $data['body'] = $ret['message'];
            $data['subject'] = $ret['subject'];
            $data['sent_errmsg'] = 'Error in Sending Confirmation Email';
            $data['sent_msg'] = 'Confirmation Email Sent';                                                                
            $data['silentsend']='TRUE'; 
            $ret = $this->ogre_lib->emailMessageArray($data);
//            $data['content'] = $this->schedule_lib->buildGameScheduleRowRefresh($gid, $dmode='P');
        }
        else{
            $data['content'] = "";
        }
        return view("ogre-ajax8", $data);
    }
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function regAction($gid, $gm=0){
        $pst = filter_input_array(INPUT_POST);
        $this->event->event_init($gid);
        $data['title'] = 'Registration Form';
        $data['content'] = $this->schedule_lib->registerPlayerOnsite($pst, $gid, $gm);       
        return view("ogre-ajax8", $data);
    }     
//---------------------------------------------------
//
//---------------------------------------------------
    public function regActionRegByNum($gid, $gm=0){
        $pst = filter_input_array(INPUT_POST);
        $pst['alternate'] = 0;
        $this->event->event_init($gid);
        if($this->event->is_full()==TRUE){
            $pst['alternate'] = 1;
        }
        $ret1 = $this->schedule_lib->registerPlayerOnsite($pst, $gid, $gm);
        $ret = ($ret1 != FALSE) ?  '<p>Player is registered</p>' : '<p>Error! There was a problem with the registration</p>';
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);
      }
//---------------------------------------------------
//
//---------------------------------------------------
    public function adminAddPlayer($gid, $type="rpga", $edit=FALSE){
            $data['title'] = 'Preregistration Form';
            $data['style'] = 'style2a.css';
            $this->event->event_init($gid);
            $data['content'] = $this->event->buildAddJudgePlayerAdmin($gid);
            return view("ogre-ajax8", $data);
    } 
//---------------------------------------------------
//
//---------------------------------------------------
    public function gameEditX(){
      $pst = filter_input_array(INPUT_POST);
      $gid = $pst['id'];
      $ret='';      
      $ret.= $this->event->gameEditForm($gid);                
      $data['content']=$ret;
      return view("ogre-ajax8", $data);
    } 
//---------------------------------------------------
//
//---------------------------------------------------
    public function gameEditInX(){
        $pst = filter_input_array(INPUT_POST);
        $rval = $this->event->updateGameDesc($pst);
        $data['content'] = ($rval == TRUE) ?   'DONE' :  'ERROR';
        return view("ogre-ajax8", $data);
    }    

//---------------------------------------------------
//
//---------------------------------------------------
    public function gamesReqDetails($reqid, $ajax=FALSE){
        $data['title'] = 'Game Proposal/Request Details';
        $data['style'] = 'style2a.css';
        $ret=$this->proposal->proposalWhat($reqid);
        $ret.=$this->proposal->proposalWhen($reqid);
        $ret.=$this->proposal->proposalWhere($reqid);
        $ret.=$this->proposal->proposalOther($reqid);         
        $data['content'] = $ret;
        if($ajax===FALSE){
            return view("ogre_view2", $data);
        }
        else{
            return view("ogre-ajax8", $data);
        }
    } 
//---------------------------------------------------
//
//---------------------------------------------------        
    public function closedMsg($id){
        $content = $this->ogre_lib->getMiscContent($id);                    
        $data['content']='';
        if(is_array($content)){
            $data['content'] = '<p>' . $content['content'] . '</p>';    
        }          
        return view("ogre-ajax8", $data);
    }         
 
//---------------------------------------------------
//
//
//
//---------------------------------------------------        
    public function playerGameListRefresh(){
        $conid = $this->session->ogre_conid;  
        $curr_userid = $this->session->userdata('ogre_user_ID');         
        $plist = $this->person->getPlayerScheduleRoles($conid, $curr_userid);
        $data['content'] = $plist;
        return view("ogre-ajax8", $data);            
    }        
    
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------        
    public function gmPlayerRefresh(){
        $conid = $this->session->ogre_conid;  
        $pst = filter_input_array(INPUT_POST);
        $this->convention->init( $conid);
        $gid = $pst["gid"];
        $ret=$this->event->getGMPlayerList($gid);
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);            
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------        
    public function gmPlayerDDRefresh($type){
        $conid = $this->session->ogre_conid;  
        $pst = filter_input_array(INPUT_POST);
        $this->convention->init( $conid);
        $gid = $pst["gid"];
        $ret = ($type==='1') ? '<p><span class="ddgms">&#10551; <strong>GM/Host(s)</strong>: '. $this->schedule_lib->getGMNames($gid,$type). '.</span></p>' : '<p><span class="ddplayers">&#10551; <strong>Player(s)</strong>: '. $this->schedule_lib->getGMNames($gid,$type). '.</span></p>';
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);            
    }
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------           
    public function reAffiliationMenu($late=0){
        $conid = $this->session->ogre_conid;  
        $pst = filter_input_array(INPUT_POST);
        $sel = $pst['aff'];
        $data['content'] = $this->RPGA_lib->affiliation_menux($conid, $late, $sel);
        return view("ogre-ajax8", $data);
    } 
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------        
    public function getRegisteByNumEventInfo(){
        $conid = $this->session->ogre_conid;  
        $pst = filter_input_array(INPUT_POST);
        $id = $pst['eid'];
        $this->event->event_init($id, $conid);           
        if($this->event->id!=0){
            $einfo = $this->event->getDaySlotTime_short() . ': ' . $this->event->game_name;
            if(trim($this->event->game_title) !=''){
                $einfo .= '<br /><em>'.$this->event->game_title.'</em>';
            }
            if($this->event->max_number_of_players!=0){
                $einfo .= ($this->event->mmrpgFlag==0) ? '<br /><strong>Players (Max/Curr.)</strong>: '.$this->event->max_number_of_players.'/'.$this->event->getNumberOfPlayers('0') : '<br /><strong>Players (Max/Curr.)</strong>: '.intval($this->event->rpga_number_of_tables)*intval($this->event->rpga_max_players_per_table).'/'.$this->event->getNumberOfPlayers('0');
            }
        }
        else {
            $einfo = 'UNKNOWN EVENT!';
        }
        $data['content'] = $einfo;
        return view("ogre-ajax8", $data);          
    }
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------        
    public function getRegisterByNumPlayerInfo(){
        $conid = $this->session->ogre_conid;  
        $pst = filter_input_array(INPUT_POST);
        $id = $pst['pid'];
        $this->person->init($conid,'',$id);           
        $pinfo = ($this->person->user_id_num != 0) ?  $this->ogre_lib->bootBadgePill($this->person->fullname,"bg-success") : $this->ogre_lib->bootBadgePill('UNKNOWN USER!',"bg-danger");                      
        $data['content'] = $pinfo;
        return view("ogre-ajax8", $data);          
    } 

//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function getMultiSlotChildren($gid=0){
        $pst = filter_input_array(INPUT_POST);
        if($gid==0){
            $gid=$pst['id'];
        }
        $ret=$this->event->getMultiSlotChildren($gid);
        $data['content'] = $ret;               
        return view("ogre-ajax8", $data);
    }   
    
    //---------------------------------------------------
    //
    //
    //
    //---------------------------------------------------          
      public function regularRowRefresh($gid=0, $dmode="P"){
        $pst = filter_input_array(INPUT_POST);
        if($gid==0){
            $gid = $pst['id'];
        }
        if(isset($pst['vmode'])){
            $this->session->set(array('viewmode' => $pst['vmode']));
        }
        else{
            $this->session->set(array('viewmode' => 'MAIN')); 
        }
        $ret = $this->schedule_lib->buildGameScheduleRowRefresh($gid, $dmode);
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);               
      }   
      
//---------------------------------------------------
//
//
//
//---------------------------------------------------             
    public function opCellRefresh($gid=0){
        $conid = $this->session->ogre_conid;  
        $pst = filter_input_array(INPUT_POST);
        $this->convention->init( $conid);
        $ret='';
        if ($gid==0) {
            $gid = $pst["gid"];                   
        }
        if(isset($pst['vmode'])){
            $this->session->set(array('viewmode' => $pst['vmode']));
            $config->set_item('viewmode', $pst['vmode']);
        }            
        $ret = $this->RPGA_lib->build_rpga_cellx($gid);
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);            
    }
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
     public function conventionIn(){
        $pst = filter_input_array(INPUT_POST);
        
        $data['content'] ='';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE) {
            $ret = $this->admin_lib->conventionIn($pst);
            $data['content'] =  ($ret == TRUE) ? '<p>Convention Data Saved!  Refresh the list to see results.</p>' : '<p>Error: Convention Data Not Saved</p>';
        }
        else{
            $data['content'] ='Access Denied';
        }
        return view("ogre-ajax8", $data);
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function slotsx($slotid=0, $conid=0){
       
       $ret = '<h2>Slots Admin</h2>';
       $ret .= $this->admin_lib->slotForm($conid, $slotid);
       $data['content'] = $ret;
       $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-script.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-slots.js');
       return view("ogre-ajax8", $data);
    }
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
     public function slotsInX($cid=0){
        $conid = ($cid==0) ? $this->session->userdata('ogre_conid') : $cid;
        $pst = filter_input_array(INPUT_POST);
        $this->convention->init($conid);
        
        $ret = $this->admin_lib->slotsInX($pst);
        $ret1 = ($ret===TRUE) ? '<p>Slot successfully added.</p>' : '<p>ERROR</p>';
        $data['content'] = $ret1;
        return view("ogre-ajax8", $data);
     }
     
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function slotsRem($id,$cid=0){
        $conid = ($cid==0) ? $this->session->userdata('ogre_conid') : $cid;
        $this->convention->init($conid);
        
        $ret = $this->admin_lib->slotRemX($id);
        $ret = ($ret===TRUE) ? $this->convention->viewSlotList(TRUE, $conid) :  $ret='ERROR';
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function slotsListx($cid=0){
        $conid = ($cid==0) ? $this->session->userdata('ogre_conid') : $cid;
        $this->convention->init($conid);             
        $ret = $this->convention->viewSlotList(TRUE, $conid);
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);
    }   
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function opAdminSlotChange($id=0,$newslot=""){
       $pst = filter_input_array(INPUT_POST); 
       $conid = $this->session->ogre_conid;  
       if(isset($pst['newslot'])){
           $id = $pst['id'];
           $newslot = $pst['newslot'];
       }
       $this->event->event_init($id, $conid);
       $res = $this->event->xmodifyOPGamesSlots($pst);
       $res['msg']=str_replace('%GAME_TITLE%', '<em>'.$this->event->game_title.'</em>', $res['msg']);
       $ret = $res['msg'];
       $data['content'] = $ret;
       return view("ogre-ajax8", $data);
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function opadmin_slotcheck($id=0,$newslot=""){
       $ret = '';
       $pst = filter_input_array(INPUT_POST);
       $conid = $this->session->ogre_conid;  
       if(isset($pst['newslot'])){
           $id = $pst['id'];
           $newslot = $pst['newslot'];
       }
       $this->event->event_init($id, $conid);
       $res = $this->event->checkScenarioExistsInSlot($newslot);
       if($res ===TRUE){
           $ret = 'Exists!';
       }
       $data['content'] = $ret;
       return view("ogre-ajax8", $data);              
    }
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function scenario_edit($scenid=0){
       
       $ret ='';
       if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
           $ret .= '<div id="scenario-admin-main-form">';
           $ret .= $this->scenario->scenarioAdminForm($scenid);
           $ret .= '</div>';
           $data['content'] = $ret;
       }          
       return view("ogre-ajax8", $data);
    }
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function scenarioList($aff=""){
        
        $ret ='';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            $ret .= '<div id="scenario-admin-main-list">';
            $ret .= $this->scenario->scenarioListAdmin($aff); 
            $ret .= '</div>';
            $data['content'] = $ret;
        }          
        return view("ogre-ajax8", $data);
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function scenarioIn(){
        $conid = $this->session->ogre_conid;  
        $pst = filter_input_array(INPUT_POST);
        
        $ret ='';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            $scenid = $pst['scenid'];
            $this->scenario->init(intval($scenid), $conid);
            $res = $this->scenario->saveScenario($pst);               
            $ret = ($res['valid'] == TRUE) ? '<p>Scenario Saved</p>' : '<p>Error Saving Scenario'.$ret['msg'].'</p>';
            $data['content'] = $ret;
        }
        else{
            $data['content'] ='Access Denied';
        }
        return view("ogre-ajax8", $data);
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function refresh_scenariolist($aff=''){
//        
//        $ret ='';
//        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
//            $ret = $ci->scenario->scenarioListAdmin($aff);               
//            $data['content'] = $ret;
//        }
//        return view("ogre-ajax8", $data);
    } 
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function refreshMySchedule(){
        $ret ='';
        $p = filter_input_array(INPUT_POST);
        $ret = $this->person->displayMySchedule($this->session->ogre_conid, $p['pid']);               
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);
    }    

//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function refreshMyScheduleDialog(){
        $ret ='';
        $p = filter_input_array(INPUT_POST);
        $ret = $this->person->displayMySchedule($this->session->ogre_conid, $p['pid']);               
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);
    }        
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function scenarioDel($scenid = 0){
        $scenid = ($input->post('scenid')!==FALSE) ? $input->post('scenid') : $scenid;                 ;
        $orgid = $this->session->ogre_orgid;
        $conid = $this->session->ogre_conid;  
        
        $ret ='';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            $this->scenario->init($scenid, $conid);
            $res = $this->scenario->removeScenario();
            $ret1 = ($res==TRUE) ? $this->RPGA_lib->reset_enums($conid) : FALSE;                        
            $ret= ($ret1===TRUE) ? 'TRUE' : '';
            $data['content'] = $ret;
        }
        return view("ogre-ajax8", $data);
    }
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function scenario_check($scenid = 0){
        $scenid = ($input->post('id')!==FALSE) ? $input->post('id') : $scenid;
        $conid = $this->session->ogre_conid;  
        
        $ret ='0';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            $this->scenario->init($scenid, $conid);
            $ret = $this->scenario->removeScenarioCheck($scenid);
            $data['content'] = $ret;
        }
        return view("ogre-ajax8", $data);
    }
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function delete_game($gameid){
        $conid = $this->session->ogre_conid;  
        
        $ret ='';
        $view='ogre-ajax8';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){                
            $this->event->event_init($gameid);
            $res = $this->event->removeGame();
            if($res===TRUE){
                if ($this->event->rpga_number_of_slots > 1){
                    $gameid2 = $this->event->findOPMultiRoundChild();
                    foreach($gameid2 as $gid2){
                        $this->event->event_init($gid2);
                        $ret1 = $this->event->removeGame();
                    }
                }
            }                
            $ret = ($res===TRUE) ? '<p>Game Removed</p>':'<p>Error in Data.  Not Removed</p>';
            if ($this->event->mmrpgFlag == 1){
                $ret1 = $this->RPGA_lib->reset_enums($conid);
            }
            $data['content'] = $ret;
        }
        else{
            $data['content'] ='Access Denied';
        }
        return view($view, $data);
    }
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function gameListX($gtid = 0){
       $p = filter_input_array(INPUT_POST);
       $gtid = (($gtid == 0) ? $p['gid'] : $gtid );
       $kw = ((isset($p['kword']))? $p['kword'] : '');
       $ret = $this->game->getGameViewList($gtid, 'Yes', '' , $kw);
       $data['content'] = $ret;
       $data['jscript']= [base_url() . '/' . JSCRIPT_DIR . '/ogre-games.js'];
       return view("ogre-ajax8", $data);
    }    
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function game($gid=0){
        
        $ret ='';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){                            
            if ($gid != 0){
                $title = 'Edit Game';
                $intro = array('content' => '', 'title'=>'');
            }
            else{
                $title = 'Add Game';
                $intro = $this->ogre_lib->getMiscContent(25);
            }               
            $ret = '<h2>' . $title . '</h2>';
            $ret .= $this->game->game_form($gid);
            $ret .=  $intro['content'];
        }
        else{
            $ret ='Access Denied';
        }
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);
    }    
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------   
    public function gameIn(){
        
        $ret ='';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            $p = filter_input_array(INPUT_POST);
            if ($p["gn_game_id"] == 0){
                $p["gn_gman_id"] = ($p["gn_gman_id"] == '0') ? ((trim($p['gman_name'])!="") ? $this->game->createNewPublisher($p["gman_name"], $p["gman_web"]) : $p["gn_gman_id"]) : $p["gn_gman_id"] ;
                $res = $this->game->game_insert($p);
                $ret = ($res['success'] != TRUE) ? $res['errormsg'] : '<p>Game Saved</p>';                       
            }
            else{
                $this->game->init($p["gn_game_id"]);                    
                $res = $this->game->game_update($p);
                $ret = ($res['success'] != TRUE) ? $res['errormsg'] : '<p>Game updated</p>';               
            }
            $data['content'] = $ret;
        }
        else{
            $data['content'] ='Access Denied';
        }
        return view("ogre-ajax8", $data);
    }    
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function preRegEditIn(){
       
       $p = filter_input_array(INPUT_POST);
       $rval = $this->event->save_prereg_info($p);  
       $data['content']=($rval==TRUE)? $this->event->preregEditForm($p['gameid']) : '0';
       return view("ogre-ajax8", $data);
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------         
    public function openPreReg($gmid=0, $gid=0){
        $p = filter_input_array(INPUT_POST);
        
        $rval = $this->event->save_prereg_info($p, TRUE);
        if($rval===TRUE){
            $ret = $this->event->preregisterEditList($gmid, $gid);
        }
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);            
    }    
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------         
    public function getSlots(){
        $p = filter_input_array(INPUT_POST);
        $conid = $this->session->ogre_conid;  
                    
        $ret = $this->admin_lib->getSlotsX($conid, $p['sid']);           
        $data['content'] =$ret;         
        return view("ogre-ajax8", $data);
    }  
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------         
    public function getAddSlot($sid=0, $conid=0){
        if($conid==0){
            $conid = $this->session->ogre_conid;  
        }
        $ret = '';
        $ret .= '<h2>Add/Edit Slots</h2>';
        if(filter_input(INPUT_POST, 'sid')!==NULL){
            $sid = filter_input(INPUT_POST, 'sid');
        }
          
        $ret .= $this->admin_lib->slotForm($conid, $sid);
        $data['content'] =$ret;        
        return view("ogre-ajax8", $data);
    }      
//---------------------------------------------------
//
//---------------------------------------------------         
    public function getGames($pcg=0){
        $ci=&get_instance();
        $p = filter_input_array(INPUT_POST);
        $pc = ($pcg == 0) ? FALSE : TRUE;
        $ret = $ci->game->getGameSelect($p['gid'], $pc, 1, !$pc);         
        $data['content'] = $ret;           
        return view("ogre-ajax8", $data);
    }    
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function locationIn($conid=0){
        $conid = (($conid == 0) ? $this->session->ogre_conid : $conid);
        $p = filter_input_array(INPUT_POST);
        $ret = '';
        $ret1 = $location->new_loc_data($p, $conid);
        if(isset($p['last_table_number'])){
            $tables = ((trim($p['last_table_number'])!=="") ? $p['last_table_number'] . ' Tables Created' : '');
            $ret =($ret1===TRUE)? 'Location Added. ' . $tables : 'Problems adding Location';
        }else{
            $ret =($ret1===TRUE)? 'Location Saved. ' : 'Problems saving Location';
        }
            
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);  
    }     
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function locationsImport($to_conid){
        
        $ret = $this->admin_lib->locationImport($to_conid);
        $ret .= '<div id="locationimportllist">';
        $ret .= '</div>';
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);
    }   
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function locationsImportIn($from_conid, $to_conid){
       $ret = $location->transfer_lastyear($from_conid,$to_conid);
       $data['content'] = $ret;
       return view("ogre-ajax8", $data);
    }
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function locationImportList($from_conid){
       $ret = $convention_lib->viewLocationList($from_conid, FALSE);
       $data['content'] = $ret;
       return view("ogre-ajax8", $data); 
    }

//---------------------------------------------------
//
//---------------------------------------------------
    public function delLocation(){        
       $ret='0';
       $ret = $location->remove_location(filter_input(INPUT_POST, 'locid'));      
       $ret=($ret===TRUE) ? '1' : '0';
       $data['content'] =$ret;            
       return view("ogre-ajax8", $data);
    }    
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function slotsImport($to_conid){
       
       $ret = $this->admin_lib->slotImport($to_conid);
       $data['content'] = $ret;
       return view("ogre-ajax8", $data);             
    }    
//---------------------------------------------------
//
//---------------------------------------------------
    public function slotsImportIn($from_conid, $to_conid){
        
       $ret = $this->admin_lib->transferLastYearSlots($from_conid,$to_conid);
       $data['content'] = $ret;
       return view("ogre-ajax8", $data);
    }     
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function slotImportList($from_conid){
       $ret = $this->convention->viewSlotList(FALSE, $from_conid);
       $data['content'] = $ret;
       return view("ogre-ajax8", $data);
    }  
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function checkprefix($pref='0', $conid=0){
       $pref = ($pref==='0')?filter_input(INPUT_POST, 'pref'):$pref; 
       $conid = ($conid===0)?filter_input(INPUT_POST, 'conid'):$conid;
       $val = $location->prefix_exists($pref, $conid);
       $ret = (intval($val) >0)?"Exists":"Good";
       $data['content'] =$ret;           
       return view("ogre-ajax8", $data);            
    }    
//---------------------------------------------------
//
//---------------------------------------------------
    public function tables($lid=0){
        $ret ='';         
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            if ($lid > 0){
                $ret = '<div id="tablelist">';
                $ret .= $location->display_tables($lid);
                $ret .= '</div>';
            }                       
            $data['content'] = $ret;
        }
        return view("ogre-ajax8", $data);
    }   
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function tablesIn(){
       
       $p = filter_input_array(INPUT_POST);
       if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
           $ret = $location->save_tables($p);
           $ret = ($ret===TRUE) ? '<p>Tables Saved</p><hr />' :  '<p>Error in Save</p><hr />';
           $data['content'] = $ret;
       }
       $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-location.js');
       return view("ogre-ajax8", $data);
    }   
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function tablesList($lid=0){
       $p = filter_input_array(INPUT_POST); 
       $lid = ($lid==0) ? $p['locid'] : $lid; 
       
       $ret ='';
       if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
           $ret .= $location->display_tables($lid);
           $data['content'] = $ret;
       }
       $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-location.js');
       return view("ogre-ajax8", $data);
    }   
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function addTables(){
//        $conid = $this->session->ogre_conid;  
        $x =  filter_input(INPUT_POST, 'tbls');      
        for($i=1; $i<=$x; $i++){
            $ret = $location->add_table(filter_input(INPUT_POST, 'locid'));               
            if($ret===FALSE){                   
                break;
            }
        }
        $ret = $location->updateTableNumber(filter_input(INPUT_POST, 'locid'));
        $ret= ($ret===TRUE) ? '1' : '0';
        $data['content'] = $ret;           
        return view("ogre-ajax8", $data);             
    }
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function delTables(){        
       $ret1 = $location->removeTable(filter_input(INPUT_POST, 'tblid'));
       $ret=($ret1===TRUE) ? '1' : '0';
       $ret1 = $location->updateTableNumber(filter_input(INPUT_POST, 'locid'));
       $data['content'] =$ret;            
       return view("ogre-ajax8", $data);
    }    
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------         
    public function getTables() {
        $ci=&get_instance();       
        $p = filter_input_array(INPUT_POST);
        $ret = $ci->location->getTableselect($p['locid']);          
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);
    }            
 
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function gamesRemoveX(){          
        $ret='0';            
        $p = filter_input_array(INPUT_POST);
        $this->event->event_init($p['gid']);                  
        $ret = $this->event->removeGame();
        if($ret===TRUE){
            if ($this->event->rpga_number_of_slots > 1){
                $gameid2 = $this->event->findOPMultiRoundChild();
                foreach($gameid2 as $gid2){
                    $this->event->event_init($gameid2);
                    $ret = $this->event->removeGame();  
                }
            }
        }        
        $ret = ($ret===TRUE) ? $this->event->gameAdminOPSCurrentSchedule(0 , $p['aff']) : '0';
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);         
    }   
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function gamesRefreshX(){
             
        $p = filter_input_array(INPUT_POST);
        $this->event->event_init($p['gid']);
        $ret = '<select id="slotNum' . $this->event->id . '" name="slotNum' . $this->event->id . '" onchange="flagchange(' . "'" . $this->event->slot_code . "'," . $this->event->id . '); deleteCheck(this.value, ' . $this->event->id . ",'" . site_url('ogrex/gamesRemoveX', 'https') . "','" . site_url('ogrex/gamesRefreshX', 'https') . "'" . ');">';
        $ret.= $this->admin_lib->getGameSlotSelect($this->event->slot_code, $this->event->slot_length);
        $ret .= '</select>';
        $data['content'] = $ret;            
        return view("ogre-ajax8", $data);             
    }

//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function currentSchedule($aff='0'){
        $p = filter_input_array(INPUT_POST); 
        $aff = (($aff=='0') ? $p['aff'] : $aff);
        $ret= $this->event->gameAdminOPSCurrentSchedule(0, $aff);                       
        $data['content']=$ret;            
        return view("ogre-ajax8", $data);
    }    
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function currentScenarioList($aff='0'){ 
        $conid = $this->session->ogre_conid;  
        $p = filter_input_array(INPUT_POST); 
        $aff = ($aff=='') ? $p['aff'] : $aff;
                   
        $ret = $this->convention->getScenarioSelect($conid, 'gameScenario', $aff);   
        $ret = '<label for="gameScenario" class="gamescenario_fileredlabel">'.$aff.' Scenario</label><div class="select-style">' . str_replace('<select', '<select onchange="loadslots(this.options[this.selectedIndex].value, ' ."'". site_url('ogrex/getSlots', 'https') ."'". ')" ', $ret) . '</div>';
        $data['content']=$ret;            
        return view("ogre-ajax8", $data);
    }    
    
   
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function adminViewPlayer(){
        $p = filter_input_array(INPUT_POST); 
        $this->event->event_init($p['gid']);
        $data['content'] = $this->event->game_admin_rpga_playeradmin($p['gid']);
        return view("ogre-ajax8", $data);
    }    
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function adminInsertPlayer($mmrpg=0){ 
        $conid = $this->session->ogre_conid;  
        $p = filter_input_array(INPUT_POST); 
        if(isset($p['autoactivate'])){
            if($p['autoactivate']=='true'){
                $access=($p["activity2"]=="Judge")?GAMEMASTER:PLAYER;
                $this->person->init($conid,'',$p['userID']);
                $retx = $this->person->activate($access);
            }
        }
        $ret = $this->schedule_lib->preregAction(TRUE, $p);                
        if($mmrpg==1){
            $data['content']= $ret['resp'];                
        }
        else{
            $ret1=$this->event->game_admin_rpga_playeradmin($p['gid']);
            $data['content']= ($ret['result']===TRUE) ? $ret1 : $ret['resp'];
        }
        return view("ogre-ajax8", $data);           
    }
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------        
    public function removePlayer(){
        $ret='';
        $p = filter_input_array(INPUT_POST); 
        $conid = $this->session->ogre_conid;  
        if(isset($p['pid'])){
            $this->person->get($p['pid'],$conid);    
            $gl[1] = $p['gid'];
            $ret = $this->person->removeFromGame($gl);
            if($ret===TRUE)
            {
                $ret=$this->event->game_admin_rpga_playeradmin($p['gid']);
            }
        }
        $data['content']=$ret;
        return view("ogre-ajax8", $data);                        
    }    
//---------------------------------------------------
//
//---------------------------------------------------        
    public function removePlayerResults(){
        $ret = TRUE;
        $p = filter_input_array(INPUT_POST); 
        $conid = $this->session->ogre_conid;  
        if(isset($p['pid'])){
            $this->person->get($p['pid'],$conid);    
            $gl[1] = $p['gid'];
            $ret = $this->event->event_init($p['gid'], $conid);
            if(!$this->event->uniqueinstance_gm($p['pid'],$p['gid'])){
                $ret = $this->person->removeFromGame($gl);
            }
            if($ret===TRUE){
                $ret = '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
                $ret .= '<div><strong>Dropped: </strong>' . $this->event->slot_time." : ".$this->event->game_name;;
                $ret .= '</div> </div>';
            }
            else{
                $ret = '<div class="alert alert-warning alert-dismissible fade show" role="alert">';
                $ret .= '<div><strong>Contact Coordinator to Cancel:</strong>' . $this->event->slot_time." : ".$this->event->game_name;;
                $ret .= '</div> </div>';                
            }
        }
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);                        
    }     
//---------------------------------------------------
//
//
//
//---------------------------------------------------        
    public function removePlayerOnsite(){
        $ret='';          
        $p = filter_input_array(INPUT_POST);
        $this->session->set(array('viewmode' => $p['vmode']));
        if(isset($p['pid'])){   
            $ret = $this->event->removePlayer($p['pid']);
            $ret1 = $this->event->promote_alternate($p['gid']);
            if($ret === TRUE){
                $ret = $this->event->onsiteGamePlayerAdmin($p['gid']);
            }
        }
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);                        
    }
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------         
    public function gameEdit($gsid=0,$type='GAME'){
        // GAME = Add Game (rtype = 1)
        // VOL =  Add Volunteer Shift (rtype=
        // PAN = Add Panel
        $p = filter_input_array(INPUT_POST);
        $gsid = (intval($gsid)==0)? $p['gid'] : $gsid;
        $data['content'] = $this->event->gameEditForm($gsid,$type,TRUE);          
        return view("ogre-ajax8", $data);            
    }        
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------              
    public function gmEdit(){
        $p = filter_input_array(INPUT_POST); 
        $conid = $this->session->ogre_conid;  
        
        $ret = $this->event->getGMEditForm($p,$conid,TRUE);
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);                         
    }   
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------              
    public function userAdminSearch(){
        $p = filter_input_array(INPUT_POST);
        $conid = $this->session->ogre_conid;  
        $ret = $this->admin_lib->usersAdminSearchResults($p, $conid);
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);              
    }    
    
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------              
    public function gmplayer_admin_search($gid){
        $conid = $this->session->ogre_conid;  
        $p = filter_input_array(INPUT_POST);
        
        $ret = $this->admin_lib->gmPlayerAdminSearchResults($p, $conid, $gid);
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);               
    } 
    

//---------------------------------------------------
//
//
//
//---------------------------------------------------                    
    public function game_cancel($id=0, $val){
        $p = filter_input_array(INPUT_POST);
        $p['gid'] = ($id != 0) ? $id : $p['gid'];
        $rval = $this->event->cancelgame($p["gid"] , $val);
        $ret = ($rval===TRUE) ? $this->event->preregisterEditList($p["pid"], $p["gnid"]) : 'ERROR';        
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);                 
    }   
//---------------------------------------------------
//
//
//
//---------------------------------------------------   
    public function editprereg($gid){
        $ret = $this->event->preregEditForm($gid);
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);              
    } 
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------          
    public function gameGroup($gid){
        $ret=$this->event->getPlayersChoiceForm($gid);            
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);
    }
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------          
    public function gameGroupIn(){
        $p = filter_input_array(INPUT_POST);
        $ret = $this->event->playersChoiceIn($p);            
        $data['content'] = $ret;            
        return view("ogre-ajax8", $data);          
    }
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------          
    public function gameGroupDel(){
        $p = filter_input_array(INPUT_POST);
        $ret1=$this->event->playersChoiceDel($p['pcid']);
        if($ret1===TRUE){
            $ret=$this->event->playerschoice_list($p['gid']);
        }
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);          
    }     
//---------------------------------------------------
//
//
//
//---------------------------------------------------          
    public function gameGroup_refresh(){
        $p = filter_input_array(INPUT_POST);
        $ret = $this->event->playerschoice_list($p['gid']);
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);          
    }      
//---------------------------------------------------
//
//
//
//---------------------------------------------------          
    public function getGameEditListByGM(){
        $p = filter_input_array(INPUT_POST);
        $ret = ($p['gmid']!='ALL') ? $this->event->preregisterEditList($p['gmid']) : $this->event->preregisterEditList();
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);              
    }    
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------          
    public function getGameEditListByGame(){
        $p = filter_input_array(INPUT_POST);
        $ret = ($p['gmid'] != 'ALL') ? $this->event->preregisterEditList(0, $p['gmid']) : $this->event->preregisterEditList();
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);              
    }     
    
//---------------------------------------------------
//
//---------------------------------------------------          
    public function changeslot($gid){
        $ret=$this->event->addGameWhen($gid);
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);               
    }
//---------------------------------------------------
//
//---------------------------------------------------          
    public function changeGame($gid=0, $stype=1){          
        $ret=$this->event->addWhatGame($gid, 0, $stype);
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);                 
    }    
    
//---------------------------------------------------
//
//---------------------------------------------------          
    public function changeLocation($gid){
             $ret=$this->event->gameadd_where($gid);
             $data['content'] =$ret;            
             return view("ogre-ajax8", $data);               
    }    
  
     
//---------------------------------------------------
//
//---------------------------------------------------
    public function proposalInfo($grid=0){
        $p = filter_input_array(INPUT_POST);
        if($grid ===0){
            $grid = $p['id'];
        }
        $ret = $this->proposal->proposalTab($grid);
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);           
    }
//---------------------------------------------------
// getProposalListByGM 
//---------------------------------------------------
    public function getProposalListByGM($gmid=0){
        $p = filter_input_array(INPUT_POST);
        $conid = $this->session->ogre_conid;         
        $ret = $this->proposal->proposalList($conid, (($gmid!==0)?$gmid:$p['gmid']));      
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);            
    }   
//---------------------------------------------------
//
//---------------------------------------------------         
    public function proposalStatusIn(){
        $p = filter_input_array(INPUT_POST); 
        $conid = $this->session->ogre_conid;     
        $ret1 = $this->proposal->proposalStatusIn($p['pid'], $p['status']);  
        if ($ret1==TRUE){
            $ret = $this->proposal->proposalList($conid);
        }
        else{
            $ret = '0';
        }
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);                
    }       
//---------------------------------------------------
//
//---------------------------------------------------   
    public function checkEmailAddress(){
        $ret = '';
        $p = filter_input_array(INPUT_POST);
        if (isset($p['em'])){
            $em = urldecode($p['em']);
            $pid = $p['pid'];
            $val = $this->ogre_lib->userExists($em, $pid);
            $ret = ($val===TRUE)? 'User Email Exists' : 'Good';
        }
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);        
    }   

//---------------------------------------------------
//
//---------------------------------------------------       
    public function check_userid(){
        $ret = '';
        $p = filter_input_array(INPUT_POST);
        if (isset($p['em'])){
            $em = urldecode($p['em']);
            $pid = $p['pid'];
            $val = $this->ogre_lib->userIDExists($em, $pid);
            $ret = ($val===TRUE)? 'User ID Exists' : 'Good';
        }
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);        
    }          
//---------------------------------------------------
//
//---------------------------------------------------     
    public function checkOgreID($pid){
        $ret = '';
        $val = $this->ogre_lib->ogreid_exists($pid);
        $ret = ($val['result']===TRUE)? 'Good,'.$val['user'] : 'Ogre ID Does not Exists';
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);              
    }
    
//---------------------------------------------------
//
//---------------------------------------------------     
    public function slotcheck($gid){
        $p = filter_input_array(INPUT_POST);
        $conid = $this->session->ogre_conid;  
        $sc = $this->event->getSlotCode($gid);
        $pid = $p['pid'];
        $ret = 0;
        $this->person->init($conid,'', $pid);
        if($this->person->access_rating <= CONADMIN){
            $ret = $this->person->alreadyInSlot($sc);
        }
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);         
    } 

//---------------------------------------------------
//
//---------------------------------------------------     
    public function checkUserEmail($email=""){
        $ret = '';
        $p = filter_input_array(INPUT_POST);
        if($email==""){
            $email = urldecode($p['email']);
        }
        $val = $this->ogre_lib->userExists($email,0,TRUE);
        $ret = ($val['result']===TRUE)? 'Good,'.$val['user'] : '';
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);              
    }     
    
//---------------------------------------------------
//
//---------------------------------------------------    
    public function getExistingScenarios($aff=''){
        $ret = '';
        $ret = $this->scenario->existingScenarioForm($aff);
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);        
    }   
    
//---------------------------------------------------
//
//---------------------------------------------------    
    public function refreshExistingScenarios($aff){
        $ret = '';
        $ret = $this->scenario->existingScenarioList($aff);
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);        
    }   
    
//---------------------------------------------------
//
//---------------------------------------------------    
    public function getScenarioInfo($id){
        $ret = '';
        $ret = $this->scenario->scenarioAdminForm($id, TRUE);
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);         
    }    
    
//---------------------------------------------------
//
//---------------------------------------------------    
    public function resetScenarioForm($id=0){
        $ret = '';
        $ret = $this->scenario->scenarioAdminForm($id);
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);         
    }     
    
//---------------------------------------------------
//
//---------------------------------------------------    
    public function getSlotInstructions(){        
        $ret='';
        $cnt = $this->ogre_lib->getMiscContent('%SLOT_MINIMUM%');           
        $txt = $this->ogre_lib->getMiscContent('%GAMESLOTINSTRUCTIONS%');
        $ret .= '<div id="slotinstructions">';
        $ret .= $txt['content'] . $cnt['content'];
        $ret .= '</div>';
        $data['content'] = $ret;
        return view("ogre-ajax8", $data); 
    }    
    
//---------------------------------------------------
//
//---------------------------------------------------    
    public function getActInstructions($miscid){        
        $ret='';
        $conid = $this->session->ogre_conid;  
        $cnt = $this->ogre_lib->activationInstruction($miscid,$conid);
        $contact = $this->ogre_lib->getConGamingInfoKey($conid, "con_gamingcoordinatoremail");  
        $clink = mailto($contact, 'Gaming Coordinator');
        $cnt = str_replace('%_GAMING_COORDINATOR_%', $clink, $cnt);         
        $ret .= '<div class="instructions">';
        $ret .= $cnt;
        $ret .= '</div>';
        $data['content'] = $ret;
        return view("ogre-ajax8", $data); 
    } 
//---------------------------------------------------
//
//---------------------------------------------------     
    public function gotPlayers($gid=0){
        $p = filter_input_array(INPUT_POST);
        if($gid===0){
            $gid = $p['id'];
        }
        $ret = $this->event->getNumberOfPlayers(0, $gid);           
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);           
    }   
//---------------------------------------------------
//
//---------------------------------------------------  
    public function getChangeConList(){
        $orgid = $this->session->ogre_orgid; 
        $conid = $this->session->ogre_conid; 
        
        $ret = $this->ogre_lib->changeConList($orgid, $conid);           
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);          
    }
    
//---------------------------------------------------
//
//---------------------------------------------------      
    public function setChangeCon($conid){
        $orgid = $this->convention->getOrgId($conid);
        $msa_conid = $this->convention->get_msa_conid($conid);
        
        if ($this->session->ogre_conid != $conid){
            $conarray = $this->ogre_lib->setSessionVarsCon($orgid, $conid);
            $userarray = ($this->session->ogre_logged_in=== TRUE) ? $this->ogre_lib->setSessionVarsUser($this->session->ogre_user_ID, $conid, $orgid): $this->ogre_lib->setSessionVarsUser(0,$conid,$orgid);
            $ret = $this->ogre_lib->setSessionData(array_merge($conarray, $userarray));
        }     
        $data['content'] = $conid.'.'. $orgid.'.'. $msa_conid . $ret;
        return view("ogre-ajax8", $data); 
    } 
//---------------------------------------------------
//
//---------------------------------------------------      
    public function onisteConfirm($ppid=0){
        $conid = $this->session->ogre_conid;   
        $confirm = $this->schedule_lib->confirmPreregPlayer($ppid);
        $ret = ($confirm===TRUE) ? $this->schedule_lib->onsite_confirm($conid) : 'ERROR';        
        $data['content'] = $ret;
        return view("ogre-ajax8", $data); 
    }    
//---------------------------------------------------
//
//---------------------------------------------------      
    public function onsite_delete($ppid=0){
        $conid = $this->session->ogre_conid;   
        $confirm = $this->schedule_lib->confirmDeletePlayer($ppid);
        $ret = ($confirm===TRUE) ? $this->schedule_lib->onsite_confirm($conid, 'del') : 'ERROR';        
        $data['content'] = $ret;
        return view("ogre-ajax8", $data); 
    }      
////---------------------------------------------------
////
////---------------------------------------------------  
//    public function game_bgglookup(){
//        $ret = $this->game->bggLookupForm();           
//        $data['content'] = $ret;
//        return view("ogre-ajax8", $data);          
//    }    
    
//---------------------------------------------------
//
//---------------------------------------------------      
    public function refreshGameAdminFilter($aff, $conid=0){
        $conid = ($conid==0) ? $this->session->ogre_conid : $conid;
        $ret ='<label for="affiliation">Organized Play Filter (Which OP do you wish to see?)</label>'.  $this->event->getEventAffiliationFilter($aff, $conid) . '';
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);         
    } 
//---------------------------------------------------
//
//---------------------------------------------------
     public function gmPolicyX($id=0) {
            $conid = $this->session->ogre_conid;  
            $this->convention->init($conid);
            $gmpolicy = $this->ogre_lib->getMiscContent("%GMPOLICY%", $conid);
            $gc = safe_mailto($this->convention->gamingcoordinatoremail,'Gaming Coordinator');
            $gmpolicy['content'] = str_replace('%GENERAL_GAMING_CONTACT%', $gc, $gmpolicy['content']);               
            $gmpolicy['content']=$this->ogre_lib->processMiscContent($gmpolicy['content']);               
            $data['content'] = '<div>' . $gmpolicy['content'] . '</div>';
            return view("ogre-ajax8", $data);
      }  
      
//---------------------------------------------------
//
//---------------------------------------------------
     public function gameRegDialog($id=0) {
            $conid = $this->session->ogre_conid;  
            $orgid = $this->session->ogre_orgid;
            $this->convention->init($conid);
            $pid=0;
            $accessrating=0;
            $verified=FALSE;
            $this->event->event_init($id);
            if($this->session->ogre_logged_in !== FALSE){
                $pid = $this->session->ogre_user_ID;
                $accessrating = $this->session->get('ogre_user_accesslevel_' . $orgid);
                $verified = $this->session->get('ogre_user_activated_' . $conid);
            }
            $ret = $this->schedule_lib->getPreregLinkReg(intval($this->event->prereg_players_allowed), $id, $this->event->mmrpgFlag, $accessrating, $verified, 0, 'DIALOG');
            $data['content'] = $ret;
            return view("ogre-ajax8", $data);
      }  
      
//---------------------------------------------------
//
//---------------------------------------------------          
    public function downloadScheduleCSV(){
        $conid = $this->session->ogre_conid;
        $this->convention->init($conid);
        $p = array('gm_name' => '0', 'gameslot' => '0');
        $collist = ' ogre_gameschedule.gs_id AS ID, ogre_gameschedule.gs_slot_day AS DAY, ogre_gameschedule.gs_slot_time AS Time,  ';
        $collist .= ' ogre_gameschedule.gs_location_name AS GAMEROOM, ogre_gameschedule.gs_table_number AS GAMETABLE, ogre_gameschedule.gs_game_name AS GAME, ogre_gameschedule.gs_game_title AS SCENARIOTITLE, ';
        $collist .= ' ogre_gameschedule.gs_affiliation AS AFFILIATION,   CONCAT(ogre_gameschedule.gs_game_type," ",ogre_gameschedule.gs_event_type) As GAMETYPE, ';
        $collist .= ' ogre_gameschedule.gs_max_number_of_players As MAXPLAYERS ';
        $sql = $this->schedule_lib->buildGamingScheduleSQL(FALSE, $p, 0, FALSE, '', $conid, '', '', $collist);

        $datestring = "Y-m-d-h-i";
        $time = new Datetime();
        $filename = str_replace(' ', '-', $this->convention->name) . '-gameschedule-' . $time->format($datestring);
        $this->ogre_lib->downloadCSV($sql, $filename);        
    }           
//---------------------------------------------------
//
//---------------------------------------------------      
    public function addPCgame($geid){
        $data['content'] = $this->event->addPCgame();
        return view("ogre-ajax8", $data);        
    }
//---------------------------------------------------
//
//---------------------------------------------------      
    public function changeGMStatus($ppid, $status=1){
        $ret = $this->event->update_prereg_GMstatus($ppid, $status);
        $gameid = $this->event->get_gsid_from_prereg($ppid);
        $data['content'] =($ret === TRUE) ? $this->event->onsiteGamePlayerAdmin($gameid) : 'ERROR';
        return view("ogre-ajax8", $data);       
    }
//---------------------------------------------------
//
//---------------------------------------------------      
    public function getScheduleBreakDown(){
        $p = filter_input_array(INPUT_POST);
        $ret = '';
        $this->convention->init($p["conid"]);        
        $ret = '<div class="card border-primary mb-3" style="max-width:100%;">';
        $ret .= '<div class="card-header">'.$this->convention->name.' </div>';
        $ret .= '<div class="card-body">';
        $ret .= $this->schedule_lib->getBreakDownList($p["conid"], $p["dmode"]);
        $ret .= '</div>';
        $ret .= '</div>';
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);
    }
//---------------------------------------------------
//
//---------------------------------------------------       
    public function ogreAlert(){
        $p = filter_input_array(INPUT_POST);        
        $data['content'] = $this->ogre_lib->bootAlert($p['type'], $p['id'], $p['title'], $p['text']);
        return view("ogre-ajax8", $data);        
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------      
    public function get_gameidlist($pid=0){
        $p = filter_input_array(INPUT_POST);  
        $pid = ($pid==0) ? $p['pid'] : $pid;
        $conid = $this->session->ogre_conid;
        $this->person->get($pid, $conid);
        $data['content'] = $this->person->game_id_list;
        return view("ogre-ajax8", $data);
    }
//---------------------------------------------------
//
//---------------------------------------------------                    
    public function dropAllProgress(){
        $p = filter_input_array(INPUT_POST);
        $data['content'] =$this->person->dropoutProgressBar($p['perc']);        
        return view("ogre-ajax8", $data);                 
    }   
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function logInActionX(){
       $pst = filter_input_array(INPUT_POST);
       $this->convention->init($this->session->ogre_conid);
       $controller = $this->convention->ogre_dir;  
       $user = $this->ogre_lib->setSessionVarsUser();
       $ret = $this->ogre_lib->logInAction($this->session->ogre_conid, $pst);
       $logintest = $this->ogre_lib->grant_access(PLAYER);
       $data['content'] = ($logintest && $ret['ogre_logged_in']) .','. $this->ogre_lib->loginSuccessRedirect($pst, $controller) .','. $ret['ogre_loginerror'].','. $ret['ogre_welcome'];
       return view("ogre-ajax8", $data);
   }    
        
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function getGameLibraryBuilder($pid=0){
        $ret='';
        $conid = $this->session->ogre_conid;
        $p = filter_input_array(INPUT_POST); 
        $pid = (($p !== NULL)? $p['pid']:$pid);
        $ret = $this->schedule_lib->gameLibraryWizard($pid);
        $data['include'] = 'ogre-bgg-search.php';        
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);       
    }
    
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function getBGGSearch($gtype=3){
        $ret='';
        $conid = $this->session->ogre_conid;
        $ret = $this->propose_lib->bggSearch($gtype);       
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);       
    }       
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function bgLibraryIn(){
        $p = filter_input_array(INPUT_POST);
        $ret='';
        $ret1 = '';
        $ret = $this->event->saveMyGameLibraryEvent($p);
        $ret1 = ($ret == TRUE) ? 'Board Game Library Submitted for Aprroval. ' . $this->schedule_lib->gamelibrary_email($p): 'ERROR ADDING GAME LIBRARY';
        $data['content'] = $ret1;
        return view("ogre-ajax8", $data);       
    }    
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------          
    public function changeDisplayMode($gid, $dmode){
        $p = filter_input_array(INPUT_POST);
        $ret=$this->event->update_displaymode($gid, $dmode);
        $data['content'] =$ret;            
        return view("ogre-ajax8", $data);               
    }      
//---------------------------------------------------
//
//
//
//---------------------------------------------------          
    public function gameApprove($gid, $dmode){
        $p = filter_input_array(INPUT_POST);
        $ret=$this->event->update_displaymode($gid, $dmode);             
        $data['content'] = ($ret == TRUE) ? $this->event->game-edit-form($gid,'GAME',TRUE) : 'EROOR IN APPROVAL';            
        return view("ogre-ajax8", $data);               
    }      
//---------------------------------------------------
//
//---------------------------------------------------          
    public function pglApprove($gid, $dmode){
        $p = filter_input_array(INPUT_POST);
        $ret=$this->event->update_displaymode($gid, $dmode);     
        $data['content'] = ($ret == TRUE) ? $this->proposal->personalGameLibraryList() : 'EROOR IN APPROVAL';            
        return view("ogre-ajax8", $data);               
    }    
    
//---------------------------------------------------
//
//---------------------------------------------------         
    public function actCodeIn(){
        $p = filter_input_array(INPUT_POST);
        $ret ='';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            $ret = $this->admin_lib->generate_activatecode($p);
            $data['content'] = ($ret['result']===TRUE) ?  '<p>Activate Code Generated and Sent</p>' : '<p>Error in Generating an Activation Code</p>';
            $data['from_eaddress']= 'gaming@justusproductions.com';               
            $data['to_eaddress1'] = $p['email']; /*  */
            $data['to_eaddress2'] = '';
            $data['to_eaddress3'] = '';

            $data['subject'] = 'OGRE ACTIVATION CODE';
            $mbody = '<p>Below you will find your OGRe Activation Information </p>';
            $mbody .= '<p>OGRe Activation Email: ' . $ret['email'] . '<br />OGRe Activation Code: '. strtoupper($ret['code']) . '</p>';
            $mbody .= '<p> You can activate up to 1 Acccount(s) with this information.</p>';
            $data['body'] =   $mbody;                
            $ret = $this->ogre_lib->emailMessageArray($data);
        }
        else{
            $data['content'] ='Access Denied';
        }
        return view("ogre-ajax8", $data);                    
    }     
//---------------------------------------------------
//
//---------------------------------------------------         
    public function addGameComment($gameid=0,$replyid=0){
        $p = filter_input_array(INPUT_POST);
        $ret = $this->event->addComments($p['gid'], $p['msg'], $p['pid']);
        if($ret === TRUE){
            $data['content'] = $this->event->getEventComments($p['gid']);  
        }else{
            $data['content'] = '<p>Error in Saving Comment!</p>';
        }
        return view("ogre-ajax8", $data); 
    }
//---------------------------------------------------
//
//---------------------------------------------------         
    public function addGameCommentReply($gid){
        $p = filter_input_array(INPUT_POST);
        $ret = $this->event->addComments($gid, $p['msg'], $p['pid'], $p['cid']);
        if($ret === TRUE){
            $data['content'] = $this->event->getEventCommentReply($p['cid']);  
        }else{
            $data['content'] = '<p>Error in Saving Comment!</p>';
        }
        return view("ogre-ajax8", $data); 
    }   
//---------------------------------------------------
//
//---------------------------------------------------         
    public function markMessagesRead(){
        $p = filter_input_array(INPUT_POST);
        $this->person->get($p['pid']);
        $isGM = $this->person->isGM($p['pid'], $p['gid']);
        if ($isGM===TRUE){
            $ret = $this->person->markCommentReadGM($p['pid'], $p['gid']);
        }else{
            $ret = $this->person->markCommentRead($p['pid'], $p['gid']);
        }
        $data['content'] = $ret;
        return view("ogre-ajax8", $data);
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function gamesIn($mode='rpga', $act='', $gameid=0){
       $conid = $this->session->ogre_conid;
       $view="ogre8";
       $ret ='';
       $ret2 = TRUE;
       if($this->ogre_lib->grant_access(CONADMIN) == TRUE){               
           switch ($mode){
                case 'rpga':
                   $rval = $this->event->gamesAdminOPIn($act, $gameid, filter_input_array(INPUT_POST));                  
                   $ret =  $rval['msg'];
                   $view="ogre-ajax8";
                   break;
               case 'rpgax':
                   $act=($act=="")?$mode:$act;
                   $gameid=(($input->post('gameid')!==FALSE) ? $input->post('gameid'): $gameid);
                   $ret1 = $this->event->gamesAdminOPIn($act, $gameid, filter_input_array(INPUT_POST));   
                   $rret = $this->RPGA_lib->reset_enums($conid);
                   $ret= ($ret1===TRUE)? "<p>Game Updated</p>" : "Error in updating game.";
                   $view="ogre-ajax8";
                   break;
               case 'add':                  
                   $ret = $this->event->saveGameEvent(filter_input_array(INPUT_POST));                   
                   $ret = is_numeric($ret) ? $ret : "ERROR";
                   $view="ogre-ajax8";                        
                   break;
               case 'update':
                   $ret = FALSE;
                   $ret = $this->event->saveGameEvent(filter_input_array(INPUT_POST));
                   $ret = ($ret===TRUE) ? "Done" : "ERROR";
                   $view="ogre-ajax8";
                   break;

               case 'regdetails':     
                   $rval = $this->event->updateGameDesc(filter_input_array(INPUT_POST));                      
                   break;
               default:
                   $ret = 'Desination Unknown';
                   break;
           }
           $data['content'] = $ret;
       }
       else{
           $data['content'] ='Access Denied';
       }
       $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-games.js');
       return view($view, $data);
    }  
//---------------------------------------------------
//
//---------------------------------------------------    
public function onsiteActIn($conid){
    $p = filter_input_array(INPUT_POST);
    $view = "ogre-ajax8";
    $ret = $this->ogre_lib->userLoginExists($p["pemail"]);
    if($ret !== TRUE){
        $ret = $this->schedule_lib->makeQuickUserActiveProfile($conid, $p);
    } else {
        $this->person->init($conid, $p['pemail']);
        $ret = $this->person->activate();  
        $ret = (($ret === TRUE) ? $this->person->user_id_num : -1 );
    }
    $data['content'] = (intval($ret) > 0 ? 'Activated.  Your OGRe Number is: ' . $ret : 'Error');
    return view($view, $data);
}

    
}  //======  END OGREX