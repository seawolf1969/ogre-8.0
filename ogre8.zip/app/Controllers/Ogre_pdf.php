<?php
namespace App\ThirdParty;
namespace App\Controllers;

use App\Libraries\Ogre_lib;
use App\Models\Convention;
use App\Models\Person;
use App\Models\Organization;
use Dompdf\Dompdf;
use DateTime;

require APPPATH . 'ThirdParty/dompdf/lib/Cpdf.php';

use CodeIgniter\Controller;

class Ogre_pdf extends BaseController{
    
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
    public function __construct(){

    }
    
    public function index(){
//        return view('pdf_view');
    }

    private function  htmlToPDF($html, $filename){
        $dompdf = new \Dompdf\Dompdf(); 
        $dompdf->loadHtml($html);
        $dompdf->setPaper('letter', 'portrait');
        $dompdf->render();
        $dompdf->stream($filename);
    }    
 
//---------------------------------------------------
//
//
//
//---------------------------------------------------       

    public function pdfTickets($pid){
         $conid = $this->session->ogre_conid;
         $this->convention->init($conid); 
         $content = $this->schedule_lib->buildTickethtml($pid);
         $data['content'] = $content;
         $html = view('ogre-pdf-file.php', $data);
         $datestring = "Y-m-d-h-i";
         $time = new DateTime();
         $pfname = $this->person->getPlayerFilename($pid);
         $filename = str_replace(' ', '.', $this->convention->name) . '-' .$pfname . '-tickets-' . $time->format($datestring);         
         $this->htmlToPDF($html, $filename);
    }
   
//---------------------------------------------------
//
//
//
//---------------------------------------------------            
    public function pdfMyscedule($pid=0){
        $conid = $this->session->ogre_conid;
        $this->convention->init($conid);
        $this->person->init($conid,'',$pid);
        $content = $this->person->displayPlayerSchedulex(TRUE, $pid);      
        $data['content'] = $content;           
        $html = view('ogre-pdf-file', $data);
        $date = new DateTime();
        $pfname = $this->person->getPlayerFilename($pid);
        $filename = str_replace(' ', '-', $this->convention->name) . '-' . $pfname .'-schedule-' . $date->format('Y-m-d-H-i-s');
        $this->htmlToPDF($html, $filename);
      
    }        
     
//---------------------------------------------------
//
//
//
//---------------------------------------------------        
        public function pdfPlayerList($pid=0){
             $conid = $this->session->ogre_conid;
             $this->convention->init($conid);
             $content = $this->event->preregReport(0, 'None', '', 0, $pid);  
             $pname = (($pid !== 0) ? (($this->person->init($conid,'',$pid) === TRUE) ? '<h2>'.$this->person->fullname.' Player List</h2>' : '') : '');
             $data['content'] = (((trim($pname)!=='') ? $pname : '') . $content);           
             $html = view('ogre-pdf-file', $data);
             $datestring = "Y-m-d-h-i";
             $time = new Datetime();
             $pfname = $this->person->getPlayerFilename($pid);
             $filename = str_replace(' ', '-', $this->convention->name). '-' . $pfname  . '-playerlist-' . $time->format($datestring);
             $this->htmlToPDF($html, $filename);
        } 
//---------------------------------------------------
//
//
//
//---------------------------------------------------            
        public function pdfOPPlayerList($aff, $gm=0){
             $conid = $this->session->ogre_conid;  
             $this->convention->init($conid);
             $content = $this->event->preregReport(0, $aff, 0, $gm);  
             $data['content'] = $content;          
             $html = view('ogre-pdf-file', $data);
             $datestring = "Y-m-d-h-i";
             $time = new Datetime();
             $filename = str_replace(' ', '.', $this->convention->name) . '.' .$aff.'.'.(($gm==0)?'player':'judge').'list.' . $time->format($datestring);
             $this->htmlToPDF($html, $filename);
        }        
}
?>
