<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
use CodeIgniter\HTTP\UserAgent;
use CodeIgniter\I18n\Time;


use App\Libraries\Ogre_lib;
use App\Libraries\Person_lib;
use App\Libraries\Schedule_lib;
use App\Libraries\Propose_lib;
use App\Libraries\Convention_lib;
use App\Libraries\Admin_lib;
use App\Libraries\Rpga_lib;

use App\Models\Convention;
use App\Models\Person;
use App\Models\Organization;
use App\Models\Game;
use App\Models\Bgggame;
use App\Models\Proposal;
use App\Models\Event;
use App\Models\Scenario;

/**
 * Class BaseController
 *
 * BaseController provides a convenient place for loading components
 * and performing functions that are needed by all your controllers.
 * Extend this class in any new controllers:
 *     class Home extends BaseController
 *
 * For security be sure to declare any new methods as protected or private.
 */
class BaseController extends Controller{
// SYSTEM    
    var $db; 
    var $agent;  
    var $session;
    var $emailer;

// OGRE LIBRARIES    
    var $ogre_lib; 
    var $person_lib;
    var $schedule_lib;
    var $propose_lib;
    var $admin_lib;
    var $RPGA_lib;
    var $convention_lib;
    
//OGRE MODELS
    var $convention;
    var $organization;
    var $person;
    var $game;
    var $bgggame;
    var $proposal;
    var $event; 
    var $scenario;
    /**
     * Instance of the main Request object
     * @var CLIRequest|IncomingRequest
     */
    protected $request;
    /**
     * An array of helpers to be loaded automatically upon    * class instantiation. These helpers will be available    * to all other controllers that extend BaseController.
     *     * @var array     */
    protected $helpers = ['Ogre_helper','html','url','file','date','text','directory','form','string'];
/**      * Constructor.     */
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger){
// Do Not Edit This Line
        parent::initController($request, $response, $logger);
        register_ci_instance($this);      
        // Preload any models, libraries, etc, here.
        // array('database','email','session', 'user_agent','encryption');
        // E.g.: $this->session = \Config\Services::session();
        $this->db = \Config\Database::connect();
        $this->session = \Config\Services::session();
        $this->email = \Config\Services::email();
        $this->encrypter = \Config\Services::encrypter();
        $this->emailer = \Config\Services::email();
        $this->request = service('request');
        $this->agent = $this->request->getUserAgent();       
        
        //OGRE LIBRARIES
        //'person_lib', 'schedule_lib', 'propose_lib', 'rpga_lib', 'convention_lib'
        $this->ogre_lib = new Ogre_lib();
        $this->person_lib = new Person_lib();
        $this->schedule_lib = new Schedule_lib();
        $this->propose_lib = new Propose_lib();
        $this->admin_lib = new Admin_lib();
        $this->RPGA_lib = new Rpga_lib();
        $this->convention_lib = new Convention_lib();
        
        $this->organization = new Organization();
        $this->convention = new Convention();
        $this->person = new Person();
        $this->game = new Game();
        $this->bgggame = new BggGame();
        $this->proposal = new Proposal();
        $this->event = new Event();
        $this->scenario = new Scenario(); 

        if(!$this->session->ogre_conid || intval($this->session->ogre_conid === 0)){
            $ret = $this->ogre_lib->ogreInit($this->session->ogre_orgid);
            $ret = $this->ogre_lib->initSessionVarsUser($this->session->ogre_conid, $this->session->get('ogre_orgid'));
        }
          
//----------------------------------------
// EMAIL CONFIG
//----------------------------------------
//        $this->emailer->protocol = "smtp";
//        $this->emailer->SMTPHost   = "127.0.0.1";
//        $this->emailer->SMTPUser = "newuser";
//        $this->emailer->SMTPPass = "RWM.69";
//        $this->emailer->SMTPPort = "25";
//        $this->emailer->mailType  =  'html';
//        $this->emailer->CRLF  =  "\r\n";
//        $this->emailer->wordWrap = TRUE;        

        
        $config['protocol'] = "smtp";
        $config['smtp_host'] = "mail.justusproductions.com";
        $config['smtp_user'] = "gaming@justusproductions.com";
        $config['smtp_pass'] = "%M@CE!mace!69%";
        $config['smtp_port'] = "587";
        $config['mailtype']  =  'html';
        $config['crlf']  =  "\r\n";
        $config['newline']  =  "\r\n";
        $config['wordwrap'] = TRUE;
            
//            $config['protocol'] = "smtp";
//            $config['smtp_host'] = "smtp.sendgrid.net";
//            $config['smtp_user'] = "apikey";
//            $config['smtp_pass'] = "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";
//            $config['smtp_port'] = "587";
//            $config['mailtype']  =  'html';
//            $config['crlf']  =  "\r\n";
//            $config['newline']  =  "\r\n";
//            $config['wordwrap'] = TRUE;
    }
    


    
    
}
