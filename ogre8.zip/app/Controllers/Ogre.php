<?php
namespace App\Controllers;

use App\Libraries\Ogre_lib;
use App\Models\Convention;
use App\Models\Person;
use App\Models\Organization;

class Ogre extends BaseController {
   private $cntlr ;         
//---------------------------------------------------
//
//---------------------------------------------------    
    public function __construct(){
        
//        $this->ogre_lib->resetSessionVarsCon();
    }   
//---------------------------------------------------
//
//---------------------------------------------------    
    public function index(){
        $data['content'] = 'Error';
        return view("ogre8", $data);          
    }
//---------------------------------------------------
//
//---------------------------------------------------      
    private function htmlToPDF($html, $filename){
        $dompdf = new \Dompdf\Dompdf(); 
        $dompdf->loadHtml($html);
        $dompdf->setPaper('letter', 'portrait');
        $dompdf->render();
        $dompdf->stream($filename);
    }    
    
//---------------------------------------------------
//
//---------------------------------------------------    
    public function homepage($pconid=0){ 
        $ret = '';
        if($pconid == 0){
            if(!$this->session->ogre_orgid){
                $ret = "<p>Error: Organization ID Not Assigned</p>";
            } elseif (!$this->session->ogre_conid) {
                $ret = "<p>Error: Convention ID Not Assigned</p>";
            }  else {
                $ret = $this->ogre_lib->ogreHome();
                $data['jscript'] = array(base_url() . '/'. JSCRIPT_DIR . '/ogre-news.js', base_url() .'/'. JSCRIPT_DIR . '/ogre-my-profile.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-login.js');
                $data['bc'] = 'Home';            
            }
        } else {
            $ret = $this->ogre_lib->ogreHome($pconid);
            $data['jscript'] = array(base_url() . '/'. JSCRIPT_DIR . '/ogre-news.js', base_url() .'/'. JSCRIPT_DIR . '/ogre-my-profile.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-login.js');
            $data['bc'] = 'Home';                 
        }
        $data['content'] = $ret;
        return view('ogre8',$data);
    }    
//---------------------------------------------------
//
//---------------------------------------------------       
   public function clear(){
       $ret = $this->ogre_lib->resetSessionVarsUser($this->session->ogre_orgid, $this->session->ogre_conid);     
       $data['content'] = 'Session Unset.</a>.';
       return view("ogre8", $data);           
   }   
   
//---------------------------------------------------
//
//---------------------------------------------------
    public function about(){
        $conid = $this->session->ogre_conid;
        $data['content']='';
        $data['bc'] = 'About';
        $ret='';
        $ret .= '<div id="horizontalTab-about">';           
        $ret .= '<ul>';                   
        $ret .= '<li>';
        $ret .= '<a href="#about-tab-1" >';
        $ret .= 'About';
        $ret .= '</a>';
        $ret .= '</li>';
        $ret .= '<li>';
        $ret .= '<a href="#about-tab-2" >';
        $ret .= 'FAQ';
        $ret .= '</a>';
        $ret .= '</li>';
        $ret .= '<li>';        
        $ret .= '<a href="#about-tab-3" >';
        $ret .= 'Contact';
        $ret .= '</a>';        
        $ret .= '</li>';
        $ret .= '</ul>';                
        $ret .= '<div id="about-tab-1">';
        $content = $this->ogre_lib->getMiscContent('%About%', $conid);                    
        $ret .= '<div class="subcontent"><h1>' . $content['title'] . '</h1>' . $content['content'] .'</div>';                  
        $content1 = $this->ogre_lib->getMiscContent('%COPYRIGHT%', $conid);                    
        $ret .= '<div class="subcontent"><h1>' . $content1['title'] . '</h1>' . $content1['content'] . '</div>';                  
        $content2 = $this->ogre_lib->getMiscContent('%PRIVACYPOLICY%', $conid);                   
        $ret .= '<div class="subcontent"><h1>' . $content2['title'] . '</h1>' . $content2['content'] . '</div>';
        $ret .= '</div>';
        $ret .= '<div id="about-tab-2">';
        $faq = $this->ogre_lib->getMiscContent(1);
        $ret .= '<div class="subcontent"><h1>' . $faq['content'] . '</div>';                
        $ret .= '</div>';
        $ret .= '<div id="about-tab-3">';
        $ret .= '<div class="subcontent">' . $this->ogre_lib->getContacts($this->session->ogre_orgid) . '</div>';                
        $ret .= '</div>';
        $ret .= '</div>';
        $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-about.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-login.js');
        $data['content'] .= $ret;
        return view("ogre8", $data);           
    }          
//---------------------------------------------------
//
//---------------------------------------------------
    public function view($cont=0){
       $conid = $this->session->ogre_conid;
       $data['content']='';
       $content = $this->ogre_lib->getMiscContent($cont, $conid);  
       $data['content'] .= '<h1>' . $content['title'] . '</h1>';
       $data['content'] .= $content['content'];
       return view("ogre8", $data);
     }
//---------------------------------------------------
//
//---------------------------------------------------
    public function login($msg='', $dest='index'){
        $data['content'] = '';
        $orgid = $this->session->ogre_orgid;
        $conid = $this->session->ogre_conid;
        $data['bc'] = 'Log In/Register';
        $logintest = $this->ogre_lib->grant_access(-1);
        $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-login.js');      
        if ($logintest != TRUE){
            $ret='';
            $ret .= '<div id="horizontalTab1">';           
            $ret .= '<ul>';                   
            $ret .= '<li>';
            $ret .= '<a href="#tab-1" >';
            $ret .= 'Log In';
            $ret .= '</a>';
            $ret .= '</li>';
            $ret .= '<li>';
            $ret .= '<a href="#tab-2">';
            $ret .= 'Make Account';
            $ret .= '</a>';
            $ret .= '</li>';
            $ret .= '</ul>';
            $ret .= '<div id="tab-1">';
            $ret .= '<div id="loginform1">';
            $ret .= $this->ogre_lib->loginScreen($dest);
            $ret .= '</div>';
            $ret .= '<div id="forgot-password-form" style="display:none;">';
            $ret .=  $this->ogre_lib->forgotLoginScreen();
            $ret .= '</div>';
            $ret .= '</div>';
            $ret .= '<div id="tab-2">';
            $ret .= $this->ogre_lib->getRegisterForm($conid);
            $ret .= '</div>';
            $ret .= '</div>';
            $data['content'] .= $ret;
            return view("ogre8", $data);
        }
        else {
            $orgid = $this->session->ogre_orgid;;
            $conid = $this->session->ogre_conid;
            $this->convention->init( $conid);
            $data['menu'] = $this->ogre_lib->menu_build();
        }
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function logoff(){                    
        $ret = $this->ogre_lib->logoff_user();
        $conid = $this->session->ogre_conid;
        $this->convention->init($conid);
        $controller = $this->convention->ogre_dir;  
        $data['content'] = $controller . ' '. $conid;
        return redirect()->to(base_url().'/'. $controller); 
     }
//---------------------------------------------------
//
//---------------------------------------------------
    public function forgot($email=''){
       $ret =  $this->ogre_lib->forgotLoginScreen($email);
       $data['bc'] = 'Forgot Password';
       $data['content'] = $ret;
       return view("ogre8", $data);
     }
          
//---------------------------------------------------
//
//---------------------------------------------------
    public function activation(){
        $ret = '';
        $conid = $this->session->ogre_conid;
        $pid = $this->session->ogre_user_ID;
        if($this->ogre_lib->grant_access(PLAYER) != TRUE){
          $ret = 'Access Denied';
        }
        else{
          $act=$this->person->isActivated($pid);
           $ret .= (($act===FALSE) ? $this->ogre_lib->activationForm($conid) : $ret.='<h2>Already Activated for this event</h2>');
        }
        $data['content'] = $ret;
        return view("ogre8", $data);
    }    
         
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function autoActivationIn(){
//        $orgid = $this->session->ogre_orgid;;
        $conid = $this->session->ogre_conid;
        if($this->ogre_lib->grant_access(PLAYER) != TRUE){
          $ret = 'Access Denied';
        }
        else{
            $pid = $this->session->ogre_user_ID;
            $this->person->init($conid, '', $pid);
            $access = PLAYER;
            $ret = $this->person->activate($access);
            $data = $this->person->emailActivation();      
            $acttext = $this->ogre_lib->getMiscContent('%ACTIVATION.SUCESS%');
            $logindata = array('ogre_user_activated_' . $conid => 1);
            $this->session->set($logindata);
            $contact = $this->ogre_lib->getConGamingInfoKey( $conid, "con_gamingcoordinatoremail");
            $clink = safe_mailto($contact, 'Gaming Coordinator');
            $ret = $this->ogre_lib->emailMessageArray($data);
            $acttext['content'] = str_replace('%_GAMING_COORDINATOR_%', $clink, $acttext['content']);
            $ret = $acttext['content'] . $ret;
        }
        $data['content'] = $ret;
        return view("ogre8", $data);
    }         
         
         
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function transactionid(){
        $ret = '';
        $orgid = $this->session->ogre_orgid;;
        $pid=$this->session->ogre_user_ID;                
        if($this->ogre_lib->grant_access(PLAYER) != TRUE){
          $ret = 'Access Denied';
        }
        else{
          $act=$this->person->isActivated($pid);
          if ($act===FALSE){
            $ret .= $this->ogre_lib->transactionID();
          }
          else{
              $ret.='<h2>Already Activated for this event</h2>';
          }                                                   
        }
        $data['bc'] = 'Get Activation';
        $data['content'] = $ret;
        return view("ogre8", $data);
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function transactionid_in() {
        $ret = '';
        $p = filter_input_array(INPUT_POST);
        if($this->ogre_lib->grant_access(PLAYER) != TRUE){
          $ret = 'Access Denied';
        }
        else{
            $act = $this->person-> getTransactionID($p['emailaddress']);
                    if ($act != ''){
                        $mailmsg = $this->person->emailTransaction($act, $p['emailaddress']);
                        $data['from_eaddress']= $mailmsg['from_eaddress'];
                        $data['to_eaddress1']= $mailmsg['to_eaddress1'];
                        $data['to_eaddress2']= $mailmsg['to_eaddress2'];
                        $data['to_eaddress3']= $mailmsg['to_eaddress3'];
                        $data['cc_eaddress1']= $mailmsg['cc_eaddress1'];
                        $data['body'] = $mailmsg['body'];
                        $data['subject'] = $mailmsg['subject'];
                        $data['sent_errmsg'] = $mailmsg['sent_errmsg'];
                        $data['sent_msg'] = $mailmsg['sent_msg'];
                        $acttext = '<h2>Activation Code Found</h2>';
//                        $data['include'] = 'mailer.php';
                        $ret = $this->ogre_lib->emailMessageArray($data);
                    }
                    else
                    {
                        $acttext = '<h2>No Transaction Not Found Associated to that email address</h2>';
                    }
                }
                $data['content'] = $acttext . $ret;
                return view("ogre8", $data);
          }
          
//---------------------------------------------------
//
//---------------------------------------------------     
    public function browseschedule($mode='', $gid=0, $aff='0', $late=0, $iprint=0, $dmode='P'){
        $pst = filter_input_array(INPUT_POST);
        $this->session->set(array('viewmode' => 'MAIN'));
        $print=$iprint==0?FALSE:TRUE;
        $conid = $this->session->ogre_conid;
        $data['content'] = '';     
        switch ($mode){
            case 'allx':
                $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-login.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-schedule.op.js',base_url() . '/' . JSCRIPT_DIR . '/ogre-schedule.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-prereg-form.js',base_url() . '/' . JSCRIPT_DIR . '/ogre-games.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-my-schedule.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-browse-schedule.js');   
                $ret = '<div id="gstabmenu" style="dislay:block;">';
                $ret .= $this->schedule_lib->getOptionsTabMenu(OGREBROWSER, $conid, $pst);
                $ret .= '</div>';
                $data['content'] = $ret;                                
                break;                            
            case 'share':
                $pst = $this->schedule_lib->genSharePostData($gid);
                $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-schedule.op.js',base_url() . '/' . JSCRIPT_DIR . '/ogre-schedule.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-prereg-form.js',base_url() . '/' . JSCRIPT_DIR . '/ogre-games.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-my-schedule.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-browse-schedule.js');   
                $data['content'] = '<div id="gstabmenu" style="dislay:block;">';
                $data['content'] .= $this->schedule_lib->getOptionsTabMenu(OGREBROWSER, $conid, $pst, 'P');
                $data['content'] .= '</div>';   
                
                break;            
            case 'rpga':
                $ret = $this->RPGA_lib->gen_row_enum(0, $conid);      
                $data['content'] .= (($aff != 'all') ? $this->RPGA_lib->rpga_schedule_title($aff, $late, $print) . $this->RPGA_lib->rpga_schedule_boot($aff, $late,'',$print) : $this->RPGA_lib->rpga_schedule_title($aff, $late, $print) . $this->RPGA_lib->rpga_schedule_all($late, $print));
                $mc = $this->ogre_lib->getMiscContent(7);
                $data['content'] .= '<table><tr><td>' . $mc["content"] . '</td></tr></table>';
                break;
            case 'rpgax':
                $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-schedule.op.js');
                $ret = $this->RPGA_lib->gen_row_enum(0, $conid);   
                $data['content'] .=  (($aff != 'all') ? $this->RPGA_lib->rpga_schedule_title($aff, $late, $print, TRUE) :  $this->RPGA_lib->rpga_schedule_title($aff, $late, $print, TRUE));
                $mc = $this->ogre_lib->getMiscContent(7);
                $data['content'] .= '<table><tr><td>' . $mc["content"] . '</td></tr></table>';
                break;                            
            case 'rpgalate':
                    $ret = $this->RPGA_lib->gen_row_enum(1, $conid);
                    $data['content'] .= ($aff != 'all') ? $this->RPGA_lib->rpga_schedule_title($aff, $late, $print) . $this->RPGA_lib->opSchedule($aff, $late) : $this->RPGA_lib->rpga_schedule_title($aff, $late, $print) . $this->RPGA_lib->rpga_schedule_all($late);
                break;
            case 'rpgagrid':                
                    $data['content'] = $this->RPGA_lib->rpga_gridview();
                    break;
            case 'whatsnew':
                    $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-schedule.js');
                    $data['content'] = $this->schedule_lib->gameScheduleX($conid, $pst, 0, TRUE, $dmode);                            
                break;   
            default:
                $ret = 'Error';
                $data['content'] = $ret;
                break;
        }
        $data['bc'] = 'Event Schedule';
        return view("ogre8", $data);
    }           

//---------------------------------------------------
//
//---------------------------------------------------
    public function gameListGeneral($bycompany=FALSE){
       $conid = $this->session->ogre_conid;
       $data['content'] = $this->schedule_lib->generalGameList($conid, $bycompany);
       return view("ogre8", $data);
     }
//---------------------------------------------------
//
//---------------------------------------------------
    public function propose(){
       $data['bc'] = 'Propose Game';
       $data['tinymce'] = 'TRUE';
       $this->cntlr = $this->session->ogre_control;
       if($this->ogre_lib->grant_access(PLAYER) != TRUE){
           return redirect()->to(site_url($this->cntlr . '/login'));
       }
       else{
           $data['jscript']= array(base_url() .'/'. JSCRIPT_DIR . '/bgg/bgg_api.js', base_url() .'/'. JSCRIPT_DIR . '/ogre-proposal.js');
           $data['content'] = '<div id="proposal_outer">';
           $data['content'] .= $this->propose_lib->eventProposal();
           $data['content'] .= '</div>';
           return view("ogre8", $data);
       }
     }
        
//---------------------------------------------------
//
//---------------------------------------------------
    public function gmpolicy($id=0) {
        $orgid = $this->session->ogre_orgid;;
        $conid = $this->session->ogre_conid;
        $this->convention->init($conid);
        $policy=$this->ogre_lib->getConfigKey('GM.POLICY',$this->convention->orgid);
        $data['bc'] = 'GM Policy';
        $data['title'] = 'GM Policy';
        $data['style'] = 'style.css';
        $gmpolicy = $this->ogre_lib->getMiscContent($policy);
        $gc = safe_mailto($this->convention->gamingcoordinatoremail,'Gaming Coordinator');
        $gmpolicy['content'] = str_replace('%GENERAL_GAMING_CONTACT%', $gc, $gmpolicy['content']);               
        $gmpolicy['content']=$this->ogre_lib->processMiscContent($gmpolicy['content']);               
        $data['content'] = '<div>' . $gmpolicy['content'] . '</div>';
        $data['norefresh'] = 'Yes';
        return view("ogre8", $data);
     }
//---------------------------------------------------
//
//---------------------------------------------------
    public function myprofile(){
       $conid = $this->session->ogre_conid;
       $this->cntlr = $this->session->ogre_control;
       $data['bc'] = 'My Profile';
       $data['jscript']= array(base_url() .'/'. JSCRIPT_DIR . '/ogre-proposal.js', base_url() .'/'. JSCRIPT_DIR . '/bgg/bgg_api.js',base_url() .'/'. JSCRIPT_DIR . '/ogre-script.js', base_url() .'/'. JSCRIPT_DIR . '/ogre-my-profile.js', base_url() .'/'. JSCRIPT_DIR . '/ogre-games.js', base_url() .'/'. JSCRIPT_DIR . '/ogre-schedule.js', base_url() .'/'. JSCRIPT_DIR . '/ogre-my-schedule.js');
       if($this->ogre_lib->grant_access(PLAYER) != TRUE){
           return redirect()->to(site_url($this->cntlr . '/login')); 
       }
       else{
         $data['content'] = $this->person_lib->getMyProfile($conid);
       }
       return view("ogre8", $data);
    }
//---------------------------------------------------
//
//---------------------------------------------------
      public function registerIn(){
        $p = filter_input_array(INPUT_POST);
        $conid = $this->session->ogre_conid;
        $this->convention->init( $conid);
        $data['con_name'] = $this->convention->name;
        if($this->ogre_lib->grant_access(PLAYER) != TRUE){
            $data['content'] =  $this->ogre_lib->registerIn($p);                    
            return view("ogre8", $data);
        }
        else{
            $controller = $this->convention->ogre_dir;  
        }
      }

//---------------------------------------------------
//
//---------------------------------------------------
    public function password_in(){
      $p = filter_input_array(INPUT_POST);  
      $orgid = $this->session->ogre_orgid;;
      $conid = $this->session->ogre_conid;
      if($this->ogre_lib->grant_access(PLAYER) == TRUE){
        $this->person->init($conid, '', $this->session->ogre_user_ID);
        $res = $this->person->changePasswordIn($p);
        $data['content'] = $res['errmsg'];
        return view("ogre8", $data);
      }
      else{
        $this->convention->init($conid);
        $controller = $this->convention->ogre_dir;  
      }
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function loginid(){
      $orgid = $this->session->ogre_orgid;;
      $conid = $this->session->ogre_conid;
      if($this->ogre_lib->grant_access(PLAYER) == TRUE){
        $this->person->init($conid, '', $this->session->userdata('ogre_user_ID'));
        $data['content'] = $this->person->changeLogInIDForm();
        return view("ogre8", $data);
      }
      else{
        $this->convention->init($conid);
        $controller = $this->convention->ogre_dir;  
      }
    }

//---------------------------------------------------
//
//---------------------------------------------------
    public function loginid_in(){
      $p = filter_input_array(INPUT_POST);   
      $orgid = $this->session->ogre_orgid;;
      $conid = $this->session->ogre_conid;
      if($this->ogre_lib->grant_access(PLAYER) == TRUE){
        $this->person->init($conid, '', $this->session->userdata('ogre_user_ID'));
        $res = $this->person->changeLoginIDIn($p);
        $data['content'] = $res['errmsg'];
        return view("ogre8", $data);
      }
      else{
        $this->convention->init($conid);
        $controller = $this->convention->ogre_dir;  
      }
    }


//---------------------------------------------------
//
//---------------------------------------------------
    public function row_enum($conid=0){
        if ($conid == 0){
          $conid = $this->session->ogre_conid;
        }
        $data['content'] = $this->RPGA_lib->gen_row_enum(0, $conid);
        return view("ogre8", $data);
    }     
//----------------------------------------------------------------------------------------------------------       
//         OGRE_POPUP   
//----------------------------------------------------------------------------------------------------------         

//---------------------------------------------------
//
//---------------------------------------------------
    public function preregReport($gameid=0, $aff='0', $slotnum=0, $gm=0, $gmid=0){
        $data['title'] = 'Preregistration Report';
        $data['style'] = 'rptstyle.css';
        $data['content'] = $this->event->preregReport($gameid, (($aff=='0')?'None':$aff), (($slotnum==0)?'':$slotnum), $gm, $gmid);
        $data['norefresh'] = 'Yes';
        return view("ogre_view2", $data);
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function preRegReportOP($gm=0, $slotnum='', $aff='', $gameid=NULL){
        $data['title'] = 'Judge Report';
        $data['style'] = 'rptstyle.css';
        $data['content'] = $this->event->preRegReportOP($gameid, $aff, $slotnum, $gm);
        $data['norefresh'] = 'Yes';
        return view("ogre_view2", $data);
    }  
         
//---------------------------------------------------
//
//---------------------------------------------------
    public function conPreRegReport($gameid=0, $aff='0', $slotnum=0, $gm=0, $gmid=0){
        $data['title'] = 'Preregistration Report';
        $data['style'] = 'rptstyle.css';
        $data['content'] = $this->event->conPreRegReport();
        $data['norefresh'] = 'Yes';
        return view("ogre_view2", $data);
    }        
        
//----------------------------------------------------------------------------------------------------------        
//         OGRE_ADMIN       
//----------------------------------------------------------------------------------------------------------         
//---------------------------------------------------
//
//---------------------------------------------------
 public function convention($cid=0, $cyear="0"){
    $data['content'] ='';
    $view = "ogre8";
    $data['bc'] = 'Admin: Convention';
    if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
        if ($cid == 0){
            $data['content'] = ($cyear=="0") ? $this->convention->conventionListHeader() . $this->convention->conventionList() : $this->convention->conventionList($cyear);
            $view = ($cyear != "0") ? "ogre-ajax8": $view ; 
        }
        else{
            $data['content'] = $this->convention->getConventionForm($cid);
            $view= "ogre-ajax8";
        }
    }
    else{               
        $data['content'] ='Access Denied';
    }
    $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-admin.js');
    return view($view, $data);
 }
//---------------------------------------------------
//
//---------------------------------------------------
    public function slots($slotid=0, $cid=0){
       $conid = ($cid==0) ? $this->session->ogre_conid : $cid;
       
       $data['bc'] ='Admin: Slots';
       $data['content'] ='';
       $data['content'] = ($this->ogre_lib->grant_access(CONADMIN) == TRUE) ?   $this->admin_lib->slots_main($conid, $slotid) : 'Access Denied';
       $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-slots.js');
       return view("ogre8", $data);
    }             
//---------------------------------------------------
//
//---------------------------------------------------
    public function slotsIn(){
        $pst = filter_input_array(INPUT_POST); 
        
        $data['content'] ='';            
        $data['content'] = ($this->ogre_lib->grant_access(CONADMIN) == TRUE) ?  $this->admin_lib->slotsIn($pst) : 'Access Denied';
        return view("ogre8", $data);
    }
    
//---------------------------------------------------
//
//---------------------------------------------------
     public function user($userid=0){   
        $view="ogre-ajax8";
        $ret = '';
        $pst = filter_input_array(INPUT_POST);
        $conid = $this->session->ogre_conid;
        $this->convention->init($conid);
        
        $data['content'] ='';
        $data['bc'] = 'User Admin';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            if(intval($userid) === 0){
                $data['bc'] = 'User Admin';
                $ret = '<h1>' . $this->convention->name . ' User Admin (Search)</h1>' . $this->admin_lib->userAdmin($pst, $conid);
                $view="ogre8";
            }
            elseif (intval($userid) > 0){
                $ret .= '<h2>User Admin (Edit)</h2>';
                $ret .= '<div id="uaresults" class="results"></div>';
                $ret .= $this->admin_lib->user_admin_form($userid);
                $view="ogre-ajax8";
            }
            else{
                $ret .= '<h2>User Admin (Add)</h2>';
                $ret .= '<div id="uaresults" class="results"></div>';
                $ret .= $this->admin_lib->user_admin_form($userid);
                $view="ogre-ajax8";
            }
            $data['content'] = $ret;
        }
        else{
            $data['content'] ='Access Denied';
        }
        $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-admin.js',base_url() . '/' . JSCRIPT_DIR . '/ogre-user.js');
        return view($view, $data);
     }
         
//---------------------------------------------------
//
//---------------------------------------------------
    public function userAdmin(){
       $orgid = $this->session->ogre_orgid;;
       $data['bc'] = 'Admin: Gaming Admin';
       $ret ='';
       if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
           $ret = $this->admin_lib->userAdminTabs();
           $data['content'] = $ret;
       }
       else{
           $data['content'] ='Access Denied';
       }
       $data['jscript']=array(base_url() . '/' . JSCRIPT_DIR . '/ogre-user.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-admin.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-games.js',  base_url() . '/' . JSCRIPT_DIR . '/ogre-location.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-user-admin.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-my-profile.js');
       return view("ogre8", $data);
    }           
//---------------------------------------------------
//
//---------------------------------------------------
    public function userIn($mode='save', $access=0, $id=0){
        $pst = filter_input_array(INPUT_POST);
        $conid = $this->session->ogre_conid;
        $ret ='';
        $data['content'] ='';
        $view="ogre8";       
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            $ret = TRUE; 
            $retx=FALSE;
            switch ($mode){
                case 'save':                      
                    $this->person->init($pst['conid'], '', $pst['userIndex']);
                    if(intval($pst['userIndex']) != 0){
                        if ($this->person->saveUserInfoAdmin($pst) != TRUE){
                            $ret = "ERROR IN SAVING USER";
                        }
                        else{
                            $ret = "USER SAVED";
                        }
                    }else{
                        if ($this->person->insertNewUserAdmin($pst) == TRUE ){
                           $ret = "USER SAVED";
                        }
                        else{
                            $ret = "ERROR IN SAVING USER";
                        }
                    }
                    $view="ogre-ajax8";
                    break;

                case 'autoact':
                    $this->person->init($conid, '', $id);
                    $ret = $this->person->activate($access);
                    $data1 = $this->person->emailActivation();
                    $data = array_merge($data, $data1);
                    break;
                case 'autoactx':
                    $this->person->init($conid, '', $id);
                    $retx = $this->person->activate($access);
                    $data1 = $this->person->emailActivation();
                    $data = array_merge($data, $data1);
                    $view="ogre-ajax8";
                    break;                    
                case 'deact':
                    $this->person->init($conid, '', $id);
                    $ret = $this->person->deactivate($conid);
                    break;
                case 'deactx':
                    $this->person->init($conid, '', $id);
                    $retx = $this->person->deactivate($conid);
                    $view="ogre-ajax8";
                    break;                    
                default:
                    $ret = FALSE;
                    break;
            }
            if(isset($data['to_eaddress1'])){
                $data["sent_msg"] = '<p>User Updated!!</p>';
                $data["sent_errmsg"] = '<p>Error Updating User!</p>';
                $ret = $this->ogre_lib->emailMessageArray($data);
            }
            $data['content'] = $ret;
        }
        else{
            $data['content'] ='Access Denied';
        }
        return view($view, $data);
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function scenario($scenid=0){
       $data['bc'] = 'Admin: OP Scenario';
       
       $ret ='';
       $data['content'] = ($this->ogre_lib->grant_access(CONADMIN) == TRUE) ? $this->admin_lib->scenarioAdminMain() : 'Access Denied';
       $data['jscript']=array(base_url() . '/' . JSCRIPT_DIR . '/ogre-admin.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-scenario.js');
       return view("ogre8", $data);
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function gamingadmin(){
       $data['bc'] = 'Admin: Gaming Admin';
       
       $data['content'] = ($this->ogre_lib->grant_access(CONADMIN) == TRUE)? $this->admin_lib->gamingAdminTabs() : 'Access Denied';
       $data['jscript']=array(base_url() . '/' . JSCRIPT_DIR . '/ogre-gaming-event-admin.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-admin.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-games.js',  base_url() . '/' . JSCRIPT_DIR . '/ogre-location.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-proposal.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-event-admin.js');
       return view("ogre8", $data);
    }            
//---------------------------------------------------
//
//---------------------------------------------------
    public function eventadmin(){
       $orgid = $this->session->ogre_orgid;;
       $data['bc'] = 'Admin: Event Admin';
       
       $data['content'] = ($this->ogre_lib->grant_access(CONADMIN) == TRUE) ? $this->admin_lib->eventAdminTabs() : 'Access Denied';
       $data['jscript']=array(base_url() . '/' . JSCRIPT_DIR . '/ogre-admin.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-slots.js',  base_url() . '/' . JSCRIPT_DIR . '/ogre-location.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-games.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-event-admin.js');
       return view("ogre8", $data);
    }          
//---------------------------------------------------
//
//---------------------------------------------------
    public function opAdmin(){
       $data['bc'] = 'Admin: OP Admin';
       $data['content'] = ($this->ogre_lib->grant_access(CONADMIN) == TRUE) ?  $this->admin_lib->opAdminTabs() : 'Access Denied';
       $data['jscript']=array(base_url() . '/' . JSCRIPT_DIR . '/ogre-admin.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-scenario.js',  base_url() . '/' . JSCRIPT_DIR . '/ogre-games.js',  base_url() . '/' . JSCRIPT_DIR . '/ogre-op-admin.js');
       return view("ogre8", $data);
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function games($mode='', $gameid=0, $propid=0){
        $p = filter_input_array(INPUT_POST);
        $view="ogre8";
        $ret ='';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            switch ($mode){
                case 'start':
                    break;
                 case 'rpga':
                    $ret = ($gameid==0) ? $this->event->gameAdminOP($gameid) : $this->event->gameAdminOPTabForm($gameid);
                    $view='ogre-ajax8'; 
                    break;
                case 'reg':
                    $view='ogre-ajax8'; 
                    $ret = $this->event->game-edit-form($p['gid'],'GAME',TRUE);
                    break;
                case 'regdetails':
                    $ret = '<h2>Regular Game Admin: Details?</h2>';
                    $ret .= ($propid!='0') ? $proposal->proposalOther($propid) : '';
                    $ret .= '<div id="edit-admin-games-list">';
                    $ret .= '<div id="gameeditform">';
                    $ret .= $this->event->game-edit-form($gameid, 'GAME',TRUE);
                    $ret .= '</div>';
                    $ret .= '</div>';                   
                    break;
                case 'import':
                    $view='ogre-ajax8';                        
                    $ret = '<h2>Game Proposal Import</h2>';
                    $ret .= $this->event->game_admin_regular($gameid, $p, $propid);
                    break;                    
                default:
                    $ret = 'Desination Unknown';
                    break;
            }
            $data['content'] = $ret;
        }
        else
        {
            $data['content'] ='Access Denied';
        }
        $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-script.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-games.js');
        return view($view, $data);
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function removeScenario($scenid){
        $conid = $this->session->ogre_conid;
        $ret ='';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            $this->scenario->initialize($scenid, $conid);
            $res = $this->scenario->removeScenario($event);
            $ret = ($res==TRUE) ? '<p>Scenario Removed</p>':'<p>Error in Data.  Not Removed</p>';
            $ret = $this->admin_lib->scenarioAdminMain($scenario);
            $ret .= $this->scenario->scenarioListAdmin();
            $ret1 = $this->RPGA_lib->reset_enums($conid);
            $data['content'] = $ret;
        }
        else{
            $data['content'] ='Access Denied';
        }
        return view("ogre8", $data);
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function gameDBList($gtid=0){
        $data['bc'] = "Games on File";
        $ret ='';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            $ret .= $game->getGameViewHeader($gtid);
            $ret .= '<div id="gamelist">';
            $ret .= $game->getGameViewList($gtid, 'Yes');
            $ret .= '</div>'; 
            $data['content'] = $ret;
        }
        else
        {
            $data['content'] ='Access Denied';
        }
        $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-games.js');
        return view("ogre8", $data);
    }
         
         
//---------------------------------------------------
//
//---------------------------------------------------
     public function whatgame_select($gtid=0){
        
        $ret ='';
        $data['backgroundcolor']='#D5D5D5';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            $ret .= $game->getWhatGameForm($gtid);               
            $data['content'] = $ret;
        }
        else{
            $data['content'] ='Access Denied';
        }
        return view("ogre_iframe", $data);
     }
//---------------------------------------------------
//
//---------------------------------------------------
    public function preregedit($gmid=0, $gsid=0){
        
        $ret ='';
        $ret.='<h1>Edit Game Admin</h1>';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            $ret .= ($gsid == 0) ? $this->event->preregisterEdit($gmid) : $this->event->preregEditForm($gsid);
            $data['content'] = $ret;
        }
        else{
            $data['content'] ='Access Denied';
        }
        $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-script.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-games.js');
        return view("ogre8", $data);
    }     
//---------------------------------------------------
//
//---------------------------------------------------
    public function setup(){
        $ret ='';
        if($this->ogre_lib->grant_access(ADMIN) == TRUE){
            $intro = $this->ogre_lib->getMiscContent(26);
            $ipadd = $this->session->userdata('ip_address');
            $res = $this->admin_lib->xml_setupindb($ipadd);
            $ret = $this->admin_lib->ogre_setupform();
            $data['content'] = $intro['content'] . $ret;
        }
        else{
            $data['content'] ='Access Denied';
        }
        return view("ogre8", $data);
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function setup_in(){
        $load->dbutil();            
        $p = filter_input_array(INPUT_POST);
        $conid = $this->session->ogre_conid;
        $this->convention->init($conid);
        
        $ret ='';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            $ipadd = $this->session->userdata('ip_address');
            $ret = $this->admin_lib->xml_setupindb($ipadd, $p['conid']);
            $ret = $this->admin_lib->xml_savesetup($ipadd);
            $data['content'] = $ret;
        }
        else{
            $data['content'] ='Access Denied';
        }
        return view("ogre8", $data);                          
    }
//---------------------------------------------------
//
//---------------------------------------------------         
    public function emailform(){
        
        $ret ='';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            $ret = $this->admin_lib->emailform();
            $data['content'] = $ret;
        }
        else{
            $data['content'] ='Access Denied';
        }
        return view("ogre8", $data);             
     }
         
//---------------------------------------------------
//
//---------------------------------------------------         
    public function emailaction(){
        $p = filter_input_array(INPUT_POST);
        $conid = $this->session->ogre_conid;
        $this->convention->init($conid);
        
        $ret ='';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){              
            $ret = 'Email : ' . $p['subject'];
            $data['from_eaddress']= $this->convention->gamingcoordinatoremail;              
            $data['to_eaddress1'] = $this->convention->gamingcoordinatoremail;
            $data['to_eaddress2'] = '';
            $data['to_eaddress3'] = '';
            $data['to_groupaddress'] = $this->admin_lib->getemailaddresses($db, $conid, $p['emtype']);
            $data['subject'] = 'OGRe E-mail: ' . $p['subject'];
            $data['body'] =   $p['comments'];
            $ret = $this->ogre_lib->emailMessageArray($data);
            $data['content'] = $ret;

        }
        else{
            $data['content'] ='Access Denied';
        }           
        return view("ogre8", $data);          
    }  
        
//---------------------------------------------------
//
//---------------------------------------------------         
    public function genActivationCode(){
        $ret ='';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            $ret = $this->admin_lib->generateActivationCodeForm();
            $data['content'] = $ret;
        }
        else{
            $data['content'] ='Access Denied';
        }
        return view("ogre8", $data);                    
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function location($lid=0,$conid=0){
        $conid = ($conid===0) ? $this->session->ogre_conid : $conid;
        
        $ret ='';
        $ret1 ='';
        $data['bc']="Admin: Locations";
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
            if(is_numeric($lid)){
                if ($lid > 0){                  
                    $title = 'Edit Location';
                    $ret = $location->display_location($lid, $conid);
                    $view='ogre-ajax8';
                }
                elseif ($lid == 0){
                    $title = 'Add Location';
                    $ret = $location->display_location(0, $conid);
                    $view='ogre-ajax8';
                }
                else{
                    $ret = '<h2>' . $title . '</h2>';                        
                    $ret .= '<div id="loclist">';
                    $ret .= $convention_lib->viewLocationList($conid, TRUE);
                    $ret .= '</div>';
                    $view='ogre8';                  
                }
            }
            else{
                $ret .= $convention_lib->viewLocationList($conid, TRUE);
                $view='ogre-ajax8';
            }
            $data['content'] = $ret;
        }
        else{
            $data['content'] ='Access Denied';
        }
        $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-location.js');
        return view($view, $data);
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function proposals($grid=0){
       $orgid = $this->session->ogre_orgid;;
       
       $ret ='';
       $ret.='<h1>Proposal Admin</h1>';
       if($this->ogre_lib->grant_access(CONADMIN) == TRUE){
           $ret .= $proposal->proposalList();
            $data['content'] = $ret;
       }
       else{
           $data['content'] ='Access Denied';
       }
       $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-proposal.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-script.js', base_url() . '/' . JSCRIPT_DIR . '/ogre-games.js');
       return view("ogre8", $data);
    }     
//---------------------------------------------------
//
//---------------------------------------------------         
    public function ipn_test(){
        
        $ret ='';
        if($this->ogre_lib->grant_access(CONADMIN) == TRUE){ 
            $action='ogre_paypal/process_paypal_txn/TRUE';
            $ret = $this->admin_lib->ipnForm($action);
            $data['content'] = $ret;
        }
        else{
            $data['content'] ='Access Denied';
        }
        $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-admin.js');
        return view("ogre8", $data);             
    }   
//---------------------------------------------------
//
//---------------------------------------------------         
    public function sendActivationCode(){
        $ret = '';
        if($this->ogre_lib->grant_access(CONADMIN) !== TRUE){ 
          $ret = 'Access Denied';
        }
        else{
          $ret .= $this->ogre_lib->transactionID();
        }         
        $data['content'] = $ret;
        return view("ogre8", $data);         
    } 

//---------------------------------------------------
//
//---------------------------------------------------         
    public function autoActivateOnsite($conid, $key){
        $ret = '';
        $this->convention->init($conid);
        $orgid = $this->convention->orgid;
        $code = $this->ogre_lib->getConfigKey('ONSITE.ACTIVATION.CODE', $orgid, $conid);
        if(strtolower($key) === strtolower($code)){
            $ret .= $this->ogre_lib->getOsiteActivationForm($conid);
        }
        $data['jscript']= array(base_url() . '/' . JSCRIPT_DIR . '/ogre-script.js');
        $data['content'] = '<h1>'.$this->convention->name.'<h1>'.$ret;
        return view("ogre8-basic", $data);         
    }     
}
?> 