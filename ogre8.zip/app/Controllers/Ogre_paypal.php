<?php
namespace App\Controllers;
use CodeIgniter\Controller;

use App\Libraries\Ogre_lib;
use App\Models\Convention;
use App\Models\Person;
use App\Models\Organization;

class Ogre_paypal extends BaseController{
// OGRE PAYPAL CONFIG
// Will have to have a PayPal Controller for each Org.
// This is for the default ORG
    
        const ORGANIZATIONID = 1;
        
        var $orgid = '0';
        var $conid = '0'; 
        var $item_name = '';
        var $business = '';
        var $item_number = '';
        var $mc_gross = '';
        var $txn_id = '';
        var $quantity = '1';    
        var $num_cart_items = '1';
        var $payment_date = '';
        var $first_name = '';
        var $last_name = '';
        var $payment_type = '';
        var $payment_status = '';
        var $memo = '1';
        var $payer_email  = '';
        var $txn_type  = '';
        var $address_street  = '';
        var $address_city  = '';
        var $address_state = '';
        var $address_zip = '';
        var $address_country = '';
        var $tax = '';
        var $option_name1 = '';             
        var $option_selection1 = '';
        var $option_name2 = '';
        var $option_selection2 = '';               
        var $invoice = '';           
        var $custom = '';
        var $mc_fee = '';
        var $parent_txn_id = '';   
        var $pending_reason = '';
        var $reason_code = '';            
        var $subscr_id = '';      
        var $subscr_date = '';  
        var $subscr_effective = '';                 
        var $period1 = '';  
        var $period2 = '';
        var $period3 = '';                   
        var $amount1  = ''; 
        var $amount2 = ''; 
        var $amount3 = ''; 
        var $mc_amount1 = '';                    
        var $mc_amount2 = '';    
        var $mc_amount3 = '';                 
        var $recurring = ''; 
        var $reattempt = '';
        var $retry_at = '';   
        var $recur_times  = ''; 
        var $username  = ''; 
        var $password = '';
        var $data = ['body'=>'','from_eaddress'=>'gaming@justusproductions.com',
                     'to_eaddress1'=>'',
                     'cc_eaddress1'=>'gaming@justusproductions.com',
                     'subject'=>''];         
        var $debugmsg = ''; 
        var $msg = '';
        var $fecha = '';
        var $errmsg = '';
// TLS 1.2 CONVERSION        
        /** @var bool Indicates if the sandbox endpoint is used. */
        var $use_sandbox = false;
        /** @var bool Indicates if the local certificates are used. */
        var $use_local_certs = true;
        /** Production Postback URL */
        
        
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function __construct(){
//       parent::__construct();
    }
  
   
//---------------------------------------------------
//     * Sets the IPN verification to sandbox mode (for use when testing,
//     * should not be enabled in production).
//     * @return void
//---------------------------------------------------
    public function useSandbox(){
        $this->use_sandbox = true;
    }
//---------------------------------------------------
//     * Sets curl to use php curl's built in certs (may be required in some
//     * environments).
//     * @return void
//---------------------------------------------------
    public function usePHPCerts(){
        $this->use_local_certs = false;
    }
//---------------------------------------------------
//     * Determine endpoint to post the verification data to.
//     *
//     * @return string
//---------------------------------------------------
    public function getPaypalUri(){
        if ($this->use_sandbox) {
            $ret =  SANDBOX_VERIFY_URI;
        } else {
           
            $ret =  VERIFY_URI;
        }
        return $ret;
    }
//---------------------------------------------------
//     * Verification Function
//     * Sends the incoming post data back to PayPal using the cURL library.
//     *
//     * @return bool
//     * @throws Exception
//---------------------------------------------------
    private function verifyIPN($pst){
        $i=0;
        if ( ! count($pst)) {
            $this->err_log("Missing POST Data");
            $this->errmsg = "Missing POST Data";
            exit();
        }
        $raw_post_data = file_get_contents('php://input');
        $raw_post_array = explode('&', $raw_post_data);
        $myPost = array();
        foreach ($raw_post_array as $keyval) {
            $keyval = explode('=', $keyval);
            if (count($keyval) == 2) {
//                 Since we do not want the plus in the datetime string to be encoded to a space, we manually encode it.
                if ($keyval[0] === 'payment_date') {
                    if (substr_count($keyval[1], '+') === 1) {
                        $keyval[1] = str_replace('+', '%2B', $keyval[1]);
//                        $this->err_log($keyval[1]);
                    }
                }
                $myPost[$keyval[0]] = urldecode($keyval[1]);
                
            }
        }
        
//         Build the body of the verification post request, adding the _notify-validate command.
        $req = 'cmd=_notify-validate';
//        $get_magic_quotes_exists = false;
//        if (function_exists('get_magic_quotes_gpc')) {
//            $get_magic_quotes_exists = true;
//        }
        foreach ($myPost as $key => $value) {
//            if ($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
//                $value = urlencode(stripslashes($value));
//            } else {
                $value = urlencode($value);
//            }
            $req .= "&$key=$value";
        }
//         Post the data back to PayPal, using curl. Throw exceptions if errors occur.
        $ppurl = $this->getPaypalUri();
        $ch = curl_init($ppurl);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
        curl_setopt($ch, CURLOPT_SSLVERSION, 6);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
//        This is often required if the server is missing a global cert bundle, or is using an outdated one.
        if ($this->use_local_certs) {
            curl_setopt($ch, CURLOPT_CAINFO, __DIR__ . "/cert/cacert.pem");
        }    
        curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('User-Agent: PHP-IPN-Verification-Script',  'Connection: Close', ));
        $res = curl_exec($ch);
//       $this->err_log($ch);
        if ( ! ($res)) {
            $errno = curl_errno($ch);
            $errstr = curl_error($ch);
            curl_close($ch);
            $this->err_log("cURL error: [$errno] $errstr");
            exit();
        }
        $info = curl_getinfo($ch);
        $http_code = $info['http_code'];
        if ($http_code != 200) {
            $this->err_log("PayPal responded with http code $http_code");
            exit();
        }
        curl_close($ch);
//        Check if PayPal verifies the IPN data, and if so, return true.
        if ($res == VALID) {
            return TRUE;
        } else {
            return FALSE;
        }
    }        
//---------------------------------------------------
//
//
//
//---------------------------------------------------        
    private function init($pst){
        $ci = &get_instance();
        $this->orgid = self :: ORGANIZATIONID;
        $this->item_name = (isset($pst['item_name'])) ? $pst['item_name'] : '';
        $this->business = (isset($pst['business'])) ? $pst['business'] : '';
        $this->item_number = (isset($pst['item_number'])) ? $pst['item_number'] :  '';
        $this->mc_gross = ((isset($pst['mc_gross']))? $pst['mc_gross'] : '');
        $this->txn_id = $pst['txn_id'];
        $this->quantity = (isset($pst['quantity'])) ? $pst['quantity'] : '1';    
        $this->num_cart_items = (isset($pst['num_cart_items'])) ? $pst['num_cart_items'] : '';
        $this->payment_date = $pst['payment_date'];
        $this->first_name = str_replace("'", '', $pst['first_name']);
        $this->last_name = str_replace("'", '', $pst['last_name']);
        $this->payment_type = $pst['payment_type'];
        $this->payment_status = $pst['payment_status'];
        $this->memo = (isset($pst['memo'])) ? $pst['memo'] : '1';  
        $this->payer_email = $pst['payer_email'];
        $this->txn_type = $pst['txn_type'];
        $this->address_street = (isset($pst['address_street'])) ? $pst['address_street'] : '';
        $this->address_city = (isset($pst['address_city'])) ? $pst['address_city'] : '';
        $this->address_state = (isset($pst['address_state'])) ? $pst['address_state'] : '';
        $this->address_zip = (isset($pst['address_zip'])) ? $pst['address_zip'] : '';
        $this->address_country = (isset($pst['address_country'])) ? $pst['address_country'] : '';          
        $this->tax = (isset($pst['tax'])) ? $pst['tax'] : '';
        $this->option_name1 = (isset($pst['option_name1'])) ? $pst['option_name1'] : '';             
        $this->option_selection1 = (isset($pst['f'])) ? $pst['option_selection1'] : '';
        $this->option_name2 = (isset($pst['option_name2'])) ? $pst['option_name2'] : '';
        $this->option_selection2 =(isset($pst['option_selection2'])) ? $pst['option_selection2'] : '';                
        $this->invoice =(isset($pst['invoice'])) ? $pst['invoice'] : '';            
        $this->custom = (isset($pst['custom'])) ? $pst['custom'] : '';
        $this->mc_fee = $pst['mc_fee'];
        $this->parent_txn_id = (isset($pst['parent_txn_id'])) ? $pst['parent_txn_id'] : '';   
        $this->pending_reason = (isset($pst['pending_reason'])) ? $pst['pending_reason'] : '';
        $this->reason_code = (isset($pst['reason_code'])) ? $pst['reason_code'] : '';             
        // subscription specific vars   
        $this->subscr_id = (isset($pst['subscr_id'])) ? $pst['subscr_id'] : '';      
        $this->subscr_date =  (isset($pst['subscr_date'])) ? $pst['subscr_date'] : '';   
        $this->subscr_effective =  (isset($pst['subscr_effective'])) ? $pst['subscr_effective'] : '';                 
        $this->period1 = (isset($pst['period1'])) ? $pst['period1']: '';  
        $this->period2 = (isset($pst['period2'])) ? $pst['period2'] : '';
        $this->period3 = (isset($pst['period3'])) ? $pst['period3'] : '';                   
        $this->amount1 = (isset($pst['amount1'])) ? $pst['amount1'] : ''; 
        $this->amount2 = (isset($pst['amount2'])) ? $pst['amount2'] : '';  
        $this->amount3 = (isset($pst['amount3'])) ? $pst['amount3'] : '';  
        $this->mc_amount1 = (isset($pst['mc_amount1'])) ? $pst['mc_amount1'] : '';                     
        $this->mc_amount2 = (isset($pst['mc_amount2'])) ? $pst['mc_amount2'] : '';    
        $this->mc_amount3 = (isset($pst['mc_amount3'])) ? $pst['mc_amount3'] : '';                  
        $this->recurring = (isset($pst['recurring'])) ? $pst['recurring'] : ''; 
        $this->reattempt = (isset($pst['reattempt'])) ? $pst['reattempt'] : '';
        $this->retry_at = (isset($pst['retry_at'])) ? $pst['retry_at'] : '';   
        $this->recur_times = (isset($pst['recur_times'])) ? $pst['recur_times'] : ''; 
        $this->username = (isset($pst['username'])) ? $pst['username'] : ''; 
        $this->password = (isset($pst['password'])) ? $pst['password'] : '';
        $this->data['to_eaddress1'] = $this->payer_email;        
        return TRUE;
    }        
//---------------------------------------------------
//
//
//
//---------------------------------------------------        
    public function index($debug = FALSE){
        $ci = &get_instance();
        $emailcode = TRUE;
//---------------------------------------------------   
// Use the sandbox endpoint during testing.
// $this->useSandbox();
//---------------------------------------------------          
        $pst = $this->request->getPost();
        $ret = '';
        $ret = $this->init($pst);
        if(strpos($this->custom, "wp_cart_id")===false){
            $verified = $this->verifyIPN($pst);
        }
        else{
            $verified = true;
        }
        if ($verified) {
            $this->fecha = date("m")."/".date("d")."/".date("Y");
            $this->fecha = date("Y").date("m").date("d");
            $checkquery = "SELECT txnid FROM ogre_paypal_payment_info WHERE txnid = '".$this->txn_id."' AND conid = " . $this->conid;              //  check if transaction ID has been processed before
            $query = $ci->db->query($checkquery);                                                                 
            $nm = $query->getNumRows();
            if ($nm == 0){
                $ret = $this->paypalProcessData($pst, $debug);
                $emailcode = ($this->payment_status == 'Refunded') ? FALSE : (($this->payment_status == 'Reversed') ? FALSE : TRUE);
            } else {
                $this->msg = '~VERIFIED DUPLICATED TRANSACTION ' .  $this->txn_id;
                $this->data = array('subject' => '', 'body' =>  '', 'from_eaddress' => '', 'to_eaddress1' => '', 'cc_eaddress1' => '');  
                $this->debugmsg .= ($debug ==TRUE) ? $this->msg : '';  
                $emailcode = FALSE;
            }
        }
    else{                                                                                                               
            $log = $this->err_log("INVALID IPN 1: " . $this->txn_id);
        }

        if($debug === TRUE){
            $this->data['content'] = $this->debugmsg;
            $this->data['body'] .= $this->msg;
            $log = $this->err_log($this->msg . $this->debugmsg);
        }            

        if ($emailcode !== FALSE){
            $emailcode = $this->email_code($this->txn_id, $this->conid);
        }
        if($emailcode === TRUE) {
            $ret = $this->ogre_lib->emailMessageArray($this->data);
        }
        $data = $this->data;
        return view('ogre-ajax8',$data);       
    }
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------    
    private function paypalProcessData($pst, $debug){
        $log = '';
        $rlog = '';
        $ret = '';

        switch($this->txn_type){
            case "cart":                                                                                                                                                
                $ret = $this->paypalProcessCart($pst, $debug);
                break;
            case "web_accept":                                                                                                             
                $ret = $this->paypalProcessBuyNow();
                if($ret === FALSE){
                    $this->msg .= 'Default - ogre_paypal_payment_info, Query failed:<br>' . mysql_error() . '<br />' . mysql_errno();
                    $log = $this->err_log($this->msg);
                    $this->debugmsg .= ($debug ==TRUE) ? $this->msg : '';                           
                }                                      
                else{
                    $ret = $this->paypalProcessBuyNow2();
                }
                if($ret === TRUE){
                    $actinfo = $this->ogre_lib->getMiscContent('%ACTIVATIONCODEEMAIL%', $this->conid);
                    $this->data['body'] = '<p>Below you will find your OGRe Activation Information </p>' . '<p>OGRe Activation Email: ' . $this->payer_email . '</p><p>OGRe Activation Code: '. $this->txn_id . '</p>' . '<p> You can activate up to 1 Acccount with this code for ' . $ci->convention->name . '.</p>';                                 
                    $this->data['body'] .= $actinfo["content"];
                    $this->data['subject'] =  $ci->convention->name.' OGRE ACTIVATION CODE';
                }
                else{
                    $this->msg.='Default - ogre_paypal_cart_info, Query failed:<br>' . mysql_error() . '<br />' . mysql_errno();
                    $this->data  = array("from_eaddress" => '',"to_eaddress1" => '', "cc_eaddress1" => '');
                    $log=$this->err_log($this->msg);
                    $this->debugmsg .= ($debug === TRUE) ? $this->msg : '';
                }                                        
                break;                               
            case 'subscr_payment':                                                                                                        
                $ret = $this->paypalProcessSubscription($debug);
                break;
            }
            if ($log !== ''){
                $rlog = $this->err_log("INVALID IPN 2: " . $this->txn_id);
            }
            return $ret;
    }
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------     
    private function paypalProcessSubscription($debug){ 
//  subscription handling branch        
        $ci = &get_instance();
//  insert subscriber payment info into ogre_paypal_payment_info table        
        if ( $this->txn_type == "subscr_signup"  ||  $this->txn_type == "subscr_payment"  ){                                    
            $strQuery = 'insert into ogre_paypal_payment_info(';
            $strQuery .= ' conid, ';
            $strQuery .= ' npaymentstatus, ';
            $strQuery .= ' buyer_email,';
            $strQuery .= ' firstname, ';
            $strQuery .= ' lastname, ';
            $strQuery .= ' street, ';
            $strQuery .= ' city, ';
            $strQuery .= ' state, ';
            $strQuery .= ' zipcode, ';
            $strQuery .= ' country, ';
            $strQuery .= ' mc_gross, ';
            $strQuery .= ' mc_fee, ';
            $strQuery .= ' memo, ';
            $strQuery .= ' paymenttype, ';
            $strQuery .= ' paymentdate, ';
            $strQuery .= ' txnid, ';
            $strQuery .= ' pendingreason, ';
            $strQuery .= ' reasoncode, ';
            $strQuery .= ' tax, ';
            $strQuery .= ' datecreation) ';
            $strQuery .= ' values (';
            $strQuery .= $this->conid . ', ';
            $strQuery .= '"'.$this->payment_status.'",';
            $strQuery .= '"'.$this->payer_email.'",';
            $strQuery .= '"'.$this->first_name.'",';
            $strQuery .= '"'.$this->last_name.'",';
            $strQuery .= '"'.$this->address_street.'",';
            $strQuery .= '"'.$this->address_city.'",';
            $strQuery .= '"'.$this->address_state.'",';
            $strQuery .= '"'.$this->address_zip.'",';
            $strQuery .= '"'.$this->address_country.'",';
            $strQuery .= '"'.$this->mc_gross.'",';
            $strQuery .= '"'.$this->mc_fee.'",';
            $strQuery .= '"'.$this->memo.'",';
            $strQuery .= '"'.$this->payment_type.'",';
            $strQuery .= '"'.$this->payment_date.'",';
            $strQuery .= '"'.$this->txn_id.'",';
            $strQuery .= '"'.$this->pending_reason.'",';
            $strQuery .= '"'.$this->reason_code.'",';
            $strQuery .= '"'.$this->tax.'",';
            $strQuery .= '"'.$this->fecha.'")';
            $log = $this->err_log($strQuery);
            $ci->db->query($strQuery);                                
            $ret1 = ($ci->db->affectedRows() > 0)? TRUE : FALSE;  
            if($ret1===FALSE){
                $this->msg.="Subscription - ogre_paypal_payment_info, Query failed:<br />" . mysql_error() . "<br />" . mysql_errno();  
                $log = $this->err_log($this->msg);
                $this->debugmsg .= ($debug === TRUE) ? $this->msg : '';
                }                                
            }
//                          insert subscriber info into ogre_paypal_subscription_info table
            $strQuery2 = 'insert into ogre_paypal_subscription_info(';
            $strQuery2 .= 'subscr_id , ';
            $strQuery2 .= 'sub_event, ';
            $strQuery2 .= 'subscr_date, ';
            $strQuery2 .= 'subscr_effective, ';
            $strQuery2 .= 'period1, ';
            $strQuery2 .= 'period2, ';
            $strQuery2 .= 'period3, ';
            $strQuery2 .= 'amount1, ';
            $strQuery2 .= 'amount2, ';
            $strQuery2 .= 'amount3, ';
            $strQuery2 .= 'mc_amount1, ';
            $strQuery2 .= 'mc_amount2, ';
            $strQuery2 .= 'mc_amount3, ';
            $strQuery2 .= 'recurring, ';
            $strQuery2 .= 'reattempt, ';
            $strQuery2 .= 'retry_at, ';
            $strQuery2 .= 'recur_times, ';
            $strQuery2 .= 'username, ';
            $strQuery2 .= 'password, ';
            $strQuery2 .= 'payment_txn_id, ';
            $strQuery2 .= 'subscriber_emailaddress, ';
            $strQuery2 .= 'datecreation) values (';
            $strQuery2 .= '"'.$this->subscr_id.'",';
            $strQuery2 .= '"'.$this->txn_type.'",';
            $strQuery2 .= '"'.$this->subscr_date.'",';
            $strQuery2 .= '"'.$this->subscr_effective.'",';
            $strQuery2 .= '"'.$this->period1.'",';
            $strQuery2 .= '"'.$this->period2.'",';
            $strQuery2 .= '"'.$this->period3.'",';
            $strQuery2 .= '"'.$this->amount1.'",';
            $strQuery2 .= '"'.$this->amount2.'",';
            $strQuery2 .= '"'.$this->amount3.'",';
            $strQuery2 .= '"'.$this->mc_amount1.'",';
            $strQuery2 .= '"'.$this->mc_amount2.'",';
            $strQuery2 .= '"'.$this->mc_amount3.'",';
            $strQuery2 .= '"'.$this->recurring.'",';
            $strQuery2 .= '"'.$this->reattempt.'",';
            $strQuery2 .= '"'.$this->retry_at.'",';
            $strQuery2 .= '"'.$this->recur_times.'",';
            $strQuery2 .= '"'.$this->username.'",';
            $strQuery2 .= '"'.$this->password.'", ';
            $strQuery2 .= '"'.$this->txn_id.'",';
            $strQuery2 .= '"'.$this->payer_email.'",';
            $strQuery2 .= '"'.$this->fecha."')";
            $log = $this->err_log($strQuery2);
            $ci->db->query($strQuery2);                                
            $ret = ($ci->db->affectedRows() > 0)? TRUE : FALSE;  
            if(($ret1&&$ret2)==TRUE){
                $this->data['body'] = '<p>Below you will find your OGRe Activation Information </p>';
                $this->data['body'] .= '<p>OGRe Activation Email: ' . $this->payer_email . '<br />OGRe Activation Code: '. $this->txn_id . '</p>';
                $this->data['body'] .= '<p> You can activate up to 1 Acccount with this code for ' . $ci->convention->name . '.</p>';                                 
                $this->data['subject'] =  $ci->convention->name.' OGRE ACTIVATION CODE';                                                                                 
            }
            else{
                $this->msg.="Subscription - ogre_paypal_subscription_info, Query failed:<br>" . mysql_error() . "<br>" . mysql_errno();
                $log=$this->err_log($this->msg);
                $this->data['body'] = $this->msg;                                                                    
                $this->data["from_eaddress"]='gaming@justusproductions.com';          
                $this->data["to_eaddress1"]= 'gaming@justusproductions.com';
            }     
        
        return $ret && $ret1;
    }
//---------------------------------------------------
//
//
//
//--------------------------------------------------- 
    private function paypalProcessBuyNow2(){
        $ci = &get_instance();
        $this->conid=$this->getConventionID($this->item_number);
        $ci->convention->init($this->conid);
        $strQuery = 'insert into ogre_paypal_cart_info(';
        $strQuery .= 'ppci_orgid, ';
        $strQuery .= 'ppci_conid, ';
        $strQuery .= 'ppci_buyer_email, ';
        $strQuery .= 'txnid, ';
        $strQuery .= 'itemnumber, ';
        $strQuery .= 'itemname, ';
        $strQuery .= 'fieldname, ';
        $strQuery .= 'fieldvalue, ';
        $strQuery .= 'os1, ';
        $strQuery .= 'on1, ';
        $strQuery .= 'quantity, ';
        $strQuery .= 'invoice, ';
        $strQuery .= 'custom ';
        $strQuery .= ') ';
        $strQuery .= ' values (';
        $strQuery .= $this->orgid . ',';
        $strQuery .= $this->conid . ',';                                       
        $strQuery .= '"'.$this->payer_email.'", '; 
        $strQuery .= '"'.$this->txn_id . '", '; 
        $strQuery .= '"'.$this->item_number . '", '; ;
        $strQuery .= '"'.$this->item_name. '", '; 
        $strQuery .= '"'.$this->option_name1.'", '; 
        $strQuery .= '"'.$this->option_selection1.'", '; 
        $strQuery .= '"'.$this->option_name2.'", '; 
        $strQuery .= '"'.$this->option_selection2.'", '; 
        $strQuery .= '"'.$this->quantity . '", ';                             
        $strQuery .= '"'.$this->invoice.'", ';
        $strQuery .= '"'.$this->custom.'"';
        $strQuery .= ')';
        $ci->db->query($strQuery);                                
        $ret = ($ci->db->affectedRows() > 0)? TRUE : FALSE; 
        return $ret;
    }    
        
//---------------------------------------------------
//
//--------------------------------------------------- 
    private function paypalProcessBuyNow(){
        $ci = &get_instance();
        $strQuery = 'insert into ogre_paypal_payment_info(';
        $strQuery .= 'orgid, ';
        $strQuery .= 'paymentstatus, ';
        $strQuery .= 'buyer_email, ';
        $strQuery .= 'firstname, ';
        $strQuery .= 'lastname,';
        $strQuery .= 'street,';
        $strQuery .= 'city,';
        $strQuery .= 'state,';
        $strQuery .= 'zipcode,';
        $strQuery .= 'country,';
        $strQuery .= 'mc_gross,';
        $strQuery .= 'mc_fee,';
        $strQuery .= 'itemnumber,';
        $strQuery .= 'itemname,';
        $strQuery .= 'os0,';
        $strQuery .= 'on0,';
        $strQuery .= 'os1,';
        $strQuery .= 'on1,';
        $strQuery .= 'quantity,';
        $strQuery .= 'memo,';
        $strQuery .= 'paymenttype,';
        $strQuery .= 'paymentdate,';
        $strQuery .= 'txnid,';
        $strQuery .= 'pendingreason,';
        $strQuery .= 'reasoncode,';
        $strQuery .= 'tax,';
        $strQuery .= 'datecreation) ';
        $strQuery .= 'values (';
        $strQuery .= $this->orgid . ", '";
        $strQuery .= $this->payment_status."','";
        $strQuery .= $this->payer_email."','";
        $strQuery .= $this->first_name."','";
        $strQuery .= $this->last_name."','";
        $strQuery .= $this->address_street."','";
        $strQuery .= $this->address_city."','";
        $strQuery .= $this->address_state."','";
        $strQuery .= $this->address_zip."','";
        $strQuery .= $this->address_country."','";
        $strQuery .= $this->mc_gross."','";
        $strQuery .= $this->mc_fee."','";
        $strQuery .= $this->item_number."','";
        $strQuery .= $this->item_name."','";
        $strQuery .= $this->option_name1."','";
        $strQuery .= $this->option_selection1."','";
        $strQuery .= $this->option_name2."','";
        $strQuery .= $this->option_selection2."','";
        $strQuery .= $this->quantity."','";
        $strQuery .= $this->memo."','";
        $strQuery .= $this->payment_type."','";
        $strQuery .= $this->payment_date."','";
        $strQuery .= $this->txn_id."','";
        $strQuery .= $this->pending_reason."','";
        $strQuery .= $this->reason_code."','";
        $strQuery .= $this->tax."','";
        $strQuery .= $this->fecha."')";;
        $ci->db->query($strQuery);                                
        $ret = ($ci->db->affectedRows() > 0)? TRUE : FALSE; 
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------       
    private function paypalProcessCart($p, $debug){
        $ci=&get_instance();
        $qty = 0;
        $strQuery = 'insert into ogre_paypal_payment_info (';
        $strQuery .= 'orgid,';
        $strQuery .= 'paymentstatus,';
        $strQuery .= 'buyer_email,';
        $strQuery .= 'firstname,';
        $strQuery .= 'lastname,';
        $strQuery .= 'street,';
        $strQuery .= 'city,';
        $strQuery .= 'state,';
        $strQuery .= 'zipcode,';
        $strQuery .= 'country,';
        $strQuery .= 'mc_gross,';
        $strQuery .= 'mc_fee,';
        $strQuery .= 'memo,';
        $strQuery .= 'quantity,';
        $strQuery .= 'paymenttype,';
        $strQuery .= 'paymentdate,';
        $strQuery .= 'txnid,';
        $strQuery .= 'pendingreason,';
        $strQuery .= 'reasoncode,';
        $strQuery .= 'tax,';
        $strQuery .= 'parent_txn_id,';
        $strQuery .= 'datecreation) ';  
        $strQuery .= ' values (';
        
        $strQuery .= $this->orgid . ", '";
        $strQuery .= $this->payment_status."','";
        $strQuery .= $this->payer_email . "','";
        $strQuery .= $this->first_name."','";
        $strQuery .= $this->last_name."','";
        $strQuery .= $this->address_street."','";
        $strQuery .= $this->address_city."','";
        $strQuery .= $this->address_state."','";
        $strQuery .= $this->address_zip."','";
        $strQuery .= $this->address_country."','";
        $strQuery .= $this->mc_gross."','";
        $strQuery .= $this->mc_fee."','";
        $strQuery .= quotes_to_entities($this->memo)."','";
        $strQuery .= $this->num_cart_items."','";
        $strQuery .= $this->payment_type."','";
        $strQuery .= $this->payment_date."','";
        $strQuery .= $this->txn_id."','";
        $strQuery .= $this->pending_reason."','";
        $strQuery .= $this->reason_code."','";
        $strQuery .= $this->tax."','";
        $strQuery .= $this->parent_txn_id."','";
        $strQuery .= $this->fecha."')";
        $ci->db->query($strQuery);
        $ret = ($ci->db->affectedRows() > 0)? TRUE : FALSE;
        $log = $this->err_log($strQuery);
        if($ret === FALSE){
            $this->msg = "Cart - ogre_paypal_payment_info, Query failed:<br />" . mysql_error() . "<br />" . mysql_errno();    
            
            $this->debugmsg .= ($debug == TRUE) ? $this->msg : '';
        }
        else{
            for ($i = 1; $i <= intval($this->num_cart_items); $i++){
                $itemname = "item_name".$i;          
                $itemnumber = "item_number".$i;
                $on0 = "option_name1_".$i;
                $os0 = "option_selection1_".$i;
                $on1 = "option_name2_".$i;
                $os1 = "option_selection2_".$i;
                $quantity = "quantity".$i;   
                if(strpos($this->custom, "wp_cart_id")!==false){
                    $items = explode("(", $p[$itemname]);
                    $p[$itemnumber] = str_replace(")","",$items[1]);
                }                          
                $conid = $this->getConventionID((isset($p[$itemnumber]) ? $p[$itemnumber] : ''));
                if ($conid !== '0'){
                    $ci->convention->init($conid);  
                } 
                $qty = intval($qty) + (isset($p[$quantity]) ? $p[$quantity] : '1');
                for ($j = 1; $j <= intval($p[$quantity]); $j++){                      
                    $strQuery = 'insert into ogre_paypal_cart_info(';
                    $strQuery .= 'ppci_orgid, ';
                    $strQuery .= 'ppci_conid, ';
                    $strQuery .= 'ppci_buyer_email, ';
                    $strQuery .= 'txnid, ';
                    $strQuery .= 'itemnumber, ';
                    $strQuery .= 'itemname, ';
                    $strQuery .= 'fieldname, ';
                    $strQuery .= 'fieldvalue, ';
                    $strQuery .= 'os1, ';
                    $strQuery .= 'on1, ';
                    $strQuery .= 'quantity, ';
                    $strQuery .= 'invoice, ';
                    $strQuery .= 'custom) ';
                    $strQuery .= ' values (';
                    $strQuery .= $this->orgid . ',';
                    $strQuery .= $conid . ',';                                       
                    $strQuery .= '"'.$this->payer_email.'", '; 
                    $strQuery .= '"'.$this->txn_id . '", '; 
                    $strQuery .= '"'.(isset($p[$itemnumber]) ? $p[$itemnumber] : '') .'", '; ;
                    $strQuery .= '"'.(isset($p[$itemname]) ? $p[$itemname] : ''). '", ';
                    $strQuery .= '"'.(isset($p[$on0]) ? $p[$on0] : '').'", '; 
                    $strQuery .= '"'.(isset($p[$os0]) ? str_replace(array("'",'"'), "_", $p[$os0]) : '').'", ';
                    $strQuery .= '"'.(isset($p[$on1]) ? $p[$on1] : '').'", '; 
                    $strQuery .= '"'.(isset($p[$os1]) ? str_replace(array("'",'"'), "_", $p[$os1]) : '').'", ';
                    $strQuery .= '"'.(isset($p[$quantity]) ? $p[$quantity] : '1') .'", ';                             
                    $strQuery .= '"'.$this->invoice.'", ';
                    $strQuery .= '"'.$this->custom.'")';
                    $ci->db->query($strQuery);
                    $ret = ($ci->db->affectedRows() > 0)? TRUE : FALSE;
//                    $log=$this->err_log($strQuery);
                    if($ret === FALSE){                                            
                        $this->msg .= "Cart - ogre_paypal_cart_info, Query failed:<br />" . mysql_error() . "<br />" . mysql_errno();
                        $this->debugmsg .= ($debug === TRUE) ? $this->msg : '';      
                    }
                    // ----------------
                    // AUTO ACTIVATE    
                    // $p[$os1]=email Address $p[$os0] = Name  process user in OGRe
                    // ----------------
                    $this->msg .= $this->activateOgreAccount($conid, $p[$os1], $p[$os0]);
                }
            }     
        }
        if($ret==TRUE){
            $this->updatePaypalPaymentInfoConid($ci->convention->conid);
            //EMAIL TO PAYER
            $this->data['body'] = '<p>Below you will find your OGRe Activation Information </p>';                         
            $this->data['subject'] =  $ci->convention->name .' OGRE AUTO ACTIVATION ';
            $actinfo = $ci->ogre_lib->getMiscContent('%ACTIVATIONCODEEMAIL%', $conid);
            $this->data['body'] .= $actinfo["content"];
        }
        else{
            $this->data['body'] = $this->msg;                                    
            $this->data["from_eaddress"]='gaming@justusproductions.com';           
            $this->data["to_eaddress1"]= 'gaming@justusproductions.com';                                    
        }  
        
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------     
    private function activateOgreAccount($conid, $email, $name){
        $p=[];
        $ret = FALSE;
        $resp=[];
        if(trim($email) !== ''){
            $exists  = $this->ogre_lib->userLoginExists(trim($email));  //  check if exists
            if($exists){                   //  if exists activate, send message
                $this->person->init($conid, $email);
                $ret = $this->person->activate(PLAYER,$conid);
                //email Existing User
                $data = $this->person->emailActivation($conid);
                $resp = $this->ogre_lib->emailMessageArray($data);
            }
            else{                                   // if does not exist, create and activate, send message
                $p["user_email"] = $email;
                $p["userloginid"] = $email;
                $names = explode(" ", trim($name));
                $nnum = count($names);
                $p["userpassword1"] = $this->person_lib->generatePassword();
                $p["userpassword2"] = $p["userpassword1"];
                $p['user_first_name'] = str_replace("'","`", $names[0]);
                $p['user_last_name'] = str_replace("'","`", $names[$nnum-1]);
                $p['userfirstname'] = str_replace("'","`", $names[0]);
                $p['userlastname'] = str_replace("'","`", $names[$nnum-1]);
                $p['accessrating'] = PLAYER;
                $this->person->clear();
                $this->ogre_lib->registerIn($p);
                
                $this->person->init($conid, $email);
                $ret = $this->person->activate(PLAYER,$conid);
                //email new user
                $resp = $this->ogre_lib->emailMessageArray($data);
            }
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------     
    private function updatePaypalPaymentInfoConid($conid){
            $ci = &get_instance();
            $qry = 'UPDATE ogre_paypal_payment_info SET conid = ' . $conid. ' WHERE txnid = "'.$this->txn_id .'"';
            $ci->db->query($qry);        
    }
//---------------------------------------------------
//
//--------------------------------------------------- 
    private function getConventionID($ppid){
        $ci = &get_instance();
        $ret = 0;          
        $sql = "SELECT * FROM ogre_paypalitem WHERE ppi_itemcode='" . $ppid . "'";
        $query = $ci->db->query($sql);			
        if ($query->getNumRows() > 0){			
            foreach ($query->getResultArray() as $row){             
                $ret = $row['ppi_conid'];
            }
        }    
        return $ret;
    }
//---------------------------------------------------
// 
//---------------------------------------------------       
    private function err_log($msg){
        $ci=&get_instance();
        $qry='INSERT INTO ogre_errlog (log_date, log_text) ';
        $qry .= ' VALUES (NOW(), "';
        $qry .= quotes_to_entities($msg) . '"';
        $qry .= ');';
        $ci->db->query($qry);
        $ret =($ci->db->affectedRows() > 0)? TRUE:FALSE;
        return $ret;
    }

//---------------------------------------------------
// Checks to make sure hte Code was properly saved.
//--------------------------------------------------- 
    private function email_code($txid){
        $ci = &get_instance();
        $qry = 'SELECT ogre_paypal_cart_info.txnid, ';
        $qry .= 'ogre_paypal_cart_info.ppci_conid, ';
        $qry .= 'ogre_paypal_cart_info.itemnumber ';
        $qry .= ' FROM ogre_paypal_payment_info INNER JOIN ';
        $qry .= ' ogre_paypal_cart_info ON ogre_paypal_payment_info.txnid = ogre_paypal_cart_info.txnid ';
        $qry .= ' WHERE ';
        $qry .= ' ogre_paypal_cart_info.txnid = "' . $txid . '" ';
        $qry .= ' AND ogre_paypal_cart_info.ppci_conid <> 0 ';
        $query = $ci->db->query($qry);
        $ret = ($query->getNumRows() > 0) ? TRUE : FALSE;
        return $ret;
    }   
//--------------------------------
//
//--------------------------------
    public function autoActivateBatch($conid=0){
        $ci = &get_instance();
        $qry = 'SELECT ogre_paypal_cart_info.on1, ogre_paypal_cart_info.fieldvalue ';
        $qry .= ' FROM ogre_paypal_cart_info ';
        $qry .= ' WHERE ppci_conid = "' . $conid . '" ';
        $query = $ci->db->query($qry);			
        if ($query->getNumRows() > 0){			
            foreach ($query->getResult() as $row){             
                $this->activateOgreAccount($conid, $row->on1, $row->fieldvalue);
                
            }
        }            
        
    }
        
        
        
} ///END OF OGRE_PAYPAL
?>