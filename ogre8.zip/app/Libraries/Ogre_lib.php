<?php 
namespace App\Libraries;
use CodeIgniter\I18n\Time;

class Ogre_lib {
   private $cntlr;
//---------------------------------------------------
//  OGRE INIT
//---------------------------------------------------      
    public function ogreInit($porgid=0, $pconid=0){
        $ci = &get_instance();
        if ((!$ci->session->ogre_conid)||($ci->session->ogre_conid != $pconid)){
            $conarray = $this->setSessionVarsCon($porgid, $pconid); 
            $userarray = ($ci->session->get('ogre_logged_in')===TRUE) ? $this->setSessionVarsUser($ci->session->ogre_user_ID, $conarray['ogre_conid']): $this->setSessionVarsUser(0,$conarray['ogre_conid'], $porgid);
            $ret = $this->setSessionData(array_merge($conarray, $userarray));
        }
        return $ret;
    }     
//---------------------------------------------------
// SET SESSION VARS FOR CON
//---------------------------------------------------    
    public function setSessionVarsCon($porgid, $pconid=0, $pmsa_conid=0){
        $ci = &get_instance();
        $porgid = (($porgid == 0) && ($pconid != 0) ? $ci->convention->getOrgid($pconid) : $porgid);
        $ci->organization->init($porgid);
        $prefx = ($ci->organization->configprefix == NULL) ? '' : $ci->organization->configprefix;
        if($pconid == 0 || $pconid == NULL){
            $msa_conid = getenv($prefx.'CONVENTION.MSA.ID');                
            $orgid = getenv($prefx.'ORGANIZATION.ID');
            $maint = getenv($prefx.'MAINTENANCE.MODE');  
            $conid = getenv($prefx.'CONVENTION.ID');
            $curr_conid = getenv($prefx.'CONVENTION.ID');
            $ci->convention->init($conid); 
            $controller = $ci->convention->ogre_dir;
        } else {
            $curr_conid = $pconid;
            $msa_conid = $pmsa_conid;                
            $orgid = $porgid;
            $maint = getenv($prefx .'MAINTENANCE.MODE');  
            $conid = $pconid;
            $ci->convention->init($conid); 
            $controller = $ci->convention->ogre_dir;
        }
        $ret = $this->resetSessionVarsCon($orgid);  
        $condata = array(
            'ogre_control' => $controller,
            'ogre_orgid' => $orgid,
            'ogre_conid' => $conid,
            'ogre_maintenance' => $maint,
            'ogre_msa_conid' => $msa_conid);
        return $condata;
    }
//---------------------------------------------------
//
//---------------------------------------------------      
    public function setSessionVarsUser($puserid=0, $pconid=0, $porgid=0, $larray=NULL){
        $ci = &get_instance();
        $ret = $this->resetSessionVarsUser($porgid, $pconid);
        $this->cntlr = $ci->session->ogre_control;
        if ($puserid == 0){
            $logindata = [
                'ogre_welcome' => '',
                'ogre_loginerror' => (isset($larray['ogre_loginerror'])) ? $larray['ogre_loginerror'] : '',
                'ogre_logged_in'  => FALSE,
                'ogre_user_ID' => 0,
                'ogre_user_name' => '',
                'ogre_user_email'  => '',
                'ogre_user_activated_' . $pconid => 0,
                'ogre_user_accesslevel_' . $porgid => 0];
        } else {
            $ci->person->init($pconid, '', $puserid);
            $logindata = [
                'ogre_logged_in'  => TRUE,
                'ogre_loginerror' => (isset($larray['ogre_loginerror'])) ? $larray['ogre_loginerror'] : '',
                'ogre_user_ID'  => $ci->person->user_id_num,
                'ogre_user_login_id'  => $ci->person->user_login_id,
                'ogre_user_name'  => $ci->person->fullname,
                'ogre_user_email' => $ci->person->email,
                'ogre_user_accesslevel_' . $porgid => $ci->person->access_rating,
                'ogre_user_activated_' . $pconid => $ci->person->user_verified,
                'ogre_welcome' => anchor(site_url($this->cntlr .'/myprofile'), $ci->person->fullname .' - OGRE ID: '.str_pad($ci->person->user_id_num,6,"0",STR_PAD_LEFT).' ',['class' => 'text-light'])];
        }

        return $logindata;
    }
//---------------------------------------------------
//
//---------------------------------------------------      
    public function resetSessionVarsUser($porgid=0,$pconid=0){
        $ci = &get_instance();
        $user = ['ogre_welcome','ogre_logged_in','ogre_loginerror','ogre_user_ID','ogre_user_name','ogre_user_email','ogre_user_activated_' . $pconid,'ogre_user_accesslevel_' . $porgid];
        $ci->session->remove($user);
        return TRUE;
    }
//---------------------------------------------------
//
//---------------------------------------------------      
    public function resetSessionVarsCon($porgid=0){
        $ci = &get_instance();
        $ci->session->remove('ogre_orgid');
        $ci->session->remove('ogre_conid');
        $ci->session->remove('ogre_maintenance');
        $ci->session->remove('ogre_msa_conid');
        return TRUE;
    }
//---------------------------------------------------
//
//---------------------------------------------------      
    public function setSessionData($sdata){
        $ci = &get_instance();
        $orgid = ((isset($sdata['ogre_orgid'])) ? $sdata['ogre_orgid'] : 0);
        $conid = ((isset($sdata['ogre_conid'])) ? $sdata['ogre_conid'] : 0);
        $ci->session->set('ogre_control', ((isset($sdata['ogre_control'])) ? $sdata['ogre_control'] : ''));
        $ci->session->set('ogre_orgid', ((isset($sdata['ogre_orgid'])) ? $sdata['ogre_orgid'] : 0));
        $ci->session->set('ogre_conid', ((isset($sdata['ogre_conid'])) ? $sdata['ogre_conid'] : 0));
        $ci->session->set('ogre_maintenance', ((isset($sdata['ogre_maintenance'])) ? $sdata['ogre_maintenance'] : 0));
        $ci->session->set('ogre_welcome', ((isset($sdata['ogre_welcome'])) ? $sdata['ogre_welcome'] : ''));
        $ci->session->set('ogre_loginerror', ((isset($sdata['ogre_loginerror'])) ? $sdata['ogre_loginerror'] : ''));
        $ci->session->set('ogre_logged_in', ((isset($sdata['ogre_logged_in'])) ? $sdata['ogre_logged_in'] : FALSE));
        $ci->session->set('ogre_user_ID', ((isset($sdata['ogre_user_ID'])) ? $sdata['ogre_user_ID'] : 0));
        $ci->session->set('ogre_user_name', ((isset($sdata['ogre_user_name'])) ? $sdata['ogre_user_name'] : ''));
        $ci->session->set('ogre_user_email', ((isset($sdata['ogre_user_email'])) ? $sdata['ogre_user_email'] : ''));
        $ci->session->set('ogre_user_accesslevel_'.$orgid, ((isset($sdata['ogre_user_accesslevel_'.$orgid])) ? $sdata['ogre_user_accesslevel_'.$orgid] : ''));    
        $ci->session->set('ogre_user_activated_'.$conid, ((isset($sdata['ogre_user_activated_'.$conid])) ? $sdata['ogre_user_activated_'.$conid] : ''));    
        return TRUE;
    }
//---------------------------------------------------
//
//---------------------------------------------------      
    public function init_sessionvars_con($pconid=0,$porgid=0){
        $ci = &get_instance();
        $ci->session->set('ogre_orgid', 0);
        $ci->session->set('ogre_conid', 0);
        $ci->session->set('ogre_maintenance', 0);
        return TRUE;          
    }
//---------------------------------------------------
//
//---------------------------------------------------      
    public function initSessionVarsUser($pconid=0,$porgid=0){
        $ci = &get_instance();
        $ci->session->set('ogre_welcome', '');
        $ci->session->set('ogre_loginerror', '');
        $ci->session->set('ogre_logged_in', FALSE);
        $ci->session->set('ogre_user_ID', 0);
        $ci->session->set('ogre_user_name', '');
        $ci->session->set('ogre_user_email', '');
        if($porgid != 0){
            $ci->session->set('ogre_user_accesslevel_'.$porgid, 0);
        }
        if($pconid != 0){
            $ci->session->set('ogre_user_activated_'.$pconid, 0);
        }
        return TRUE;          
    }
//---------------------------------------------------
//  OGRE TITLE
//---------------------------------------------------      
    public function ogreTitle(){
        $ci = &get_instance();
        $title = $this->getConfigKey('OGRE.TITLE', $ci->session->get('ogre_orgid'));
        $ver = $this->getConfigKey('OGRE.VERSION', $ci->session->get('ogre_orgid'));
        return 'OGRe ' . $ver . ' - ' . $title;        
    }
//---------------------------------------------------
//    OGRE HOME
//---------------------------------------------------       
    public function ogreHome($conid=0){
        $ci = &get_instance();
        if((trim($conid) != '') && (intval($conid) != 0)){
            $ci->convention->init($conid);
            $orgname = $ci->convention->orgname();
        } else{
            $orgid = $ci->session->ogre_orgid;
            $ci->organization->init($orgid);
            $orgname = $ci->organization->name;
        }
        $news = $this->displayNewsBoot(3);
        $ret = '<div id="indexhTab">';           
        $ret .= '<ul>';   
        $ret .= '<li>';
        $ret .= '<a href="#itab-0" >'. 'Home' . '</a>';
        $ret .= '</li>';        
        $ret .= '<li>';
        $ret .= '<a href="#itab-1" >' . 'News ('. $news["ncount"]. ')</a>';
        $ret .= '</li>';
        $ret .= '<li>';
        $ret .= '<a href="#itab-2" >' . 'Con Dates &amp; Info' . '</a>';
        $ret .= '</li>';
        $ret .= '</ul>'; 
        $ret .= '<div id="itab-0">';
        //tab 0
        $ret .= $this->display_welcome();
        $ret .= $this->displayCurrentCfg($conid, $orgname, $ci->convention->name, $ci->convention->website, $ci->convention->logo_img);
        $ret .= '</div>';
        //tab 1
        If($news['news'] !== NULL){
            $ret .= '<div id="itab-1">';
            $ret .= '<p>'.$this->getMiscContent('%%NEWSINSTRUCTIONS%%',0,TRUE).'</p>';
            $ret .= $news["news"];
//            Bulletins           
            $ret .= '</div>';
        }else{
            $ret .= '<div id="itab-1">';
            $ret .= '<div class="alert alert-danger">';
            $nonews = $this->getMiscContent('%%NONEWS%%',0);
            $ret .= '<h3>'.$nonews['title'].'</h3>';
            $ret .= '<p>'.$nonews['content'].'</p>';
            $ret .= '</div>';                  
            $ret.='</div>';            
        } 
        $ret .= '<div id="itab-2">';
        $ret .= $this->displayHomeEventTable();
        $ret .= $this->displayHomeOrgTable();
        $ret  .= '</div>';
        $ret  .= '</div>';
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------       
    private function displayCurrentCfg($conid, $orgname, $conname, $website, $img){
        $ci = &get_instance();
        $this->cntlr = $ci->session->ogre_control;
        $title = 'Current '. $orgname . ' OGRe Schedule';
        $ret =  '<div style="text-align: center ">';
        if(trim($img)!==""){
            $image_properties = array(
                'src' => $img,
                'alt' => 'conlogo',
                'width' => '300',
                'class' => 'img-responsive center-block'
            );
            $ret .=  '<div class="current-logo">';
            $ret .=  (!$ci->agent->isMobile()) ? img($image_properties) : ''; 
            $ret .=  '</div>';
        }
        $ret .=  '</div>';
        $txt = str_replace('%CONNAME%', $conname, str_replace('%CONWEBSITE%', $website, str_replace('%ORGNAME%', $orgname, $this->getMiscContent('%OGRECURRENTSETUP%',$conid))));
        $ret .= $txt["content"];
        $ret .= $this->getBulletinPost(); 
        $ret = $this->jumbotronText($ret, $title, '', $website, site_url($this->cntlr .'/browseschedule/allx'), $conname, $conid);
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------    
    public function jumbotronText($text, $title='',$subtext='', $wsite='', $gschedule='', $conname= '', $conid=0){
        $ci = &get_instance();
        $ret = '<div class="card border-primary mb-3">';
        $ret .= ($title !== '' ? '<div class="card-header">'.$title.'</div>' : '');
        $ret .= '<div class="card-body">';
        $ret .= ($conname !== '' ? '<h4 class="card-title">' . $conname .'</h4>' : '');
        $ret .= '<p class="card-text">'.$text.'</p><div class="d-grid gap-2">';
        $ret .= ($wsite !== '' ? '<button class="btn btn-outline-primary btn-lg custom_width" onclick="location.href='."'".$wsite."'".'" role="button">'. (!$ci->agent->isMobile() ? $conname: ""). ' Con Website</button>' : '');
        $ret .= ($gschedule !== '' ? '<button class="btn btn-outline-primary btn-lg custom_width" onclick="location.href='."'".$gschedule."'".'" role="button">'. (!$ci->agent->isMobile() ? $conname: "") . ' Game Schedule</button>' : '');
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';
        return $ret;
    }


//---------------------------------------------------
//
//---------------------------------------------------      
    public function resetUserAccess($puserid=0, $pconid=0, $porgid=0){
        $ci = &get_instance();
        $this->cntlr = $ci->session->ogre_control;
        if ($puserid !== 0){
            $ci->person->get($puserid,$pconid);
            $ci->session->set('ogre_user_name', $ci->person->fullname);
            $ci->session->set('ogre_user_email', $ci->person->email);
            $ci->session->set('ogre_user_accesslevel_'.$porgid, $ci->person->access_rating);    
            $ci->session->set('ogre_user_activated_'.$pconid, $ci->person->user_verified);   
            $ci->session->set('ogre_welcome', anchor(site_url($this->cntlr .'/myprofile'), $ci->person->fullname .' ('.str_pad($ci->person->user_id_num,6,"0",STR_PAD_LEFT).')',['class' => 'text-light']) . '');
        }       
        return TRUE;
    }    
//---------------------------------------------------
//
//---------------------------------------------------    
    public function checkActivation($orgid=0,$conid=0){
        $ci = &get_instance();
        $ret = FALSE;
        
        if($conid != 0){
            if ($ci->session->ogre_logged_in === TRUE){
                $act = $ci->session->get('ogre_user_activated_' . $conid);
                $acc = $ci->session->get('ogre_user_accesslevel_' . $orgid);
                $pid = $ci->session->ogre_user_ID;
                $ret = $ci->person->getUserVerified($conid,$pid);
                $dbact = $ci->person->user_verified;
                $dbaccess = $ci->person->access_rating;
                if((intval($act) !== intval($dbact)) || (intval($acc) !== intval($dbaccess))){
                    $ret = $this->resetUserAccess($pid,$conid, $orgid);
                }
            }
        }
        
        return $ret;
    }       
//---------------------------------------------------
//
//---------------------------------------------------   
public function loginSuccessRedirect($p, $controller){
        $ci = &get_instance(); 
        $dest = (isset($p["dest"])) ? $p["dest"] : 'index';
        $ret = '';
        switch ($dest){
            case 'index':
                $ret = site_url($controller);
                break;
            case 'propose':
                $ret =  site_url($controller.'/propose');
                break;
            case 'myprofile':
                $ret = site_url($controller.'/myprofile');
                break;
            default:
                $ret = site_url($controller);
                break;
        }    
        return $ret;
   }   
//---------------------------------------------------
//
//---------------------------------------------------   
    public function loginScreen($dest='index'){
        $ci = &get_instance();    
        $ret = '';
        $instr = $this->getMiscContent('%LOGININSTRUCTIONS%');
        $ret .= '<div class="login-table" id="login-table">';   
        $ret .= $instr['content'];                    
        $action = site_url("ogrex/logInActionX");
        $ret .= '<form name="login-form" id="login-form">';
        $ret .= '<div class="login-screen">';
        $ret .= '<input type="hidden" name="dest" value="' . $dest . '" />';
        $ret .= '<label for="login" class="form-label">Log In Name or Email Address</label>';
        $ret .= '<input name="login" id="login" class="form-control" type="text" />'; 
        $ret .= '<label for="pw" class="form-label">Password</label>';
        $ret .= '<input name="pw" id="pw" class="form-control" type="password" autocomplete="off" />'; 
        $ret .= '<div class="d-grid gap-2"><button class="btn btn btn-primary" name="login-submit" id="login-submit" type="button" onclick="loginAction('."'".$action."'".');" >Log In</button>';
        $ret .= '<button class="btn btn btn-primary" name="forgot" id="forgot" type="button" onclick="toggleforgot(' .  "'"  . 'on'  . "'" . ');" >Forgot Password</button></div>';
        $ret .= '</div>';
        $ret .= '</form>';
        $ret .= '</div>';
        return $ret;  
      }
//---------------------------------------------------
//
//---------------------------------------------------   	   
    public function forgotLoginScreen($email=''){	 
            $ci = &get_instance();
            $ret = '<form id="forgotLogIn" name="forgotLogIn">'; 
            $ret .= '<div id="forgotpwtable">';
            $intro = $this->getMiscContent('%FORGOTPASSWORDINTRO%');
            $ret .= '<div id="forgotpwscreen">';                      
            $ret .= $intro['content'];
            $ret .= '<div class="form-group row" id="userpassword">';
            $ret .= '<div class="col-lg-2">';
            $ret .= '</div>';
            $ret .= '<div class="col-lg-8">';            
            $ret .= '<label for="pw" class="form-label">E-mail:</label>';
            $ret .= (trim($email) != '') ? '<input class="form-control" type="text" name="user" value="' . urldecode($email) . '" />' : '<input class="form-control" type="text" name="user" id="user" />';
            $ret .= '</div>';
            $ret .= '<div class="col-lg-2">';
            $ret .= '</div>';
            $ret .= '</div>';     
            
            $ret .= '<div class="form-group row m-3" id="userpassword">';
            $ret .= '<div class="col">';
            $ret .= '</div>';
            $ret .= '<div class="col">'; 
            $action = site_url('ogrex/forgotActx');
            $ret .= '<input class="btn btn-secondary btn-block" type="button" name="forgotlogin" id="forgotlogin" value=" Reset Password"  onclick="getPassword('."'".$action."'".');" />';
            $ret .= '</div>';
            $ret .= '<div class="col">';
            $ret .= '</div>';
            $ret .= '</div>'; 
            
            $ret .= '<div class="form-group row m-3" id="userpassword">';
            $ret .= '<div class="col">';
            $ret .= '</div>';
            $ret .= '<div class="col">'; 
            $ret .= '<input class="btn btn-secondary btn-block" type="button" id="forgotback" name="forgotback" value=" Back to Log In " onclick="toggleforgot(' .  "'"  . 'off'  . "'" . ');" />'; 
            $ret .= '</div>';
            $ret .= '<div class="col">';
            $ret .= '</div>';
            $ret .= '</div>';
            $ret .= '</div>';
            $ret .= '</form>';
            $ret .= '</div>';   
            $ret .= '<div id="forgotmsg"></div>';
            return  $ret;
      }
//---------------------------------------------------
//
//---------------------------------------------------
    public function logInAction($conid, $p) {
       $ci=&get_instance();   
       $logdata = array();
       $uexists = array();
       if (isset($p["login"])){
           $uexists = $this->userExistsValidation($p);
           $logdata = (($this->password_checkh2($p["login"], $p["pw"]) && $uexists['ogre_logged_in']) ? ['ogre_logged_in'  => TRUE, 'ogre_loginerror' => '', 'ogre_welcome' => ' ' . $ci->person->fullname . ' is Logged In. '] : ['ogre_logged_in'  => FALSE,'ogre_loginerror' => ((!$uexists['ogre_logged_in']) ? $uexists['ogre_loginerror'] : ' Error.  Invalid Login or Password. '), 'ogre_welcome' => '' ]);
       }
       else{
           $logdata = ['ogre_logged_in' => FALSE,'ogre_loginerror' => '  Error Logging In. Invalid Login or Password. ', 'ogre_welcome' => ''];
       }
       if($logdata['ogre_logged_in'] === TRUE){
            $rret = $this->initUser($p, $conid);
            $ret = $this->loginUser($ci->person->user_id_num, $logdata);       
       }
       else{
           $ret = $this->loginUser(0, $logdata);
       }
       return $logdata;
   }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------     
    private function userExistsValidation($p){
        $ci=&get_instance();
        $ret = $this->userLoginExists($p["login"]);
        $retarr = (($ret) ? array('ogre_logged_in'  => TRUE,'ogre_loginerror' => '' ) : array('ogre_logged_in'  => FALSE,'ogre_loginerror' => '  Error.  Invalid Login or Password.  ' ));
        return $retarr;
    }   
//---------------------------------------------------
//
//---------------------------------------------------     
    private function initUser($p, $conid){
        $ci=&get_instance(); 
        if (filter_var(strtolower($p["login"]), FILTER_VALIDATE_EMAIL)) {                                    
            $ci->person->init($conid, strtolower($p["login"]), 0);
        }
        else{
            $ci->person->init($conid, '', 0, strtolower($p["login"]));
        }
        return TRUE;
    }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------   
    public function loginUser($pid, $logarr){
        $ci = &get_instance();         
        $usarray = $this->setSessionVarsUser($pid, $ci->session->ogre_conid, $ci->session->ogre_orgid, $logarr);
        $conarray = $this->setSessionVarsCon($ci->session->ogre_orgid, $ci->session->ogre_conid);
        $ret = $this->setSessionData(array_merge($usarray,$conarray));       
        return $ci->session->get('ogre_logged_in') && $ret;
    } 
//---------------------------------------------------
//
//---------------------------------------------------   
    public function logoff_user(){ 
        $ci=&get_instance();
        $orgid = $ci->session->ogre_orgid;
        $conid = $ci->session->ogre_conid;
        $conarray = $this->setSessionVarsCon($orgid, $conid);
        $userarray =  $this->setSessionVarsUser( 0, $conid, $orgid);
        $ret = $this->setsessiondata(array_merge($conarray, $userarray));        
        return "User is Logged Off";
    } 
    //---------------------------------------------------
    //
    //  
    //
    //---------------------------------------------------   
    public function userExists($email, $pid=0, $retinfo=FALSE){
        $ci=&get_instance();
        $qry = 'SELECT user_index_id, user_email, user_first_name, user_last_name ';
        $qry .= ' FROM ogre_users WHERE user_email = "' . $email . '" ';
        $qry .=  ($pid != 0) ? 'AND user_index_id != ' . $pid : '';
        $query = $ci->db->query($qry);
        if($retinfo==FALSE){
            $ret = ($query->getNumRows() > 0)?  TRUE : FALSE;
        }
        else{
            $ret['result'] = FALSE;
            $ret['user'] = '';
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                    $ret['user'] = $row->user_first_name .','. $row->user_last_name .','.$row->user_email.','.$row->user_index_id;
                    $ret['result'] = TRUE;
                }                     
            }            
        }
        return $ret; 
     }
                 
//---------------------------------------------------
//
//---------------------------------------------------   
    public function ogreid_exists($pid){
        $ci=&get_instance();
        $ret = array();
        $ret['user']='';
        $ret['result']=FALSE;
        $qry = 'SELECT user_index_id, user_email, user_first_name, user_last_name FROM ogre_users WHERE user_index_id = ' . $pid;
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $ret['user'] = $row->user_first_name .','. $row->user_last_name .','.$row->user_email;
            }                     
        }    
        $ret['result'] = ($query->getNumRows() > 0)?  TRUE : FALSE;                      
        return $ret; 
    }                 
//---------------------------------------------------
//
//---------------------------------------------------   */
    public function userLoginExists($login){
        $ci=&get_instance();                   
        $ret = FALSE;
        $qry = 'SELECT LOWER(user_login_id) as LogIn FROM ogre_users WHERE LOWER(user_login_id) = "'.trim(strtolower($login)).'" ;';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            $ret = TRUE;
        }
        else{
            $qry = 'SELECT LOWER(user_login_id) as LogIn FROM ogre_users WHERE LOWER(user_email) = "'.trim(strtolower($login)).'" ;';
            $query = $ci->db->query($qry);
            $ret =($query->getNumRows() > 0) ? TRUE : FALSE;
        }
        return $ret;
     }
//---------------------------------------------------
//
//---------------------------------------------------   
    public function userIDExists($login, $id=''){
        $ci=&get_instance();                   
        $qry = 'SELECT user_login_id, user_first_name, user_last_name, user_email FROM ogre_users WHERE user_login_id = "' . $login . '"';

        if (trim($id)!=''){
            if (!is_numeric($id)){
                $qry .= ' AND user_email <> "' . $id . '";';
            }
            else if($id != 0){
                $qry .= 'AND user_index_id != ' . $id;
            }
        }
        $query = $ci->db->query($qry);
        $ret = ($query->getNumRows() > 0)? TRUE : FALSE;
        return $ret;
    }

//---------------------------------------------------
//
//---------------------------------------------------   
    public function password_checkh2($login, $pw){
        $ci=&get_instance();
        $emaillogin = filter_var($login, FILTER_VALIDATE_EMAIL);
        $qry = 'SELECT user_passwordhash FROM ogre_users ';
        $qry .= (($emaillogin === FALSE) ? ' WHERE user_login_id  = "' . $login . '";' : ' WHERE user_email  = "' . $login . '";');
        $query = $ci->db->query($qry);
        if ($query->getNumRows() == 1){
            foreach ($query->getResult() as $row){
                $ret = password_verify($pw, $row->user_passwordhash);
            }               
        }else{
            $ret =  FALSE;
        }
        return $ret;    
     }     
//---------------------------------------------------
//
//---------------------------------------------------   
    public function password_check($login, $pw){
        $ci=&get_instance();		  
        $qry = 'SELECT * FROM ogre_users WHERE user_login_id  = "' . $login . '" AND user_passwordhash = "' . $pw .'";';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            $ret = TRUE;
        }
        else{
            $qry = 'SELECT * FROM ogre_users WHERE user_email  = "' . $login . '" AND user_passwordhash = "' . $pw .'";';
            $query = $ci->db->query($qry);
            $ret = ($query->getNumRows() > 0) ? TRUE : FALSE;
        }  
        return $ret;    
     }     
//---------------------------------------------------
//
//---------------------------------------------------   
    public function isLoggedIn($session){ 
       $ci=&get_instance();
       $orgid = $ci->session->get('ogre_orgid');
       $sesslogin = $ci->session->get('ogre_logged_in');
       if( trim($sesslogin) !== ''){
           $ret = $ci->session->get("ogre_logged_in");
           if (!is_bool($ret)){
               $ret = ($ret == 1) ? TRUE : FALSE;
           }			 
       }
       else{
           $ret = $ci->session->get("ogre_logged_in");
       } 
       return $ret;   
     }	  
//---------------------------------------------------
//
//  
//
//---------------------------------------------------   
    public function menu_build($ver=''){
        $ci=&get_instance();                    
        $ret ='';
        $ret .= '<div style="padding: 0px 0px 0px 20px;">';
        $ret .= '<div class="navmenu">';	
        $ret .= '<ul id="navmenu-h">';
        $orgid = $ci->session->get('ogre_orgid');
        $conid = $ci->session->get('ogre_conid');
        $ci->convention->init($conid);
        $qry = 'SELECT * FROM ogre_menus WHERE mnu_loc="' . $ver . '" AND mnu_display = 1 AND mnu_sub_id =0 ORDER BY mnu_code';
        $query = $ci->db->query($qry);

        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){                            
            if($ci->session->get('ogre_user_accesslevel_' . $orgid) >= $row->mnu_securitylevel){							
                if ($row->mnu_type == 1){
                        $ret .=  '<li><a href="' . $row->mnu_href . '">' . $row->mnu_text . '</a>';
                        $ret .= $this->menuBuildSubMenu($row->mnu_id, $ver);
                        $ret .=  '</li>';
                  }
                  else{
                        $ret .=  '<li><a href="' . $row->mnu_href . '" target="_blank" >' . $row->mnu_text . '</a>';	
                        $ret .=  '</li>';	
                  }
              }
            }
        }
        $ret .= '</ul>';				
        $ret .= '</div>';
        $ret .= '</div>';	
        return $ret;
    }
                 
//---------------------------------------------------
//
//---------------------------------------------------
    public function ogreStatusBarTop($bc = ""){
        $ci=&get_instance();   
        $ret ='';
        $this->cntlr = $ci->session->ogre_control;         
        $orgid = $ci->session->get('ogre_orgid');
        $conid = $ci->session->get('ogre_conid');
        $ci->convention->init($conid); 
        $ret .= '<div class="row"><div class="col-6">';
        $ret .= ((intval($orgid) != 0) ?  $this->bootBadge($ci->convention->orgname() , 'bg-primary m-1', 'org-name-title') : '') ;
        $ret .= ((intval($conid) != 0) ?  $this->bootBadge($ci->convention->name, 'bg-primary m-1', 'con-name-title') : '');
        $ret .= $this->bootBadge(' [<span id="current-location">'. $bc .'</span>]', 'bg-info text-dark m-1', 'current-location-badge');
        $ret .= '</div>'; 
        $ret .= '<div class="col-6 text-end">';
        if($ci->session->ogre_logged_in){
            $activation = ($ci->session->get('ogre_user_activated_' . $conid) == 0 ? FALSE : TRUE);
            $ret .=  $this->bootBadge(((intval($orgid) != 0) ? '' . ($ci->session->ogre_welcome) : "Pick Organization" ),'bg-success','welcome-title');
            $ret .=  ($activation === TRUE ? $this->bootBadge('Activated/Full Access  '. $this->accessLevel($ci->session->get('ogre_user_accesslevel_' . $orgid), $ci->person->ogre_level_rating),'bg-success m-1','activation-title') : $this->bootBadge(anchor(site_url($this->cntlr .'/myprofile#usertab-3'),'Inactive/Limited Access/Propose Games Only',["class"=>"text-light"]),'bg-danger m-1','inactivate-title'));
        }
        $ret .= '</div>';
        $ret .= '</div>';
        return $ret;
    } 
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function ogreStatusBarTopMobile($bc = ""){
        $ci=&get_instance();   
        $ret ='';
        $this->cntlr = $ci->session->ogre_control;         
        $orgid = $ci->session->get('ogre_orgid');
        $conid = $ci->session->get('ogre_conid');
        $ci->convention->init($conid); 
        $ret .= '<div class="row"><div class="col"><div class="d-grid gap-2">';
        $ret .= ((intval($orgid) != 0) ?  $this->bootBadge($ci->convention->orgname() , 'bg-primary m-1', 'org-name-title') : '') ;
        $ret .= ((intval($conid) != 0) ?  $this->bootBadge($ci->convention->name, 'bg-primary m-1', 'con-name-title') : '');
        $ret .= $this->bootBadge(' [<span id="current-location">'. $bc .'</span>]', 'bg-info text-dark m-1', 'current-location-badge');
        if($ci->session->ogre_logged_in){
            $activation = ($ci->session->get('ogre_user_activated_' . $conid) == 0 ? FALSE : TRUE);
            $ret .=  $this->bootBadge(((intval($orgid) != 0) ? '' . ($ci->session->ogre_welcome) : "Pick Organization" ),'bg-success','welcome-title');
            $ret .=  ($activation === TRUE ? $this->bootBadge('Activated/Full Access  '. $this->accessLevel($ci->session->get('ogre_user_accesslevel_' . $orgid), $ci->person->ogre_level_rating),'bg-success m-1','activation-title') : $this->bootBadge(anchor(site_url($this->cntlr .'/myprofile#usertab-3'),'Inactive/Limited Access/Propose Games Only',["class"=>"text-light"]),'bg-danger m-1','inactivate-title'));
        }
        $ret .= '</div></div>';
        $ret .= '</div>';
        return $ret;
    } 
//---------------------------------------------------
//
//---------------------------------------------------   
    
    public function getOgreMainNavButtonsMobile(){
        $ret = '';
        $ci=&get_instance(); 
        $orgid = $ci->session->get('ogre_orgid');
        $conid = $ci->session->get('ogre_conid');        
        if ($ci->session->ogre_logged_in === TRUE){
            $pid = $ci->session->get('ogre_user_ID');
            $ci->person->get($pid);
            $unread = $ci->person->getUnreadMessages() + $ci->person->getUnreadMessagesGM();

            $ret .= '<div class="d-grid gap-2">' .((intval($orgid) != 0) ? str_replace('<button', '<button class="btn btn-primary me-1 " role="button" href=',$this->getChangeLink())  : ''). ' ';  
            $ret .= '<button class="btn btn-primary me-1 " id="logoff" onclick="self.location = ' ."'". site_url($this->cntlr .'/logoff') ."'". '";">Log Off</button>';
            if($unread !== 0){
                $haction = site_url('ogrex/getMySchedule','https');
                $saction = site_url('ogrex/gameEditInx','https');                
                $ret .= '<button class="btn btn-primary me-1 position-relative"  onclick="return displayHistory('."'".$haction."',". $pid . ",'". $saction ."'". ');">My Schedule';
                $ret .= '<span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="unread-messages-main">';
                $ret .= $unread;
                $ret .= '</span>';
                $ret .= '</button>';
            }  
        }
        else{  
            $ret .= '<div class="d-grid gap-2">' .((intval($orgid) != 0) ? str_replace('<button ', '<button class="btn btn-primary" role="button" href=',$this->getChangeLink())  : ''). ' ';  
            $ret .= '<button class="btn btn-primary" role="button" id="login" onclick="return logOnScreen(' ."'". site_url('ogrex/login') ."','" . site_url("ogrex/logInActionX") ."','" . site_url('ogrex/register_inx'). "','" . 'reg-result' . "','". site_url('ogrex/forgotActx') . "'" . ')">Log-In/Register</button>';
        }
        $ret .= '</div>';
        return $ret;
    }    
//---------------------------------------------------
//
//---------------------------------------------------   
    
    public function getOgreMainNavButtons(){
        $ret = '';
        $ci=&get_instance(); 
        $orgid = $ci->session->get('ogre_orgid');
        $conid = $ci->session->get('ogre_conid');        
        if ($ci->session->ogre_logged_in === TRUE){
            $pid = $ci->session->get('ogre_user_ID');
            $ci->person->get($pid);
            $unread = $ci->person->getUnreadMessages() + $ci->person->getUnreadMessagesGM();

            $ret .= '<div class="col text-end">' .((intval($orgid) != 0) ? str_replace('<button', '<button class="btn btn-primary me-1 " role="button" href=',$this->getChangeLink())  : ''). ' ';  
            $ret .= '<button class="btn btn-primary me-1 " id="logoff" onclick="self.location = ' ."'". site_url($this->cntlr .'/logoff') ."'". '";">Log Off</button>';
            if($unread !== 0){
                $haction = site_url('ogrex/getMySchedule','https');
                $saction = site_url('ogrex/gameEditInx','https');                
                $ret .= '<button class="btn btn-primary me-1 position-relative"  onclick="return displayHistory('."'".$haction."',". $pid . ",'". $saction ."'". ');">My Schedule';
                $ret .= '<span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="unread-messages-main">';
                $ret .= $unread;
//                $ret .= '<span class="visually-hidden">unread messages</span>';
                $ret .= '</span>';
                $ret .= '</button>';
            }  
        }
        else{  
            $ret .= '<div class="col text-end">' .((intval($orgid) != 0) ? str_replace('<button ', '<button class="btn btn-primary" role="button" href=',$this->getChangeLink())  : ''). ' ';  
            $ret .= '<button class="btn btn-primary" role="button" id="login" onclick="return logOnScreen(' ."'". site_url('ogrex/login') ."','" . site_url("ogrex/logInActionX") ."','" . site_url('ogrex/register_inx'). "','" . 'reg-result' . "','". site_url('ogrex/forgotActx') . "'" . ')">Log-In/Register</button>';
        }
        $ret .= '</div>';
        return $ret;
    }
//---------------------------------------------------
//      define('PLAYER', 10);
//      define('GAMEMASTER', 20);
//      define('REGVOL', 80);
//      define('CONADMIN', 90);
//      define('ADMIN', 99);
//      define('SUPERADMIN', 100);
//---------------------------------------------------     
    private function accessLevel($lvl=0, $olevel=0){

        switch ($lvl){
            case 0: 
                $ret = "Guest";
                break;            
            case 10: 
                $ret = "Player/Participant";
                break;
            case 20:
                $ret = "Game Master/Volunteer";
                break;         
            case 80:
                $ret = "Registration Volunteer";
                break;
            case 90:
                $ret = "Co-Admin";
                break;             
            case 99:
                $ret = "Admin";
                break; 
            case 100:
                $ret = "SUPER ADMIN";
                break;   
            default:
                $ret = $this->getSecurityAccess($lvl, $olevel);
                break;
        }
        return $ret;
    }
    
//---------------------------------------------------
//
//---------------------------------------------------      
    public function getSecurityAccess($lvl, $olevel){
        $ci = &get_instance();
        $seclvl  = (intval($olevel) == 0) ? 'con' : 'org';
        $qry = 'SELECT * FROM ogre_security WHERE os_accesslevel="'.$lvl.'" AND os_seclevel="'.$seclvl.'" ORDER BY os_accesslevel;';
        $ret = '';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $ret =  $row->os_levelname;
            }
        }
        return $ret;        
    }
//---------------------------------------------------
//
//---------------------------------------------------                 
    public function getOgreStatusbarBottom($bc=""){
        $ci=&get_instance();   
        $orgid = $ci->session->get('ogre_orgid');
        $conid = $ci->session->get('ogre_conid');
        $ci->convention->init($conid);     
        $ret ='';
        $err = $ci->session->get('ogre_loginerror');
        $mobile = $ci->agent->isMobile();
        if(!$mobile){
            if (trim($ci->session->get('ogre_welcome')) != ''){
                $ret .= '<div style="margin: 0px 0px 0px 0px;">';
                $ret .= '<table class="statusbar_table">';;                            
                $ret .= '<tr>';                                
                $ret .= '<td class="statusbar_left">';                                
                $ret .= 'Current System Status: ';
                $ret .= '' . $this->getConfigKey('SYSTEM.STATUS', $orgid);    
                $ret .= '</td>';
                $ret .= '<td class="statusbar_right" id="breadcrums">';                                
                $ret .= '<strong>' . $ci->convention->orgname() . ' &raquo; ' . $ci->convention->name .' OGRe ' . $this->getConfigKey('OGRE.VERSION', $ci->session->get('ogre_orgid'));    
                if(isset($bc)){
                    $ret .= ' &raquo; ' . $bc;
                }
                $ret .= '</strong>';        

                $ret .= '</td>';                                
                $ret .= '</tr>';
                $ret .= '</table>';
                $ret .=  '</div>';
            }
            else{
                $ret .= '<div style="margin: 0px 0px 0px 0px;">';
                $ret .= '<table class="statusbar_table">';
                $ret .= '<tr>';
                $ret .= '<td>';
                $ret .= ' </td><td> ' ;
                $ret .= $ci->convention->game_prereg_date_prompt();
                $ret .=  '</td></tr></table>';
                $ret .=  '</div>';
            }
        }
        else{
            if (trim($err) != ''){
                $ret .= '<div style="margin: 0px 0px 20px 0px; color:#FF0000;">';
                $ret .= '<table class="statusbar_table">';
                $ret .= '<tr><td>' . $err  . '</td></tr></table></div>';
            }
            if (trim($ci->session->get('ogre_welcome')) != ''){
                $ret .= '<div style="margin: 0px 0px 0px 0px;">';
                $ret .= '<table class="statusbar_table">';                             
                $ret .= '<tr>';                                
                $ret .= '<td class="statusbar_left">';                                
                $ret .= 'Current System Status: ';
                $ret .= $this->getConfigKey('SYSTEM.STATUS', $orgid);    
                $ret .= ' </td>';
                $ret .= '</tr>';                             
                $ret .= '<tr>';                             
                $ret .= '<td class="statusbar_left" id="breadcrums">';                                
                $$ret .= '<strong>' . $ci->convention->orgname() . ' &raquo; ' . $ci->convention->name .' OGRe ' . $this->getConfigKey('OGRE.VERSION', $ci->session->get('ogre_orgid'));    
                if(isset($bc)){
                    $ret .= ' &raquo; ' . $bc;
                }
                $ret .= '</strong>';                                                                                        
                $ret .= '</td>';                                
                $ret .= '</tr>';
                $ret .= '</table>';
                $ret .=  '</div>';
            }
            else{
                $ret .= '<div style="margin: 0px 0px 0px 0px;">';
                $ret .= '<table class="statusbar_table">';
                $ret .= '<tr>';
                $ret .= '<td>';
                $ret .= ' </td><td> ' ;
                $ret .= $ci->convention->game_prereg_date_prompt();
                $ret .=  '</td></tr></table>';
                $ret .=  '</div>';
            }                        
        }
        return $ret;
    }
//---------------------------------------------------

//---------------------------------------------------  
    private function menuBuildSubMenu($mnuid, $loggedin, $activated, $accesslevel, $controller=''){
        $ci=&get_instance();
        $this->cntlr = $ci->session->get('ogre_control');
        $ret = '<ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">';
        $qry = 'SELECT * FROM ogre_menus WHERE mnu_sub_id=' . $mnuid . ' AND (mnu_loc="5OL0" ';
        if($loggedin === TRUE){
            $qry .= ' OR mnu_loc="5OL1" OR mnu_loc="5OL1F" '. (($activated != 1) ? ' OR mnu_loc="5OL1X") ' : ') ');
        }
        else{
            $qry .= ' OR mnu_loc="5OL0N") ';        
        }
        $qry .=  ' AND mnu_display = 1  ORDER BY mnu_code';
        $query = $ci->db->query($qry);			
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                if($accesslevel >= $row->mnu_securitylevel){
                $acttxt = $this->actMenuOption($row->mnu_text, $activated);  
                $mnu_href = (($row->mnu_code == "01.OGRE.HOME") ? $row->mnu_href . "/" . $controller : $row->mnu_href);
                switch($row->mnu_type){
                    case 1:
                        $ret .=  '<li><a class="dropdown-item" href="' . site_url(str_replace('ogre', $this->cntlr,$mnu_href)) . '">' . $row->mnu_text . $acttxt . '</a>';
                        $ret .=  '</li>';
                        break;
                    case 2:
                        $ret .=  '<li class="dropdown-item"><a href="' . site_url(str_replace('ogre', $this->cntlr,$mnu_href)). ' target="_blank">'.$row->mnu_text.'</a>';	
                        $ret .=  '</li>';
                        break;
                    default:
                        $ret .= '<li></li>';
                        break;
                    }
                }
            }		 
        }
        $ret .= '</ul>';
        return $ret;
     }                 
//---------------------------------------------------
//
//---------------------------------------------------  
    private function menuBuildSubMenu3($mnuid, $loggedin, $activated, $accesslevel, $controller=''){
       $ci=&get_instance();                   
       $ret = '';
       $qry = 'SELECT * FROM ogre_menus ';
       $qry .= ' WHERE mnu_sub_id=' . $mnuid;
       $qry .= ' AND (mnu_loc="7OL0" ';
       if($loggedin === TRUE){
           $qry .= ' OR mnu_loc="7OL1" OR mnu_loc="7OL1F" ';
           $qry .= (($activated != 1) ? ' OR mnu_loc="7OL1X") ' : ') ');
       }
       else{
           $qry .= ' OR mnu_loc="7OL0N") ';        
       }

       $qry .=  ' AND mnu_display = 1 ';
       $qry .= ' ORDER BY mnu_code';
       $ret .= '<div class="dropdown-menu" aria-labelledby="menu'.$mnuid.'">';
       $query = $ci->db->query($qry);			
       if ($query->getNumRows() > 0){
           foreach ($query->getResult() as $row){
               if($accesslevel >= $row->mnu_securitylevel){
               $acttxt = $this->actMenuOption($row->mnu_text, $activated);  
               $mnu_href = (($row->mnu_text == "OGRe Home") ? $row->mnu_href . "/" . $controller : $row->mnu_href);
               switch($row->mnu_type){
                   case 1:
                       $ret .= '<a class="dropdown-item" href="' . site_url($mnu_href) . '">' . $row->mnu_text . $acttxt . '</a>';
                       break;
                   case 2:
                       $ret .= '<a class="dropdown-item" href="' . site_url($mnu_href) . '" target="_blank">' . $row->mnu_text . '</a>>';
                       break;
                   default:
                       $ret .= '<a class="dropdown-item" href="' . site_url($mnu_href) . '">' . $row->mnu_text . '</a>';
                       break;
                   }
               }
           }
       }   
       $ret .= '</div>';
       return $ret;
    } 
                 
//---------------------------------------------------
//
//---------------------------------------------------  
    private function menuBuildSubMenu3_mobile($mnuid, $loggedin, $activated, $accesslevel, $controller=''){
        $ci=&get_instance();                   
        $ret = '';
        $qry = 'SELECT * FROM ogre_menus ';
        $qry .= ' WHERE mnu_sub_id=' . $mnuid;
        $qry .= ' AND (mnu_loc="7OL0" ';
        if($loggedin === TRUE){
            $qry .= ' OR mnu_loc="7OL1" OR mnu_loc="7OL1F" ';
            $qry .= (($activated != 1) ? ' OR mnu_loc="7OL1X") ' : ') ');
        }
        else{
            $qry .= ' OR mnu_loc="7OL0N") ';        
        }

        $qry .=  ' AND mnu_display = 1 ';
        $qry .= ' ORDER BY mnu_code';
        
        $query = $ci->db->query($qry);			
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                if($accesslevel >= $row->mnu_securitylevel){
                $acttxt = $this->actMenuOption($row->mnu_text, $activated);  
                $mnu_href = (($row->mnu_text == "OGRe Home") ? $row->mnu_href . "/" . $controller : $row->mnu_href);
                switch($row->mnu_type){
                    case 1:
                        $ret .= '<li><a href="' . site_url($mnu_href) . '">' . $row->mnu_text . $acttxt . '</a></li>';
                        break;
                    case 2:
                        $ret .= '<li><a href="' . site_url($mnu_href) . '" target="_blank">' . $row->mnu_text . '</a></li>';
                        break;
                    default:
                        $ret .= '<li><a href="' . site_url($mnu_href) . '">' . $row->mnu_text . '</a></li>';
                        break;
                    }
                }
            }
        }    
      
        return $ret;
    }                  
//---------------------------------------------------
//
//---------------------------------------------------   
    private function actMenuOption($mnu, $act){                
       $ret='';
        if($mnu == "My Profile"){
               if($act!==1){
               $ret = "/Activate";
           }
       }
       return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------   
    public function menuBuildSide2($loggedin=FALSE, $activated=FALSE, $accesslevel=0){
       $ci=&get_instance();
       $orgid = $ci->session->get('ogre_orgid');
       $conid = $ci->session->get('ogre_conid');
       $ci->convention->init($conid);
       $ret = '';
       $accesslevel = (($accesslevel===FALSE) ||(trim($accesslevel)=='') ? 0 : $accesslevel);
       $qry = 'SELECT * FROM ogre_menus WHERE (mnu_loc="5OL0" '. (($loggedin===TRUE) ? 'OR mnu_loc="5OL1"': '') . ') AND mnu_display = 1 AND mnu_sub_id =0 ORDER BY mnu_code';
       $query = $ci->db->query($qry);
       if ($query->getNumRows() > 0){
           foreach ($query->getResult() as $row){      
               if($accesslevel >= $row->mnu_securitylevel){
                   if (intval($row->mnu_type) == 1){        
                           $ret .=  '<li class="nav-item dropdown"><a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">' . $row->mnu_text . '</a>';                 
                           $ret .= $this->menuBuildSubMenu($row->mnu_id, $loggedin, $activated, $accesslevel, $ci->convention->ogre_dir); 
                           $ret .= '</li>';     
                   }
                   else{
                           $ret .=  '<li class="nav-item"><a class="nav-link" href="#">' . $row->mnu_text . '</li>';	
                   }
               }
           }
       }
       return $ret;
    }          
//---------------------------------------------------
//
//---------------------------------------------------   
    public function menuBuildSide($ver=''){
        $ci=&get_instance();
        $orgid = $ci->session->get('ogre_orgid');
        $ret ='';
        $qry = 'SELECT * FROM ogre_menus WHERE mnu_loc="' . $ver . '" AND mnu_display = 1 AND mnu_sub_id =0 ORDER BY mnu_code';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                if($ci->session->get('ogre_user_accesslevel_' . $orgid) >= $row->mnu_securitylevel){					
                    if ($row->mnu_type == 1){
                        $ret .=  '<h2>' . $row->mnu_text . '</h2>';
                        $ret .= $this->menuBuildSubMenu($row->mnu_id, $ver); 
                    }
                    else
                    {
                        $ret .=  '<h2>' . $row->mnu_text . '<h2>';	
                    }
                }
            }
        }
        $ret .=  '<h2>Contact</h2>';
        $ret .= '<ul>';            
        $email = $this->getConfigKey('CON.GAMING.COORDINATOR.EMAIL', $orgid);  
        $ret .= '<li>'.safe_mailto($email, 'Gaming Coordinator').'</li>';
        $email = $this->getConfigKey('CON.ORG.PLAY.COORDINATOR.EMAIL', $orgid);                   
        $ret .= '<li>'.safe_mailto($email, 'Org. Play Coor.').'</li>';
        $ret .= '</ul>';
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------   
    public function indexMenuBuild($ver=''){
        $ci=&get_instance();

        $orgid = $ci->session->get('ogre_orgid');
        $ret ='';
        $qry = 'SELECT * FROM ogre_menus WHERE mnu_loc="' . $ver . '" AND mnu_display = 1 AND mnu_sub_id =0 ORDER BY mnu_code';
        $query = $ci->db->query($qry);

        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                if($ci->session->get('ogre_user_accesslevel_' . $orgid) >= $row->mnu_securitylevel){
                    if ($row->mnu_type == 1){
                              $ret .=  '<h2>' . $row->mnu_text . '</h2>';
                              $ret .= $this->indexMenuBuildSubMenu($row->mnu_id, $ver);
                    }
                    else{
                              $ret .=  '<h2>' . $row->mnu_text . '<h2>';
                    }
                }
            }
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------   
    private function indexMenuBuildSubMenu($mnuid, $ver=''){
        $ci=&get_instance();
        $orgid = $ci->session->get('ogre_orgid');
        $ret = '<blockquote>';
        $qry = 'SELECT * FROM ogre_menus WHERE mnu_sub_id=' . $mnuid  . ' AND mnu_loc="' . $ver . '" AND mnu_display = 1 ORDER BY mnu_code';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                if($ci->session->get('ogre_user_accesslevel_' . $orgid) >= $row->mnu_securitylevel){
                    switch($row->mnu_type){
                        case 1:
                            $ret .=  '<p><a href="' . site_url($row->mnu_href) . '">' . $row->mnu_text . '</a> - ' . $row->mnu_notes . '</p>';
                            break;
                        case 2:
                            $ret .=  '<p>' . anchor(site_url($row->mnu_href), $row->mnu_text, array('target' => '_blank'),'https'). ' - ' . $row->mnu_notes . '</p>';
                            break;
                        default:
                            $ret .= '';
                            break;
                    }
                }
            }
        }
        $ret .= '</blockquote>';
        return $ret;
    }
//---------------------------------------------------
//  
//---------------------------------------------------
    public function getConGamingInfoKey($conid=0, $key=''){
        $ci=&get_instance();
        $qry = 'SELECT '.$key.' FROM ogre_convention WHERE con_id = '.$conid.';';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResultArray() as $row){
                $ret = $row[$key];
            }
        }
        else{
            $ret = FALSE;
        }  
        return $ret; 
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getConfigKey($key, $orgid=0, $conid=0){
        $ci=&get_instance();    
        $ret = '';                 
        $qry = 'SELECT * FROM ogre_config WHERE cfg_param_name="' . $key . '" ';
        if($orgid != 0){
            $qry .= ' AND cfg_orgid = ' . $orgid; 
        }
        if($conid != 0){
            $qry .= ' AND cfg_conid = ' . $conid; 
        }
        $qry .= ' ORDER BY cfg_id;';               
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $ret .= $row->cfg_param_value;
            }
        }
        return $ret;
    }                   
//---------------------------------------------------
//  
//---------------------------------------------------		
    public function ogre_index($maint, $ver){
         $ret = '';
        if ($maint == '1'){
            $ret .= '<h1 align="center">OGRe Under Maintenace.  Check Back Later</h1>';
        } 			                    
         if ($maint != '1'){   
            $ret .='<div id="ogremiheader">';  
            $ret.='<a href="#" onclick="return showMenuInstr();">';
            $ret.='OGRe Menu Explanations';
            $ret.='</a>';               
            $ret .= '</div>';
            $ret .= '<div id="menuinstructions" style="display: none;">'; 
            $ret.='<div style="text-align:right" id="closemi"><a href="#" onclick="return closeMenuInstr();">Close</a></div>';                      
            $ret.='<div class="ogrenewscontent" >';
            $ret .= $this->indexMenuBuild($ver);
            $ret .= '</div>'; 
            $ret .= '</div>';
            $ret .= '<div id="ogremifooter">-</div>';                        
         }
         else{
               $ret .= '<h1 align="center">OGRe Under Maintenace.  Check Back Later</h1>';
         }  
         return $ret;
    }
            
//---------------------------------------------------
//  
//---------------------------------------------------		
    public function getContacts($orgid=0){
        $ret = '';
        $ci=&get_instance();
        $ret .=  '<h2>Contact</h2>';
        $email = $this->getConfigKey('CON.GAMING.COORDINATOR.EMAIL', $orgid);  
        $ret .= '<p>'.safe_mailto($email, 'Gaming Coordinator').' - Any general questions about our schedule, our events or GMing.</p>';
        $email = $this->getConfigKey('CON.ORG.PLAY.COORDINATOR.EMAIL', $orgid);                   
        $ret .= '<p>'.safe_mailto($email, 'Organized Play Coordinator').' - (Includes PFS, D&amps;D AL, and SRM.  Please place the specific Organized Play group in the subject line.</p>';
        return $ret;                   
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getMiscContent($id=0, $conid=0, $contentonly=FALSE){
        $ci=&get_instance(); 
        $sql = 'SELECT * FROM ogre_misccontent  WHERE ';
        $ci->convention->init(($conid==0) ? $ci->session->ogre_conid : $conid);
        $sql .= is_numeric($id) ? ' mc_id= ' . $id : ' mc_code= "' . $id . '"';                                               
        $sql .= ($conid != 0) ? ' AND mc_orgid = ' . $ci->convention->orgid : '';
        $query = $ci->db->query($sql);  
        if($query->getNumRows() != 0){
            foreach ($query->getResult() as $row){
                $ret["content"] = $row->mc_content;
                $ret["title"]= $row->mc_name;
            }
        }else{
            $ret["content"] = '';
            $ret["title"]= '';                               
        }
        return ($contentonly===TRUE) ? $ret["content"] : $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getRegisterForm($conid=0){
        $ci=&get_instance();  
        $this->cntlr = $ci->session->ogre_control;
        $conid = ($conid==0) ? $ci->session->get('ogre_conid') : $conid;
        $ret = '';
        $notes = '';
        $emaction = site_url('ogrex/checkEmailAddress');
        $idaction = site_url('ogrex/check_userid');
        $notes = $this->getMiscContent('%OGREACCOUNTREGFORM1%');
        $link = anchor(site_url("ogre/forgot"),'go here to get your password emailed to you.','https');
        $notes = str_replace('%FORGOT_PASSWORD_LINK%', $link, $notes);
        $ci->convention->init($conid);
        $gc = safe_mailto($ci->convention->gamingcoordinatoremail,'Contact the OGRe Admin to Activate you Account.');                    
        $notes = str_replace('%OGRE_ADMIN_EMAIL%', $gc, $notes);
        $ret .= '<div id="validate-message"></div>';
        $ret .= '<div class="register-table" id="account-info-table">';
        $ret .= '<form id="make-account" action="' . site_url($this->cntlr .'/registerIn')  . '" method="post" name="make-account" autocomplete="off">';
        $ret .= '<input id="RPGANumber" name="RPGANumber" type="hidden">';
        $ret .= '<input id="pnotes" name="pnotes" type="hidden">';                    
        $ret .= '<div id="reginstructions"><a href="#" onclick="return get_regforminstructions();">Click here for OGRe Account Instructions</a></div>';
        $ret .= '<div id="reginstruct" style="display:none">'.$notes["content"].'</div>';
        $ret .= '<label for="userfirstname" class="form-label">First Name <sup>required</sup></label>';
        $ret .= '<input type="text" class="form-control" placeholder="First Name" name="userfirstname" id="userfirstname" maxlength="80" />';
        $ret .= '<label for="userlastname" class="form-label">Last Name <sup>required</sup></label>';
        $ret .= '<input type="text"  class="form-control" placeholder="Last Name" name="userlastname" id="userlastname" />';
        $ret .= '<label for="user_email" class="form-label">Valid E-mail Address <sup>required</sup></label>';
        $ret .= '<input type="text" class="form-control" placeholder="Email Address" name="user_email" id="user_email" maxlength="80" onblur="check_userinfo(this,'."'".$emaction."','emailvalid', 0".",'user_email'". ');" />';
        $ret .= '<div id="emailvalid"></div>';  
        $ret .= '<label for="userlastname" class="form-label">OGRe Log In Name (defaults to email address)</label>';
        $ret .= '<input type="text"  class="form-control" placeholder="Log In Name" name="userloginid" id="userloginid" onblur="check_userinfo(this,'."'".$idaction."','idvalid', 0".",'userloginid'". ');" />';
        $ret .= '<div id="idvalid"></div>';;
        $ret .= '<label for="userpassword1" class="form-label">Password <sup>required</sup></label>';
        $ret .= '<input type="password" class="form-control" name="userpassword1" id="userpassword1" autocomplete="off" />';
        $ret .= '<div id="idvalid"></div>';
        $ret .= '<label for="userpassword1" class="form-label">Verify Password</label>';
        $ret .= '<input type="password"  class="form-control" autocomplete="off" name="userpassword2" id="userpassword2" onblur="validatePasswordMatch(this);" />';
        $ret .= '<div id="pwvalid"></div>';
        $regaction =  site_url('ogrex/register_inx');
        $divid='reg-result';
        $ret .= '<div class="d-grid gap-2">';
        $ret .= '<button class="btn btn-secondary" type="button" id="sendinfo"  name="sendinfo" onclick="return validateUserInfo('."'".$regaction."','".$divid."'".');">Save Profile</button>';                   
        $ret .= '</div>'; 
        $ret .= '<div id="reg-result"></div>';
//        $ret .= '<div class="d-grid gap-2">';
//        $ret .= '<button class="btn btn-secondary" type="button" id="return-to-reg-form"  name="return-to-reg-form" onclick="returnUserInfo();">Back</button>';
//        $ret .= '</div>'; 
        return $ret;
    }  
//---------------------------------------------------
//
//---------------------------------------------------
    public function registerInErrMessages($indx=''){
        $msg = array();
        $resp = $this->getMiscContent('%ACCOUNTSUCCESSFUL%');                 
        $msg['success'] = $resp['content'];
        $msg['fail'] = '<h1>OGRe Account Not Created</h1><p>There was a problem creating your account.</p>';
        $msg['exists'] = '<h1>OGRe Log In ID Exists</h1><p>This Log In ID Exists in the system. Unfortunately, for security reasons, Log In information needs to be unique to each user.</p><p>Please pick another and re-register in OGRe.</p>';
        $msg['useridrequired'] = '<p>Invalid User LogIn.  Field is Required</p>';
        $msg['useridexists'] = "<p>Log In ID already exists. Please Pick Another ID.</p>";
        $msg['emailrequired'] = "<p>Invalid User E-mail.  Field is Required</p>";
        $msg['emailexists'] = "<p>Email exists already exists</p>";
        $msg['firstnamerequired'] = "<p>Invalid User First Name.  Field is Required</p>";
        $msg['lastnamerequired'] = "<p>Invalid User Last Name.  Field is Required</p>";
        $msg['passwordrequired'] =  "<p>Invalid User password.  Field is Required</p>";
        $msg['passwordmismatch'] =  "<p>Invalid User password.  The Passwords do not match.</p>";
        $msg['accountexistsmessage'] = '<h1>An OGRe Accoutn Exists for this Email Address</h1><p>The email entered has an account associated to it in OGRe.</p><p>If you would like your Login and Password emailed to you, please use the Forgot Password button on the login screen.</p>';
        return $msg[$indx];
    }    
    
//---------------------------------------------------
//
//--------------------------------------------------- 
    public function registerIn($p){                   
        $ci = &get_instance();
        $errMsg = '';
        $validData = TRUE;
        $emailresp=array();
        if (!isset($p["userloginid"])){
            // ERROR CHECK  - USER LOG IN
            $validData = FALSE;
            $errMsg .= $this->registerInErrMessages('useridrequired');
        }
        if (!isset($p["user_email"])){ 
            // ERROR CHECK  - USER EMAIL
            $validData = FALSE;
            $errMsg .= $this->registerInErrMessages('emailrequired');
        }
        if (!isset($p["userpassword1"])){ 
            //  PASSWORD CHECK
            $validData = FALSE;
            $errMsg .= $this->registerInErrMessages('passwordrequired');
        }
        if (!isset($p["userpassword2"])){ 
            //  PASSWORD CHECK
            $validData = FALSE;
            $errMsg .= $this->registerInErrMessages('passwordrequired');
        }
        if (!isset($p["userfirstname"])){
            $validData = FALSE;
            $errMsg .= $this->registerInErrMessages('firstnamerequired');
        }        
        if (!isset($p["userlastname"])){
            $validData = FALSE;
            $errMsg .= $this->registerInErrMessages('lastnamerequired');
        }  
        if($validData==TRUE){
            if (trim($p["userloginid"]) == ""){
                $validData = FALSE;
                $errMsg .= $this->registerInErrMessages('useridrequired');
            }
            if (trim($p["user_email"]) == ""){ 
                $validData = FALSE;
                $errMsg .= $this->registerInErrMessages('emailrequired');
            }
            if (trim($p["userpassword1"]) == ""){ 
                $validData = FALSE;
                $errMsg .= $this->registerInErrMessages('passwordrequired');
            }
            if (trim($p["userpassword2"]) == ""){ 
                $validData = FALSE;
                $errMsg .= $this->registerInErrMessages('passwordrequired');
            }
            if (trim($p["userfirstname"]) == ""){
                $validData = FALSE;
                $errMsg .= $this->registerInErrMessages('firstnamerequired');
            }     
            if (trim($p["userlastname"]) == ""){
                $validData = FALSE;
                $errMsg .= $this->registerInErrMessages('lastnamerequired');
            }              
        }
        $login_exists = $this->userIDExists($p["userloginid"], $p["user_email"]);
        $email_exists = $this->userExists($p["user_email"]);     
        if($login_exists==TRUE){
            $errMsg .= $this->registerInErrMessages('useridexists');
            $validData = FALSE;
        }      
        if($email_exists==TRUE){
            $errMsg .= $this->registerInErrMessages('emailexists');
            $validData = FALSE;
        }                        
        if ($validData==TRUE){
            if (trim($p["userpassword1"]) != trim($p["userpassword2"])){
                $validData = FALSE;
                $errMsg .= $this->registerInErrMessages('passwordmismatch');               
            }
        }

        if ($validData == TRUE){
            // SAVE PROFILE
            $res = $ci->person->saveProfileInfo($p); 
            $errMsg .= ($res['result'] == TRUE)? $this->registerInErrMessages('success') : $this->registerInErrMessages('fail');
            $emailresp = $this->registrationEmail($p);
        }
        $err['results'] = $errMsg;
        $ret = array_merge($err, $emailresp);
        return $ret;
    }
    
//---------------------------------------------------
//
//--------------------------------------------------- 
    public function registrationEmail($p){
        $ci = &get_instance();
        $conid = $ci->session->get('ogre_conid'); 
        $ci->convention->init($conid);
        $msg = '<p><strong>OGRe Account</strong><br /><br />';
        $msg .= 'Your OGRe Account information is as follows: <br /><br />';
        $msg .= 'Name: ' . urldecode($p["userfirstname"]) . ' ' . urldecode($p["userlastname"]) . '<br /><br />';
        $msg .= 'Email: ' . urldecode($p["user_email"]) . '<br /><br />';
        $msg .= 'Log In ID: ' . (trim($p["userloginid"])=="") ? urldecode($p["user_email"]) . '<br /><br />': urldecode($p["userloginid"]) . '<br /><br />';
        $msg .= 'Password: ' . urldecode($p["userpassword1"]) . '<br /><br />';
        $resp['from_eaddress']= $ci->convention->gamingcoordinatoremail;
        $resp['to_eaddress1'] = urldecode($p["user_email"]); 
        $resp['to_eaddress2'] = '';
        $resp['to_eaddress3'] = '';
        $resp['subject'] = 'OGRe Account Creation';
        $resp['body'] =  $msg;  
        $ret = $this->emailMessageArray($resp);
        return $resp;
    }
//***********************************
//
//***********************************
    public function activationForm($conid){
        $ci=&get_instance();
        $ret = '';
        $key = 'OGRE.ACTIVATION.MODE';           
        $activationmode = $ci->convention->getConfigKey($key, $conid);
        $action = site_url('ogrex/activationInX/0');
        $divid='activate-results';
        $instraction  = site_url('ogrex/getActInstructions'); 
        $fname = 'ogre-activation';
        $fname1 = 'ogre_activation1';
        switch (intval($activationmode)){
            case -1: // NOT SET
                $ret = '<p>Error, Activation Mode Not set</p>';
                break;
            case 0:  //AUTO
                $ret = '<p>Activation Mode: Autoactivate</p>';
                $ret .= $this->autoActivateMode($conid, $this->convention);
                break;
            case 1:  //PAYPAL ACTIVATION
                    $ci->convention->init($conid);
                    $ret .= '<div id="activate-account">';
                    $ret .= '<form action="" name="ogre-activation" id="ogre-activation">';
                    $ret .= '<h2>Activate Account</h2>'.'<p>(<a href="#" onclick="return get_instructions('."'".$instraction."','".'11'."'".');">Instructions</a>)</p>';
                    $ret .= '<p>If you received you code, type it and the accompanying email address above ..</p>';         
                    $ret .= '<label class="form-label" for="tranxid">Activation Code # (17 Digit, not case sensitive)</label>';
                    $ret .= '<input type="text" class="form-control" name="tranxid" id="tranxid" maxlength="17" />';      
                    $ret .= '<label class="form-label" for="emailaddress">Email Address Associated with the Registration Transaction</label>';
                    $ret .= '<input type="text" class="form-control" name="emailaddress" id="emailaddress"  />';
                    $ret .= '<div class="d-grid gap-2"><button class="btn btn-secondary" id="activate" name="activate" type="button" onclick="activateAccount('."'".$action."','".$divid."','".$fname."',false".');" >Activate</button></div>'; 
                    $ret .= '</form>';
                    $ret .= '</div>';
                break;
            case 2: //NOT CONNECTED
                $content = $this->getMiscContent('%REGISTRATION.NOT.CONNECTED%');
                $ret .= $content['content'];               
                break;
            default:
                 $ret = '<p>Error, Activation Mode Unknown</p>';
                break;
        }
 
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------        
    public function onsiteActivationForm(){
        $ci=&get_instance();
        $action = site_url('ogrex/activationInX/1');
        $divid='activate-results';
        $instraction  = site_url('ogrex/getActInstructions'); 
        $fname = 'onsite_ogre_activation';     
        $ret = '<div id="onsite-activate-account">';
        $ret .= '<h2>OnSite Activate Account</h2>';
        $ret .= '<p>(<a href="#" onclick="return get_instructions('."'".$instraction."','".'105'."'".');">Onsite Instructions</a>)</p>';
        $ret .= '<form name = "onsite_ogre_activation" id = "onsite_ogre_activation">';     
        $ret .= '<label class="form-label" for="tranxid_oniste">On Site Activation Code #</label>';
        $ret .= '<input type="text" class="form-control" name="tranxid_oniste" id="tranxid_oniste" />';  
        $ret .= '<div class="d-grid gap-2">';          
        $ret .= '<label class="form-label" for="tranx-id-oniste">Email Address on OGRe Account</label>';
        $ret .= '<input class="form-control" name="email-address" id="emailaddress_onsite" disabled="disabled" type="text" value="'.$ci->session->get('ogre_user_email') .'" />';
        $ret .= '</div>';        
        $ret .= '<div class="d-grid gap-2">';                
        $ret .= '<button class="btn btn-secondary" id="activate-onsite" name="activate" type="button" onclick="activateAccount('."'".$action."','".$divid."','".$fname."',true".');">Activate</button>';
        $ret .= '</div>';
        $ret .= '</form>'; 
        $ret .= '</div>';
        return $ret;
    }
//***********************************
//
//***********************************                
    public function activationInstruction($miscid, $conid){
        $ci=&get_instance();
        $ci->convention->init($conid);
        $acttext = $this->getMiscContent($miscid);
        $acttext['content'] = str_replace('%_CURRENT_CON_NAME_%', $ci->convention->name, $acttext['content']);
        $ret = $acttext['content']; 
        return $ret;                    
    }
                
//***********************************
//
//***********************************
    public function autoActivateMode($conid, $con){
        $ci = &get_instance();
        $this->cntlr = $ci->session->ogre_control;
        $ret = '';
        $title = "Click Here to Activate Your Account";
        $link =  anchor(site_url($this->cntlr .'/autoActivationIn'), $title,'https');
        $ret = '<table width="100%" border="0" cellspacing="15" cellpadding="15" align="center">';
        $ret .= '<tr valign="middle">';
        $ret .= '<td align="center"><span style="font-size:150%">';
        $ret .= $link;
        $ret .= '</span></td>';
        $ret .= '</tr>';
        $ret .= '</table>';                    

        return $ret;
    }
//***********************************
//
//***********************************
    public function transactionID(){
        $ret ='';
        $actdivid = 'act-code-results';
        $actaction = site_url('ogrex/transactionIdInX','https');
        $ret .= '<form action="" name="ogre_transactionid" id="ogre_transactionid">';
        $ret .= '<p><strong>Get Activation Code Here</strong></p>';
        $ret .= '<label for="get-email-address">Email Address on Registration Transaction or PayPal Account</label>';
        $ret .= '<input class="form-control form-control-sm m-1" name="get-email-address" id="get-email-address" type="text" />';
        $ret .= '<div class="d-grid gap-2" id="actcode-table-buttons-right">';                
        $ret .= '<button class="btn btn-secondary m-3" id="get-act-code-button" name="get-act-code-button" onclick="getActCode('."'".$actaction."','".$actdivid."'".');" >Get Activation Code</button>';
        $ret .= '</div></form>';
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getActivationCode($connected=FALSE){
        $ret = '<div class="getactcode" id="getactcode">';
        if ($connected === TRUE){
           $ci=&get_instance();
           $actdivid = 'act-code-results';
           $actaction = site_url('ogrex/transactionIdInX');
           $instraction  = site_url('ogrex/getActInstructions');
           $ret .= '<form name="ogre-transaction-id" id="ogre-transaction-id">';
           $ret .= '<p><strong>Get Your Activation Code Here</strong>';
           $ret .= ' (<a href="#" onclick="return get_instructions('."'".$instraction."','".'90'."'".');">Instructions</a>)</p>';
           $ret .= '<h2>Get/Retrieve Activation Code</h2>';
           $ret .= '<div class="form-group row">';
           $ret .= '<div class="col-lg">';          
           $ret .= '<label class="form-label" for="get-email-address">Email Address on Registration Transaction or PayPal Account</label>';
           $ret .= '<input type="text" class="form-control" name="get-email-address" id="get-email-address"  />';
           $ret .= '</div>'; 
           $ret .= '</div>';
           if ($ci->agent->isMobile()){
               $ret .= '<div class="d-grid gap-2"><button class="btn btn-secondary m-2" type="button" id="get-act-code-button" name="get-act-code-button" onclick="getActCode('."'".$actaction."','".$actdivid."'".');" >Get Code</button></div>';                 
           }
           else{
               $ret .= '<div class="d-grid gap-2"><button class="btn btn-secondary m-2" type="button" id="get-act-code-button" name="get-act-code-button" onclick="getActCode('."'".$actaction."','".$actdivid."'".');" >Get Code</button></div>';                    
           }
           $ret .= '</form>';  
        }
        $ret .= '</div>'; 
       return $ret;
    }
//***********************************
//
//***********************************
    public function processMiscContent($content){        
        $ci=&get_instance();
        $orgid = $ci->session->get('ogre_orgid');
        $sql = 'SELECT * FROM ogre_misccontent  WHERE ';
        $sql .= 'mc_orgid = ' . $orgid;
        $sql .= ' AND mc_code<>""';
        $query = $ci->db->query($sql);
        if($query->getNumRows() != 0){
            foreach ($query->getResult() as $row){
                $code = $row->mc_code;
                $content = str_replace($code, $row->mc_content, $content);
            }
        }
        return $content;                   
    }
//------------------------
//
//------------------------
    public function tabMenu($id, $sel){
        $ci=&get_instance();
        $qry = 'SELECT * FROM ogre_menus WHERE mnu_loc="TAB" AND mnu_display = 1 AND mnu_sub_id =' . $id . ' ORDER BY mnu_code';
        $ret = ' <div id="tabnav" align="center"><ul>';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $tabcode = substr($row->mnu_code, -1, 1);
                if ($sel == $tabcode){
                    $ret .= '<li id="current">' . anchor(site_url($row->mnu_href), $row->mnu_text,'title='.$row->mnu_notes,'https') . '</li>';
                }
                else{
                    $ret .= '<li>'  . anchor(site_url($row->mnu_href), $row->mnu_text,'title='.$row->mnu_notes ,'https'). '</li>';
                }
            }
        }
        return $ret . '</ul></div>';
    }
        
        
//---------------------------------------------------
//
//---------------------------------------------------
    public function getOgreNews($nid=0, $limit=1){
        $ci=&get_instance();
        $orgid = $ci->session->ogre_orgid;
        $ret = array();
        $i=0;
        $txt = '';
        $qry = 'SELECT ogre_news.* FROM ogre_news WHERE on_newsarchive = 0 AND on_orgid=' . $orgid;
        
        if (intval($nid) != 0){
            $qry .= ' AND  on_id=' . $nid;
        }                
        $qry .= ' ORDER BY  on_date DESC, on_id DESC ';
        $qry .= (intval($limit) != 0) ? ' LIMIT ' . $limit . ';' : ';';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $txt .= $row->on_newstext;
                $ret[$i]["post"] =  $this->buildEntry($row->on_newstitle, $row->on_date, safe_mailto($row->on_postedbyemail, $row->on_postedbyname), $txt, $row->on_newssubtitle);
                $ret[$i]["title"] = $row->on_newstitle;
                $ret[$i]["date"] = date('Y-m-d',strtotime($row->on_date));
                $txt = '';
                $i++;
            }   
        }else{
            $ret = NULL;
        }
        return $ret;
    }
            
//---------------------------------------------------
//
//---------------------------------------------------
    public function buildEntry($title, $postdate, $postedby, $content, $subtitle=''){
        $ret='';
        $ret .= '<div class="post">';
        $ret .= '<div class="post-bgtop">';
        $ret .= '<div class="post-bgbtm">'; 
        if (trim($postedby) != ''){
             $pdate = new Time($postdate);
             $ret .= '<p class="meta">';
             $ret .= '<span class="date">';
             $ret .= $pdate->format('F d, Y');
             $ret .= '</span>';
             $ret .= ' Posted by ';
             $ret .= $postedby;
             $ret .= '</p>';
        }                   

        $ret .= '<h2 class="title">';
        $ret .= '<a name="' . str_replace(" ", "_", $title) . '">';
        $ret .= $title;
        $ret .= '</a>';
        $ret .= '</h2>';

        $ret .= '<div class="entry">';
        if (trim($subtitle) != ''){
            $ret .= '<h2>'. $subtitle . '</h2>';
        }
        $ret .= $content;

        if (trim($postedby) != ''){
             $pdate = new Time($postdate);
             $ret .= '<p class="meta">';
             $ret .= '<span class="date">';
             $ret .= $pdate->format('F d, Y');
             $ret .= '</span>';
             $ret .= ' Posted by ';
             $ret .= $postedby;
             $ret .= '</p>';
        }                
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';                
        return $ret;
    }            
//---------------------------------------------------
//
//---------------------------------------------------           
    public function display_welcome(){
      $ci=&get_instance();
      $orgid = $ci->session->get('ogre_orgid');
      $welcome = $this->getMiscContent('%OGREWELCOME%');
      $ver = $this->getConfigKey('OGRE.VERSION', $orgid);
      $welcome['content'] = str_replace('%VERSION%', $ver, $welcome['content']);
      $ret ='<div id="ogrewelcome">';
      $ret .='<div id="ogrewelcome_content">';
      $ret .= (!$ci->agent->isMobile()) ? $welcome['content'] :  $this->mobileClean($welcome['content']);
      $ret .='</div>';
      $ret .='</div>'; 
      return $ret;  
    }  
//---------------------------------------------------
//
//---------------------------------------------------          
    public function mobileClean($txt){
        $txt = str_replace('<h2','<p><strong',$txt);
        $txt = str_replace('</h2','</strong></p',$txt);
        $txt = str_replace('<h1','<p><strong',$txt);
        $txt = str_replace('</h1','</strong></p',$txt);        
        $txt = str_replace('<h3','<p><strong',$txt);
        $txt = str_replace('</h3','</strong></p',$txt);     
        $txt = str_replace('<h4','<p><strong',$txt);
        $txt = str_replace('</h4','</strong></p',$txt);               
        return $txt;
    }
//---------------------------------------------------
//
//---------------------------------------------------           
    public function displayHomeEventTable($porgid=0, $pconid=0){
      $ci=&get_instance();
      $this->cntlr = $ci->session->ogre_control;
      $conid = ($pconid == 0) ? $ci->session->get('ogre_conid') : $pconid;
      $orgid = ($porgid == 0) ? $ci->session->get('ogre_orgid') : $porgid;

      $ret ='<div id="">';
      $txt = $this->getMiscContent('%HOMEEVENTTABLETEXT%');
      $ret .= '<h2>' . $txt['title'] . '</h2>' . $txt['content'];
      $ret .= '<table class="table">';
          $ret .= '<tr><th>';            
          $ret .= 'Go to Schedule';            
          $ret .= '</th>';
          $ret .= '</tr>'; 

      $qry = 'SELECT con_id,con_website,con_name,con_eventtype,con_loc_city,con_loc_state,con_start_date,con_end_date,(con_start_date >= NOW()) AS con_over FROM ogre_convention WHERE con_org_id = '.$orgid.' AND YEAR(con_start_date) >= YEAR(NOW())  ORDER BY con_start_date;';
      $query = $ci->db->query($qry); 
      if (($query->getNumRows()) > 0) {
          foreach ($query->getResult() as $row){
              $ret .= '<tr><td>';
              $sday = new Time($row->con_start_date);
              $eday = new Time($row->con_end_date); 
              $ret .= ($row->con_id === $conid) ? '<div id="currentcon" class="currentcon">' : '';
              $ret .= '<div class="d-grid gap-2">';                   
              $con = $row->con_name;	
              $dt = $sday->format('M d, Y') . (($row->con_eventtype!= 'day') ? ' to ' . $eday->format('M d, Y') :'');      
              $loc = $row->con_loc_city . ', ' . $row->con_loc_state;    
              $change = site_url('ogrex/setChangeCon');
              $schedule = site_url($this->cntlr .'/browseschedule/allx');
              $ret .= '<a href="#" class="btn btn-secondary" onclick="return changecon_goto('."'".$change."','".$schedule."',".$row->con_id.','.((!$ci->agent->isMobile()) ? '0.6' : '0.9').','.((!$ci->agent->isMobile()) ? '0.6' : '0.9').');"  >'.$con.' - '. $dt . ' -' . $loc . ' Schedule</a>';            
              $ret .='</div>';
              $ret .= ($row->con_id === $conid) ? '</div>' : '';                    
              $ret .= '</td></tr>';
          }
      }
      $ret .= '</td></tr>';
      $ret .= '</table>';      
      $ret .='</div>'; 
      return $ret;  
    }   
          
//---------------------------------------------------
//
//
//
//---------------------------------------------------           
    public function displayHomeOrgTable(){
        $ci=&get_instance();      
        $qry = 'SELECT org_id, org_name, org_ogrecontroller, org_configprefix FROM ogre_organization ORDER BY org_name;';
        $txt = $this->getMiscContent('%ORGANIZATIONHOME%');
        $ret =  '<h2>' . $txt['title'] . '</h2>' . $txt['content'];      
        $query = $ci->db->query($qry);
        $ret .= '<table class="table">';
        $ret .= '<tr><th>';  
        $ret .= 'Go to OGRe Site';            
        $ret .= '</th></tr>';
        if ($query->getNumRows() > 0) {
            foreach ($query->getResult() as $row){
              $curr_orgid = getenv($row->org_configprefix . 'ORGANIZATION.ID');  
              if($curr_orgid !== FALSE){
                $ret .= '<tr>';   
                $ret .= '<td>';     
                $ret .= '<div class="d-grid gap-2">';  
                $ret .= ' <a href="'. base_url($row->org_ogrecontroller) .'" class="btn btn-secondary">Go To'. $row->org_name . ' OGRe</a>';
                $ret .= '</div>';  
                $ret .= '</td>';                    
                $ret .= '</tr>';
              }
            }
        }
        $ret .= '</table>';      
        return $ret;  
    }  
    
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function displayNews($limit=1){
        $ci=&get_instance();
        $ret='';
        $rnews = array("news"=>'',"ncount"=>0);
        $news = $this->getOgreNews(0,$limit);                
        $i=0;

        if($news != NULL){
            $ret.='<div id="ogrenews">';
            $ret.='<div id="ogrenews_accordion">';            
            foreach ($news as $item){
                if(trim($item['post']) != ''){
                    $ret.='<h3>' . $item['title'] . '</h3>';
                    $ret.='<div>';
                    $ret .= (!$ci->agent->isMobile()) ? $item["post"] :  $this->mobileClean($item["post"]);
                    $ret.='</div>';                     
                }
                $i++;
            }
            $ret.='</div>';
            $ret.='</div>';            
            $rnews["news"] = $ret;
            $rnews["ncount"] = $i;          
        }
        else{
            $rnews["news"] = NULL;
            $rnews["ncount"] = 0;            
        }
        return $rnews;
    }
      
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function displayNewsBoot($limit=1){
        $ci=&get_instance();
        $ret='';
        $rnews = array("news"=>'',"ncount"=>0);
        $news = $this->getOgreNews(0,$limit);                
        $i=0;
        if($news != NULL){
            $ret.='<div id="accordion-news">';
            foreach ($news as $item){
                if(trim($item['post']) != ''){
                $ret.='<div class="card">';
                $ret.='<div class="card-header" id="heading-'.$i.'">';                      
                    $ret .= '<h5 class="mb-0">';
                    $ret .= '<button class="btn btn-link" data-toggle="collapse" data-target="#collapse-'.$i.'" aria-expanded="true" aria-controls="collapse-'.$i.'">';
                    $ret .= $item['title'];
                    $ret .= '</button>';
                    $ret .= '</h5>';
                    $ret .= '</div>';
                    $ret .= '<div id="collapse-'.$i.'" class="collapse '. (($i==0)? 'show' : '').'" aria-labelledby="heading-'.$i.'" data-parent="#accordion-news">';
                    $ret .= '<div class="card-body">';
                    $ret .= (!$ci->agent->isMobile()) ? $item["post"] :  $this->mobileClean($item["post"]);
                    $ret.='</div>'; 
                    $ret.='</div>'; 
                    $ret.='</div>';                     
                }
                $i++;
            }
            $ret.='</div>';   
            $rnews["news"] = $ret;
            $rnews["ncount"] = $i;          
        }
        else{
            $rnews["news"] = NULL;
            $rnews["ncount"] = 0;            
        }
        return $rnews;
      }      
//---------------------------------------------------
//
//---------------------------------------------------
    public function displayNewsOld($limit=1){
                $ret='';
                $news = $this->getOgreNews(0,$limit);                
                $i=0;
                $ret.='<div id="ogrenewscontent" style="display:none">';
                $ret.='<div style="text-align:right" id="closenews"><a href="#" onclick="return closeNews();">Close</a></div>';
                foreach ($news as $item){
                    if(trim($item['post']) != ''){
                        $ret.='<div class="ogrenewscontent" >';
                        $ret.= $item["post"];
                        $ret.='</div>';                     
                    }
                    $i++;
                }
                $ret.='</div>';
                $ret.='<div id="ogrenewsfooter">-</div>';
                
                $reth ='<div id="ogrenewsheader">';
                $reth.='<a href="#" onclick="return showNews();">';
                $reth.='OGRe News';
                $reth.='</a> - Latest: <em>' . $news[$i-1]['title'] . ' ' . $news[$i-1]['date'] .'</em>';
                $reth.='</div>';
                
                return $reth . $ret;
    }            
            
//---------------------------------------------------
// 
//---------------------------------------------------             
    public function emailMessageArray($email){  
            $ci=&get_instance();
            $ret = '';
            if(!is_array($email['to_eaddress1'])){
                $ret .= $this->emailMessage($email);
            }
            else{
                $x = count($to_eaddress1);
                for($i=0; $i<=$x-1; $i++){
                if(!isset($email['from_eaddress'][$i])){
                  $emaila['from_eaddress'] = $this->getConfigKey('OGReAdmin_Email_ReplyTo', $orgid);
                }                
                if(!isset($email['replyto_eaddress'][$i])) {
                    $emaila['replyto_eaddress'] = $this->getConfigKey('OGReAdmin_Email_ReplyTo', $orgid);
                }            
                if(isset($email['to_eaddress1'][$i])){
                    $emaila['to_eaddress1'] = $email['to_eaddress1'][$i];    
                    $emaila['subject'] = $email['subject'][$i];            
                    $emaila['body'] = txt2html($email['body'][$i]);                     
                    if(isset($email['to_eaddress2'][$i]) && ($email['to_eaddress2'][$i] != '')){
                            $emaila['to_eaddress2'] = $email['to_eaddress2'][$i];  
                    }
                    if(isset($email['to_eaddress3'][$i]) && ($email['to_eaddress3'][$i] != '')){
                            $emaila['to_eaddress3'] = $email['to_eaddress3'][$i];
                    }
                    if(isset($email['cc_eaddress1'][$i]) && ($email['cc_eaddress1'][$i] != '')){
                            $emaila['cc_eaddress1'] = $email['cc_eaddress1'][$i];  
                    }
                    if(isset($email['bcc_eaddress1'][$i]) && ($email['bcc_eaddress1'][$i] != '')){
                            $emaila['bcc_eaddress1'] = $email['bcc_eaddress1'][$i];  
                    }
                    $emaila['sent_errmsg'] = ((!isset($email['sent_errmsg'][$i])) ? " Mail has not been sent. " : $email['sent_errmsg'][$i]);
                    $emaila['sent_msg'] = ((!isset($email['sent_msg'][$i])) ? " Mail has been sent. " : $email['sent_msg'][$i]);
                    // $ret .= $this->emailMessage($emaila);
                }        
                
             } //LOOPS
        }
        return $ret;
    }          
            
//---------------------------------------------------
//  ARRAY MUST CONTAIN
//  $email['to_eaddress1']
//  $email['from_eaddress']
//  $email['subject']
//  $email['body']
//  CAN CONTAIN
//  $email['to_eaddress2']
//  $email['to_eaddress3']
//  $email['cc_eaddress1']
//  $email['bcc_eaddress1']
//  $email['replyto_eaddress']
//  
//---------------------------------------------------             
    public function emailMessage($email){
            $ci = &get_instance();
            $ret = TRUE;
            $orgid = getenv('organization_id');
            if (isset($email['from_eaddress'])){
                $ci->email->setFrom($email['from_eaddress']);
            }else{
                $ci->email->setFrom($this->getConfigKey('OGReAdmin_Email_ReplyTo', $orgid));
            }
            if (isset($email['to_eaddress3']) && $email['to_eaddress3'] !== ""){
                $ci->email->setTo($email['to_eaddress1'],$email['to_eaddress2'],$email['to_eaddress3']);
            }elseif (isset($email['to_eaddress2']) && $email['to_eaddress2'] !== ""){
                $ci->email->setTo($email['to_eaddress1'],$email['to_eaddress2']);
            }else
            {
                $ci->email->setTo($email['to_eaddress1']);
            }
            
            if (isset($email['cc_eaddress1'])){
                $ci->email->setCC($email['cc_eaddress1']);
            }
            if (isset($email['bcc_eaddress1'])){
                $ci->email->setBCC($email['bcc_eaddress1']);
            }
            if (isset($email['replyto_eaddress'])){
                $ci->email->reply_to($email['replyto_eaddress']);
            }            
            $ci->email->setSubject($email['subject']);
            $ci->email->setMessage( $email['body']);
            $snt = $ci->email->send();
            if (!$snt) {
                $ret = ($ci->email->printDebugger()) . (isset($email['sent_errmsg']) ? $email['sent_errmsg'] : "");
            }             
            else{
                $ret = ((isset($email['sent_msg'])) ? $email['sent_msg'] : "Email Sent.");
            }
            return $ret;              
          }  
//---------------------------------------------------
//
//
//
//---------------------------------------------------             
//        public function getBulletinTicker(){
//            $ci = &get_instance();
//            $orgid = $ci->session->get('ogre_orgid');  
//            $conid = $ci->session->get('ogre_conid');  
//            $ret = '';
//            $sql = 'SELECT * FROM ogre_misccontent  WHERE ';
//            $sql .= ' mc_code= "%SCHEDULE_HEADER%"';
//            $sql .= ' AND mc_orgid = ' . $orgid;
//            $i=1;
//            $cutoff = $this->getConGamingInfoKey($conid,'con_gaming_reg_close_date');
//            $cutoff_date = new Time($cutoff);
//            $end_date = $this->getConGamingInfoKey($conid,'con_end_date');
//            $close_date = new Time($end_date);            
//            $start_date = $this->getConGamingInfoKey($conid,'con_gaming_reg_open_date');
//            $open_date = new Time($start_date);
//            $grclosed = $ci->convention->gameRegIsClosed($conid);
//            $conname = $ci->convention->name;
//            $query = $ci->db->query($sql);
//            $ret .= '<div class="col-lg">';
//            $ret .= '<div class="tickercontainer" style="width:99%; margin-left:10px;">';
//            $ret .= '<div class="mask">';
//            $ret .= '<ul id="webticker">';                        
//            if($query->getNumRows() != 0){
//                switch ($grclosed){
//                    case -1: //BEFOPRE
//                        $ret .= '<li id="item"'.$i.'>'.$conname.' Online Gaming Registration Opens '.$open_date->format('F d, Y').'.</li>';
//                        break;
//                    case 0: // OPEN
//                        $ret .= '<li id="item"'.$i.'>'.$conname.' Online Gaming Registation Is Open. During the conevntion.';
//                        $ret .= ' On-Site Registration will be available at the con until 6 pm Saturday night. ';
//                        $ret .= ' You can also use OGRe all weekend through a laptop, tablet or phone.</li>';
//                        break;
//                    case 1: // CLOSED
//                        $keepOPopen = $this->getConfigKey('KEEP.OP.OPEN', $orgid); 
//                        $op = ($keepOPopen==='1')?'(Organized Play Games Remain Open)' :'';
//                        $ret .= '<li id="item"'.$i.'>'.$conname.' Online Gaming Registration is Closed ';
//                        $ret .= '</li>';
//                        
//                        break;
//                }
//                $i++;
//                foreach ($query->getResult() as $row){
//                     $ret .= '<li id="item"'.$i.'>' . strip_tags($row->mc_content) . '</li>';
//                     $i++;
//                }
//            }
//            $ret .= '</ul>';
//            $ret .= '<span class="tickeroverlay-left">&nbsp;</span>';
//            $ret .= '<span class="tickeroverlay-right">&nbsp;</span>';           
//            $ret .= '</div>';
//            $ret .= '</div>';
//            $ret .= '</div>';
//            return $ret;
//        }    
        
//---------------------------------------------------
//
//---------------------------------------------------             
    public function getBulletinPost(){
            $ci = &get_instance();
            $orgid = $ci->session->get('ogre_orgid');  
            $conid = $ci->session->get('ogre_conid');  
            $ret = '';
            $i=1;
            $cutoff = $this->getConGamingInfoKey($conid,'con_gaming_reg_close_date');
            $cutoff_date = new Time($cutoff);
            $end_date = $this->getConGamingInfoKey($conid,'con_end_date');
            $close_date = new Time($end_date);            
            $start_date = $this->getConGamingInfoKey($conid,'con_gaming_reg_open_date');
            $open_date = new Time($start_date);
            $grclosed = $ci->convention->gameRegIsClosed($conid);
            $conname = $ci->convention->name;
            $sql = 'SELECT * FROM ogre_misccontent  WHERE mc_code= "%SCHEDULE_HEADER%" AND mc_orgid = ' . $orgid;
            $query = $ci->db->query($sql);                           
            if($query->getNumRows() != 0){
                switch ($grclosed){
                    case -1: //BEFOPRE
                        $ret .= '<p id="item"'.$i.'>'.$conname.' Online Gaming Registration Opens '.$open_date->format('F d, Y').'.</p>';
                        break;
                    case 0: // OPEN
                        $ret .= '<p id="item"'.$i.'>'.$conname.' '.$this->getMiscContent('%%BULLETINGAMEREGTEXT1%%', $conid, TRUE).'</p>';
                        break;
                    case 1: // CLOSED
                        $keepOPopen = $this->getConfigKey('KEEP.OP.OPEN', $orgid); 
                        $op = ($keepOPopen==='1')?'(Organized Play Games Remain Open)' :'';
                        $ret .= '<p id="item"'.$i.'>'.$conname.' Online Gaming Registration is Closed ';
                        $ret .= '</p>';
                        
                        break;
                }
                $i++;
                foreach ($query->getResult() as $row){
                     $ret .= '<p id="item"'.$i.'>' . strip_tags($row->mc_content) . '</p>';
                     $i++;
                }
                
            }
            return $ret;
        }         
        
//---------------------------------------------------
//
//---------------------------------------------------             
        public function getChangeLink(){
            $ci = &get_instance();
            $action = site_url('ogrex/getChangeConList');
            $change = site_url('ogrex/setChangeCon');
            $cntlr = (($ci->organization->ogrecontroller==NULL) ? '' : $ci->organization->ogrecontroller); 
            $ret = '<button id="changecon" onclick="return changecon('."'".$action."'".','."'".$change."'".','.((!$ci->agent->isMobile()) ? '0.6' : '0.9').','.((!$ci->agent->isMobile()) ? '0.6' : '0.9').",'".site_url($cntlr)."'".');">Change Con View</button>';
            return $ret;
        }     
//-------------------------------------------
//
//
//
//-------------------------------------------
    public function changeConList($orgid, $conid=0){
        $ret = '';
        $txt = $this->getMiscContent('%CHANGECONTXT%',0,TRUE);
        $ret .= '<form>';
        $ret .= '<fieldset>';
        $ret .= '<div class="form-group row">';
        $ret .= '<div class="col-lg-12">';
        $ret .= '<div class="changeconlist_center">';
        $ret .= '<h4>What event do you wish to view?</h4>';
        $ret .= '</div>';
        $ret .=  $txt;
        $ret .= '</div>';
        $ret .= '<div class="col-lg-12">';
        $ret .= '<div class="changeconlist_center">';       
        $ret .=  $this->selectChangeConList($orgid, $conid);     
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</fieldset>';
        $ret .= '</form>';
        return $ret;
    }
    
//-------------------------------------------
//
//-------------------------------------------
    public function selectChangeConList($orgid=0, $cid=0){
        $ci=&get_instance();
        $admin = FALSE;
        date_default_timezone_set("America/New_York");
        $logged_in = $ci->session->get('ogre_logged_in');
        $access = $ci->session->get('ogre_user_accesslevel_'. $orgid);
        $ci->organization->init($orgid);
        $prefx = ($ci->organization->configprefix==NULL) ? '' : $ci->organization->configprefix;
        if($logged_in===TRUE){
            $admin = ($access >= ADMIN) ? TRUE : FALSE;
        }
        $qry = 'SELECT * FROM ogre_convention ';
        $qry .= ' WHERE con_org_id = ' . $orgid;
        if ($admin === FALSE){
            $qry .= ' AND (con_start_date >= NOW()) OR (con_id ='. $cid .') ';
        }
        $cid2 = getenv($prefx .'CONVENTION.ID'); 
        $qry .= ' OR con_id = '. $cid2 .' ';
        $qry .= ' ORDER BY con_start_date;';              
        $query = $ci->db->query($qry);                      
        $ret = '<select class="form-control" name="changeconlist" id="changeconlist" size="1">';  
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $ret .= ($cid == $row->con_id) ? '<option value = "' . $row->con_id . '" selected="selected">' . $row->con_name  . ' </option>' : '<option value = "' . $row->con_id .  '">' . $row->con_name  . '</option>';            
            }
        }
        $ret .= '</select>';
        return $ret;
    } 
//-------------------------------------------
//
//-------------------------------------------  
    public function pdf_icon(){
        $image_properties = array('src' =>'images/pdf.png', 'width' => '30' ); 
        $ret = '<span id="pdficon">' . img($image_properties) . '</span>';
        return $ret;
    }   
    
//---------------------------------------------------
//
//---------------------------------------------------      
    public function grant_access($minAccessLevel=10){
        $ci=&get_instance();        
        $access = FALSE;
        $orgid = $ci->session->get('ogre_orgid');
        $loggedin = $ci->session->get('ogre_logged_in');
        $accessrating= $ci->session->get('ogre_user_accesslevel_' . $orgid);
        if (intval($minAccessLevel) > 0){
            $access = (intval($accessrating) >= intval($minAccessLevel)) ? TRUE : FALSE;
        }else{
            $access = TRUE;
        }
        return $loggedin && $access;
    }
//---------------------------------------------------
//
//---------------------------------------------------        
    public function downloadCSV($sql,$filename){
        $ci=&get_instance(); 
         // file name 
        $filename = $filename.'.csv'; 
        header("Content-Description: File Transfer"); 
        header("Content-Disposition: attachment; filename=$filename"); 
        header("Content-Type: application/csv; ");
         // file creation 
        $file = fopen('php://output', 'w');
        $header = array("START-CODE","START-DAY-TIME","ID","DAY","TIME","ROOM","TABLE","GAME","SCENARIO","AFFILIATION","TYPE","MAX-PLAYERS"); 
        fputcsv($file, $header);
        $query = $ci->db->query($sql);
        if ($query->getNumRows() > 0){
            foreach ($query->getResultArray() as $key=>$line){ 
                fputcsv($file,$line); 
            }
        }
         fclose($file); 
    }
//---------------------------------------------------
//
//---------------------------------------------------         
    public function bootAlert($type="alert-warning" , $id=0, $title='', $text=''){
        $ret = '<div class="alert alert-dismissible fade show '.$type.'">';
        $ret .= '<h4 id="'.$id.'title" class="alert-heading">'.$title.'</h4>';
        $ret .= '<p id="'.$id.'text" class="mb-0">'.$text.'</p>';
        $ret .= '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
        $ret .= '</div>'; 
        return $ret;
  }
//---------------------------------------------------
//
//---------------------------------------------------         
    public function bootCard($type, $text='', $id='', $title='', $stitle='', $footer='' ){
        $ret = '<div class="card '.$type.' m-2"'.($id !='' ? 'id="'.$id.'" ':'').' >';
        $ret .= '<div class="card-body">';
        $ret .= (($title!='') ? '<h4 class="card-title">'.$title.'</h4>':'');
        $ret .= (($stitle!='') ? '<h6 class="card-subtitle mb-2 text-muted">'.$stitle.'</h6>':'');
        $ret .= (($text!='') ? '<p class="card-text">'.$text.'</p>':'');
        $ret .= '</div>';
        if(trim($footer) !== ''){
            $ret .= '<div class="card-footer">';
            $ret .= $footer;
            $ret .= '</div>';        
        }
        $ret .= '</div>';
        return $ret;
  }  

//---------------------------------------------------
//
//---------------------------------------------------         
    public function bootListGroup($type, $text='', $id=0, $title='', $stitle='' ){      
        $ret = '<div class="list-group '.$type.' my-1">';
        foreach ($text as $item){
            $ret .= '<div class="list-group-item list-group-item-action">';
            $ret .= $item;
            $ret .= '</div>';
        }
        $ret .= '</div>';
        return $ret;
  }    
  //---------------------------------------------------
  //
  //---------------------------------------------------         
    public function bootBadgePill($text, $type='', $id=0){      
        $ret = '<span style="font-size:120%" class="badge rounded-pill '.(($type=='')?' bg-primary' : $type).'">';
        $ret .= $text;
        $ret .= '</spam>';
        return $ret;
  }   
  //---------------------------------------------------
  //
  //---------------------------------------------------         
    public function bootBadge($text, $type='', $id=0){      
        $ret = '<span style="font-size:120%" class="badge '.(($type=='')?' bg-primary' : $type).'">';
        $ret .= $text;
        $ret .= '</span>';
        return $ret;
  }   
  //---------------------------------------------------
  //
  //---------------------------------------------------  
  public function dateOfTheWeek($d){
      $days = array('Sunday', 'Monday', 'Tuesday', 'Wednesday','Thursday','Friday', 'Saturday');
      return $days[$d];
  }
//---------------------------------------------------
//
//---------------------------------------------------               
    public function commentCard($text='Test', $name='NAME', $date=NULL, $rdate=NULL){    
        $ret = '';
        $cdate = strtotime($date);
        $rrdate = strtotime($rdate);
        $ret .= '<div class="card mb-2">';
        $ret .= '<div class="card-body">';
        $ret .= $name . ': <em>' .$text . '</em>';
        $ret .= '<div class="text-end">';
        $ret .= (($date !== NULL)? 'Created: ' . date('M-d-Y', $cdate) : '') . '<br />';
        $ret .= (($rdate !== NULL)? 'Read: ' . date('M-d-Y', $rrdate) : '');
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';
        return $ret;
    }
//---------------------------------------------------
// 
//---------------------------------------------------       
    public function err_log($msg){
        $ci=&get_instance();
        $qry='INSERT INTO ogre_errlog (log_date, log_text) ';
        $qry .= ' VALUES (NOW(), "';
        $qry .= quotes_to_entities($msg) . '"';
        $qry .= ');';

        $ci->db->query($qry);
        return ($ci->db->affectedRows() > 0)? TRUE:FALSE;
    }

//---------------------------------------------------
// 
//---------------------------------------------------       
    public function getOsiteActivationForm($conid){
        $ret = "Test";
        $ci=&get_instance();
        $ret='';
        $ret .= '<h3>On Site Activation</h3>';
        $ret .= '<div id="act-result" role="alert"></div>';
        $ret .= '<form id="onsite-activation-form" name="onsite-activation-form" action="' . site_url('ogrex/onsiteActIn','https') . '">';
        $ret .= '<label for="pnamefirst">First Name</label>';
        $ret .= '<input class="form-control form-control-sm" type="text" name="pnamefirst" id="pnamefirst">';
        $ret .= '<label for="pnamelast">Last Name</label>';
        $ret .= '<input class="form-control form-control-sm" type="text" name="pnamelast" id="pnamelast">';
        $ret .= '<label for="pemail">Email Address</label>';
        $ret .= '<input class="form-control form-control-sm" type="text" name="pemail" id="pemail">';
        $ret .= '<div class="d-grid gap-2">';
        $ret .= '<button class="btn btn-secondary m-1" type="button" onclick="activateOnsite('.$conid.');">Activate</div>';
        $ret .= '</form>     ';        
        return $ret;
    }    
}