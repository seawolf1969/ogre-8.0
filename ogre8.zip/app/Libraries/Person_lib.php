<?php 
namespace App\Libraries;
use CodeIgniter\I18n\Time;

class Person_lib{
//***********************************
//
//***********************************
    public function getUserPassword($email){
        $ci = &get_instance();
        $qry = 'SELECT user_index_id, user_email, user_login_id FROM ogre_users WHERE user_email = "' . $email . '";';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $new_user_password = $this->generatePassword($row->user_index_id);
                $ret['password'] = $new_user_password;
                $ret['userid'] = (trim($row->user_login_id)!='')?$row->user_login_id:$row->user_email;
                $ret['error'] = '';
            }
        }
        else{
            $ret['userid'] = 'ERROR! NO USER ID ASSOCIATED TO THIS EMAIL.  YOU MUST REGISTER.';
            $ret['password']='ERROR! NO PASSWORD';
            $ret['error'] = 'ERROR';
        }  
        return $ret;
     }
//-----------------------------------
//
//-----------------------------------     
    public function generatePassword($id=0){
        $ci = &get_instance();
        $pw = random_string('alnum',8);
        if($id !== 0){
            $ret = $ci->person->updatePassword($id, $pw);
        }
        return $pw;
    }
//-----------------------------------
//
//-----------------------------------
    public function getPersonEmail($prid){
        $ci = &get_instance();
        $qry = 'SELECT * FROM ogre_users WHERE user_index_id = ' . $prid . ';';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){ 
                $ret = $row->user_email;
            }
        }
        return $ret; 	 
    }
    //***********************************
    //
    //
    //
    //***********************************
    public function getMyProfile($conid=0){
        $ci = &get_instance();
        $orgid = $ci->session->ogre_orgid;
        if ($conid == 0){
            $conid = $ci->session->ogre_conid; 
        }
        $curruserid = $ci->session->ogre_user_ID;
        if ($ci->session->ogre_user_ID != FALSE){
            $ret = $ci->person->getUserProfile($curruserid);
        }
        else{
            $ret = "Access Denied. Must be Logged in.";
        }
        return $ret;
    }
    //***********************************
    //
    //***********************************
    public function getMySchedule($print, $gpopen){
        $ci = &get_instance();
        $orgid = $ci->session->ogre_orgid;
        $conid = $ci->session->ogre_conid;              
        $curruserid = $ci->session->userdata('ogre_user_ID');
        $ci->person->get($curruserid);          
        $ret = '';        
        $ret .= $ci->person->displayPlayerSchedule($print, $gpopen);
        $ret .= $ci->person->displayPlayerRequests();
        return $ret;
    }
    //***********************************
    //
    //
    //
    //***********************************
    public function getMySchedulex($print, $gpopen){
        $ci = &get_instance();
        $conid = $ci->session->ogre_conid;              
        $curruserid = $ci->session->userdata('ogre_user_ID');
        $ci->person->get($curruserid);
        $ret = '';
        $ret .= '<div id="my-schedule-view" style="display: block;">';
        $ret .= $ci->person->displayPlayerSchedulex($print, 0, $gpopen);
        $ret .= '</div>';
        $ret .= '<div id="myproposalview" style="display: none;">';
        $ret .= $ci->person->displayPlayerRequests();
        $ret .= '</div>';
        return $ret;
    }    
 
    
}
?>
