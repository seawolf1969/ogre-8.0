<?php
namespace App\Libraries;
use CodeIgniter\I18n\Time;

class Rpga_lib
{
    //------------------------
    //
    //
    //
    //------------------------
    public function rpga_schedule_title_old($aff, $late=0, $print=FALSE, $ajax=FALSE){
        $ci = &get_instance();    
        $conid = $ci->session->ogre_conid;  
        $orgid = $ci->session->ogre_orgid;
        $ret = '';
        $oplink = ($ajax==TRUE ? 'ogrex/browseScheduleX/rpga' : 'ogre/browseschedule/rpga');
        $ci->convention->init($conid);
        $con_name = $ci->convention->name;        
        $ret .= '<div class="op_schedule_title">';
        $ret .= '<h1>';
        $ret .= $con_name;
        $ret .= '</h1>';

        $ret .= '<h2>' . ($late == 1 ? 'Late Night ' : '') .(($aff=='all')? 'Organized Play ':$aff) . ' Schedule</h2>';
        $hdr = $ci->ogre_lib->getMiscContent('%SCHEDULE_HEADER%', $conid);

        if(is_array($hdr)){
            $ret .= '<div id="searchheadermessage"><p><span id="searchhdrmsgtitle">Latest Bulletin:</span>' . $hdr['content'] . '</p></div>';    
        }        
//        if ($late == 1)
//        {
//            $ret .= '<h3>Late Night Schedule</h3>';
//        }
        $ret .= '</div>';
        $ret .= '<table class="op_schedule_title_table">';
        $ret .= '<tr>';
        $ret .= '<td>';

        if ($print != TRUE){          
            $ret .= '<p>';
            if($ajax == TRUE){
                $ret .= '<div class="op_affiliationmenu" id="op_affiliationmenu">';
                $ret .= $this->affiliation_menux($conid, $late, $aff, $oplink);
                $ret .= '</div>';
            }
            $ret .= '</p>';
        }

        $ret .= '</td>';
        $ret .= '</tr>';
        $ret .= '<tr>';
        $ret .= '<td>';        
        $ret .= $this->dayoftheweekmenu($conid, $late, $aff, $ajax);
        $ret .= '</td>';
        $ret .= '</tr>';        
        $ret .= '</table>';
        $image_properties = array('src' =>'images/ajax-loader.gif','alt'=>'ajax-loader.gif'); 
        $ret .= '<div id="wait" style="display: none">' . img($image_properties) . '</div>';         
        $ret .= '<div id="schedule-view"><p>Select a tab above to view a organized play schedule.</p>';
        $ret .= '</div>';
        return $ret;        
    }
    
    //------------------------
    //
    //
    //
    //------------------------    
    public function rpga_schedule_title($aff='0', $late=0, $print=FALSE){
        $ci = &get_instance();
        $conid = $ci->session->ogre_conid;  
        $orgid = $ci->session->ogre_orgid;
        $ret = '';
        $oplink = 'ogrex/browseScheduleX/rpga';
        $ci->convention->init($conid);
        $con_name = $ci->convention->name;                
        $ret .= '<table class="op_schedule_title_table">';
        $ret .= '<tr>';
        $ret .= '<td>';
        if ($print != TRUE){
            $ret .= '<p><strong></strong></p>';
            $ret .= '<p>' . $ci->ogre_lib->getMiscContent('%SELECTAFFILIATION%',0,TRUE).'</p>';
            $ret .= '<p>';
            
            $ret .= $this->affiliation_menux($conid, $late, $aff, $oplink);
            $image_properties = array('src' =>'images/ajax-loader.gif','alt'=>'ajax-loader.gif'); 
            $ret .= '&nbsp;&nbsp;<span id="wait3" style="display: none">' . img($image_properties) . '</span>';                  
            $ret .= '</p>';
        }
       
        $ret .= '</td>';
        $ret .= '</tr>';      
        $ret .= '</table>';  
        $ret .= $this->dayoftheweekmenu($conid, $late, $aff);
//        $ret .= '<div class="table-responsive">';
        $ret .= '<div id="schedule-view_op">';
        $ret .= '</div>'; 
//        $ret .= '</div>'; 
        return $ret;        
    }
    //------------------------
    //
    //
    //
    //------------------------
    public function dayoftheweekmenu($conid, $late, $aff){
        $ret = '';
        $daystr='';
        $ret .= '<div id="op_daymenu" style="display:none">';       
        $day_array = $this->build_rpga_day_array($conid, $late);
        $daystr = implode(',', $day_array);
        $ret .= '<form action="">';
        $ret .= '<div class="toggle-btn-grp cssonly">';
        $ret .= '<div>';
        $ret .= '<input type="radio" name="daysofweek" onclick="weekday('."'".'all'."',"."'". $daystr . "'".')"></input>';
        $ret .= '<label onclick="" class="toggle-btn">';
        $ret .= 'All';
        $ret .= '</label>';
        $ret .= '</div>';
        foreach ($day_array as $gsday){
            $ret .= '<div>';  
            $ret .= '<input type="radio" name="daysofweek" onclick="weekday('."'".$gsday."',"."'". $daystr . "'".')"></input>';
            $ret .='<label onclick="" class="toggle-btn">';
            $ret .= $gsday;
            $ret .='</label>';
            $ret .= '</div>';   
        }        
        $ret .= '</div>';
        $ret .= '</form>';
        $ret .= '</div>';
        return $ret;
    }
    
    //------------------------
    //
    //
    //
    //------------------------
    public function opSchedule($aff="", $late=0, $day='Friday', $print=FALSE, $showhdr=TRUE, $ajax=FALSE, $slotlengths=0){
        $ci=&get_instance();
        $conid = $ci->session->ogre_conid;  
        $orgid = $ci->session->ogre_orgid;
        $pid = $ci->session->userdata('ogre_user_ID');
        $accessrating=0;
        $verified=0;
        $em='';
        $ret = $this->gen_row_enum($late, $conid) && $this->genSlotEnum($late, $conid);
        if ($pid != 0){
            $accessrating = $ci->session->userdata('ogre_user_accesslevel_' . $orgid);
            $verified = $ci->session->userdata('ogre_user_activated_' . $conid);
            $em = $ci->session->userdata('ogre_user_email');
        }  
        $ret = '';
        if ($slotlengths == 0) {
            $slotlengths = $this->getSlotLengths($aff, $conid);            
        } else {
            $slotlengths[0] = 4;
        }

        if ($day == '') {
            $day_array = $this->build_rpga_day_array($conid, $late);
        } else {
            $day_array['1'] = $day;
        }

        foreach ($day_array as $gsday){
            $ret .=  ($day == '') ? '<div id="'.trim($gsday).'" style="display:block">' : '';
            foreach ($slotlengths as $slotlen){
                    $maxrnum = $this->get_max_rnum($conid, 0, $aff, $gsday, $slotlen);
                    $maxcolnum = $ci->convention->getMaxSlots($slotlen);
                    $slot_codes = $this->buildOPSlotArray($conid, $slotlen, $late, $day);
                    $qry_rpga = 'SELECT ogre_gameschedule.gs_id';
                    $qry_rpga .= ' FROM (ogre_preregistergamelist ';
                    $qry_rpga .= ' RIGHT JOIN ogre_gameschedule ';
                    $qry_rpga .= ' ON ogre_preregistergamelist.pgl_gs_id = ogre_gameschedule.gs_id) ';
                    $qry_rpga .= ' LEFT JOIN ogre_rpga_game_setup ';
                    $qry_rpga .= ' ON ogre_gameschedule.gs_id = ogre_rpga_game_setup.rgs_gs_id ';
                    $qry_rpga .= ' WHERE ogre_gameschedule.gs_cancelled = 0 ';
                    $qry_rpga .= ' AND ogre_rpga_game_setup.rgs_active = 1 ';
                    $qry_rpga .= ' AND ogre_gameschedule.gs_game_title <> ""  ';
                    $qry_rpga .= ' AND ogre_gameschedule.gs_mmrpgFlag = 1 ';
                    $qry_rpga .= ' AND ogre_gameschedule.gs_late_night = ' . $late;
                    $qry_rpga .= ' AND ogre_gameschedule.gs_slot_length = ' .$slotlen;
                    $qry_rpga .= ' AND gs_convention_id = ' .$conid;
                    $qry_rpga .= ($aff!='') ? ' AND gs_affiliation = "' . $aff . '"' : '';
                    $qry_rpga .= ($gsday != '') ?  " AND gs_slot_day = '" . $gsday . "'" : '';
                    $qry_rpga .= ' ORDER BY  ogre_gameschedule.gs_slot_day, ';
                    $qry_rpga .= 'ogre_gameschedule.gs_affiliation, ';
                    $qry_rpga .= 'ogre_gameschedule.gs_slot_length, ';
                    $qry_rpga .= 'ogre_gameschedule.gs_game_title;';
                    $query = $ci->db->query($qry_rpga);           

                    $nosched = ($query->getNumRows() == 0)? TRUE:FALSE;                                
                    $d = 1;
                    $ret .= '<table id="optable_outer" class="table">';
                    $ret .= '<tr>';
                    $ret .= '<td class="op_padding">';
                    if ($d > 1){
                        $ret .= '</table>';                  
                        $ret .= '</td>';
                        $ret .= '</tr>';               
                        $ret .= '<tr>';                    
                        $ret .= '<td class="op_padding">';
                    }
                    if ($nosched != TRUE){                
                        $ret .= '<table ';
                        $ret .= (!$ci->agent->isMobile()) ? ' class="optable"' : ' class="optable_mobile"';
                        $ret .= '>';

                        $ret .= $this->build_rpga_header($gsday, $slot_codes, $gsday, $late, $aff, $showhdr);
                        for ($i=1;$i<=$maxrnum;$i++){
                         for ($j=1;$j<=$maxcolnum;$j++){   
                                $ret .= $this->build_rpga_cell($i, $j, $aff, $gsday, $late, $slotlen, $accessrating, $verified, $em, $print, $ajax);
                            }                        
                        }
                        $d++;                   
                        $ret .= '</table>';
                    }
                    $ret .= '</td>';
                    $ret .= '</tr>';
                    $ret .= '</table>';
            }
            if ($day == ''){
                $ret .='</div>';
            }
        }
        return $ret;
    }
//------------------------
//
//------------------------    
    private function opBuildScheduleSQL($conid, $aff='', $slotlen=0, $day='', $start='', $late='', $scenid=0){
        $qry = 'SELECT ogre_gameschedule.* ';
        $qry .= ' FROM (ogre_preregistergamelist ';
        $qry .= ' RIGHT JOIN ogre_gameschedule ';
        $qry .= ' ON ogre_preregistergamelist.pgl_gs_id = ogre_gameschedule.gs_id) ';
        $qry .= ' LEFT JOIN ogre_rpga_game_setup ';
        $qry .= ' ON ogre_gameschedule.gs_id = ogre_rpga_game_setup.rgs_gs_id ';
        $qry .= ' WHERE ogre_gameschedule.gs_cancelled = 0 ';
        $qry .= ' AND ogre_rpga_game_setup.rgs_active = 1 ';
        $qry .= ' AND ogre_gameschedule.gs_mmrpgFlag = 1 ';
        $qry .= ' AND gs_convention_id = ' .$conid;
        $qry .= ($late != '') ? ' AND ogre_gameschedule.gs_late_night = ' . $late : '';
        $qry .= ($slotlen != 0) ?  ' AND ogre_gameschedule.gs_slot_length = ' . $slotlen : '';
        $qry .= ($start != '') ?  ' AND ogre_gameschedule.gs_slot_start_time = "' . $start . '"': '';
        $qry .= ($scenid != 0) ?  ' AND ogre_rpga_game_setup.rgs_scenario_id = ' . $scenid : '';
        $qry .= ($aff!='') ? ' AND gs_affiliation = "' . $aff . '"' : '';
        $qry .= ($day != '') ?  " AND gs_slot_day = '" . $day . "'" : '';
        $qry .= ' ORDER BY  ogre_gameschedule.gs_slot_code, ';
        $qry .= 'ogre_gameschedule.gs_game_title;';

        return $qry;
    }
//------------------------
//
//------------------------
    public function rpga_schedule_boot($aff="", $late=0, $day='Friday', $print=FALSE, $showhdr=TRUE, $ajax=FALSE, $slotlengths=0){
        $ci=&get_instance();
        $conid = $ci->session->ogre_conid;  
        $orgid = $ci->session->ogre_orgid;
        $pid = $ci->session->userdata('ogre_user_ID');
        $accessrating = 0;
        $verified = 0;
        $em = '';
        $ret = '';
        if ($pid != 0){
            $accessrating = $ci->session->userdata('ogre_user_accesslevel_' . $orgid);
            $verified = $ci->session->userdata('ogre_user_activated_' . $conid);
            $em = $ci->session->userdata('ogre_user_email');
        }  
        if ($day == '') {
            $day_array = $this->build_rpga_day_array($conid, $late);
        } else {
            $day_array['1'] = $day;
        }        
        if (!$ci->agent->isMobile()){
            $ret = $this->gen_row_enum($late, $conid) && $this->genSlotEnum($late, $conid);
            
            if ($slotlengths == 0) {
                 $slotlengths = $this->getSlotLengths($aff, $conid);            
            } else {
                $slotlengths[0] = 4;
            }
            foreach ($day_array as $gsday){
                $ret .=  ($day == '') ? '<div id="'.trim($gsday).'" style="display:block">' : '';
                foreach ($slotlengths as $slotlen){
                    if(intval($slotlen) != 1){
                        $ret .= $this->rpga_schedule_detail_boot($conid, $aff, $day, $gsday, $slotlen, $late, $showhdr, $accessrating, $verified, $em, $print, $ajax);     
                    }
                }
                if ($day == ''){
                    $ret .='</div>';
                }
            }
        }
        else{
            foreach ($day_array as $gsday){
                if ($slotlengths == 0) {
                     $starttimes = $this->get_starttimes($aff, $conid, $gsday);            
                } else {
                    $starttimes[0][0] = "14:00:00";
                    $starttimes[0][1] = 2;
                }                
                $ret .=  ($day == '') ? '<div id="'.trim($gsday).'" style="display:block">' : '';
                foreach ($starttimes as $startt){
                    $ret .= $this->rpga_schedule_mobile_detail_boot($conid, $aff, $startt, $late, $gsday, $accessrating, $verified, $em, $print, $ajax); 
                }
                if ($day == ''){
                    $ret .='</div>';
                }
            }
                  
        }
        
        return $ret;
    }
//------------------------
// $conid, $aff, $day, $gsday, $slotlen, $late, $showhdr, $accessrating, $verified, $em, $print, $ajax
//------------------------
    private function rpga_schedule_detail_boot($conid, $aff, $day, $gsday, $slotlen, $late, $showhdr, $accessrating, $verified, $em, $print, $ajax){
        $ci=&get_instance();
        
        $maxrnum = $this->get_max_rnum($conid, 0, $aff, $gsday, $slotlen);
        $maxcolnum = $ci->convention->getMaxSlots($slotlen);
        $slot_codes = $this->buildOPSlotArray($conid, $slotlen, $late, $day);  //$conid, $aff='', $slotlen=0, $day='', $scenid=0, $late=''
        $qry = $this->opBuildScheduleSQL($conid, $aff, $slotlen, $gsday, '', $late);  
        $query = $ci->db->query($qry);
        $nosched = ($query->getNumRows() == 0)? TRUE:FALSE;                                
        $ret = '<div id="optable_outer">';
        if ($nosched != TRUE){                
            $ret .= $this->build_rpga_header_boot($gsday, $slotlen, $gsday, $late, $aff, $showhdr);
            $ret .= $this->build_rpga_slot_header_boot($gsday, $gsday, $late, $slot_codes);
            for ($i=1;$i<=$maxrnum;$i++){
                $ret .= '<div id="'.$gsday.$i.'" class="row">';    
                for ($j=1;$j<=$maxcolnum;$j++){   
                    $ret .= $this->build_rpga_cell_boot($i, $j, $aff, $gsday, $late, $slotlen, $accessrating, $verified, $em, $print, $ajax);
                }       
                $ret .= '</div>';   
            }                                   
        }
        $ret .='</div>'; 
        return $ret;
    }
//------------------------
//
//------------------------
    private function rpga_schedule_mobile_detail_boot($conid, $aff, $starts, $late, $day, $accessrating, $verified, $em, $print, $ajax){
        $ci=&get_instance();
        
        $qry = $this->opBuildScheduleSQL($conid, $aff, $starts[1], $day, $starts[0], $late, 0);
        $query = $ci->db->query($qry);
        $nosched = ($query->getNumRows() == 0)? TRUE:FALSE;                                
        $ret = '<div id="optable_outer">';
        $cday = '';
        if ($nosched != TRUE){
            foreach ($query->getResult() as $row){                                                                  //$day, $aff, $slotl,   
                $ret .= ($cday !== $row->gs_slot_day.$row->gs_slot_length) ? $this->build_rpga_header_mobile_boot($row->gs_slot_day, $aff, str_replace('.00', '', $starts[1]), TRUE) : '';
                $ret .= ($cday !== $row->gs_slot_day.$row->gs_slot_length) ? $this->build_rpga_slot_header_mobile_boot($row->gs_slot_day,$starts[2], $late) : '';
                $ret .= '<div id="'.$row->gs_id.'" class="row">';     
                $ret .= $this->build_rpga_cell_mobile_boot($row->gs_id, $aff, $row->gs_slot_day, $accessrating, $verified, $em, $print, $ajax);   
                $ret .= '</div>';  
                $cday = $row->gs_slot_day.$row->gs_slot_length;
            }                                   
        }
        $ret .='</div>'; 
        return $ret;
    }   
//------------------------
//
//------------------------
    public function rpga_schedule_footer(){
        $ci=&get_instance();
        $orgid = $ci->session->ogre_orgid;
        $email = $ci->ogre_lib->getConfigKey('OGRE.ADMIN.EMAIL.LOGIN', $orgid);
        $ret = '<p>IMPORTANT NOTE:  Report problems to ' . safe_mailto($email, 'Gaming Coordinator');
        $ret .= '</p>';
        return $ret;
    }


//------------------------
//
//------------------------
    public function rpga_schedule_all($late=0, $print=FALSE, $ajax=FALSE){
        $ci=&get_instance();        
        $conid = $ci->session->ogre_conid;         
        $aff_array = $this->build_affiliation_array();
        $day_array = $this->build_rpga_day_array($conid, $late);
        $ret = '';
        foreach ($day_array as $sday){
            $d = 1;            
            $ret .= '<div id="'.trim($sday).'" style="display:block">';
            if (is_array($aff_array)){
                foreach ($aff_array as $aff){
                    $slotlengths = $this->getSlotLengths($aff, $conid);                    
                    $ret .=  ($d == 1) ? $this->rpga_schedule_boot($aff, $late, $sday, $print, TRUE, $ajax, $slotlengths) : $this->rpga_schedule_boot($aff, $late, $sday, $print, FALSE, $ajax, $slotlengths);
                    $d++;
                }
            }
            $ret .= '</div>';
        }
        return $ret;
    }
//------------------------
//
//------------------------
    public function  build_affiliation_array(){           
        $ci=&get_instance();        
        $conid = $ci->session->ogre_conid;  
        $qry_dbAff = 'SELECT DISTINCT ogre_gameschedule.gs_affiliation';
        $qry_dbAff .= ' FROM ogre_gameschedule ';
        $qry_dbAff .= ' WHERE ogre_gameschedule.gs_mmrpgFlag <> 0 ';
        $qry_dbAff .= ' AND ogre_gameschedule.gs_cancelled = 0';
        $qry_dbAff .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
        $qry_dbAff .= ' ORDER BY ogre_gameschedule.gs_affiliation;';

        $qaff = $ci->db->query($qry_dbAff);
        $ret = '';
        $i=0;
        if ($qaff->getNumRows() > 0){
            foreach ($qaff->getResult() as $affil){
                $ret[$i] = $affil->gs_affiliation;
                $i++;
            }

        }
        return $ret;
    }
//------------------------
//
//------------------------
    public function get_max_rnum($conid, $latenight, $aff, $day='', $sl=4){  
        $ci=&get_instance();
        $qry_mx = "SELECT DISTINCT Max(ogre_gameschedule.gs_row_enum) AS MaxOfRowEnum FROM ogre_gameschedule";
        $qry_mx .= " WHERE ogre_gameschedule.gs_convention_id = " . $conid;
        $qry_mx .= " AND gs_affiliation = '" . $aff . "'";
        $qry_mx .= " AND gs_late_night = " . $latenight;
        $qry_mx .= " AND gs_slot_day = '" . $day. "'";  
        $qry_mx .= " AND gs_slot_length = " . $sl;
        $query = $ci->db->query($qry_mx);
        foreach ($query->getResult() as $row){
               $maxrnum = $row->MaxOfRowEnum;
        }
        return $maxrnum;
    }
//----------------------------
//   GENERATE SLOT Enumerator
//----------------------------
    public function genSlotEnum($conid, $late){
        $ci = &get_instance();
        $ret='';
        $ci->convention->init($conid);
        // -------->
        $qry = "UPDATE ogre_gameschedule SET ogre_gameschedule.gs_slot_enum = 0";
        $qry .= " WHERE ogre_gameschedule.gs_cancelled = 1 AND ogre_gameschedule.gs_slot_enum <> 0";
        $qry .= " AND ogre_gameschedule.gs_convention_id = " . $conid . ";";
        $ci->db->query($qry);                                         
        /// ------>            
        $days = $ci->convention->dayArray();
        $slen=$ci->scenario->getAllSlotHours();
            
        foreach ($slen as $sl){
            foreach ($days as $day){
                $qry = "SELECT DISTINCT ogre_gameslots.slot_code ";
                $qry .= " FROM ogre_gameslots ";
                $qry .= " WHERE ogre_gameslots.slot_RPGA = 1 ";
                $qry .= " AND ogre_gameslots.slot_latenight = " . $late;
                $qry .= " AND ogre_gameslots.slot_day= '" . $day . "'";
                $qry .= " AND ogre_gameslots.slot_conid = " . $conid;
                $qry .= " AND ogre_gameslots.slot_length = " . $sl;
                $qry .= " ORDER BY ogre_gameslots.slot_code ;";
                $i = 1;
                $ret = '';
                $query1 = $ci->db->query($qry);
                if ($query1->getNumRows() > 0){
                    foreach ($query1->getResult() as $row2){
                        $updtEnum = "UPDATE ogre_gameschedule SET ogre_gameschedule.gs_slot_enum = " . $i ;
                        $updtEnum .= " WHERE ogre_gameschedule.gs_slot_code = " . $row2->slot_code ;
                        $updtEnum .= " AND ogre_gameschedule.gs_mmrpgFlag = 1 AND ogre_gameschedule.gs_late_night = " . $late;
                        $updtEnum .= " AND ogre_gameschedule.gs_convention_id = " . $conid . ";";

                        $ci->db->query($updtEnum);
                        $ret = ($ci->db->affectedRows() > 0)?TRUE:FALSE;
                        $i++;
                     }
                }
            }
        }
        return $ret;
    }
//---------------------------
//
//   GENERATE Row Enumerator
//
//---------------------------

    public function gen_row_enum($late, $conid){
            $ci=&get_instance();
            // -------->
            $qry = "UPDATE ogre_gameschedule SET ogre_gameschedule.gs_row_enum = 0";
            $qry .= " WHERE ogre_gameschedule.gs_cancelled = 1 AND ogre_gameschedule.gs_row_enum <> 0";
            $qry .= " AND ogre_gameschedule.gs_convention_id = " . $conid . ";";
            $ci->db->query($qry);
            /// ------>
            $qry_dbSlots = "SELECT DISTINCT ogre_gameschedule.gs_slot_code, ogre_gameschedule.gs_mmrpgFlag ";
            $qry_dbSlots .= " FROM ogre_gameschedule WHERE ogre_gameschedule.gs_mmrpgFlag <> 0 ";
            $qry_dbSlots .= " AND ogre_gameschedule.gs_late_night = " . $late;
            $qry_dbSlots .= " AND ogre_gameschedule.gs_convention_id = " . $conid;
            $qry_dbSlots .= " ORDER BY ogre_gameschedule.gs_slot_code;";
            $qslots = $ci->db->query($qry_dbSlots);
            $ret = '';

            if ($qslots->getNumRows() > 0){
                foreach ($qslots->getResult() as $slots){             
                    $qry_dbAff = "SELECT DISTINCT ogre_gameschedule.gs_affiliation ";
                    $qry_dbAff .= " FROM ogre_gameschedule ";
                    $qry_dbAff .= " WHERE ogre_gameschedule.gs_mmrpgFlag <> 0 ";
                    $qry_dbAff .= " AND ogre_gameschedule.gs_convention_id = " . $conid;
                    $qry_dbAff .= " ORDER BY ogre_gameschedule.gs_affiliation;";
                    $qaff = $ci->db->query($qry_dbAff);
                    if ($qaff->getNumRows() > 0){
                        foreach ($qaff->getResult() as $affil){
                            $qry_dbGames ='SELECT ogre_gameschedule.gs_id, ';
                            $qry_dbGames .=' ogre_gameschedule.gs_game_title, ';
                            $qry_dbGames .=' ogre_gameschedule.gs_slot_code, ';
                            $qry_dbGames .=' ogre_gameschedule.gs_mmrpgFlag, ';
                            $qry_dbGames .=' ogre_gameschedule.gs_convention_id, ';
                            $qry_dbGames .=' ogre_gameschedule.gs_affiliation, ';
                            $qry_dbGames .=' ogre_gameschedule.gs_convention_id, ';
                            $qry_dbGames .=' ogre_rpga_scenario_setup.rss_number_of_slots, ';
                            $qry_dbGames .=' ogre_rpga_game_setup.rgs_active ';
                            $qry_dbGames .=' FROM (ogre_gameschedule INNER JOIN ogre_rpga_game_setup ';
                            $qry_dbGames .=' ON ogre_gameschedule.gs_id = ogre_rpga_game_setup.rgs_gs_id) ';
                            $qry_dbGames .=' INNER JOIN ogre_rpga_scenario_setup ';
                            $qry_dbGames .=' ON ogre_rpga_game_setup.rgs_scenario_id = ogre_rpga_scenario_setup.rss_scenario_id ';
                            $qry_dbGames .=' WHERE ogre_gameschedule.gs_game_title <> "" ';
                            $qry_dbGames .=' AND ogre_gameschedule.gs_slot_code = "'. $slots->gs_slot_code . '"';
                            $qry_dbGames .=' AND ogre_gameschedule.gs_cancelled = 0 ';
                            $qry_dbGames .=' AND ogre_gameschedule.gs_mmrpgFlag = 1 ';
                            $qry_dbGames .=' AND ogre_gameschedule.gs_convention_id = ' . $conid;
                            $qry_dbGames .=' AND ogre_gameschedule.gs_affiliation = "' . $affil->gs_affiliation . '"';
                            $qry_dbGames .=' AND ogre_rpga_game_setup.rgs_active=1 ';
                            $qry_dbGames .=' ORDER BY ogre_rpga_scenario_setup.rss_number_of_slots DESC , ogre_gameschedule.gs_game_title;';
                            $i = 1;
                            $qgames = $ci->db->query($qry_dbGames);
                            if ($qgames->getNumRows() > 0){
                                foreach ($qgames->getResult() as $games){
                                    $qry_updtRowEnum = "UPDATE ogre_gameschedule SET ogre_gameschedule.gs_row_enum = " . $i ;
                                    $qry_updtRowEnum .= " WHERE ogre_gameschedule.gs_id = " . $games->gs_id;
                                    $qry_updtRowEnum .= " AND ogre_gameschedule.gs_convention_id = " . $conid . ";";

                                    $ci->db->query($qry_updtRowEnum);
                                    $ret = ($ci->db->affectedRows() > 0)? TRUE:FALSE;                                    
                                    $i++;
                                }
                            }
                        }
                    }
                 }
            }  
            return $ret;
        }

        //------------------------
        //
        //
        //
        //------------------------
        public function buildOPSlotArray($conid, $slotlength=4, $late=-1, $day=''){
            $ci = &get_instance();
            $aryRPGASlots=array();
            $aryRPGASlots[1][1] =  '';
            $aryRPGASlots[1][2] =  '';
            $aryRPGASlots[1][3] =  '';
            $aryRPGASlots[1][4] =  '';
            $aryRPGASlots[1][5] =  '';
            $aryRPGASlots[1][6] =  '';
            $aryRPGASlots[1][7] =  '';
            $aryRPGASlots[1][8] =  '';
            $aryRPGASlots[1][9] =  '';
            $aryRPGASlots[1][10] =  '';
            $aryRPGASlots[1][11] =  '';            
            
            $qry_rpgaslots = 'SELECT ogre_gameslots.slot_rpga_number, ';
            $qry_rpgaslots .= ' ogre_gameslots.slot_start_time, ';
            $qry_rpgaslots .= ' ogre_gameslots.slot_time, ';
            $qry_rpgaslots .= ' ogre_gameslots.slot_code, ';
            $qry_rpgaslots .= ' ogre_gameslots.slot_time, ';
            $qry_rpgaslots .= ' ogre_gameslots.slot_length, ';
            $qry_rpgaslots .= ' ogre_gameslots.slot_number, ';
            $qry_rpgaslots .= ' ogre_gameslots.slot_latenight, ';
            $qry_rpgaslots .= ' ogre_gameslots.slot_day, ';
            $qry_rpgaslots .= ' ogre_gameslots.slot_date, ';
            $qry_rpgaslots .= ' ogre_gameslots.slot_baseslot ';
            $qry_rpgaslots .= ' FROM ogre_gameslots ';
            $qry_rpgaslots .= ' WHERE slot_conid = ' . $conid;
            $qry_rpgaslots .= ' AND slot_RPGA = 1 ';
            $qry_rpgaslots .= ' AND ogre_gameslots.slot_length = ' . $slotlength;
            $qry_rpgaslots .= ($late >= 0) ? ' AND ogre_gameslots.slot_latenight = ' . $late : '';
            $qry_rpgaslots .= ($day != '') ? ' AND ogre_gameslots.slot_day = "' . $day . '"' : '';
            $qry_rpgaslots .= ' ORDER BY slot_code;';
            $query = $ci->db->query($qry_rpgaslots);
            $i = 1;
            $aryRPGASlots[1][1] = "";
            if ($query->getNumRows() > 0){
		foreach ($query->getResult() as $row){
                    $aryRPGASlots[$i][1] =  "Slot " . $row->slot_rpga_number . ": " . substr($row->slot_day, 0, 3) . ' ' . $row->slot_time;
                    $aryRPGASlots[$i][2] =  $row->slot_code;
                    $aryRPGASlots[$i][3] =  $row->slot_time;
                    $aryRPGASlots[$i][4] =  $row->slot_start_time;
                    $aryRPGASlots[$i][5] =  $row->slot_length;
                    $aryRPGASlots[$i][6] =  $row->slot_number;
                    $aryRPGASlots[$i][7] =  $row->slot_latenight;
                    $aryRPGASlots[$i][8] =  $row->slot_rpga_number;
                    $aryRPGASlots[$i][9] =  $row->slot_day;
                    $aryRPGASlots[$i][10] =  $row->slot_date;
                    $aryRPGASlots[$i][11] =  $row->slot_baseslot;
                    $i++;
                }
            }
            return $aryRPGASlots;
        }
        //------------------------
        //
        //
        //
        //------------------------
        public function build_rpga_day_array($conid, $late)
        {
            $ci=&get_instance();
            $i = 1;          
            $ary[1] = '';            
            $qry = 'SELECT DISTINCT slot_day, slot_date  FROM ogre_gameslots ';
            $qry .= ' WHERE slot_conid = ' . $conid . ' AND slot_RPGA = 1 ';

            if ($late >= 0){
                $qry .= ' AND ogre_gameslots.slot_latenight = ' . $late;
            }
            $qry .= ' ORDER BY slot_date;';
            $query = $ci->db->query($qry);
//            var_dump($qry);
            if ($query->getNumRows() > 0){
		foreach ($query->getResult() as $row){
                    $ary[$i] =  $row->slot_day;
                    $i++;
                }
            }
            return $ary;
        }

//------------------------
//
//GENERATE RPGA CELL
//
//------------------------

    public function build_rpga_cell($i, $j, $aff, $d, $late, $slotlength, $accessrating=0, $verified=0, $em='', $print=FALSE){
        $ci=&get_instance();
        $ret = '';
        $schedview=$d.$i.$aff;
        $rowid = $d.$i;
        $ginfo['basic']='';
        $ginfo['detail']='';
        $maxcolnum = $ci->convention->getMaxSlots($slotlength);
        $cellitem = $ci->event->findCellInfo($i, $j, $aff, $d, $late, $slotlength);
        $ret .= ($j == 1) ? '<tr id="'.$rowid.'" style="display:table-row">' : '';
        $wdth = 100 / $maxcolnum;
        if (intval($cellitem) <> -9999){               
            $ret .= '<td  ';
            if (!$ci->agent->isMobile()){
                $ret .= ' class="op_gamecell" width="'.$wdth.'%"';
            }
            else{
                 $ret .= ' class="op_gamecell" ';
            }
            $ret .= ' id="opgicell'.$cellitem.'" ';
            $ret .= ' >';
            $ginfo = $ci->event->buildOPGameInfo($cellitem, $accessrating, $verified, $em, $print, $schedview.$j);
            $ret .= $ginfo['detail'];
            $ret .= '</td>';
        }
        else{
            $ret .= '<td ';
            $ret .=  (!$ci->agent->isMobile()) ? ' class="op_gamecell1" ' . ' width="'.$wdth.'%"': ' class="op_gamecell1" ';
            $ret .= '>&nbsp;</td>';
        }
        if ($j == $maxcolnum){                
            $ret .= '</tr>';
            $ret .= '<tr id="op_basic'.$schedview.'" style="display:none">';
            $ret .= '<td style="padding:0px;"></td>';
            $ret .= '<td style="padding:0px;"></td>';
            $ret .= '<td style="padding:0px;"></td>';    
            $ret .= '</tr>';             
        }
        return $ret;
    }
//------------------------
//
//GENERATE RPGA CELL BOOTSTRAP
//
//------------------------

    public function build_rpga_cell_boot($i, $j, $aff, $d, $late, $slotlen, $accessrating=0, $verified=0, $em='', $print=FALSE){
        $ci=&get_instance();
        $ret = '';
        $schedview=$d.$i.$aff;
        $rowid = $d.$i;
        $ginfo['basic']='';
        $ginfo['detail']='';
        $cellitem = $ci->event->findCellInfo($i, $j, $aff, $d, $late, $slotlen);
        $maxcolnum = (!$ci->agent->isMobile()) ? $ci->convention->getMaxSlots($slotlen) : 1;
        $wdth = 12 / $maxcolnum;
        if (intval($cellitem) <> -9999){               
            $ret .= '<div class="col-sm-'.$wdth.' mb-4">';
            $ginfo = $ci->event->buildOPGameInfoBoot($cellitem, $accessrating, $verified, $em, $print, $schedview.$j);
            $ret .= $ginfo['detail'];
            $ret .= '</div>';
        }
        else{
            $ret .= '<div class="col-sm-'.$wdth.'">';

            $ret .= '</div>';
        }

        return $ret;
    }
//------------------------
//
//GENERATE RPGA CELL BOOTSTRAP
//
//------------------------

    public function build_rpga_cell_mobile_boot($id, $aff, $d, $accessrating=0, $verified=0, $em='', $print=FALSE){
        $ci=&get_instance();
        $ret = '';
        $schedview=$d.$aff;
        $rowid = $id;
        $ginfo['basic']='';
        $ginfo['detail']='';

        if (intval($id) <> 0){               
            $ret .= '<div class="col-sm-12 mb-4">';
            $ginfo = $ci->event->buildOPGameInfoBoot($id, $accessrating, $verified, $em, $print, $schedview);
            $ret .= $ginfo['detail'];
            $ret .= '</div>';
        }
        else{
            $ret .= '<div class="col-sm-'.$wdth.'">';

            $ret .= '</div>';
        }

        return $ret;
    }
    
//------------------------
//
//
//
//------------------------        
    public function build_rpga_gamebasicinfo($id, $accessrating, $verified, $em, $print=FALSE, $ajax=TRUE, $schedviewid=''){
        $ret='';
        $ci=&get_instance();
        $ginfo = $ci->event->buildOPGameInfo($id, $accessrating, $verified, $em, $print, $ajax, $schedviewid);
        $content = $ginfo['basic'];
        $j = $ci->event->slot_enum;
        switch($j){
            case 1:

                $ret .= '<td class="op_gamecell_reg">';
                $ret .= $content;
                $ret .= '</td>';
                $ret .= '<td class="op_gamecell_black">&nbsp;</td>';
                $ret .= '<td class="op_gamecell_black">&nbsp;</td>';
                break;
            case 2:
                $ret .= '<td class="op_gamecell_black">&nbsp;</td>';
                $ret .= '<td class="op_gamecell_reg">';
                $ret .= $content;
                $ret .= '</td>';                   
                $ret .= '<td class="op_gamecell_black">&nbsp;</td>';                    
                break;
            case 3:
                $ret .= '<td class="op_gamecell_black">&nbsp;</td>';           
                $ret .= '<td class="op_gamecell_black">&nbsp;</td>';
                $ret .= '<td class="op_gamecell_reg">';
                $ret .= $content;
                $ret .= '</td>';                            
                break;
        }
        return $ret;
    }
//------------------------
//
//
//
//------------------------        
    public function build_rpga_cellx($gid){
        $ci=&get_instance();         
        $orgid = $ci->session->ogre_orgid;
        $conid = $ci->session->ogre_conid;  
        $pid = $ci->session->userdata('ogre_user_ID');
        $accessrating=0;
        $verified=0;
        $em='';
        if ($pid != 0)
        {
            $accessrating= $ci->session->userdata('ogre_user_accesslevel_' . $orgid);
            $verified= $ci->session->userdata('ogre_user_activated_' . $conid);
            $em= $ci->session->userdata('ogre_user_email');
        }            
        $retarry = $ci->event->buildOPGameInfo($gid, $accessrating, $verified, $em, FALSE, TRUE);
        $ret = $retarry['detail'];
        return $ret;         
    }
//------------------------
//
//
//
//------------------------
    public function build_rpga_header($day, $slots, $d, $late, $aff, $showhdr=TRUE){         
            $ci = &get_instance();
            $j = 1;
            $i = 1;
            $ret = '';
            $ds[1]='';
            $maxcolnum = 0;           
            foreach ($slots as $slot){
                if ($slot[9] == $d) {
                    $ds[$j] = $slot[1];
                    if($maxcolnum == 0){
                        $maxcolnum = $ci->convention->getMaxSlots($slot[5]);
                    }
                    $j++;
                }
            }
            $ret .= '<tr>';
            $ret .= '<th ' . (($maxcolnum!==0) ? 'colspan="'.$maxcolnum.'"': '') .' class="op_slotheader">';
            if($showhdr == TRUE)
            {
                $ret .= '<h2>' . $day . '</h2>';
            }
            $ret .= '<h3>' . $aff . ' (' . $day . ' / '.$slot[5].' hr. slots'. ')</h3>';
            $ret .= '</th>';
            $ret .= '</tr>';

            $j = 0;
            $ret .= '<tr>';
            foreach ($ds as $dslot){
                $ret .= '<th class="op_dayslot">';
                $ret .= '<strong>';
                $t = str_replace(':00','', $dslot);
                if (substr($t,11,1) == '0'){
                    $t = substr_replace($t,'',11,1);
                }
                if (substr($t,18,1) == '0'){
                    $t =  substr_replace($t,'',18,1);
                }
                if (substr($t,21,1) == '0'){
                    $t =  substr_replace($t,'',21,1);
                }
                if ($late == 1){
                    if (substr($t,19,1) == '0'){
                        $t =  substr_replace($t,'',19,1);
                    }
                    $t = str_replace('Slot 2','Late Night 1', $t);
                    $t = str_replace('Slot 5','Late Night 2', $t);
                    $t = str_replace('12 AM','12', $t);
                    $t = str_replace('12 AM','12', $t);
                }

                $ret .= $t;
                $ret .= '</strong></th>';
                $j++;
            }
            switch ($j){
                case 1:
                    $ret .= '<th class="dayslot">&nbsp;</th><th class="dayslot">&nbsp;</th>';
                    break;
                case 2:
                    $ret .= '<th class="dayslot">&nbsp;</th>';
                    break;
            }
            $ret .= '</tr>';
            return $ret;

    }

//------------------------
//
//
//
//------------------------
    private function build_rpga_header_boot($day, $slotl, $d, $late, $aff, $showhdr=TRUE){         
            $ci = &get_instance();
            $ret='';

            if($showhdr == TRUE){
                $ret .= '<h2>' . $day . '</h2>';
            }
            $ret .= '<h3>' . $aff . ' (' . $day . ' / '.$slotl.' hr. slots'. ')</h3>';
            $ret .= '</div>';
            
            return $ret;
    }
    

//------------------------
//
//
//
//------------------------
    private function build_rpga_header_mobile_boot($day, $aff, $slotl, $showhdr=TRUE){         
        $ret = '';    
        if($showhdr == TRUE){
                $ret .= '<h3>' . $day . '</h3>';
        }
        $ret .= '<h4>' . $aff . ' (' . substr($day,0,3) . ' / '.$slotl.' hr. slots'. ')</h4>';
        $ret .= '</div>';

        return $ret;
    }
//------------------------
//
//
//
//------------------------
    private function build_rpga_slot_header_boot($day, $d, $late, $slots){ 
             $ci=&get_instance();
             $j = 1;
             $i = 1;
             $ret = '';
             $ds[1]='';
             $maxcolnum = 0;
             foreach ($slots as $slot){ 
                if ($slot[9] == $d) {
                     $ds[$j] = $slot[1];
                     if(intval($maxcolnum) == 0){
                         $maxcolnum = $ci->convention->getMaxSlots($slot[5]);
                     }   
                     $j++;
                 }
             }                        
            $ret = '<div id="op-'.$day.'-slots" class="row">';  
            foreach ($ds as $dslot){
                $ret .= '<div ' .(($maxcolnum!==0) ? 'class="col-sm-'. 12/intval($maxcolnum) : 'class="col-sm"').'">';  //(($maxcolnum!==0) ? 'colspan="'.$maxcolnum.'"': '')
                $ret .= '<div class="card mb-2">';
                $ret .= '<div class="card-header">';
                $ret .= '<h6 class="text-center">';                
                $t = str_replace(':00','', $dslot);
                if (substr($t,11,1) == '0'){
                    $t = substr_replace($t,'',11,1);
                }
                if (substr($t,18,1) == '0'){
                    $t =  substr_replace($t,'',18,1);
                }
                if (substr($t,21,1) == '0'){
                    $t =  substr_replace($t,'',21,1);
                }
                if ($late == 1){
                    if (substr($t,19,1) == '0'){
                        $t =  substr_replace($t,'',19,1);
                    }
                    $t = str_replace('Slot 2','Late Night 1', $t);
                    $t = str_replace('Slot 5','Late Night 2', $t);
                    $t = str_replace('12 AM','12', $t);
                    $t = str_replace('12 AM','12', $t);
                }

                $ret .= $t;
                $ret .= '</h6>';
                $ret .= '</div>';
                $ret .= '</div>';
                $ret .= '</div>';
                $j++;
            }       
            $ret .= '</div>';
            return $ret;
    }
//------------------------
//
//
//
//------------------------
    private function build_rpga_slot_header_mobile_boot($day, $slottime, $late){
            $ret = '<div id="op-'.$day.'-slots" class="row">';  
            $ret .= '<div class="col-sm">';
            $ret .= '<div class="card mb-2">';
            $ret .= '<div class="card-header">';
            $ret .= '<h6 class="text-center">';                
            $t = str_replace(':00','', $slottime);
            if (substr($t,11,1) == '0'){
                $t = substr_replace($t,'',11,1);
            }
            if (substr($t,18,1) == '0'){
                $t =  substr_replace($t,'',18,1);
            }
            if (substr($t,21,1) == '0'){
                $t =  substr_replace($t,'',21,1);
            }
            if ($late == 1){
                if (substr($t,19,1) == '0'){
                    $t =  substr_replace($t,'',19,1);
                }
                $t = str_replace('Slot 2','Late Night 1', $t);
                $t = str_replace('Slot 5','Late Night 2', $t);
                $t = str_replace('12 AM','12', $t);
                $t = str_replace('12 AM','12', $t);
            }

            $ret .= $t;
            $ret .= '</h6>';
            $ret .= '</div>';
            $ret .= '</div>';
            $ret .= '</div>';
            $ret .= '</div>';
            return $ret;
    }     
        //------------------------
        //
        //
        //
        //------------------------
        public function slot_array_search($slots, $tslot){
                $j = 1;
                $index = 0;
                foreach ($slots as $slot){
                    if ($slot[2] == $tslot){
                        $index = $j;
                    }
                    $j++;
                }
            return $index;

        }
        //------------------------
        //
        //
        //
        //------------------------
        public function affiliation_menux($conid, $late, $sel='0', $oplink=''){
            $ci=&get_instance();
            
            $qry = 'SELECT DISTINCT ogre_gameschedule.gs_affiliation';
            $qry .= ' FROM ogre_gameschedule ';
            $qry .= ' WHERE ogre_gameschedule.gs_mmrpgFlag <> 0 ';
            $qry .= ' AND ogre_gameschedule.gs_cancelled <> 1 ';
            $qry .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
            $qry .= ' ORDER BY ogre_gameschedule.gs_affiliation;';
            
            $qaff = $ci->db->query($qry);
            $ret = ' <div id="affiliationdropdown">';
            $ret .= '<label class="form-label" for="affdropdown">Affiliation</label>';
            $ret .= '<select  class="form-select" id="affdropdown" name="affdropdown" size="1" onchange="changeOpView(this.options[this.selectedIndex].value);">';
            if ($sel == '0'){
                $ret .= '<option selected="selected" value="0" hidden="hidden">-SELECT-</option>';
            }
            else{
                $ret .= '<option value="0" hidden="hidden">-SELECT-</option>';
            }
            if ($qaff->getNumRows() > 0){
                foreach ($qaff->getResult() as $affil){
                    if ($sel == $affil->gs_affiliation){
                        $action = site_url($oplink.'/0/' . $affil->gs_affiliation . '/' . $late,'https');
                        $ret .= '<option selected="selected" value="'.$action.'">' . $affil->gs_affiliation . '</option>';
                    }
                    else
                    {
                        $action = site_url($oplink.'/0/' . $affil->gs_affiliation . '/' . $late,'https');
                        $ret .= '<option value="'.$action.'">' . $affil->gs_affiliation . '</option>';
                    }
                }
     
            }
//            if ($sel == 'all')
//            {
//                $action = site_url($oplink.'/0/all/' . $late,'https');
//                $ret .= '<option selected="selected" value="'.$action.'">All</option>';
//            }
//            else{
//                $action = site_url($oplink.'/0/all/' . $late,'https');
//                $ret .= '<option value="'.$action.'">All</option>';
//            }
            if(!$ci->agent->isMobile()){
                if ($sel == 'grid')
                {
                    $action = site_url($oplink.'grid','https');
                    $ret .= '<option selected="selected" value="'.$action.'">Grid View</option>';
                }
                else{
                    $action = site_url($oplink.'grid','https');
                    $ret .= '<option value="'.$action.'">Grid View</option>';
                }
            }
            $ret .= '</select>';
            return $ret;
        }
        //------------------------
        //
        //
        //
        //------------------------
//        public function affiliation_menux_old($conid, $late, $sel='all',$oplink='ogrex/browseScheduleX/rpga'){
//            $ci=&get_instance();
//            
//            $qry_dbAff = 'SELECT DISTINCT ogre_gameschedule.gs_affiliation';
//            $qry_dbAff .= ' FROM ogre_gameschedule ';
//            $qry_dbAff .= ' WHERE ogre_gameschedule.gs_mmrpgFlag <> 0 ';
//            $qry_dbAff .= ' AND ogre_gameschedule.gs_cancelled <> 1 ';
//            $qry_dbAff .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
//            $qry_dbAff .= ' ORDER BY ogre_gameschedule.gs_affiliation;';
//            
//            $qaff = $ci->db->query($qry_dbAff);
//            $ret = ' <div id="tabnav" align="center"><ul>';
//            if ($qaff->getNumRows() > 0){
//                foreach ($qaff->getResult() as $affil){
//                    if ($sel == $affil->gs_affiliation){
//                        $action=site_url($oplink.'/0/' . $affil->gs_affiliation . '/' . $late);
//                        $menurefresh = site_url('ogrex/reAffiliationMenu/'.$late);
//                        $ret .= '<li id="current"><a href="#" onclick="return searchSchedule(' . "'" . $action . "',". "'" . $menurefresh . "',". "'" . $affil->gs_affiliation . "'". ');">' . $affil->gs_affiliation . '</a></li>';
//
//                    }
//                    else
//                    {
//                        $action = site_url($oplink.'/0/' . $affil->gs_affiliation . '/' . $late);
//                        $menurefresh = site_url('ogrex/reAffiliationMenu/'.$late);
//                        $ret .= '<li><a href="#" onclick="return searchSchedule(' . "'" . $action . "',". "'" . $menurefresh . "',". "'" . $affil->gs_affiliation . "'". ');">' . $affil->gs_affiliation . '</a></li>';
//                    }
//                }
//     
//            }
//            if ($sel == 'all')
//            {
//                $action = site_url($oplink.'/0/all/' . $late);
//                $menurefresh = site_url('ogrex/reAffiliationMenu/'.$late);
//                $alllink = '<li id="current"><a href="#" onclick="return searchSchedule(' . "'" . $action . "',". "'" . $menurefresh . "',". "'all'". ');">All</a></li>';
//            }
//            else{
//                $action = site_url($oplink.'/0/all/' . $late);
//                $menurefresh = site_url('ogrex/reAffiliationMenu/'.$late);
//                $alllink = '<li><a href="#" onclick="return searchSchedule(' . "'" . $action . "',". "'" . $menurefresh . "',". "'all'". ');">All</a></li>';
//            }
//            if ($sel == 'grid')
//            {
//                $action = site_url($oplink.'grid');
//                $menurefresh = site_url('ogrex/reAffiliationMenu/'.$late);
//                $gridlink = '<li id="current"><a href="#" onclick="return searchSchedule(' . "'" . $action . "',". "'" . $menurefresh . "',". "'grid'". ');">Grid</a></li>';
//            }
//            else{
//                $action = site_url($oplink.'grid');
//                $menurefresh = site_url('ogrex/reAffiliationMenu/'.$late);
//                $gridlink = '<li><a href="#" onclick="return searchSchedule(' . "'" . $action . "',". "'" . $menurefresh . "',". "'grid'". ');">Grid</a></li>';
//            }            
//            $rpga_gameschedule_print_page = 'ogre/browseschedule/rpga/0/' . $sel . '/' . $late . '/1';
//            $rprint = '<div class="printreport">';
//            $rprint .= '<a href="' . site_url($rpga_gameschedule_print_page) . '" target="_blank">Printable Version</a>';
//            $rprint .= '</div>';                            
//        
//        return $ret . $alllink . $gridlink.'</ul></div>' . $rprint;
//        }
        //------------------------
        //
        //
        //
        //------------------------
        public function affiliation_menu($conid, $late, $sel='RPGA',$oplink='ogre/browseschedule/rpga'){
            $ci=&get_instance();
            
            $qry_dbAff = 'SELECT DISTINCT ogre_gameschedule.gs_affiliation';
            $qry_dbAff .= ' FROM ogre_gameschedule ';
            $qry_dbAff .= ' WHERE ogre_gameschedule.gs_mmrpgFlag <> 0 ';
            $qry_dbAff .= ' AND ogre_gameschedule.gs_cancelled <> 1 ';
            $qry_dbAff .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
            $qry_dbAff .= ' ORDER BY ogre_gameschedule.gs_affiliation;';

            $qaff = $ci->db->query($qry_dbAff);
            $ret = ' <div id="tabnav" align="center"><ul>';
            if ($qaff->getNumRows() > 0)
            {
                foreach ($qaff->getResult() as $affil)
                {
                    if ($sel == $affil->gs_affiliation)
                    {
                        $ret .= '<li id="current">' . anchor(site_url($oplink.'/0/' . $affil->gs_affiliation . '/' . $late,'https'), $affil->gs_affiliation) . '</li>';

                    }
                    else
                    {
                        $ret .= '<li>' . anchor(site_url($oplink.'/0/' . $affil->gs_affiliation . '/' . $late,'https'), $affil->gs_affiliation) . '</li>';
                    }
                }
     
            }
            if ($sel == 'all')
            {
                $alllink = '<li id="current"> ' . anchor(site_url($oplink.'/0/all/' . $late,'https'), 'All') . '</li>';
            }
            else
            {
                $alllink = '<li> ' . anchor(site_url($oplink.'/0/all/' . $late,'https'), 'All') . '</li>';
            }
            return $ret . $alllink . '</ul></div>';
        }
        //------------------------
        //
        //
        //
        //------------------------
        public function rpga_gridview(){
            $ci=get_instance();
//            $orgid = $ci->session->ogre_orgid;
            $conid = $ci->session->ogre_conid;  
            $ret = '';
            $scenqry = 'SELECT ogre_rpga_scenario_setup.rss_scenario_id ';
            $scenqry .= ' FROM ogre_rpga_scenario_setup ';
            $scenqry .= ' WHERE ogre_rpga_scenario_setup.rss_convention_id =' . $conid;
            $scenqry .= ' AND ogre_rpga_scenario_setup.rss_deleteflag = 0 ';
            $scenqry .= ' ORDER BY ogre_rpga_scenario_setup.rss_affiliation, ';
            $scenqry .= ' ogre_rpga_scenario_setup.rss_slotlength, ';
            $scenqry .= 'ogre_rpga_scenario_setup.rss_scenario_name;';
            $scen_qry = $ci->db->query($scenqry);
            $lastaffil = "";
            $lastslen = "";
            $r = 1;
            if ($scen_qry->getNumRows() > 0 ){
                foreach ($scen_qry->getResult() as $scen_row){
                    $ci->scenario->initialize($scen_row->rss_scenario_id, $conid);     
                    $qry_rpgaslots = 'SELECT slot_code, slot_day, slot_start_time, slot_length, slot_time, slot_rpga_number FROM ogre_gameslots ';
                    $qry_rpgaslots .= ' WHERE slot_conid = ' . $conid;
                    $qry_rpgaslots .= ' AND slot_RPGA = 1 ';
                    $qry_rpgaslots .= ' AND slot_length = ' . $ci->scenario->slot_length;
                    $qry_rpgaslots .= ' ORDER BY slot_code;';
                    $maxcol = $ci->convention->getMaxSlotNum($ci->scenario->slot_length);
                    
                    $slot_qry = $ci->db->query($qry_rpgaslots);
                    if(isset($slots)){
                        unset($slots);
                    }
                    $slots = array();
                    $i = 1;
                    if ($slot_qry->getNumRows() > 0){
                        foreach ($slot_qry->getResult() as $slots_row){
                            $slots[$i][1] = $slots_row->slot_code;
                            $slots[$i][2] = $slots_row->slot_day;
                            $slots[$i][3] = $slots_row->slot_start_time;
                            $slots[$i][4] = $slots_row->slot_length;
                            $slots[$i][5] = $slots_row->slot_time;
                            $slots[$i][6] = $slots_row->slot_rpga_number;
                            $i++;
                        }
                    }                    
                    
                    if ($ci->scenario->affiliation != $lastaffil){
                        if ($lastaffil != ""){
                            $ret .= '</table>';
                            $ret .= '</div>';
                        }
                        
                        $ret .= '<div id="op_' . $ci->scenario->affiliation . '_grid">';
                        $ret .= $this->build_grid_slot_hdr($slots, $ci->scenario->affiliation, $maxcol);
                    }else{
                        if ($ci->scenario->slot_length != $lastslen){
                            if ($lastslen != ""){
                                $ret .= '</table>';
                                $ret .= '</div>';
                            }

                            $ret .= '<div id="op_' . $ci->scenario->affiliation . $ci->scenario->slot_length . '_grid">';
                            $ret .= $this->build_grid_slot_hdr($slots, $ci->scenario->affiliation, $maxcol);
                        }  
                    }
                    $ret .= '<tr>';
                    $ret .= '<td>';
                    $ret .= $ci->scenario->scenario_name;
                    $ret .= '</td>';
                    
                    $gslots = $ci->scenario->getSlotsArray();
                    foreach ($slots as $slot){
                        $s = $slot[1];
                        if (count($gslots) == 0){
                            $ret .= '<td>';
                            $ret .= "&nbsp;";
                            $ret .= '</td>';
                        } else{
                            if (in_array($s , $gslots)){
                                if (intval($ci->scenario->number_of_slots) > 1){
                                    if ($r == 1){
                                        $ret .= '<td align="center" colspan="' . $ci->scenario->number_of_slots . '" class="gridbox">';
                                        $ret .= "-&nbsp;";
                                        $r++;
                                    }
                                    else { 
                                        if ($r == intval($ci->scenario->number_of_slots) ){
                                            $r = 1;
                                            $ret .= '</td>';
                                        } 
                                        else{
                                            $r++;
                                            $ret .= '-&nbsp;';
                                        }
                                    }
                                } else {
                                    $ret .= '<td align="center" class="gridbox">';
                                    $ret .= "-&nbsp;";
                                    $ret .= '</td>';
                                }
                            } else {
                                $ret .= '<td align="center">';
                                $ret .= "&nbsp;";
                                $ret .= '</td>';
                            }
                        }
                    }
                     $ret .= '</tr>';
                     $lastaffil = $ci->scenario->affiliation;
                     $lastslen = $ci->scenario->slot_length;
                    }
                }
                $ret .= '</table>';
                return $ret;
            }

        //---------------------------------------------------
        //
        //
        //
        //---------------------------------------------------
        function build_grid_slot_hdr($sl, $aff, $colnum=9){
            $ret = '<table id="opgrid_table" >';
            $ret .= '<tr>';
            $ret .= '<th rowspan="2" id="op_grid_table_scenariolabel">';
            $ret .= $aff .' Scenarios (' . $sl[1][4] . ' hrs)';
            $ret .= '</th>';
            $ret .= '<th colspan="'.$colnum.'" id="op_grid_table_slotlabel">'; 
            $ret .= 'Slots';
            $ret .= '</tr>';
            $ret .= '<tr>';

            for ($i=1;$i<=count($sl);$i++){
                $ret .= '<th id="op_grid_table_slotslabel" width="'. 50/count($sl) .'%">';
                $ret .= $sl[$i][6];
                $ret .= '</th>';
            }
            $ret .= '</tr>';
            return $ret;
        }

//        //---------------------------------------------------
//        //
//        //
//        //
//        //---------------------------------------------------
//        function convert_slot_code($sc){
//            $sc = substr($sc,-2,2);
//            $sn = substr($sc,0,1);
//            
//            if (substr($sc,1,1) == "5")
//            {
//                $sn .=  '<br />MM';
//            }
//            elseif (substr($sc,1,1) != "0"){
//                $sn = substr($sc,0,2);
//            }
//            return $sn;
//        }
           
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function get_starttimes($aff, $conid, $day){
        $ci=get_instance();
        $i=0;
        $ret = NULL;
        $qry = 'SELECT DISTINCT ';
        $qry .= ' ogre_gameschedule.gs_slot_start_time, ';
        $qry .= ' ogre_gameschedule.gs_slot_length, ';
        $qry .= ' ogre_gameschedule.gs_slot_time,';
        $qry .= ' ogre_gameschedule.gs_slot_code';
        $qry .= ' FROM ogre_gameschedule ';
        $qry .= ' WHERE ogre_gameschedule.gs_convention_id = ' . $conid;
        $qry .= ' AND ogre_gameschedule.gs_affiliation = "' . $aff . '" ';
        $qry .= ' AND ogre_gameschedule.gs_slot_day = "' . $day . '" ';
        $qry .= ' ORDER BY ogre_gameschedule.gs_slot_code';
        $starts = $ci->db->query($qry);
        if ($starts->getNumRows() > 0){
            foreach ($starts->getResult() as $startsrow){                                          
                $ret[$i][0]=$startsrow->gs_slot_start_time; 
                $ret[$i][1]=$startsrow->gs_slot_length;
                $ret[$i][2]=$startsrow->gs_slot_time;
                $i++;
            }
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getSlotLengths($aff, $conid){
        $ci=get_instance();
        $i=0;
        $ret=array();
        $qry = 'SELECT DISTINCT ogre_gameschedule.gs_slot_length FROM ogre_gameschedule ';
        $qry .= ' WHERE ogre_gameschedule.gs_convention_id = ' . $conid;
        $qry .= ' AND ogre_gameschedule.gs_affiliation = "' . $aff . '"';

        $slotlen = $ci->db->query($qry);

        if ($slotlen->getNumRows() > 0)
        {
            foreach ($slotlen->getResult() as $slotlenrow)
            {                                          
                $ret[$i]=$slotlenrow->gs_slot_length; 
                $i++;
            }
        }

        return $ret;
    }
    //---------------------------------------------------
    //
    //---------------------------------------------------
      public function reset_enums($conid=0){
//                      Day Slots
        $ret1 = $this->gen_row_enum(0, $conid);
        $ret1 = $this->genSlotEnum($conid, 0);
//                      Late Slots
        $ret1 = $this->gen_row_enum(1, $conid);
        $ret1 = $this->genSlotEnum($conid, 1); 
        
        return $ret1;
      }
}
?>
