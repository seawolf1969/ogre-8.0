<?php
namespace App\Libraries;
use CodeIgniter\I18n\Time;

 class Schedule_lib{   
    //---------------------------------------------------

    //---------------------------------------------------
    public function gameScheduleX($conid, $p, $gameid=0, $whatsnew=FALSE, $dmode='P'){
        $ci = &get_instance();                     
        $ret ='';
        $accessrating = 0;
        $curr_userid = $ci->session->ogre_user_ID;
        if ($curr_userid != 0){
            $ci->person->init($conid, '', $curr_userid);
            $accessrating = $ci->person->access_rating;
        }                                                   
        return  $ret;
    }     
    //---------------------------------------------------
    //
    //---------------------------------------------------                
    public function gameSchedulexFiltersBottom($dm='P'){
        $ci = &get_instance();                     
        $ret ='';                    
        $ret .= '<div class="col-6 '.(($ci->agent->isMobile())? ' text-center ' : ' text-end ').'">'; 
        $ret .= '<div  id="search-criteria-top'.(($dm=='N') ? '-panels':'').'">';
        $action = site_url('ogrex/getScheduleBreakDown');
        $buttonlabel = (($dm == 'P') ? 'TOTAL GAME EVENTS' :'TOTAL PANELS/CON EVENTS');
        $ret .= ' <button type="button" class="btn btn-primary" onclick="break_down('."'".$action."',".$ci->session->ogre_conid.','.(($ci->agent->isMobile()) ? '0.90' : '0.50').','."'".$dm ."'".');">';
        
        $ret .= $buttonlabel .': ';
        $ret .= $this->gameSchedulexCount($dm);
        $ret .= '</button>';
        $ret .= '</div>';
        $ret .= '</div>';
        return $ret;                    
    }
                
    //---------------------------------------------------
    //
    //
    //
    //--------------------------------------------------- 
    public function gameScheduleXDisplay($dmode="P"){
        $ci = &get_instance();                      
        $ret ='';                    
        $image_properties = array('src' =>'images/ajax-loader.gif','alt'=>'ajax-loader.gif'); 
        $ret .= '<div id="'.(($dmode=='P')?'wait':'waitN').'">' . img($image_properties) . '</div>';                     
        $ret .= '<div id="schedule-view'.(($dmode=='P')?'':'-panels').'">';
        $ret .= '<div id="no-schedule-displayed'.(($dmode=='P')?'':'-panels').'">';
        $ret .= '<div class="alert alert-warning text-center my-2">';     
        $ret .= $ci->ogre_lib->getMiscContent('%%EMPTYSCHEDULE%%',0,TRUE);
        $ret .= '</div>';
        $ret .= "</div>";                      
        $ret .= '</div>';   
        return $ret;
    }             
                
    //---------------------------------------------------
    //
    //
    //
    //--------------------------------------------------- 
    public function gameScheduleXBody($conid, $p, $dmode){                
        $ret = '<div id="gameschedule_main">';
        $ret .= $this->scheduleSearchTopx($conid, $p, $dmode);
        $ret .= $this->gameScheduleXDisplay($dmode); 
        $ret .= '</div>';
        return $ret;
    }
    //---------------------------------------------------
    //
    //
    //
    //---------------------------------------------------                
    public function gameSchedulexCount($dm='P', $new=FALSE){
        $ci = &get_instance();
        $conid = $ci->session->ogre_conid;
        $sql = 'SELECT gs_id FROM ogre_gameschedule WHERE gs_convention_id='.$conid;
        $sql.= ' AND gs_cancelled=0 AND gs_displaymode = "' . $dm . '" ';
        $sql .=  (($new===TRUE) ? ' AND ogre_gameschedule.gs_date_last_modified >= SUBDATE(CURDATE(), INTERVAL 14 DAY) ' : '');     
        $query = $ci->db->query($sql);
        $ret = $query->getNumRows();  
        return $ret;
    }

//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function gameSchedule($p, $conid, $gameid=0, $whatsnew=FALSE, $dmode='P', $mode='all', $span="2W"){                   
        
        $ci = &get_instance();                  
        $ret ='';
        $sql='';
        $access_rating=0;
        $verified=0;
        $orgid = $ci->session->ogre_orgid;
        $curr_userid = $ci->session->ogre_user_ID;
        if ($curr_userid != 0){
            $access_rating= $ci->session->get('ogre_user_accesslevel_' . $orgid);
            $verified= $ci->session->get('ogre_user_activated_' . $conid);
        }
        
        if($dmode !== "N"){
            if ($gameid != 0){	
                $p = ["gameslot" => "0", "affiliation" => "0", "gametype" => "0", "keyword" => "", "gm_name" => "0"];
                $whatsnew = FALSE;
            }
            elseif ($whatsnew === TRUE){
                $gameid= -1;
                $p["gameslot"] = "0";
            }	 
            else{
                $gameid = -1;
                $whatsnew = FALSE;
            }            
            if (isset($p["gameslot"])){                         
                $sql = $this->buildGamingScheduleSQL($whatsnew, $p, $gameid, FALSE, '', $conid, $dmode, $span);
            } 
            elseif ($gameid != -1){
                $sql = $this->buildGamingScheduleSQL($whatsnew, $p, $gameid, FALSE, '', $conid, $dmode, $span);
            }
        } else{
            if ($gameid != 0){	
                $p = array("panelslot" => "0", "affiliation" => "0", "gametype" => "0", "pkeyword" => "", "mod_name" => "0");
                $whatsnew = FALSE;
            }
            elseif ($whatsnew === TRUE){
                $gameid= -1;
                $p["panelslot"] = "0";
            }	 
            else{
                $gameid = -1;
                $whatsnew = FALSE;
            }
            if (isset($p["panelslot"])){                         
                $sql = $this->buildGamingScheduleSQL($whatsnew, $p, $gameid, FALSE, '', $conid, $dmode, $span);
            } 
            elseif ($gameid != -1){
                $sql = $this->buildGamingScheduleSQL($whatsnew, $p, $gameid, FALSE, '', $conid, $dmode, $span);
            }               
        }
        
        $rcount = 0;
        $STemp = 0;
//        $ret .= $ci->ogre_lib->getMiscContent('%%PLAYGMBUTTONINST%%',$conid,TRUE);
//  <!------------------------------------------- GAMES SCHEDULE TABLE ------------------------------------------->
        $ret .= '<div class="table-responsive">';
        $ret .= '<table class="table table-striped table-hover m-2" id="game-schedule-table'.($dmode=='N' ? '-panels':'').'" >';  
        if ($curr_userid != 0){
                $ret .= '<tr style="display:none;">';
                $ret .= '<td  ' . ((!$ci->agent->isMobile()) ? 'colspan="4"' : '') . ' class="players-game-list" id="players-game-list'.(($dmode=='N') ? '-panels':'').'">';
                $ps = $ci->person->getPlayerScheduleRoles($conid,$curr_userid);
                $ret .= $ps;
                $ret .= '</td>';
                $ret .= '</tr>';                                    
        }
        else{
                $ret .= '<tr style="display:none;">';
                $ret .= '<td  ' . ((!$ci->agent->isMobile()) ? 'colspan="4"' : '') . ' class="players-game-list"  id="players-game-list'.(($dmode=='N') ? '-panels':'').'">';
                $ret .= '';
                $ret .= '</td>';
                $ret .= '</tr>';                            
        }
        if($sql!=''){  
            $query = $ci->db->query($sql);                   
            if($query->getNumRows() > 0){ 
                foreach ($query->getResult() as $row_gs){
                    if($STemp != $row_gs->start_code){  
                        $rcount = 0;
                        $ret .= $this->buildGameScheduleRowHeaderStart($row_gs->start_day_time);
                    }                                
                    $ret .= ((($rcount % 2) == 1) ? '<tr id="gsrow'.$row_gs->gs_id.'" class="oddrowcolor">' : '<tr id="gsrow'.$row_gs->gs_id.'" class="evenrowcolor">');
                    $ret .= $this->buildGameScheduleRow($row_gs->gs_id, $access_rating, $verified, $dmode);
                    $ret .= '</tr>';
                    $STemp = $row_gs->start_code;
                    $rcount ++;
                }
                $ret .= '<tr>';
                $ret .= '<td ' . (!$ci->agent->isMobile() ? 'colspan="4"' : '') . ' class="numberdisplayed" id="numberdisplayed'. ($dmode=='N' ? '-panels':'').'">';
                $ret .= '<p>Events Displayed: ' . $query->getNumRows() .'</p>';
                $ret .= '</td>';
                $ret .= '</tr>';                              
                } 
                else{
                    $ret .= '<tr>';
                    $ret .= '<td>';

                    $ret .= '<table class="no-schedule-displayed" id="no-schedule-displayed'.($dmode=='N' ? '-panels':'').'">';
                    $ret .= '<tr>';
                    $ret .= '<td>';
                    if($dmode != "N"){
                        $msg = $ci->ogre_lib->getMiscContent('%NO_SCHEDULE_POSTED%', $conid);
                        $ret .= '<h4 class="text-warning">'.$msg['content'].'</h4>';
                    }
                    else{
                        $msg = $ci->ogre_lib->getMiscContent('%NO_PANELSCHEDULE_POSTED%', $conid);
                        $ret .= '<h4 class="text-warning">'.$msg['content'].'</h4>';
                    }
                    $ret .= '</td>';
                    $ret .= '</tr>';
                    $ret .= '</table>';                                                                 
                    $ret .= '</td>';
                    $ret .= '</tr>';
                }
            }
        else{
                    $ret .= '<tr>';
                    $ret .= '<td>';
                    $ret .= '<table class="no-schedule-displayed" id="no-schedule-displayed'.($dmode=='N' ? '-panels':'').'">';
                    $ret .= '<tr>';
                    $ret .= '<td>';                                
                    $ret .= '<h4>CLICK DISPLAY SCHEDULE.</h4>';
                    $ret .= '</td>';
                    $ret .= '</tr>';
                    $ret .= '</table>'; 
                    $ret .= '</td>';
                    $ret .= '</tr>';                        
        }       
        if ($curr_userid != 0){
            $ret .= '<tr>';
            $ret .= '<td  ' . (!$ci->agent->isMobile() ? 'colspan="4"' : '') . '  class="playersgamelist_colorcodes" id="playersgamelist_colorcodes'.($dmode=='N' ? '-panels':'').'">';
            $ret .= (!$ci->agent->isMobile() ? $this->getPlayerScheduleColorCodes() : '');
            if(strpos($ps,'R') !==FALSE){
                $ret .= '<span id="psvolmsg"> You have Volunteer Hours.  Please check Click My Schedule to see those.</p></span>';
            }
            $ret .= '</td>';
            $ret .= '</tr>';   
        }
        $ret .= '</table>';
        $ret .= '</div>';

        $ret .= '<div id="gamesearchinstr">';
        $bottom = $ci->ogre_lib->getMiscContent('%SCHEDULE_BROWSER_BOTTOM%');
        $ret .= $bottom['content'];
        $ret .= '</div>'; 
        return  $ret;
    }
                
//---------------------------------------------------
//
//---------------------------------------------------
    private function getPlayerScheduleColorCodes(){
        $ret = '<div class="pscolorcodes">';
        $ret .= '<span id="psccGM">Game Master or a Host</span> &nbsp;';
        $ret .= '<span id="psccPLC">Confirmed Player</span> &nbsp;';       
        $ret .= '<span id="psccPLU">Alternate Player</span> &nbsp;';
        $ret .= '<span id="psccVOL">Volunteer</span>';                      
        $ret .= '</div>';
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    private function buildGameScheduleRowHeader($slotday, $slottime){
        $ci=&get_instance();
        $ret = '';
        $ret .= '<tr>';
        $ret .= '<td  ' . (!$ci->agent->isMobile() ? 'colspan="4"' : '') . ' class="slotdaytime">';
        $ret .= ((!$ci->agent->isMobile()) ? '<h3>' : '<h4>');
        $ret .= $slotday . " " .  $slottime;
        $ret .= ((!$ci->agent->isMobile()) ? '</h3>' : '</h4>');
        $ret .= '</td></tr>';
        $ret .= '<tr id="game-schedule-table-header">';
        $ret .= '<th class="sched-game">'. ((!$ci->agent->isMobile()) ? '<spam style="margin:0 10px 0 5px">GAME ID</span>Game/Type/Tag' :  'Game Event') . '</th>';
        if (!$ci->agent->isMobile()){
            $ret .= '<th class="sched-signup" > Play </th>';
            $ret .= '<th class="sched-open">Open Seats</th>';
            $ret .= '<th class="sched-signup" > GM </th>';
        }
        $ret .= '</tr>';                                        
        return $ret;
    }                

  //---------------------------------------------------
//
//  
//
//---------------------------------------------------
    private function buildGameScheduleRowHeaderStart($starttime){
        $ci=&get_instance();
        $ret = '';
        $ret .= '<tr>';
        $ret .= '<td  ' . (!$ci->agent->isMobile() ? 'colspan="4"' : '') . ' class="slotstart">';
        $ret .= ((!$ci->agent->isMobile()) ? '<h3>' : '<h4>');
        $ret .= $starttime;
        $ret .= (!$ci->agent->isMobile()) ? '</h3>' : '</h4>';
        $ret .= '</td></tr>';
        $ret .= '<tr id="game-schedule-table-header">';
        $ret .= '<th class="sched-game">'. ((!$ci->agent->isMobile()) ? '<span style="margin:0 10px 0 15px;">GAME ID#</span><span style="margin:0 10px 0 15px;">Game Event</span><span style="margin:0 10px 0 35px;">Type/Tag</span>' :  'Game Event') . '</th>';
        if (!$ci->agent->isMobile()){
            $ret .= '<th class="sched-signup" > Play </th>';
            $ret .= '<th class="sched-open">Open Seats</th>';
            $ret .= '<th class="sched-signup" > GM </th>';
        }
        $ret .= '</tr>';                                        
        return $ret;
    }                 
                
//---------------------------------------------------
//
//---------------------------------------------------
    public function getDisplayMode($dm){
        $ci = &get_instance();                   
        $qry='SELECT ogre_displaymode.dm_mode FROM ogre_displaymode WHERE dm_modecode = "' . $dm . '";';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                        $ret = $row->dm_mode;
                }
        }
        return $ret;                    
    }

//---------------------------------------------------
//
//  BUILD GAMINIG SCHEDULE SQL  
//
//---------------------------------------------------
    public function buildGamingScheduleSQL($whatsnew, $p, $gameid, $grid, $sday, $conid=0, $dmode='P', $span="2W", $collist='', $cancel=0){
        $where = '';
        $where2 = '';
        if($whatsnew===FALSE){
            $sql = 'SELECT ';
            if(isset($p["gm_name"])){
                if($p["gm_name"]!="0"){
                    $sql .= ' ogre_prereg_player.pp_player_id,';
                    $sql .= ' pp_gm_judge_flag,';
                }   
            }
            $sql .= ' SUBSTR(ogre_gameschedule.gs_slot_code,1,4) as start_code, ';
            $sql .= ' CONCAT(ogre_gameschedule.gs_slot_day," ", TIME_FORMAT(ogre_gameschedule.gs_slot_start_time,"%r")) as start_day_time,';            
            if($collist==''){ 
                $sql .= ' ogre_gameschedule.gs_id, ';
                $sql .= ' ogre_gameschedule.gs_slot_code, ';
                $sql .= ' ogre_gameschedule.gs_slot_time, ';
                $sql .= ' ogre_gameschedule.gs_cancelled, ';
                $sql .= ' ogre_gameschedule.gs_displaymode, ';
                $sql .= ' ogre_gameschedule.gs_table_number, ';
                $sql .= ' ogre_gameschedule.gs_slot_day, ';
                $sql .= ' ogre_preregistergamelist.pgl_gs_id, ';
                $sql .= ' ogre_gameschedule.gs_roll_up_game, ';
                $sql .= ' ogre_gameschedule.gs_convention_id, ';
                $sql .= ' ogre_gameschedule.gs_game_name, ';
                $sql .= ' ogre_gameschedule.gs_game_title, ';
                $sql .= ' ogre_gameschedule.gs_affiliation, ';
                $sql .= ' ogre_rpga_game_setup.rgs_gs_id, ';
                $sql .= ' ogre_rpga_game_setup.rgs_active, ';
                $sql .= ' ogre_gameschedule.gs_game_type, ';
                $sql .= ' ogre_gameschedule.gs_slot_length,  ';
                $sql .= ' ogre_gameschedule.gs_slot_start_time,  ';
                $sql .= ' ogre_gameschedule.gs_max_number_of_players,  ';
                $sql .= ' ogre_gameschedule.gs_descriptorlist,  ';
                $sql .= ' ogre_rpga_game_setup.rgs_active ';
            } else {
                $sql .= $collist;
            }
            $sql .= ' FROM ';
            $sql .= '((ogre_gameschedule LEFT JOIN ogre_preregistergamelist ';
            $sql .= ' ON ogre_gameschedule.gs_id = ogre_preregistergamelist.pgl_gs_id) ';
            $sql .= ' LEFT JOIN ogre_rpga_game_setup ';
            $sql .= ' ON ogre_preregistergamelist.pgl_gs_id = ogre_rpga_game_setup.rgs_gs_id)';
// GM NAME JOIN                            
            if(isset($p["gm_name"])){
                if($p["gm_name"] != "0"){
                   $sql .= ' LEFT JOIN ogre_prereg_player ON ogre_gameschedule.gs_id = ogre_prereg_player.pp_gs_id ';
                }
            }
            if(isset($p["mod_name"])){
                if($p["mod_name"] != "0"){
                   $sql .= ' LEFT JOIN ogre_prereg_player ON ogre_gameschedule.gs_id = ogre_prereg_player.pp_gs_id ';
                }
            }            
            $sql .= ' WHERE ';
// GAME SLOT WHERE 
            if(isset($p['gameslot'])){ 
                if ($p["gameslot"] != '0'){
                    $sql .= ' ('; 				
                    $sql .= (((strtoupper($p["gameslot"]) != "FRIDAY")  && (strtoupper($p["gameslot"]) != "SATURDAY") && (strtoupper($p["gameslot"]) != "SUNDAY")) ? '  ogre_gameschedule.gs_slot_code = "' . $p["gameslot"] . '"' :  '  ogre_gameschedule.gs_slot_day ="' . $p["gameslot"] .'"');
                    $where .=  $p["gameslot"];
                    $sql .= ') '; 			    
                }  
            }
            if($sday != ''){
                $sql .= ((trim($where) != '') ? ' AND ' :  ' ');
                $sql .=  '  (ogre_gameschedule.gs_slot_day ="' . $sday .'")';
            }  
            
            if(isset($p['panelslot'])){ 
                if ($p["panelslot"] != '0'){
                    $sql .= ' ('; 				
                    $sql .= (((strtoupper($p["panelslot"]) != "FRIDAY")  && (strtoupper($p["panelslot"]) != "SATURDAY") && (strtoupper($p["panelslot"]) != "SUNDAY")) ? '  ogre_gameschedule.gs_slot_code = "' . $p["panelslot"] . '"' :  '  ogre_gameschedule.gs_slot_day ="' . $p["panelslot"] .'"');
                    $where .=  $p["panelslot"];
                    $sql .= ') '; 			    
                }  
            }
            if($sday != ''){
                $sql .= ((trim($where) != '') ? ' AND ' :  ' ');
                $sql .=  '  (ogre_gameschedule.gs_slot_day ="' . $sday .'")';
            }              
//  KEYWORD WHERE
            if(isset($p['keyword'])){
                $sql .= $this->buildGamingScheduleSQLKeyword($p, $where, $dmode);
                $where .=  ((trim($p["keyword"]) != '') ? $p["keyword"] : '');
            }

            if(isset($p['pkeyword'])){ 
                $sql .= $this->buildGamingScheduleSQLKeyword($p, $where, $dmode);
                $where .=  ((trim($p["pkeyword"]) != '') ? $p["pkeyword"] : '');
            }            
//          GAME/PANEL NAME WHERE
            if(isset($p['gamename'])){
                if(!is_array($p['gamename'])) {
                    if(trim($p['gamename'])!=="0"){
                        $sql .= $this->buildGamingScheduleSQL_gamename($p, $where, $dmode);
                        $where .= "Game Name";
                    }
                }
                else{
                    if($p['gamename'][0] !== "0"){
                        $sql .= $this->buildGamingScheduleSQL_gamename($p, $where, $dmode);
                        $where .= "Game Name";
                    }
                }             
            }   
            if(isset($p['panelname'])){
                if(!is_array($p['panelname'])) { 
                    if(trim($p['panelname'])!=="0"){
                       $sql .= $this->buildGamingScheduleSQL_gamename($p, $where, $dmode);
                       $where .= "Panel Name";
                    }
                } 
                else{
                    $sql .= $this->buildGamingScheduleSQL_gamename($p, $where, $dmode);
                    $where .= "Panel Name";                
                }                
            }

            
//          GAME TYPE WHERE
            if(isset($p['gametype'])){
                $sql1 = $this->buildGamingScheduleSQL_gametype($p, $where);
                $where .= ((trim($sql1) != '') ? 'gametype' : ''); 
                $sql .= $sql1;
            }
            
//          GM WHERE                            
            if(isset($p['gm_name'])){
                $sql1 = $this->buildGamingScheduleSQL_gm($p, $where);
                $where .=  ((trim($sql1) !== '') ? $p['gm_name'] : '');
                $sql .= $sql1;
            }
            if(isset($p['descriptor'])){    
                if($p['descriptor'] <> ''){
                    if($p['descriptor'][0] !== "0"){
                        $sql1 = $this->buildGamingScheduleSQL_descriptor($p, $where); 
                        $where .=  "descriptor";    
                        $sql .= $sql1;
                    }    
                }
            }
            if(isset($p['whatsnewspan'])){
                if(($p['whatsnewspan'] <> '') && ($p['whatsnewspan'] <> '0')){
                    $sql .= $this->buildGamingScheduleSQLWhatsNew($p['whatsnewspan'], $where);
                    $where .=  "whatsnew";
                }
            }
            $sql .= ((trim($where) !== "") ? ' AND ' : '');
            $sql .= ' ogre_gameschedule.gs_convention_id = ' . $conid . '';
            $sql .= ' AND (ogre_rpga_game_setup.rgs_active <> 0  ';
            $sql .= ' OR ogre_rpga_game_setup.rgs_active IS NULL) ';
            $sql .= (($cancel >= 0) ? ' AND ogre_gameschedule.gs_cancelled = ' . $cancel : '');
            $sql .= ((trim($dmode) != '' ) ? ' AND ogre_gameschedule.gs_displaymode = "' . $dmode . '" ' : ' AND ogre_gameschedule.gs_displaymode <> "" ');
            $where = 'BASE';
//  OTHER FILTERING 	
            $other1 = $this->buildGamingScheduleSQLOther($gameid, $where, $where2);
            $where .= ((trim($other1) != '') ? 'OTHER' : '');
            $sql .= $other1;
//  SPECIFIC SLOT DAY            
            $sql .= (($grid === TRUE) ? ' AND ogre_gameschedule.gs_slot_day = "' . $p['gameslot'] . '"' :  ' ');
//  ORDER BY
            if ($grid != TRUE){
                $sql .= ' ORDER BY ';
                $sql .= ' start_code, ';
                $sql .= ' ogre_gameschedule.gs_game_name, ';
                $sql .= ' ogre_gameschedule.gs_game_title, ';
                $sql .= ' ogre_gameschedule.gs_table_number, ';
                $sql .= ' ogre_gameschedule.gs_affiliation';
            }
            else{
                $sql .= ' ORDER BY ';
                $sql .= ' ogre_gameschedule.gs_game_type, ';
                $sql .= ' ogre_gameschedule.gs_affiliation, ';
                $sql .= ' ogre_gameschedule.gs_slot_code, ';
                $sql .= ' ogre_gameschedule.gs_game_name,  ';
                $sql .= ' ogre_gameschedule.gs_game_title';
            }  
        }
        else{
            $sql = $this->buildGamingScheduleSQLWhatsNewAuto($conid, $span, $dmode);
        }

        return $sql;
    }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------                  
    private function buildGamingScheduleSQLKeyword($p, $where, $dmode){    
        $sql='';
        
        switch($dmode){
            case "P":
                if(trim($p["keyword"]) != ''){
                    if(is_numeric(trim($p["keyword"])) && trim($p["keyword"]) != '0' ){
                        $sql .= (trim($where) != '') ? ' AND ' :  ' ';
                        $sql .= ' ogre_gameschedule.gs_id = ' . intval(urldecode(trim($p["keyword"]))). ' ';
                    }
                    else{
                        $sql .= (trim($where) != '') ? ' AND ' :  ' ';
                        $sql .= ' (ogre_gameschedule.gs_game_name LIKE "%' . urldecode(trim($p["keyword"])) . '%"' . ' OR  ogre_gameschedule.gs_game_title LIKE "%' . urldecode(trim($p["keyword"])) . '%")';
                    }
                } 
            break;
            case "N":
                if(trim($p["pkeyword"]) != ''){
                    if(is_numeric(trim($p["pkeyword"])) && trim($p["pkeyword"]) != '0' ){
                        $sql .= (trim($where) != '') ? ' AND ' :  ' ';
                        $sql .= ' ogre_gameschedule.gs_id = ' . intval(urldecode(trim($p["pkeyword"]))). ' ';
                    }
                    else{                
                        $sql .= (trim($where) != '') ? ' AND ' :  ' ';
                        $sql .= ' (ogre_gameschedule.gs_game_name LIKE "%' . urldecode(trim($p["pkeyword"])) . '%"' . ' OR  ogre_gameschedule.gs_game_title LIKE "%' . urldecode(trim($p["pkeyword"])) . '%")';
                    }
                }
            break;
            default:
                $sql = '';
        }
        return $sql;
    }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------                  
    private function buildGamingScheduleSQLOther($gameid, $where, $where2){
        $sql = '';
        if (($gameid == 0) OR ($gameid == -1)){
            $sql .= (trim($where) != '') ? ' AND ' :  ' ';
            $sql .= ' ogre_gameschedule.gs_roll_up_game = 0  ';
        } elseif (is_array($gameid) === TRUE) {
            $sql .= (trim($where) != '') ? ' AND (' :  ' (';
            foreach ($gameid as $gid){
                if(($gid != -1) && (trim($gid) != '')){ 
                    $sql .= (trim($where2) != '') ? ' OR ': '';
                    $sql .= '  ogre_gameschedule.gs_ID = ' . $gid;
                    $where2 .=  $gid;
                }    
            } 
            $sql .= ') '; 
        }
        return $sql;
    }
                
                
//---------------------------------------------------
//
//  
//
//---------------------------------------------------                  
    private function buildGamingScheduleSQL_gm($p, $where){    
        $sql = '';
        if((trim($p['gm_name']) != '0') && (trim($p['gm_name']) != '')){
            $sql .= (trim($where) != '') ? ' AND ' :  ' ';
            $sql .= ' ( ';
            if(!isset($p['my-schedule'])){   
                $sql .= ' ABS(ogre_prereg_player.pp_gm_judge_flag) = 1 AND';
            }
            $sql .= ' ogre_prereg_player.pp_player_id = "' . $p['gm_name'] . '"';
            $sql .= ' AND ogre_prereg_player.pp_delete_flag = 0  ';  
            $sql .= ') ';
        }	                
        return $sql;
    }
                
//---------------------------------------------------
//
//  
//
//---------------------------------------------------                  
    private function buildGamingScheduleSQL_gametype($p, $where){
        $sql = '';
        if(is_array($p['gametype'])){
            foreach($p['gametype'] as $gt){
                    $sql .= ($gt !=='0') ? ' ogre_gameschedule.gs_game_type = "' . $gt . '" OR ' : '';
            }
            $sql = (trim($sql) != '') ? (substr($sql,0,strlen($sql)-4)) : '';
            
            $sql = (trim($sql) != '') ? (((trim($where) != '') ? ' AND (' :  ' (') . $sql . ') ') : '';
        }
        else{
            $sql .= ((trim($p['gametype']) != '0') && (trim($p['gametype']) != '')) ?  ((trim($where) != '') ? ' AND ' :  ' ') . ' ogre_gameschedule.gs_game_type = "' . $p['gametype'] . '"' : '';
        }  
        return $sql;
    }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------                  
    private function buildGamingScheduleSQL_gamename($p, $where, $dmode='P'){
        $sql = '';
        
        $gname = ($dmode == 'N') ? 'panelname' : 'gamename';
        if(is_array($p[$gname])){
            foreach($p[$gname] as $gn){
                    $sql .= ($gn !=='0') ? ((is_numeric($gn)) ? 'ogre_gameschedule.gs_gn_id = ' . $gn . '' : 'ogre_gameschedule.gs_game_name = "' . $gn . '"') . ' OR ' : '';
            }
            $sql = (trim($sql) != '') ? (substr($sql,0,strlen($sql)-4)) : '';
            
            $sql = (trim($sql) != '') ? (((trim($where) != '') ? ' AND (' :  ' (') . $sql . ') ') : '';
        }
        else{
            if((trim($p[$gname]) != "0") && (trim($p[$gname]) != '')){ 
                $sql .= (trim($where) != '') ? ' AND ' :  ' ';
                $sql .= (is_numeric($p[$gname])) ? 'ogre_gameschedule.gs_gn_id = ' . $p[$gname] . '' : 'ogre_gameschedule.gs_game_name = "' . $p[$gname] . '"';
            }              
        }  
        
        return $sql;
        
        
      
    }                
//---------------------------------------------------
//
//  
//
//---------------------------------------------------       
    private function buildGamingScheduleSQL_descriptor($p, $where){
        $sql = '';
        if(is_array($p['descriptor'])){
            foreach($p['descriptor'] as $gt){
                    $sql .= ($gt !=='0') ? '( (ogre_gameschedule.gs_descriptorlist LIKE "%' . $gt . '%,")' : '';
                    $sql .= ($gt !=='0') ? ' OR ' : '';
                    $sql .= ($gt !=='0') ? ' (ogre_gameschedule.gs_affiliation = "' . $gt . '") ) ' . ' AND ' : '';                       
            }
            $sql = (trim($sql) != '') ? (substr($sql,0,strlen($sql)-4)) : '';
            $sql = (trim($sql) != '') ? (((trim($where) != '') ? ' AND (' :  ' (') . $sql . ') ') : '';
        }
        else{
            $sql .= ((trim($p['descriptor']) != '0') && (trim($p['descriptor']) != '')) ?  ((trim($where) != '') ? ' AND ' :  ' ') . ' ogre_gameschedule.gs_descriptorlist LIKE "%' . $p['gametype'] . '%"' : '';
        }        
        
        return $sql;    
    }        
    
//---------------------------------------------------
//
//  
//
//---------------------------------------------------      
    private function buildGamingScheduleSQLWhatsNew($span, $where=''){
        $sql = '';
        $sql = (trim($where) !== '') ? ' AND ' : '';
        switch ($span){
            case "2W":
                $sql .= ' ogre_gameschedule.gs_date_last_modified > SUBDATE(CURDATE(), INTERVAL 14 DAY) ';
                break;
            case "1W":
                $sql .= ' ogre_gameschedule.gs_date_last_modified > SUBDATE(CURDATE(), INTERVAL 7 DAY) ';
                break;
            case "5D":
                $sql .= ' ogre_gameschedule.gs_date_last_modified > SUBDATE(CURDATE(), INTERVAL 5 DAY) ';
                break;
            case "2D":
                $sql .= ' ogre_gameschedule.gs_date_last_modified > SUBDATE(CURDATE(), INTERVAL 2 DAY) ';
                break;
            case "1D":
                $sql .= ' ogre_gameschedule.gs_date_last_modified > SUBDATE(CURDATE(), INTERVAL 1 DAY) ';
                break;
            default:
                $sql = '';
                break;
        }        
        return $sql;
    }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------                
    private function buildGamingScheduleSQLWhatsNewAuto($conid, $span, $dmode){
        $sql = 'SELECT ';
        $sql .= ' SUBSTR(ogre_gameschedule.gs_slot_code,1,4) as start_code, ';
        $sql .= ' CONCAT(ogre_gameschedule.gs_slot_day," ", TIME_FORMAT(ogre_gameschedule.gs_slot_start_time,"%r")) as start_day_time,';         
        $sql .= ' ogre_gameschedule.gs_id, ';
        $sql .= ' ogre_gameschedule.gs_slot_length,  ';
        $sql .= ' ogre_gameschedule.gs_slot_code, ';
        $sql .= ' ogre_gameschedule.gs_slot_time, ';
        $sql .= ' ogre_gameschedule.gs_cancelled, ';
        $sql .= ' ogre_gameschedule.gs_displaymode, ';
        $sql .= ' ogre_gameschedule.gs_table_number, ';
        $sql .= ' ogre_gameschedule.gs_slot_day, ';
        $sql .= ' ogre_gameschedule.gs_max_number_of_players,  ';
        $sql .= ' ogre_preregistergamelist.pgl_gs_id, ';
        $sql .= ' ogre_gameschedule.gs_roll_up_game, ';
        $sql .= ' ogre_gameschedule.gs_convention_id, ';
        $sql .= ' ogre_gameschedule.gs_game_name, ';
        $sql .= ' ogre_gameschedule.gs_game_title, ';
        $sql .= ' ogre_gameschedule.gs_affiliation, ';
        $sql .= ' ogre_rpga_game_setup.rgs_gs_id, ';
        $sql .= ' ogre_rpga_game_setup.rgs_active, ';
        $sql .= ' ogre_gameschedule.gs_game_type, ';
        $sql .= ' ogre_gameschedule.gs_date_last_modified, ';
        $sql .= ' ogre_rpga_game_setup.rgs_active,  ';
        $sql .= ' ogre_gameschedule.gs_slot_start_time  ';
        $sql .= ' FROM (ogre_gameschedule LEFT JOIN ogre_preregistergamelist  ';
        $sql .= ' ON ogre_gameschedule.gs_id = ogre_preregistergamelist.pgl_gs_id) ';
        $sql .= ' LEFT JOIN ogre_rpga_game_setup ';
        $sql .= ' ON ogre_gameschedule.gs_id = ogre_rpga_game_setup.rgs_gs_id ';  
        $sql .= ' WHERE ';
        $sql .= ' ogre_gameschedule.gs_roll_up_game = 0 ';
        $sql .= ' AND ';
        $sql .= ' (';
        $sql .= ' ogre_rpga_game_setup.rgs_active <> 0 ';
        $sql .= ' OR ogre_rpga_game_setup.rgs_active IS NULL';
        $sql .= ' )';
        $sql .= ' AND (ogre_gameschedule.gs_cancelled = 0) ';
        $sql .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
        switch ($span){
            case "2W":
                $sql .= ' AND ogre_gameschedule.gs_date_last_modified > SUBDATE(CURDATE(), INTERVAL 14 DAY) ';
                break;
            case "1W":
                $sql .= ' AND ogre_gameschedule.gs_date_last_modified > SUBDATE(CURDATE(), INTERVAL 7 DAY) ';
                break;
            case "5D":
                $sql .= ' AND ogre_gameschedule.gs_date_last_modified > SUBDATE(CURDATE(), INTERVAL 5 DAY) ';
                break;
            case "2D":
                $sql .= ' AND ogre_gameschedule.gs_date_last_modified > SUBDATE(CURDATE(), INTERVAL 2 DAY) ';
                break;
            case "1D":
                $sql .= ' AND ogre_gameschedule.gs_date_last_modified > SUBDATE(CURDATE(), INTERVAL 1 DAY) ';
                break;
        }
        $sql .= ($dmode!='') ? ' AND ogre_gameschedule.gs_displaymode = "' . $dmode . '"' : '';
        $sql .= ' ORDER BY ogre_gameschedule.gs_slot_code, ogre_gameschedule.gs_affiliation, ';
        $sql .= ' ogre_gameschedule.gs_game_name, ogre_gameschedule.gs_game_title;';   
        return $sql;
    }
    
//---------------------------------------------------
//
//  BUILD GAMINIG SCHEDULE ROW  refresh
//
//---------------------------------------------------
            public function buildGameScheduleRowRefresh($gsid, $dmode='P'){
                $ci = &get_instance();                  
                $access_rating = 0;
                $verified = 0;
                $orgid = $ci->session->ogre_orgid;	
                $conid = $ci->session->ogre_conid;	
                $curr_userid = $ci->session->ogre_user_ID;               
                if ($curr_userid != 0){
                    $access_rating= $ci->session->get('ogre_user_accesslevel_' . $orgid);
                    $verified= $ci->session->get('ogre_user_activated_' . $conid);
                }
                $ret = $this->buildGameScheduleRow($gsid, $access_rating, $verified, $dmode);
                return $ret;
            }
//---------------------------------------------------
//
//  BUILD GAMINIG SCHEDULE ROW  refresh
//
//---------------------------------------------------            
    public function buildGameScheduleRow1($gsid, $access_rating=0, $verified=0, $mode='all'){
        $ret = '<td class="sched-game">';
        $ret .= $gsid;
        $ret .= '</td>';
        $ret .= '<td id="sched-signup-'.$gsid.'">';
        $ret .= $access_rating;
        $ret .= '</td>';
        $ret .= '<td class="sched-open-'.$gsid.'">';
        $ret .= $verified;
        $ret .= '</td>';
        $ret .= '<td id="sched-gm-signup-'.$gsid.'">';
        $ret .= $mode;
        $ret .= '</td>';  
        return $ret;
    }
                                                           
//---------------------------------------------------
//
//  BUILD GAMINIG SCHEDULE ROW  
//
//---------------------------------------------------
    public function buildGameScheduleRow($gsid, $access_rating=0, $verified=0, $dmode='P'){ 
        $ci = &get_instance();
        $ci->event->event_init($gsid);
        $ret = '<td class="sched-game">';
        $ret .= $this->buildGameScheduleRowGameInfoBoot($dmode, $ci->event, $gsid);
        $ret .=  '</td>';
        $openalt = (intval($ci->event->prereg_opentoalt) == 0) ? FALSE : TRUE;
        if (!$ci->agent->isMobile()) { 
            $ret .=  '<td id="sched-signup-'. $ci->event->id .'">';
            $ret .= '<div class="sched-signup">';
            $preregLink = (intval($ci->event->rpga_game_round) > 1) ? '-' :  $this->getPreregLinkReg(intval($ci->event->prereg_players_allowed), $ci->event->id, $ci->event->mmrpgFlag, $access_rating, $verified, 0, 'PL');
            $ret .= $preregLink;
            $ret .=  '</div>';	
            $ret .=  '</td>';	

            $ret .= '<td class="sched-open">';
            $ret .= '<span id="open-seats-'. $ci->event->id .'">';
            $os = $ci->event->getOpenSeats($gsid);
            if(is_numeric($os)){
                if (intval($os)==0){
                    $tip = ' title="'.(($openalt==TRUE) ? 'One Table full, but open to alternates':'Closed, Alternates Taken Onsite').'" ';
                    $ret .= '<span class="badge bg-pill bg-danger" style="font-size:110%" '.$tip.'>';
                    $ret .= $os;
                    $ret .= '</span>';

                }else{
                    $tip = ' title="'.(($openalt==TRUE) ? 'Seats Available, Open to Alternates':'Seats Open').'" ';
                    $ret .= '<span class="badge bg-pill bg-primary" style="font-size:110%" '.$tip.'>'.$os.'</span>';
                }
            }else{
                 $ret .= '<span class="badge bg-pill bg-warning" style="font-size:110%">'.$os.'</span>';;
            }
            $ret .= '</span>';
            $ret .= '</td>';

            $ret .=  '<td id="sched-gm-signup-'. $ci->event->id .'">';
            $ret .=  '<div class="sched-signup">';
            $preregGMLink = (intval($ci->event->rpga_game_round) > 1) ? '-' : $this->getPreregLinkReg(intval($ci->event->prereg_players_allowed), $ci->event->id, $ci->event->mmrpgFlag, $access_rating, $verified, 1, 'GM');
            $ret .= $preregGMLink;
            $ret .=  '</div>';
            $ret .=  '</td>';  
        }
        return $ret;            
    }
            
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
    public function buildGameScheduleRowGameInfoBoot ($dmode, $gevent, $gsid){   
        $ci = &get_instance();
        $ginfo = site_url('ogrex/getGameInformation','https');
        $regbuttons = 'ogrex/gameRegDialog/' . $gsid;
        $rowrefresh = site_url('ogrex/regularRowRefresh/'.$gsid.'/'.$dmode,'https');
        $rowdiv = 'gsrow'.$gsid;
        $girefresh = site_url('ogrex/gameInfoRefresh/'.$gsid,'https');
        $gidiv ='game-info-dialog';
        $vmode = 'MAIN';            
        $ret = '';   
        $image_expand = array('title' => 'Click to Toggle Summary','onclick' => 'toggleSummaryList('.$gsid.')','class'=>'drill-down-icon-img','style'=>'display:block; margin-left: 3px; margin-right: 3px','src' =>'images/expand1.png','alt'=>'expand', 'height'=>'18px', 'width'=>'18px','id'=>'ddicon0'.$gsid); 
        $image_collapse = array('title' => 'Click to Toggle Summary','onclick' => 'toggleSummaryList('.$gsid.')','class'=>'drill-down-icon-img','style'=>'display:none; margin-left: 3px; margin-right: 3px','src' =>'images/collapse1.png','alt'=>'collapse', 'height'=>'18px', 'width'=>'18px','id'=>'ddicon1'.$gsid);           
        $ret .= '<div id="drill-down-'.$gsid.'">';
        $ret .= '<div class="btn-group" role="group" aria-label="Game Info">';
        $ret .= '<span style="margin: 0 10px 0 5px;">' . img($image_expand) . img($image_collapse) . '</span>';
        $ret .= (!$ci->agent->isMobile()) ? '<span style="margin: 0 10px 0 10px;">'. str_pad($gevent->id,5,'0', STR_PAD_LEFT) . '</span>' :  '';
        $gnarray = $this->processGameName($gevent->game_name, $gevent->game_title, $gevent->gameid, $gevent->rpga_exp_level, $gevent->mmrpgFlag,$dmode);
        $ret .= '<span style="margin: 0 10px 0 5px;">' .$this->gameDialogLinkBoot($gnarray['gname'], $gevent->id, $ginfo, $rowrefresh, $rowdiv, $girefresh, $gidiv, $vmode, $dmode, $regbuttons);
        $ret .= '</span></div>';
        if (!$ci->agent->isMobile()){	
            $ret .= '<span class="badge rounded-pill bg-primary m-1"  title="'.$gevent->game_type.'">'.$gevent->game_type.'</span>';  //bg-color-'.strtolower(str_replace(" ","-",str_replace("/","-",$gevent->game_type))).'
            $ret .= ($gevent->mmrpgFlag != 0) ? '<span class="badge bg-pill bg-secondary m-1"  title="Organized Play">OP</span>' : '';
            $ret .= (($gevent->affiliation != "None") &&(trim($gevent->affiliation) != "")) ? '<span class="badge bg-pill bg-secondary m-1"  title="'.$this->getAffiliationTitle($gevent->affiliation).'">'.$gevent->affiliation.'</span>' : '';	
            $ret .= ($gevent->is_new($gevent->id, 14)) ?  '<span class="badge bg-pill bg-success"  title="New in the past 2 weeks">NEW</span>' : '';
        }              
        $ret .= '<div id="drill-down-details-'.$gsid.'" style="display:none">';
        $ret .= $this->gameInfoDialogBoot($gsid, $dmode, $ginfo, $rowrefresh, $rowdiv, $girefresh, $gidiv, $vmode, $regbuttons);
        $ret .= '</div></div>';
        return $ret; 
  }
            
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
    public function buildGameScheduleRowGameInfo ($dmode, $gevent, $gsid){
        $ci = &get_instance(); 
        $ret = '';
        $ddaction = site_url('ogrex/gmPlayerDDRefresh','https');
        $ginfo = site_url('ogrex/getGameInformation','https');
        $regbuttons = 'ogrex/gameRegDialog/' . $gsid;
        $divid = 'playerinfo'.$gsid;
        $rowrefresh = site_url('ogrex/regularRowRefresh/'.$gsid.'/'.$dmode,'https');
        $rowdiv = 'gsrow'.$gsid;
        $girefresh = site_url('ogrex/gameInfoRefresh/'.$gsid,'https');
        $gidiv ='game-info-dialog';
        $vmode = 'MAIN';        
        $image_properties = array('class'=>'drill-down-icon-img','title'=>'Click to see GM/Player List','style'=>'display:block','src' =>'images/expand1.png','alt'=>'expand', 'width'=>'18px', 'onclick'=>'toggleplayerlist('.$gsid.",'" . $ddaction . "','" . $divid . "'" . ')', 'id'=>'ddicon0'.$gsid); 
        $image_properties1 = array('class'=>'drill-down-icon-img','title'=>'Click to collapse GM/Player List', 'style'=>'display:none','src' =>'images/collapse1.png','alt'=>'collapse', 'width'=>'18px', 'onclick'=>'toggleplayerlist('.$gsid.",'" . $ddaction . "','" . $divid . "'" .')', 'id'=>'ddicon1'.$gsid);                

        $ret .= '<table class="gamedrilldown" id="gamedrilldown'.($dmode=='N' ? '-panels':'').'">';
        $ret .= '<tr>';
        $ret .= ((!$ci->agent->isMobile()) ? '<td class="drilldownicon">'. img($image_properties1) . img($image_properties) .'</td>' :  '' );
        $ret .= '<td class="titleinfo">';
        $ret .= (!$ci->agent->isMobile()) ? str_pad($gevent->id,5,'0', STR_PAD_LEFT) . ' - ' :  '';
        $gnarray = $this->processGameName($gevent->game_name, $gevent->game_title, $gevent->gameid, $gevent->rpga_exp_level, $gevent->mmrpgFlag,$dmode);
        $ret .= $gnarray['gname'];
        //$ret .= $this->gameDialogLink($gnarray['gname'], $gevent->id, $ginfo, $rowrefresh, $rowdiv, $girefresh, $gidiv, $vmode, $dmode, $regbuttons);
        if (!$ci->agent->isMobile()){	
            $ret .= '<span class="badge bg-pill bg-color-'.strtolower(str_replace(" ","-",str_replace("/","-",$gevent->game_type))).' mx-1" title="'.$gevent->game_type.'">'.$gevent->game_type.'</span>';
            $ret .= ($gevent->mmrpgFlag != 0) ? '<span class="badge bg-pill bg-secondary mx-1" title="Organized Play">OP</span>' : '';
            $ret .= (($gevent->affiliation != "None") &&(trim($gevent->affiliation) != "")) ? '<span class="badge bg-pill bg-secondary mx-1" title="'.$this->getAffiliationTitle($gevent->affiliation).'">'.$gevent->affiliation.'</span>' : '';	
            $ret .= ($gevent->is_new($gevent->id, 14)) ?  '<span class="badge bg-pill bg-success">NEW</span>' : '';
        }
        $ret .= '</td>';
        $ret .= '</tr>';

        $ret .= '<tr id="playerdrilldown'.$gevent->id.'">';
        $ret .= '<td>';
        $ret .= '</td>';
        $ret .= '<td>';
        $ret .= '<div class="ddplayerinfo" id="ddplayerinfo'.$gevent->id.'">';
// PLAYER LIST DIV
        $ret .= '</div>';
        $ret .= '</td>';
        $ret .=  '</tr>';                
        $ret .= '</table>';  
        return $ret;
    }
            
            
            
//---------------------------------------------------
//
//  
//
//---------------------------------------------------            
    public function gameDialogLink($gname, $gid, $ginfo='', $rowrefresh='', $rowdiv='', $girefresh='', $gidiv='', $vmode='', $dmode='', $regbuttons=''){
        $ci = &get_instance();
        $ret = '';
        $ret .= '<a '. (!$ci->agent->isMobile() ? 'title="Click the game name for game information, player lists and for GMs to edit their own game."' : '');
        $ret .= ' id="' . $gid . '" name="' . $gid . '" href="#' . $gid . '" ';
        $ret .= ' onclick="return openGIDialog(' . $gid . ",'" .$ginfo. "','". site_url('ogrex/gameEditInx','https');
        $ret .= "','". $rowrefresh."','".$rowdiv."','".$girefresh."','".$gidiv."','".$vmode."','".$dmode."','". ((trim($regbuttons!=="")) ? site_url($regbuttons,'https') : '') ."'" . ');">';
        $ret .= $gname;
        $ret .= '</a>';	                
        return $ret;
    }        
            
//---------------------------------------------------
//
//  
//
//---------------------------------------------------            
    public function gameDialogLinkBoot($gname, $gid, $ginfo='', $rowrefresh='', $rowdiv='', $girefresh='', $gidiv='', $vmode='', $dmode='', $regbuttons=''){
        $ci = &get_instance();
        $ret = '';
        if ($ci->agent->isMobile()){
            $ret .= '<a class="btn text-left btn-sm" ';
            $ret .= ' id="' . $gid . '" name="' . $gid . '" href="#' . $gid . '" ';
            $ret .= ' onclick="return openGIDialog(' . $gid . ",'" .$ginfo. "','". site_url('ogrex/gameEditInx','https');
            $ret .= "','". $rowrefresh."','".$rowdiv."','".$girefresh."','".$gidiv."','".$vmode."','".$dmode."','". ((trim($regbuttons!=="")) ? site_url($regbuttons,'https') : '') ."'" . ');">';
        }
        $ret .= $gname;
        if ($ci->agent->isMobile()){
            $ret .= '</a>';
        }
        return $ret;
    }    
//---------------------------------------------------
//
//  
//
//---------------------------------------------------            
    public function gameDescDialog($gid){
        $ci = &get_instance();                   	
        $ci->event->event_init($gid);                
        $ret ='';
        $ret .= '<h2>' . (($ci->event->mmrpgFlag == 0) ? (($ci->event->displaymode == 'P') ? htmlspecialchars($ci->event->game_name) : htmlspecialchars($ci->event->game_title)) : htmlspecialchars($ci->event->game_title)) . '</h2>';
        $ret .= '<p><span style="font-style:italic">'. (($ci->event->mmrpgFlag == 0) ? (($ci->event->displaymode == 'P') ? htmlspecialchars($ci->event->game_title) : '' )  : htmlspecialchars($ci->event->game_name)) . '</span> ';
        $ret .= (($ci->event->rpga_exp_level <> '') ||($ci->event->rpga_exp_level <> NULL)) ? '<strong>Tier</strong>: ' . $ci->event->rpga_exp_level : '';
        $ret .= '<div class="alert alert-primary">';
        $ret .= $this->gameTagList($gid);
        $ret .= '</div>';        
        $ret .= '<div class="alert alert-success">';
        $ret .= $this->giPlayerBox($gid);
        $ret .= '</div>';
        $ret .= '<p><strong>Day/Time</strong>: ' . $ci->event->slot_day . ' ' . $ci->event->getSlotTime() .'</p>';
        $ret .= '<p><strong>Location</strong>: ' . $ci->event->location_name . ' ';
        $ret .= (trim($ci->event->table_number) != '') ?  ' <strong>Table</strong>: ' . $ci->event->table_number . '</p>' : '';
        $gm = $this->getGMNames($ci->event->id);
        $ret .= (trim($gm) != '') ? '<p><strong>GM/Host</strong>: ' . $gm  . '</p>' : '';
        $ret .= '<p><strong>Type</strong>: ' . $ci->event->game_type . ', ' . $ci->event->event_type;
        if ($ci->event->mmrpgFlag == 0){
            if (trim(strip_tags($ci->event->game_notes)) != ""){
                $ret .= ($ci->event->game_type == "RPG") ? '<p><strong>Adventure Description:</strong></p>' : '<p><strong>Notes:</strong>:</p>';
                $ret .= '<p>'.$ci->event->game_notes.'</p>';
            }
        }
        if ($ci->event->mmrpgFlag == 0){
            if (trim(strip_tags($ci->event->game_desc)) != ""){
                $ret .= '<p>';
                $ret .= '<strong>' . htmlspecialchars($ci->event->game_name) . '</strong>: </p>';
                $ret .= '<p>'. $ci->event->game_desc;
                $ret .= '</p>';
            }                   
            if (trim($ci->event->rpga_rss_scenario_desc) != ''){
                $ret .= '<p>';
                $ret .= '<strong>Scenario Description:</strong> ';
                $ret .= '</p>';
                $ret .= $ci->event->rpga_rss_scenario_desc;
            }
        }
        else{
            if (trim($ci->event->rpga_rss_scenario_desc) != ''){
                $ret .= '<p>';
                $ret .= '<strong>Scenario Description:</strong> ';
                $ret .= '</p>';
                $ret .= '<p>';
                $ret .= nl2br(ascii_to_entities($ci->event->rpga_rss_scenario_desc));
                $ret .= '</p>';
            } 
            if (trim(strip_tags($ci->event->game_desc)) != ""){
                $ret .= '<p>';
                $ret .= '<strong>' . htmlspecialchars($ci->event->game_name) . '</strong>: </p>';
                $ret .= '<p>'. nl2br(ascii_to_entities($ci->event->game_desc,ENT_QUOTES));
                $ret .= '</p>';
            }                    
        }
        if($ci->event->game_list != 0){
            $qry_demolist = 'SELECT ogre_playerschoicelist.pc_game_desc, ';
            $qry_demolist .= ' ogre_playerschoicelist.pc_game_name, ';
            $qry_demolist .= ' ogre_playerschoicelist.pc_num_of_players ';
            $qry_demolist .= ' FROM ogre_playerschoicelist ';
            $qry_demolist .= ' WHERE ogre_playerschoicelist.pc_gs_id = ' . $ci->event->id;
            $query = $ci->db->query($qry_demolist);
            if ($query->getNumRows() > 0){
                $ret .= '<table class="playerschoicelist">';
                $ret .= '<tr><td style="text-align:center;">';
                $ret .= '<strong>PLAYERS CHOICE/DEMO GAME LIST</strong>';
                $ret .= '</td></tr>';
                $ret .= '<tr><td>';
                foreach ($query->getResult() as $row_pc){
                    $ret .= '<p><strong>' . $row_pc->pc_game_name . '</strong> (<span style="font-style:italic;">Players:</span>' . $row_pc->pc_num_of_players . ')</p>';
                    $ret .=  ($query->getNumRows() <= 6) ? '<p>' . nl2br(strip_tags(ascii_to_entities($row_pc->pc_game_desc))) . '</p>' : '<p></p>';
                }
                $ret .= '</td></tr></table>';
            }
        }
        $ret .= $this->giRatings();
        return $ret;
    }
            
//---------------------------------------------------
//
//  
//
//---------------------------------------------------            
    public function gameDescBoot($gid){
        $ci = &get_instance();
        if($ci->event->id == 0){
            $ci->event->event_init($gid);  
        }        
        $ret = [];
        $ret[0] = '<h4> ['. str_pad($ci->event->id,6,'0',STR_PAD_LEFT) . '] '. $ci->event->game_name . ((trim($ci->event->game_title) !=='')? ' - <em>'.$ci->event->game_title . '</em>': '').'</h4>';
        $ret[1] = $this->gameTagList($gid);
        $ret[2] = '<strong>Day/Time</strong>: ' . $ci->event->slot_day . ' ' . $ci->event->getSlotTime();
        $ret[3] = '<strong>Location</strong>: ' . $ci->event->location_name . ' ' . ((trim($ci->event->table_number) != '') ?  '. <strong>Table</strong>: ' . $ci->event->table_number  : '') . ' '. $this->giPlayerBox($gid) . '';
        $ret[4] = '<strong>Type</strong>: ' . $ci->event->game_type . ', ' . $ci->event->event_type . ((($ci->event->rpga_exp_level <> '') ||($ci->event->rpga_exp_level <> NULL)) ? '. <strong>Tier</strong>: ' . $ci->event->rpga_exp_level : ''). '. ['.trim(strip_tags($this->giRatings())).']' ;
        if($ci->event->game_list != 0){
            $qry_demolist = 'SELECT ogre_playerschoicelist.pc_game_desc, ';
            $qry_demolist .= ' ogre_playerschoicelist.pc_game_name, ';
            $qry_demolist .= ' ogre_playerschoicelist.pc_num_of_players ';
            $qry_demolist .= ' FROM ogre_playerschoicelist ';
            $qry_demolist .= ' WHERE ogre_playerschoicelist.pc_gs_id = ' . $ci->event->id;
            $query = $ci->db->query($qry_demolist);
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row_pc){
                    $ret[5] = '<strong>' . $row_pc->pc_game_name . '</strong> (<span style="font-style:italic;">Players:</span>' . $row_pc->pc_num_of_players . ')';
                }
            }
        }
        return $ci->ogre_lib->bootListGroup('mx-4', $ret);
    }            
//---------------------------------------------------
//
//  
//
//---------------------------------------------------  
    public function gameTagList($gid=0){
        $ci = &get_instance();  
        if($ci->event->id == 0){
            $ci->event->event_init($gid);  
        }   
        $ret = '';  
        $tmp = '';
        $tags = explode(",", $ci->event->descriptor_list);
        asort($tags);

        foreach($tags as $tag){
            if((trim($tag) !== '') && ($tag !== $tmp)){
                $ret .= '<span class="badge bg-pill bg-primary" style="font-size:110%">'.$tag.'</span>&nbsp;';
            }
            $tmp = $tag;
        }
        return $ret;
    }            
//---------------------------------------------------
//
//  
//
//---------------------------------------------------                       
    private function giPlayerBox($gid){
        $ci = &get_instance();
        $ret = '';
        $pid = $ci->session->ogre_user_ID;
        
        $openseats = intval($ci->event->getOpenSeats());
        $seats = intval($ci->event->getNumberOfSeats($gid));
        $tables = intval($ci->event->getNumberOfTables($gid));
        $plgm = intval($ci->event->isPlayerGM($pid, $gid));
        $seats = $tables * $seats;
        $openalt = (intval($ci->event->prereg_opentoalt) == 0) ? FALSE : TRUE;
        switch($ci->event->displaymode){
            case 'P':
                if($seats != -1){
                    $ret .= (($ci->event->is_full($gid) === FALSE) ? (($openseats > 0) ? '<span class="badge bg-success mx-2">Open Seats: ' . $openseats . ' out of ' . $seats . '</span>' : '<span class="badge bg-danger mx-2" style="font-size:95%">This Game is FULL</span>') : '<span class="badge bg-danger mx-2" style="font-size:95%">This Game is FULL.</span>');
                    $ret .= (($openalt ==TRUE) ? ' <span class="badge bg-pill bg-info mx-2">Open to Alternates</span>' : '');
                } else {
                    $ret = '<span class="badge bg-warning text-dark">This Game is not Open for Registration.</span>';
                }
                $ret .=  ($plgm == -999) ? '' : (($plgm == 0) ? '<span class="badge bg-pill bg-success mx-2"> You are a Player. </span>' : '<span class="badge bg-pill bg-success"> You are a GM </span>');
                $ret .=  ($plgm == -1) ? '<span class="badge bg-pill bg-success mx-2">(Participating GM)</span>' : '';
                break;
            case 'N':
                $ret = '<span class="badge bg-pill bg-warning mx-2" style="font-size:95%">This is a Discussion Panel Or Convention (non-Gaming) Event</span>';
            break;    
            case 'R':
                $ret = '<span class="badge bg-pill bg-warning mx-2" style="font-size:95%">This is a Personal Schedule Item only visible to you</span>'; 
            break;
        }
        return $ret;               
    }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------               
            private function giRatings(){
                $ci = &get_instance(); 
                $ret = '<p>';
                $ret .= (trim($ci->event->maturity_rate) != "") ?  'Maturity: ' . $ci->event->maturity_rate . " " : '';
                $ret .= ((trim($ci->event->roleplaying_rate) != "") AND (trim($ci->event->roleplaying_rate) != "0")) ? 'RP: ' . $ci->event->roleplaying_rate . " " : '';
                $ret .= ((trim($ci->event->puzzlesolving_rate) != "") AND (trim($ci->event->puzzlesolving_rate) != "0")) ? 'PS: ' . $ci->event->puzzlesolving_rate . " " : '';
                $ret .=  ((trim($ci->event->action_rate) != "") AND (trim($ci->event->action_rate) != "0")) ? 'ACT: ' . $ci->event->action_rate . " " : '';
                $ret .= ((trim($ci->event->complexity_rate) != "") AND (trim($ci->event->complexity_rate) != "0")) ? 'CLX: ' . $ci->event->complexity_rate : '';
                $ret .= '</p>';
                $ret .= '<p>';
                $ret .= (intval($ci->event->game_fee) != 0) ? 'Game Fee: $' . $ci->event->game_fee : '';
                $ret .= '</p>';      
                return $ret;
            }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------            
    public function gameInfoDialogTabs($gid=0, $dmode='P'){
                $ci = &get_instance();
                $ret = '';
                $gid = intval($gid);
                $withemail = FALSE;
                $allowed = $ci->event->getPreregPlayersAllowed($gid);
                $editform = $this->getGameInfoEditTab($gid);
                $orgid = $ci->session->ogre_orgid;
                $pid = $ci->session->ogre_user_ID;
                $ar = $ci->session->get('ogre_user_accesslevel_' . $orgid);
                $ret .= '<div id="tabs">';
                $ret .= '<ul>';
                $ret .= '<li><a href="#tabs-1">Info</a></li>';
                $ret .= ($dmode=='P') ? '<li><a href="#tabs-2">Players</a></li>' : '';
                $ret .= $editform['tab'];
                $ret .= '</ul>';
                $ret .= '<div id="tabs-1">';
                $ret .= '<div id="game-info-dialog">';
                $ret .= $this->gameDescDialog($gid);
                $ret .= '</div>';
                $ret .= '</div>';
                if ($dmode=='P') {
                    if ($allowed != -1){
                        $ret .= '<div id="tabs-2">';
                        $role = $ci->event->isPlayerGM($pid, $gid);
                        $withemail = ($role != -999) ? (($role == 0)? FALSE : TRUE) : FALSE;
                        $withemail = (intval($ar) >= CONADMIN) ? TRUE : $withemail;
                        $numTotlPlayers = $ci->event->getPlayerNum($gid, $allowed);
                        $plist = $ci->event->getPlayerList(1, $gid);
                        $ret .= $this->genPlayeList($gid, $plist, $numTotlPlayers, $withemail, 1);
                        $plist = $ci->event->getPlayerList(0, $gid);
                        $ret .= $this->genPlayeList($gid, $plist, $numTotlPlayers, $withemail, 0);
                        $ret .= '</div>';
                    }
                    else{
                        $ret .= '<div id="tabs-2">';
                        $ret .= '<p>This game is currently not open to preregistration. Contact the Gaming Coordinator is you think this is in error.</p>';
                        $ret .= '</div>';
                    }
                }
                $ret .= $editform['content'];
                $ret .= '</div>';
                
                return $ret;               
    }           
//---------------------------------------------------
//
//  
//
//---------------------------------------------------            
    public function gameInfoDialogBoot($gid=0, $dmode='P', $ginfo='', $rowrefresh='', $rowdiv='', $girefresh='', $gidiv='', $vmode='', $regbuttons=''){
        $ci = &get_instance();
        $ret = '';
        $buttons = '';
        $gid = intval($gid);
        $withemail = FALSE;
        $allowed = $ci->event->getPreregPlayersAllowed($gid);
        $orgid = $ci->session->ogre_orgid;
        $conid = $ci->session->ogre_conid;
        $pid = $ci->session->ogre_user_ID;
        $ar = $ci->session->get('ogre_user_accesslevel_' . $orgid);
        
        if (($dmode!=='R')) {
            if ($allowed != -1){
                $ret .= $this->gameDescBoot($gid);
                $role = $ci->event->isPlayerGM($pid, $gid);
                $withemail = ($role != -999) ? (($role == 0)? FALSE : TRUE) : FALSE;
                $withemail = (intval($ar) >= CONADMIN) ? TRUE : $withemail;
                $numTotlPlayers = $ci->event->getPlayerNum($gid, $allowed);
                $plist = $ci->event->getPlayerList(1, $gid);
                $gms = $this->genPlayerListBoot($gid, $plist, $numTotlPlayers, $withemail, 1);
                $plist = $ci->event->getPlayerList(0, $gid);
                $players = $this->genPlayerListBoot($gid, $plist, $numTotlPlayers, $withemail, 0);
                $ret .= $ci->ogre_lib->bootListGroup('m-4',["0" => $gms,"1" => $players]);
                $buttons = '';               
                $buttons .= '<div class="text-end"> <div class="btn-group m-0">';
                $buttons .= '<a class="btn btn-sm btn-primary me-2" '. (!$ci->agent->isMobile() ? 'title="Click the game name for game information, player lists and for GMs to edit their own game."' : '');
                $buttons .= ' id="more-btn-' . $gid . '" name=""more-btn-' . $gid . '" href="#" ';
                if (trim($ginfo) !== ''){
                    $buttons .= ' onclick="return openGIDialog(' . $gid . ",'" .$ginfo. "','". site_url('ogrex/gameEditInx','https');
                    $buttons .= "','". $rowrefresh."','".$rowdiv."','".$girefresh."','".$gidiv."','".$vmode."','".$dmode."','". ((trim($regbuttons!=="")) ? site_url($regbuttons,'https') : '') ."'" . ');">';
                    $buttons .= 'More Info</a>';
                    $buttons .= '</div></div>';
                    $ret .= $ci->ogre_lib->bootListGroup('m-4',["0" => $buttons]);
                }
                
            }
            else{
                $ret .= $ci->ogre_lib->getMiscContent('%%NOTOPENPREREG%%',$conid,TRUE);
            }
        }
        
        return $ret;               
    }  
//---------------------------------------------------
//
//  
//
//---------------------------------------------------            
    public function getGameInfoEditTab($gameid){    
        $ret['content'] = '';
        $ret['tab'] = '';
        $ci = &get_instance();
        $conid = $ci->session->ogre_conid;                
        $login = $ci->session->ogre_logged_in;
        if($login === TRUE){
            $curr_userid = $ci->session->ogre_user_ID; 
            $ci->person->init($conid, '', $curr_userid);
            $gamegm_id_list = $ci->person->getPlayerSchedule($conid, 1, $curr_userid);
            $reggmlist = explode(',', $gamegm_id_list);
            $gming = in_array($gameid,$reggmlist);
            if($gming === TRUE){
                $ci->event->event_init($gameid);
                if(($ci->event->editable==1) && ($ci->event->mmrpgFlag==0)){
                    $ret['tab'] .= '<li><a href="#tabs-3">Edit</a></li>';
                    $ret['content'] .= '<div id="tabs-3">';
                    $ret['content']  .= $ci->event->gameEditForm($gameid);
                    $ret['content']  .= '</div>';
                }
            }
        }
        return $ret;
    }

//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function processGameName($gn, $gt, $gid=0, $lvl="", $mmrpg="0", $dmode='P'){
        $ci=&get_instance();
        $ret = array();
        $level =  ((strlen(trim($lvl)) > 1) ? (trim($lvl)!=""?' ('.trim($lvl).') ':'') : ((is_numeric($lvl)) ? (intval($lvl) > 0 ? ' ('.trim($lvl).') ' : '') : ''));
        if ($dmode != 'N'){ 
            if(trim($gt) != ''){ 
                $gtitle = str_replace('&','&#38;',$gn) .' - '.str_replace('&','&#38;', $gt);
                $gname = htmlspecialchars($gn, ENT_QUOTES); 
                $gltitle = htmlspecialchars($gt, ENT_QUOTES);
                if (intval($mmrpg)== 0){
                    $gname .= (!$ci->agent->isMobile()) ? ' - <span style="font-style: italic">' . $gltitle  . '</span>' . $level : ' - <span style="font-style: italic">' . $gltitle  . '</span>' . $level ;   
                } else {
                    $gname .= (!$ci->agent->isMobile()) ? ' - <span style="font-style: italic">' . $gltitle  . '</span>' . $level : $gname = $gltitle;
                }
            }
            else{
                    $gtitle = str_replace('&','&#38;',$gn);                              
                    $gname = $gn;
               }
           }
        else{  
           $gtitle = str_replace('&','&#38;',$gt) .' - '.str_replace('&','&#38;',$gn);
           $gname = htmlspecialchars($gt,ENT_QUOTES);
        }
        $ret['gtitle'] = $gtitle;
        $ret['gname'] = $gname;
       return $ret;
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function genPlayerListBoot($evid, $plist, $maxseats=6, $withemail=FALSE, $gm=0){
        $ci=&get_instance();
        $conid = $ci->session->ogre_conid;
        $ret='';         
        $maxseats = (($maxseats == 0) && ($gm == 1)) ? 1 : $maxseats;
        $ret .=  ($gm==0) ? '<strong>Current Player/Participant List</strong>: ' : '<strong>Current GM/Host List</strong>: ';
        $i=1;
        if(is_array($plist)){
            foreach($plist as $player){
                if(trim($player[1]) !=='-'){
                    $ret .= ' (';
                    $ret .= ($i <= $maxseats) ? $i : '<span style="color:#FF0000">?</span>';
                    $ret .= ') ';
                    $logged_in = $ci->session->ogre_logged_in;
                    $act = $ci->session->get('ogre_user_activated_' . $conid);
                    if(($logged_in === TRUE) && ($act == 1)){
                        $ret .= ($withemail==TRUE) ? mailto($player[3], $player[1]) : $player[1];
                    }
                    else{
                        $pname = explode(' ', $player[1]);
                        if(count($pname) > 1){
                            $ret .= trim($pname[0]);
                            $ret .= (trim($pname[1])!='') ? ' ' . substr(trim($pname[1]), 0, 1) . '.' : '';
                        }
                        else{
                            $ret .= trim($player[1]); 
                        }

                    }
                    $ret .=($i > $maxseats) ? ' <span style="color:#FF0000">(A)</span>' : '';
                    $ret .= ',';
                    $i++;
                }
            }
        }
        if(($i===1) && (trim($player[1])==='-')){
            $ret .=  ($gm!=0) ? 'None' : 'None';
                $ret .= ' ';
        }           
//        $ret.='</p>';
        return substr($ret, 0, strlen($ret)-1);
    }       
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function genPlayeList($evid, $plist, $maxseats=6, $withemail=FALSE, $gm=0){
        $ci=&get_instance();
        $conid = $ci->session->ogre_conid;
        $ret='';          
        $maxseats = (($maxseats == 0) && ($gm == 1)) ? 1 : $maxseats;
        $ret .= '<table id="gsplayerlist-'.$gm.'" class="gsplayerlist">';   
        $ret .= '<tr><th colspan="2">';
        $ret .=  ($gm==0) ? 'Current Player/Participant List' : 'Current GM/Host List';
        $ret .= '</th>';
        $ret .= '</tr>';
        $i=1;
        if(is_array($plist)){
            foreach($plist as $player){
                if(trim($player[1]) !=='-'){
                    $ret .= '<tr><td>(';
                    $ret .= ($i <= $maxseats) ? $i : '<span style="color:#FF0000">?</span>';
                    $ret .= ')</td>';
                    $ret .= '<td>';

                    $logged_in = $ci->session->ogre_logged_in;
                    $act = $ci->session->get('ogre_user_activated_' . $conid);

                    if(($logged_in === TRUE) && ($act == 1)){
                        $ret .= ($withemail==TRUE) ? mailto($player[3], $player[1]) : $player[1];
                    }
                    else{
                        $pname = explode(' ', $player[1]);
                        if(count($pname) > 1){
                            $ret .= trim($pname[0]);
                            $ret .= (trim($pname[1])!='') ? ' ' . substr(trim($pname[1]), 0, 1) . '.' : '';
                        }
                        else{
                            $ret .= trim($player[1]); 
                        }

                    }
                    $ret .=($i > $maxseats) ? ' <span style="color:#FF0000">(A)</span>' : '';
                    $ret .= '</td>';
                    $ret .= '</tr>';
                    $i++;
                }
            }
        }
        if(($i===1) && (trim($player[1])==='-')){
                $ret .= '<tr>';
                $ret .= '<td>';
                $ret .= 'No Current Players are signed up.';
                $ret .= '</td>';
                $ret .= '</tr>';
        }
        $ret .= '</table>';            

        return $ret;
    }
     
//---------------------------------------------------
//
//
//
//---------------------------------------------------
    public function gen_playerlist_old($seatsval, $evid, $plist, $maxseats=6, $withemail=FALSE){
            $ci=&get_instance();
            $conid = $ci->session->ogre_conid;
            $ret='';
            $ret .= '<a name="' . $evid . '" id="ID3' . $evid . '" href="#' . $evid . '" onclick="return overlay(this, ' . "'" . 'subcontent3' . $evid . "'" . ', ' . "'" . 'rightbottom' . "'" . ')" >';
            $ret .= $seatsval;
            $ret .= '</a>';
            $ret .= '<div id="subcontent3' . $evid . '"';
            $ret .= ' style="position:absolute;';
            $ret .= ' display: none;';
            $ret .= ' border: 3px solid black;';
            $ret .= ' background-color: silver;';
            $ret .= ' width: 200px;';
            $ret .= ' padding: 4px;';
            $ret .= ' font-family:Arial, Helvetica, sans-serif;';
            $ret .= ' font-size:100%; ';
            $ret .= ' color:#000000">';

            $ret .= '<div style="text-align:right">';
            $ret .= '<a href="#' . $evid . '" onclick="overlayclose(' . "'" . 'subcontent3' . $evid . "'" . '); return false" style="color:#0000FF">Close</a>';
            $ret .= '</div>';            
            $ret .= '<table id="gsplayerlist">';   
            $ret .= '<tr>';
            $ret .= '<td colspan="2">';           
            $ret .= '<p><strong>Current Player List</strong></p>';
            $ret .= '</td>';
            $ret .= '</tr>';
            $i=1;
            foreach($plist as $player){
                $ret .= '<tr>';
                $ret .= '<td>(';
                $ret .=($i <= $maxseats) ? $i : '<span style="color:#FF0000">?</span>';
                $ret .= ')</td>';
                $ret .= '<td>';
                $logged_in = $ci->session->ogre_logged_in;
                $act = $ci->session->get('ogre_user_activated_' . $conid);
                if($logged_in == TRUE && $act == 1){
                    $ret .=($withemail==TRUE) ? mailto($player[3], $player[1]) : $player[1];
                }
                else{
                    $pname = explode(' ', $player[1]);
                    $ret .= (count($pname) > 1) ? $pname[0] . ' ' . substr($pname[1], 0, 1) . '.' :  $player[1];
                }
                $ret .=  ($i > $maxseats) ? ' <span style="color:#FF0000">(A)</span>' : '';
                $ret .= '</td>';
                $ret .= '</tr>';
                $i++;
            }
            $ret .= '</table>';            
            $ret .= '</div>';          
            return $ret;
    }

//---------------------------------------------------
//
//  PREREG LINK FOR REGULAR SCHEDULE
//
//---------------------------------------------------		
    function getPreregLinkReg($pn, $gameid, $mmfg=0, $accessrating=0, $verified=0, $role=0, $col='PL'){
            $ci = &get_instance(); 
            $regplaylist = array();
            $reggmlist = array();
            $playing = FALSE;
            $gming = FALSE;  
            $regrole = 'NONE';
            $ci->event->event_init($gameid);
            $conid = $ci->session->ogre_conid;
            $orgid = $ci->session->ogre_orgid;
            $curr_userid = $ci->session->ogre_user_ID;                   
            $sesslogin = $ci->session->ogre_logged_in;
            $nowstate = (($ci->convention->isBefore($conid)==TRUE) ? 'BEFORE' : ""). ($ci->convention->isClosed($conid)==TRUE ? 'CLOSED' : "")  . ($ci->convention->isOpen($conid)==TRUE ? 'OPEN' : ""); 
            $isfull = $ci->event->is_full($gameid);
            $opentoalt1 = $ci->event->getEventPreregInfo($gameid,'pgl_opentoalt');
            $opentoalt = ($opentoalt1=='') ? '0' : $opentoalt1; 
            $openafterfull = (($opentoalt=='1') ? TRUE : FALSE); 
            if ($curr_userid != 0){
               $gamepl_id_list = $ci->person->getPlayerSchedule($conid, 0, $curr_userid);
               $regplaylist = explode(',', $gamepl_id_list);     
               $playing = in_array($gameid,$regplaylist);
               $gamegm_id_list = $ci->person->getPlayerSchedule($conid, 1, $curr_userid);
               $reggmlist = explode(',', $gamegm_id_list);
               $gming = in_array($gameid, $reggmlist);
               $regrole = (($gming === TRUE) ? "GM" : (($playing === TRUE) ? "PLAY": "NONE"));
            }
            $gmpriv = $ci->ogre_lib->getConfigKey("GM.PRIVILEDGE.FLAG", $orgid);
            $opentoreg = $ci->event->get_preregistergamelist_preregs_allowable($gameid);
            $link = (intval($opentoreg) > 0 ) ? $this->get_prereglinktype($sesslogin, $nowstate, $accessrating, $regrole, $pn, $gmpriv) : (($accessrating >= REGVOL) ? "REG" :"NA");
            $outPutString = ($col != 'DIALOG') ? $this->getPreRegLink($gameid, $conid, $link, $col, $verified, $role, $regrole, $openafterfull, $isfull) : $this->get_preregreg_dialog($gameid, $conid, $link, 'PL', $verified, 0, $regrole, $openafterfull, $isfull).'%'. $this->get_preregreg_dialog($gameid, $conid, $link, 'GM', $verified, 1, $regrole, $openafterfull, $isfull);
            return $outPutString;		
    }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------        
        public function get_prereglinktype($sesslogin, $nowstate, $accessrating, $regrole, $pn, $gmpriv){
            $ci = &get_instance();
            switch ($sesslogin){                                        // LOGGED IN                
                case TRUE: 
                    switch ($nowstate){
                        case "BEFORE":                                  //NOT OPEN YET                 
                            switch ($accessrating){
                                case SUPERADMIN;
                                case ADMIN;
                                case CONADMIN:   
                                    $link = 'REG';
                                    break;
                                case GAMEMASTER:
                                    $link = ($gmpriv==1) ? (($regrole=="NONE") ? "PLAY1" : (($regrole=="PLAY") ? "EDITP" : "EDITG")): "DATE";
                                    break;
                                case PLAYER:
                                    $link = ($pn == 0) ? "ZERO" : "DATE";
                                    break;
                                default:
                                     $link = ($pn == 0) ? "ZERO" : "DATE";
                                    break;
                            }               
                            break;
                        case "CLOSED":                                  //CLOSE EVERYTHING                      
                            switch ($accessrating){
                                case SUPERADMIN;
                                case ADMIN:
                                    $link = 'REG';
                                    break;
                                case CONADMIN;
                                case GAMEMASTER;
                                case PLAYER:
                                    $link = 'CLOSED'; 
                                    break;
                                default:
                                    $link = 'CLOSED';  
                                    break;
                            }                                   
                            
                            break;
                        case "CUTOFFOPEN":                              //OPEN AFTER CUTOFF              
                            switch ($accessrating){
                                case SUPERADMIN;    
                                case ADMIN;
                                case CONADMIN:   
                                    $link = 'REG';
                                    break;
                                case GAMEMASTER:
                                    $link = ($pn == 0) ? "ZERO" : (($regrole=="NONE") ? "PLAY0" : "EDIT");
                                    break;
                                case PLAYER:
                                     $link = ($pn == 0) ? "ZERO" : (($regrole=="NONE") ? "PLAY0" : "EDIT");
                                    break;
                                default:
                                    $link = ($pn == 0) ? "ZERO" : (($regrole=="NONE") ? "PLAY0" : "EDIT");
                                    break;
                            }                                   
                            break;
                        case "OPEN":                                    // OPEN PREREG              
                            switch ($accessrating){
                                case SUPERADMIN;
                                case ADMIN;
                                case CONADMIN:   
                                    $link = 'REG';
                                    break;
                                case GAMEMASTER:
                                    $link = ($pn == 0) ? "ZERO" : (($regrole=="NONE") ? "PLAY1" : "EDIT");
                                    break;
                                case PLAYER:
                                     $link = ($pn == 0) ? "ZERO" : (($regrole=="NONE") ? "PLAY1" : "EDIT");
                                    break;
                                default:
                                    $link = ($pn == 0) ? "ZERO" :(($regrole=="NONE") ? "PLAY1" : "EDIT");
                                    break;
                            }                                    
                            break;
                        default:
                            $link = ($pn == 0) ? "ZERO" : $nowstate;
                            break;
                    }
                break;  
                case FALSE:
                    switch ($nowstate){
                        case "NOTOPEN":
                            $link = 'DATE'; 
                            break;
                        case "CLOSED":                                   //CLOSE EVERYTHING                      
                            $link = 'CLOSED'; 
                            break;
                        case "OPEN0";
                        case "OPEN";
                        case "CUTOFFOPEN";    
                        case "OPEN1":                                   // OPEN PREREG             
                            $link = 'OPEN';     
                            break;  
                        default:
                            $link = "DATE";
                            break;                        
                    }                    
                break;
            }
            
            return $link;
        }
        
//---------------------------------------------------
//
//  
//
//---------------------------------------------------          
        public function getPreRegLink($gameid, $conid, $link, $col, $verified, $role, $regrole, $openafterfull, $isfull){
            $ci = &get_instance(); 
            $ret = '-';
            switch ($link){
                case "OPEN":
                    $ret = ($col=='PL') ? 'Play' : 'GM';
                    break;
                case "PLAY0";
                case "PLAY1":
                    if ($verified > 0){
                        $ret = ($col=='PL') ? ($isfull == TRUE ? (($openafterfull!==TRUE) ?  '<span class="fulltable">FULL</span>' :  $this->autopreregisterx($gameid, $role)) : $this->autopreregisterx($gameid, $role)): $this->autopreregisterx($gameid, $role);
                    }
                    else{
                        $ret =  '<span>' . '<a href="'. site_url('ogre/myprofile#usertab-3').'" class="btn btn-outline-warning btn-sm text-dark" >Activate</a>' . '</span>';                     
                    }
                    break;
                case "EDITG";
                case "EDITP";    
                case "EDIT":
                    if(($regrole.$col==='PLAYPL') || ($regrole.$col==='GMGM') ){
                        $ret =  $this->preregisterEditx('ogrex/preRegFormX/TRUE', $gameid);    
                    }
                    break;                
                case "REG":
                    $ret = ($col=='PL') ? $this->onsite_registerx($gameid) : "&nbsp;";
                    break;
                case "DATE":
                    $start_date = $ci->ogre_lib->getConGamingInfoKey($conid,'con_gaming_reg_open_date');
                    $open_date = new Time($start_date);                    
                    $ret = $open_date->format("M d");
                    break;
                case "CLOSED":
                    $ret = 'Closed';
                    break;
                case "NA":
                    $ret = 'NA';
                    $closedmsg = $ci->ogre_lib->getMiscContent(111);
                    $pnotes = $ci->event->get_prereg_players_notes($gameid);
                    $ret = ($regrole.$col==='PLAYPL') ? $this->preregisterEditx('ogrex/preRegFormX/TRUE', $gameid) : '<a href="#" onclick="'.'return getClosedMsg('."'".  site_url('ogrex/closedMsg/111','https')."','".$closedmsg['title']."','Reason: ".$pnotes."'".')'.'">'. $this->notAvailable(). '</a>';
                    break;                    
                    break;                
                default:
                    $closedmsg = $ci->ogre_lib->getMiscContent(111);
                    $pnotes = $ci->event->get_prereg_players_notes($gameid);
                    $ret = '<a href="#" onclick="'.'return getClosedMsg('."'".  site_url('ogrex/closedMsg/111','https')."','".$closedmsg['title']."','Reason: ".$pnotes."'".')'.'">'. $this->notAvailable(). '</a>';
                    break;
            }
            return $ret;
        }
        
//---------------------------------------------------
//
//  
//
//---------------------------------------------------          
        public function get_preregreg_dialog($gameid, $conid, $link, $col, $verified, $role, $regrole, $openafterfull, $isfull){
            $ret = '';
            $loggedin = '1';
            switch ($link){
                case "OPEN":
                    $loggedin = '0';
                    $ret = 'NOTLOGGED~';
                    break;
                case "PLAY0";
                case "PLAY1":
                    if ($verified > 0){
                        $ret .= ($col=='PL') ? ($isfull == TRUE ? (($openafterfull!==TRUE) ?  'FULL' :  ('REG'.$role)) : 'REG'.$role): 'REG'.$role;
                        $ret .= '~';
                        $ret .= ($col=='PL') ? ($isfull == TRUE ? (($openafterfull!==TRUE) ?  'FULL' :  $this->autopreregisterx($gameid, $role, TRUE)) : $this->autopreregisterx($gameid, $role, TRUE)): $this->autopreregisterx($gameid, $role, TRUE);
                    }
                    else{
                        $ret .=  'ACTIVATE';                     
                        $ret .= '~';
                        $ret .=  'ogre/myprofile#usertab-3';
                    }
                    break;
                case "EDITG";
                case "EDITP";     
                case "EDIT":
                    if($regrole == 'PLAY'){
                        $ret .= 'EDIT.PLAY';    
                        $ret .= '~';
                        $ret .=  $this->preregisterEditx('ogrex/preRegFormX/TRUE', $gameid,'',TRUE);
                    } elseif ($regrole == 'GM'){
                        $ret .= 'EDIT.GM';
                        $ret .= '~';
                        $ret .=  $this->preregisterEditx('ogrex/preRegFormX/TRUE', $gameid,'',TRUE);    
                    }
                    break;                
                case "REG":
                    $ret .= 'REG';
                    $ret .= '~';
                    $ret .= $this->onsite_registerx($gameid, TRUE);
                    break;
                case "NA";
                case "DATE";
                case "ZERO";     
                case "CLOSED":    
                    $ret .= 'CLOSED';
                    $ret .= '~';
                    $ret .= 'x';
                    break;
            }
            return trim($loggedin). '^' . ($ret);
        }        
        
        
        //---------------------------------------------------
        //
        //  
        //
        //---------------------------------------------------	        
        private function notAvailable(){
            $image_properties = array('class'=>'notavailable','title'=>'Not Available','style'=>'','src' =>'images/notavailable.png','alt'=>'Not Available', 'width'=>'40px', 'align'=>'center'); 
            return img($image_properties);
            
        }
    //---------------------------------------------------
    //
    //  
    //
    //---------------------------------------------------
    public function onsite_registerx($id, $linkonly=FALSE){ 
        $ret = '';
        $ci = &get_instance();
        $vmode = $ci->session->viewmode;
        $action = 'ogrex/regFormX/' . $id;
        $gprefresh="";
        switch($vmode){
            case 'MAIN':
                $prereg_action = 'ogrex/regAction/' . $id;
                $divid ='gsrow'.$id;
                $refresh = 'ogrex/regularRowRefresh/' . $id;                             
                break;
            case 'OP':
                $prereg_action = 'ogrex/regAction/' . $id;
                $action = 'ogrex/regFormX/' . $id;
                $divid ='opgicell'. $id;
                $refresh = 'ogrex/opCellRefresh/' . $id;                         
                break;
            default:
                $prereg_action = '';
                $divid ='';
                $refresh = '';                               
                break;   
        }     
        if($linkonly === FALSE){
            $ret .= '<a href="#" title="Open Onsite Registration" class="regbutton" onclick="return registerForm('. "'" . site_url($action,'https') . "'," . $id . ',' . "'" .site_url($prereg_action,'https'). "'". ',' . "'" .$vmode. "'" . ',' . "'" .site_url($refresh,'https'). "'" . ',' . "'" .$divid. "'"  . ')">'; //, , vmode
            $ret .= ' Reg ';
            $ret .= '</a>';
        }
        else{
            $ret .= site_url($action,'https') . "," . $id . ',' . site_url($prereg_action,'https'). ',' . $vmode. ',' . site_url($refresh,'https'). ',' . $divid;            
        }
        return $ret;
    }
                
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
    public function preregisterx($action, $id){
        $ci = &get_instance();
        $vmode = $ci->session->viewmode;
        $pglrefresh = site_url('ogrex/playergamelistrefresh','https');
        $gprefresh = site_url('ogrex/gmPlayerRefresh','https');
        switch($vmode){
            case 'MAIN':
                $prereg_action = site_url('ogrex/preregActionX/' . $id,'https');
                $divid ='gsrow'.$id;
                $refresh = site_url('ogrex/regularRowRefresh/' . $id,'https');  
                $remaction = site_url('ogrex/preregActionX/' . $id . '/TRUE/TRUE','https');                            
                break;
            case 'OP':
                $prereg_action = site_url('ogrex/preregActionX/' . $id,'https');
                $divid ='opgicell'. $id;
                $refresh = site_url('ogrex/opCellRefresh/' . $id,'https');
                $remaction=site_url('ogrex/preregActionX/' . $id . '/TRUE/TRUE','https');                          
                break;
            default:
                $prereg_action = '';
                $divid ='';
                $refresh = '';  
                $remaction = '';                               
                break;   
        }
                                                                                                            //// action,            prereg_action,       refresh,        remove_action, gprefresh, pglrefresh
        $ret = '<a href="#" onclick="return preregisterForm('. "'" . site_url($action,'https') . "'," . $id .",'".$prereg_action ."','".$refresh ."','".$divid ."','".$remaction."','".$gprefresh."','".$vmode."','".$pglrefresh."'" .')">';
        $ret .= '[SignUp]';
        $ret .= '</a>'; 
        return $ret;
    }
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
    public function autopreregisterx($id, $role=0, $linkonly=FALSE){
        $ci = &get_instance();
        $orgid = $ci->session->ogre_orgid;
        $vmode = $ci->session->viewmode;
        $accessrating = $ci->session->get('ogre_user_accesslevel_' . $orgid);
        $slotcheck = site_url('ogrex/slotcheck/' . $id,'https');
        $msccheck = site_url('ogrex/getMultiSlotChildren/' . $id,'https');
        $pid = $ci->session->ogre_user_ID;
        $gmlock = (intval($accessrating) <= 10 )? 1 : $ci->event->get_eventinfo($id, "gs_lockgmsignup");
        $pglrefresh = site_url('ogrex/playergamelistrefresh','https');
        switch($vmode){
            case 'MAIN':
                $prereg_action = site_url('ogrex/autoPreregActionX/' . $id,'https');
                $divid ='gsrow';
                $refresh = site_url('ogrex/regularRowRefresh/' . $id,'https');  
                $remaction=site_url('ogrex/preregActionX/' . $id . '/TRUE/TRUE','https');                            
                break;
            case 'OP':
                $prereg_action = site_url('ogrex/autoPreregActionX/' . $id,'https');
                $divid ='opgicell';
                $refresh = site_url('ogrex/opCellRefresh/' . $id,'https');
                $remaction=site_url('ogrex/preregActionX/' . $id . '/TRUE/TRUE','https');                          
                break;
            default:
                $prereg_action = '';
                $divid ='';
                $refresh = '';  
                $remaction = '';                               
                break;   
        }
        $roletxt = ($role==0)?'Play':'GM';
        $title = ($role==0) ? 'Register as a Player for this event.' : 'Register as a GM or Judge for this event';
        $ret = ($linkonly === FALSE) ? '<a href="#" id="'.$roletxt.'AP'.$id.'" title="'.$title.'" class="playgmbutton" onclick="return auto_prereg('.$id.",".$gmlock.",'".$slotcheck."','".$prereg_action."',".$pid.",".$role.",'".$divid ."','".$vmode."','".$msccheck."','".$refresh."','".$pglrefresh."'".')">' : $id.",".$gmlock.",".$slotcheck.",".$prereg_action.",".$pid.",".$role.",".$divid .",".$vmode.",".$msccheck.",".$refresh.",".$pglrefresh;
        $ret .= ($linkonly === FALSE) ? $roletxt : '';
        $ret .= ($linkonly === FALSE) ? '</a>' :''; 
        return $ret;
    }                
//---------------------------------------------------
//
//  
//
//---------------------------------------------------
    public function preregisterEditx($action, $id, $linktxt='', $linkonly=FALSE){
        $ci = &get_instance();
        $vmode = $ci->session->viewmode;
        $pglrefresh = site_url('ogrex/playergamelistrefresh','https');
        $gprefresh = site_url('ogrex/gmPlayerRefresh','https');
        switch($vmode){
            case 'MAIN':
                $prereg_action = site_url('ogrex/preregActionX/' . $id,'https');
                $divid ='gsrow'.$id;
                $refresh = site_url('ogrex/regularRowRefresh/' . $id,'https');  
                $remaction = site_url('ogrex/preregActionX/' . $id . '/TRUE/TRUE','https');                            
                break;
            case 'OP':
                $prereg_action = site_url('ogrex/preregActionX/' . $id,'https');
                $divid ='opgicell'. $id;
                $refresh = site_url('ogrex/opCellRefresh/' . $id,'https');
                $remaction=site_url('ogrex/preregActionX/' . $id . '/TRUE/TRUE','https');                          
                break;
            case 'MY':
                $prereg_action = site_url('ogrex/preregActionX/' . $id,'https');
                $divid ='my-schedule-view';
                $refresh=site_url('ogre/refresh_player_myschedule','https'); 
                $remaction=site_url('ogrex/preregActionX/' . $id . '/TRUE/TRUE','https');                               
                break;
            default:
                $prereg_action = '';
                $divid ='';
                $refresh = '';  
                $remaction = '';                               
                break;   
        }

        if(trim($linktxt) == ''){
            $ret = ($linkonly===FALSE) ? '<a href="#" title="Edit your registration information or GM information here" id="play-gm-edit-button" class="playgmeditbutton" onclick="return preregisterForm('. "'" . site_url($action,'https') . "'," . $id . ",'" . $prereg_action . "','" . $refresh . "','" . $divid . "','" . $remaction . "','" . $gprefresh . "','" . $vmode . "','" . $pglrefresh ."'".');">   ...   </a>' : site_url($action,'https') . "," . $id .",".$prereg_action .",".$refresh .",".$divid .",".$remaction.",".$gprefresh.",".$vmode.",".$pglrefresh;
        }
        else{
            $ret = ($linkonly===FALSE) ? '<a href="#" title="Edit your registration information or GM information here" onclick="return preregisterForm('. "'" . site_url($action,'https') . "'," . $id .",'".$prereg_action ."','".$refresh ."','".$divid ."','".$remaction."','".$gprefresh."','".$vmode."','".$pglrefresh ."'".');">'.$linktxt.'</a>' : site_url($action,'https') . "," . $id .",".$prereg_action .",".$refresh .",".$divid .",".$remaction.",".$gprefresh.",".$vmode.",".$pglrefresh;
        }
        return $ret;
    }                

//---------------------------------------------------
//
//
//
//---------------------------------------------------
    private function scheduleSearchTopxGetGameNameLabel($dmode){
        switch($dmode){
            case 'P':
                $gamenamelabel = 'Game Name';
                break;
            case 'N':
                $gamenamelabel = 'Event Name/Type';
                break;                            
        }
        return $gamenamelabel;
    }
//---------------------------------------------------
//
//---------------------------------------------------    
    private function secondBasicFilter($gsp, $dmode, $conid){
        $p = array();
        if($gsp === NULL){
            $ret = $this->getGameTypeFilter($dmode, $conid, $p);
        } else if ($gsp["is"] === TRUE) {
            $p = array($gsp['skey'] => $gsp["svalue"]);
            
            switch($gsp["skey"]){
                case 'gamename':
                    $ret = $this->getGameTypeFilter($dmode, $conid, $p);
                    break;
                case 'gametype':
                    $ret = $this->getGameTypeFilter($dmode, $conid, $p);
                    break;                    
                case 'gameslot':
                    $ret = $this->getSlotFilter($conid, $dmode, $p);
                    break;
                case 'gm_name':
                    $ret = $this->getGMHostFilter($conid, $p, $dmode);
                    break;
                case 'descriptor':
                    $ret = $this->getDescriptorsFilter($conid, $p);
                    break;                
                case 'keyword':
                    $ret =  $this->getKeyWordField($p, $dmode);
                    break;
                default:
                    $ret = $this->getGameTypeFilter($dmode, $conid, $p);
                    break;
            }
        } else {
            $ret = $this->getGameTypeFilter($dmode, $conid, $p);
        }
            
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------    
    private function getSearchActionURL($dmode){
        switch($dmode){
            case 'N':
                $divid = "schedule-view-panels";
                $wait = 'waitN';
                $action = site_url('/ogrex/browseScheduleX/panelsx','https');
                break;
            case 'P':
                $action = site_url('/ogrex/browseScheduleX/search','https');
                $divid = "schedule-view";
                $wait = 'wait';
                break;                            
        }
        return ["divid" => $divid, "wait" => $wait, "action" => $action];
    }    
                
//---------------------------------------------------
//
//---------------------------------------------------
    public function scheduleSearchTopx($conid, $p=NULL, $dmode='P'){
        $ci=&get_instance();
        $ret ='';
        $gamenamelabel = $this->scheduleSearchTopxGetGameNameLabel($dmode);
        $search = $this->getSearchActionURL($dmode);
        $gspost = ($p != NULL) ? $this->isGSPostData($p) : NULL;
        $logged_in = $ci->session->ogre_logged_in;
        $ret = ''; 
        $ret .= $this->getSearchBottom($dmode, $logged_in);
        $ret .= $this->buildGameScheduleFilterSummary($dmode); 
        $ret .= '<div class="d-grid gap-2">';
        $ret .= '<button type="button" class="btn btn-outline-secondary" onclick="return filterdisplay('."'".$dmode."'".');" id="hidefilters-button'.(($dmode=='P')?'':'-panels').'" />Hide Filters</button>';
        $ret .= '<button type="button" class="btn btn-outline-secondary" onclick="return clearfilters('."'".$dmode."'".');" id="clearfilters-button'.(($dmode=='P')?'':'-panels').'" />Clear Filters</button>';
        $ret .= '</div>';
        $ret .= '<div id="game-search-table'.(($dmode!=='P')?'-panels':'').'" class="bg-light bg-gradient border mx-1 my-2 p-1">';
        $ret .= '<form ' . (($dmode=='P') ? ' id="game-search-form" name="game-search-form" ' : ' id="panel-search-form" name="panel-search-form" ' ) .' method="POST" action="'.$search['action'].'">';
        $ret .= '<div class="row">';
        $ret .= '<div class="col m-1">';
        $ret .= '<label class="control-label" for="'.(($dmode=="P") ? 'gamename' : 'panelname') .'">'. $gamenamelabel.':</label>';
        $ret .= $this->getGameNameFilterMulti($dmode, $conid, $p);
        $ret .= '</div>';
        $ret .= '</div>';    
        $ret .= ($dmode != 'N') ?  '<div class="row">' : '' ;
        $ret .= ($dmode != 'N') ?  '<div class="col m-1">': '';        
        $ret .= ($dmode != 'N') ?  $this->getGameTypeFilter($dmode, $conid, $p) : '';
        $ret .= ($dmode != 'N') ?  '</div>': '';
        $ret .= ($dmode != 'N') ?  '</div>': '';
        
        $ret .= ($dmode != 'N') ?  '<div class="row">': '';
        $ret .= ($dmode != 'N') ?  '<div class="col m-1">': '';         
        $ret .= ($dmode != 'N') ?  $this->getDescriptorsFilter($conid, $p): '';
        $ret .= ($dmode != 'N') ?  '</div>': '';
        $ret .= ($dmode != 'N') ?  '</div>': '';
        
        $ret .= '<div class="row">';
        $ret .= '<div class="col m-1">';
        $ret .= $this->getSlotFilter($conid, $dmode, $p);         
        $ret .= '</div>';
        $ret .= '</div>';        
        
        $ret .= ($dmode != 'N') ?'<div class="row">': '';
        $ret .= ($dmode != 'N') ?'<div class="col m-1">': '';        
        $ret .= ($dmode != 'N') ? $this->getGMHostFilter($conid, $p, $dmode) : '';                        
        $ret .= ($dmode != 'N') ?'</div>': '';
        $ret .= ($dmode != 'N') ?'</div>': '';   
        
        $ret .= '<div class="row">';
        $ret .= '<div class="col m-1">';         
        $ret .= $this->getKeyWordField($p, $dmode);      
        $ret .= '</div>';
        $ret .= '</div>';        
        $ret .= '<div class="row">';
        $ret .= '<div class="col m-1">';
        $ret .= '<label for="">New in the past</label>';
        $ret .= $this->selectWhatsNew($dmode).'</span>';
        $ret .= '<input type="hidden" name="gameid" id="gameid'.(($dmode=='P')?'':'-panels').'" value="-1" />';
        $ret .= '<input type="hidden" name="sgameid" id="sgameid'.($dmode=='P')?'':'-panels'.'" value="-1" />';
        $ret .= '<input type="hidden" name="page1" id="page1'.($dmode=='P')?'':'-panels'.'" value="TRUE" /></td>';
        
        $ret .= '</div>';
        $ret .= '</div>'; 
        $ret .= '</div>';
        $ret .= '</form>';
        
        return $ret;
    }   
//---------------------------------------------------
//
//---------------------------------------------------    
    private function buildGameScheduleFilterSummary($dmode){
        $ret = '';
        $ret .= '<div id="filter-summary'.(($dmode!=='P')?'-panels':'').'" class="bg-light bg-gradient border ml-2 mt-1 p-1">';
        $ret .= '<span id="filter-summary-emtpy'.(($dmode!=='P')?'-panels':'').'"><strong>Filters:</strong> None</span>';
        $ret .= '<span id="filter-summary-gamename'.(($dmode!=='P')?'-panels':'').'"></span>';
        $ret .= '<span id="filter-summary-gametype'.(($dmode!=='P')?'-panels':'').'"></span>';
        $ret .= '<span id="filter-summary-descriptor'.(($dmode!=='P')?'-panels':'').'"></span>';
        $ret .= '<span id="filter-summary-slot'.(($dmode!=='P')?'-panels':'').'"></span>';
        $ret .= '<span id="filter-summary-gm'.(($dmode!=='P')?'-panels':'').'"></span>';
        $ret .= '<span id="filter-summary-key'.(($dmode!=='P')?'-panels':'').'"></span>';
        $ret .= '<span id="filter-summary-whats'.(($dmode!=='P')?'-panels':'').'"></span>';
        $ret .= '</div>';
        return $ret;
    }
    
//---------------------------------------------------
//
//---------------------------------------------------
    public function getSearchBottom($dmode, $logged_in){
        $ci = &get_instance();
        $ret='';
        $search = $this->getSearchActionURL($dmode);
//        $tot = $this->gameSchedulexCount($dmode);
        $ret .= '<div class="d-grid gap-2">';                    
        $ret .= '<input class="btn btn-primary" type="button" value=" Display Schedule " id="display-schedule" onclick="searchSchedule('."'".$search['action']."','". $search['divid']."','". $search['wait']."','','".$dmode."'".')" />';
        if ($dmode!='N' && $logged_in===TRUE){
                $ret .=  '<input class="btn btn-success" type="button" value=" My Schedule " id="my-schedule-button" onclick="searchScheduleMySchedule('."'".site_url('ogrex/browseScheduleX/my-schedule','https')."','". $search['divid']."','". $search['wait']."','','".$dmode."'".')" />';
        }            
        $ret .= '</div>';
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getDescriptorsFilter($conid, $p){
        $ret = '<label for="descriptor">Tags/Descriptors:<span class="multiselecttxt">(Multi-select)</span>'.'</label>';
        $ret .= '<div class="select-style">';
        $ret .= $this->getDescriptorSelect($conid, $p);
        $ret .= '</div>';                     
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    private function getAffiliationTitle($tag){
        $ci = &get_instance();
        $ret = '';
        $qry = 'SELECT ogre_games_descriptor.* ';
        $qry .= ' FROM ogre_games_descriptor ';
        $qry .= ' WHERE ogre_games_descriptor.gd_descriptor = "' . $tag . '"'; 
        $qry .= ' AND ogre_games_descriptor.gd_descriptor_primarytagtype <> 0';

        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $ret = $row->gd_descriptor_desc;
            }
        }
        return $ret;       
    }    
//---------------------------------------------------
//
//---------------------------------------------------
    private function getAffiliationFilterOptions($conid, $p){               
        $qry = 'SELECT DISTINCT ogre_gameschedule.gs_affiliation ';
        $qry .= ' FROM ogre_gameschedule ';
        $qry .= ' WHERE ogre_gameschedule.gs_convention_id = ' . $conid; 
        $qry .= ' ORDER BY ogre_gameschedule.gs_affiliation;';         
        $ret =  (!isset($p['affiliation'])) ? $this->selectOptionsBuild($qry,"gs_affiliation","gs_affiliation","0") : $this->selectOptionsBuild($qry,"gs_affiliation","gs_affiliation",$p['affiliation']);                                 
        return $ret;
    }    
//---------------------------------------------------
//
//---------------------------------------------------
    private function getAffiliationFilterRow($conid, $p){               
        $ci = &get_instance();
        $qry = 'SELECT DISTINCT ogre_gameschedule.gs_affiliation ';
        $qry .= ' FROM ogre_gameschedule ';
        $qry .= ' WHERE ogre_gameschedule.gs_convention_id = ' . $conid; 
        $qry .= ' ORDER BY ogre_gameschedule.gs_affiliation;';
        $tagaction = site_url("ogrex/closedMsg/60",'https');
        $taginfo = $ci->ogre_lib->getMiscContent(60);
        $ret = '<tr>';
        $ret .= '<td class="gamesearch_label">';
        $ret .= '<a href="#" onclick="return getTagInfo('."'".$tagaction."',"."'".$taginfo['title']."'".')" class="gamegrid" >';
        $ret .= '<strong>Tags:</strong>';
        $ret .= '</a>';
        $afftxt = $ci->ogre_lib->getMiscContent('%AFFILIATIONSNOTES%', $conid);
        if(count($afftxt) > 0 ){
                $ret .= '<div id="affiliationlist"';
                $ret .= ' style="position:absolute;';
                $ret .= ' display: none;';
                $ret .= ' border: 3px solid black;';
                $ret .= ' background-color: silver;';
                $ret .= ' width: 300px;';
                $ret .= ' padding: 4px;';
                $ret .= ' font-family:Arial, Helvetica, sans-serif;';
                $ret .= ' font-size:100%; color:#000000; text-align: left">';
                $ret .= $afftxt['content'];                                                       
                $ret .= '</div>';                          
        }
        $ret .= '</td>';  
        $ret .= '</tr>'; 

        $ret .= '<tr>';                         
        $ret .= '<td>';
        $ret .= '<div class="select-style">';
        $ret .= '<select size="1" id="affiliation" name="affiliation">';
        $ret .= '<option value="0" selected="selected">ALL</option>';
        $ret .=  ((!isset($p['affiliation'])) ? $this->selectOptionsBuild($qry,"gs_affiliation","gs_affiliation","0") : $this->selectOptionsBuild($qry,"gs_affiliation","gs_affiliation",$p['affiliation']));
        $ret .= '</select>';        $ret .= '</div>';
        $ret .= '</td>';                        
        $ret .= '</tr>';                                            
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    private function getKeyWordField($p, $dmode='P'){
        $keywordid = ($dmode=='P') ? 'keyword' : 'pkeyword';
        $ret = '<label for="'.$keywordid.'"';
        $ret .= '  title="Key Word Searchs Game Name or Title.  Type Numeric value to search OGRe Event ID" ';
        $ret .= '>' . 'Key Word or Event ID:' . '</label>';
        $pover = ' title="" data-container="body" data-toggle="popover" data-placement="top" data-content="Key Word Searchs Game Name or Title.  Type Numeric value to search OGRe Event ID" data-original-title="Key Word or Event ID" aria-describedby="popover503055"';
        $ret .=  (!isset($p['keyword'])) ? '<input'.$pover.' type="text" class="form-control" id="'.$keywordid.'" name="'.$keywordid.'" />' :  '<input'.$pover.'type="text" id="'.$keywordid.'" class="form-control" name="'.$keywordid.'" value="' . $p['keyword'] . '" />';
        $ret .= '</td>';   
        return $ret;                
    }

//---------------------------------------------------
//
//---------------------------------------------------
    private function getGMHostFilter($conid, $p, $dmode='P'){
        $ret = '<label for="'.($dmode =='P' ? 'gm_name' : 'mod_name').'">Host/GM Name:</label>';
        $options = (!isset($p['gm_name'])) ? $this->getGMNameSelect($conid) : $this->getGMNameSelect($conid, $p['gm_name']);
        $ret .= '<select size="1" class="form-select mb-3" ';
        $ret .= ($dmode =='P' ? ' id="gm_name" name="gm_name">' : ' id="mod_name" name="mod_name">');
        $ret .= '<option value="0">ALL</option>';
        $ret .= $options;
        $ret .= '</select>';
        return $ret;
    }
                
//---------------------------------------------------
//
//---------------------------------------------------
    public function getGameTypeFilter($dmode, $conid, $p){                
        
        $qry = 'SELECT DISTINCT ogre_gameschedule.gs_game_type ';
        $qry .= ' FROM ogre_gameschedule WHERE ogre_gameschedule.gs_convention_id = ' . $conid;
        $qry .= ' AND ogre_gameschedule.gs_displaymode = "' . $dmode . '"';
        $qry .= ' ORDER BY ogre_gameschedule.gs_game_type;';
        $ret = '<label for="gametype">Game Type: <span class="multiselecttxt">(Multi-select)</span></label>';
        $ret .= '<select size="1" id="gametype" name="gametype[]"  style="width: 100%" class="select2-multi" multiple="multiple" >';
        $ret .= (!isset($p['gametype'])) ? $this->selectOptionsBuild($qry, "gs_game_type", "gs_game_type", "0") : $this->selectOptionsBuild($qry, "gs_game_type", "gs_game_type", $p['gametype']);
        $ret .= '</select>';
        return $ret;
    }
                
//---------------------------------------------------
//
//---------------------------------------------------
    public function getGameNameFilter($dmode, $conid, $p){
        $qry  =  'SELECT DISTINCT ';
        $qry .=  ' ogre_gameschedule.gs_game_name, ';
        $qry .=  ' ogre_gameschedule.gs_gn_id ';
        $qry .=  ' FROM ogre_gameschedule ';
        $qry .=  ' WHERE ';
        $qry .=  ' ogre_gameschedule.gs_cancelled=0 ';
        $qry .=  ' AND ogre_gameschedule.gs_displaymode="' . $dmode . '"';
        $qry .=  ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
        $qry .=  ' ORDER BY ogre_gameschedule.gs_game_name;';
        $options = (!isset($p['gamename'])) ? $this->selectOptionsBuild($qry, "gs_game_name", "gs_gn_id", "0") : $this->selectOptionsBuild($qry, "gs_game_name", "gs_gn_id", $p['gamename']);
        $ret = '<div class="select-style">';
        $ret .= '<select size="1" id="gamename" name="gamename">';
        $ret .= '<option value="0">ALL</option>';
        $ret .= $options;
        $ret .= '</select>';
        $ret .= '</div>';
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getGameNameFilterMulti($dmode, $conid, $p){
        $qry  =  'SELECT DISTINCT ';
        $qry .=  ' ogre_gameschedule.gs_game_name, ';
        $qry .=  ' ogre_gameschedule.gs_gn_id ';
        $qry .=  ' FROM ogre_gameschedule ';
        $qry .=  ' WHERE ';
        $qry .=  ' ogre_gameschedule.gs_cancelled = 0 ';
        $qry .=  ' AND ogre_gameschedule.gs_displaymode="' . $dmode . '"';
        $qry .=  ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
        $qry .=  ' ORDER BY ogre_gameschedule.gs_game_name;';
        
        $options = (!isset($p['gamename'])) ? $this->selectOptionsBuild($qry, "gs_game_name", "gs_gn_id", "0") : $this->selectOptionsBuild($qry, "gs_game_name", "gs_gn_id", $p['gamename']);
        $ret = ''; 
        $ret .= '<select class="select-style" size="1" '. (($dmode=='P') ? ' id="gamename" name="gamename[]" ' : ' id="panelname" name="panelname[]" ') . ' style="width: 100%" class="select2-multi" multiple="multiple">';
        $ret .= $options;
        $ret .= '</select>';
        return $ret;
    }   
//---------------------------------------------------
//
//---------------------------------------------------
    public function getSlotFilter($conid, $dmode, $p){  
        $selname = ($dmode == 'P') ? 'gameslot' : 'panelslot';
        $ret = '<label for="'.$selname.'">Time Slot:</label>';  
        $ret .= '<div class="select-style">';
        $ret .=  (isset($p['gameslot'])) ? $this->selectOptionsBuildSlots($conid, $dmode, $p['gameslot']) : $this->selectOptionsBuildSlots($conid, $dmode);
        $ret .= '</div>';
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function getSchedulePDFLinks($user_id_num=0){
        $ci = &get_instance();
        $ret ='';
        $ret .= '<div class="form-group">';
        $ret .= '<label class="form-label form-label-sm" for="pdfselect">';
        $ret .= 'Downloads:</h6>';
        $ret .= '</label>';
        $ret .= '<div class="input-group">';
        $ret .= '<select id="pdfselect" name="pdfselect" class="form-control"  size="1">';
        $ret .= '<option value="0" hidden="hidden">SELECT DOWNLOAD</option>'; 
        $ret .= '<option value="' . site_url('ogre_pdf/pdfMyscedule','https'). '/' . $user_id_num . '">  Print My Schedule (PDF)  </option>';
        if($user_id_num != 0){
            $ret .= ($ci->person->isGM($user_id_num)===TRUE) ? '<option value="' . site_url('ogre_pdf/pdfPlayerList','https'). '/' . $user_id_num. '">  Print My Player List  (PDF)    </option>' : '';
        }   
        $ret .= '<option value="' . site_url('ogrex/downloadScheduleCSV','https'). '">  Full Schedule (CSV)  </option>';
        $ret .= '</select>';
        $ret .= '<button class="btn-primary m-2" onclick="(self.location=document.getElementById('."'".'pdfselect'."'".').value);">Go</button>';
        $ret .= '</div>';
        $ret .= '</div>';
        return $ret;
    }
                
//---------------------------------------------------
//
//---------------------------------------------------
    public function getDescriptorSelect($conid, $p){                                           
        $options = '<optgroup label="AFFILIATION">';
        $options .= $this->getAffiliationFilterOptions($conid, $p);
        $options .= '</optgroup>';
        $desc = (isset($p['descriptor']) ? $p['descriptor'] : "");
        $qryDesc = 'SELECT DISTINCT ';
        $qryDesc .= ' ogre_games_descriptor.gd_descriptor,  ';
        $qryDesc .= ' ogre_games_descriptor.gd_descriptor_type, ';
        $qryDesc .= ' gdt_game_descriptor_type ';
        $qryDesc .= ' FROM ((ogre_gameschedule INNER JOIN ogre_games_descriptor_xref ON ogre_gameschedule.gs_gn_id = ogre_games_descriptor_xref.gdx_gn_id) ';
        $qryDesc .= ' INNER JOIN ogre_games_descriptor ON ogre_games_descriptor_xref.gdx_gd_id = ogre_games_descriptor.gd_id) ';
        $qryDesc .= ' INNER JOIN ogre_games_descriptor_type ON ogre_games_descriptor.gd_descriptor_type = ogre_games_descriptor_type.gdt_id  ';
        $qryDesc .= ' WHERE ';
        $qryDesc .= ' ogre_games_descriptor.gd_descriptor_type <> 1   ';
        $qryDesc .= ' AND ogre_games_descriptor.gd_descriptor_type <> 5   ';
        $qryDesc .= ' AND ogre_games_descriptor.gd_descriptor_type <> 6   ';
        $qryDesc .= ' AND ogre_games_descriptor.gd_descriptor_type <> 3   ';
        $qryDesc .= ' AND ogre_gameschedule.gs_convention_id=' . $conid;                       
        $qryDesc .= ' ORDER BY gdt_game_descriptor_type, gd_descriptor';       
        $ci = &get_instance();
        $dt = "";
        $ret = '';
        $query = $ci->db->query($qryDesc);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                
                $options .= ($dt <> $row->gd_descriptor_type) ? '<optgroup label="' . strtoupper($row->gdt_game_descriptor_type) . '">' : '';
                $options .=  ($row->gd_descriptor == $desc) ? '<option value="'. htmlspecialchars($row->gd_descriptor) . '" selected>' . htmlspecialchars($row->gd_descriptor) . '</option>' : '<option value="'. htmlspecialchars($row->gd_descriptor) . '">' . htmlspecialchars($row->gd_descriptor) . '</option>';
                $dt = $row->gd_descriptor_type;
                $options .= ($dt <> $row->gd_descriptor_type) ? '</optgroup>' : '';
            }
        }
        $qry = 'SELECT DISTINCT ogre_manufacturers.gman_name ';
        $qry .= ' FROM (ogre_gameschedule INNER JOIN ogre_games ON ogre_gameschedule.gs_gn_id = ogre_games.gn_game_id) ';
        $qry .= ' INNER JOIN ogre_manufacturers ON ogre_games.gn_gman_id = ogre_manufacturers.gman_id ';
        $qry .= ' WHERE ogre_gameschedule.gs_convention_id = ' . $conid;
        $qry .= ' ORDER BY gman_name'; 
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            $options .= '<optgroup label="PUBLISHERS">';
            foreach ($query->getResult() as $row){
                    $options .= ($row->gman_name == $desc) ? '<option value="'. htmlspecialchars($row->gman_name) . '" selected>' . htmlspecialchars($row->gman_name) . '</option>' : '<option value="'. htmlspecialchars($row->gman_name) . '">' . htmlspecialchars($row->gman_name) . '</option>';
                }
            $options .= '</optgroup>';
        }                        
        $ret .= '<select size="1" id="descriptor" name="descriptor[]" style="width: 100%" class="select2-multi" multiple="multiple" >';
        $ret .= $options;
        $ret .= '</select>';    
        return $ret;
    }
                
//------------------------------------------
// BUILD SELECT OPTIONS - Slots
//------------------------------------------
    function selectOptionsBuildSlots($conid, $dmode='P', $slot=NULL){
        $ci = &get_instance();
        $slot = (!is_array($slot) ? ((intval($slot)==0) ? NULL : $slot) : $slot);
        $options = array('0'=>'All Sessions','Friday'=>'All Friday','Saturday'=> 'All Saturday','Sunday'=>'All Sunday');
            $qry = 'SELECT DISTINCT ';
            $qry .= ' ogre_gameschedule.gs_slot_code, ';
            $qry .= ' ogre_gameschedule.gs_slot_day, ';
            $qry .= ' ogre_gameschedule.gs_slot_time ';
            $qry .= ' FROM ogre_gameschedule ';
            $qry .= ' WHERE ogre_gameschedule.gs_displaymode="' . $dmode . '" ';
            $qry .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
            $qry .= ' ORDER BY ogre_gameschedule.gs_slot_code;';
            $query = $ci->db->query($qry);
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){ 
                    $options[$row->gs_slot_code] = substr($row->gs_slot_day, 0,3) . ' - ' . $row->gs_slot_time;
                }
            } 
            $ret = (($slot !== NULL) ? form_dropdown('gameslot', $options, $slot) : form_dropdown('gameslot', $options));
            $ret = (($dmode == 'P') ? str_replace('name="gameslot"', 'id="gameslot" name="gameslot" ', $ret) : str_replace('name="gameslot"', 'id="panelslot" name="panelslot" ', $ret));
            $ret = str_replace('<select ', '<select class="form-select mb-3" ', $ret);
            
            return $ret;	
    }	
//------------------------------------------
// BUILD SELECT OPTIONS
//------------------------------------------
    function selectOptionsBuild($qry, $displaycol, $valcol, $selval){
        $ci = &get_instance();        
        $ret = "";
        
        $query = $ci->db->query($qry);

        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $ret .= ($row->$valcol == $selval) ? '<option value="'. htmlspecialchars($row->$valcol) . '" selected>' . htmlspecialchars($row->$displaycol) . '</option>' : '<option value="'. htmlspecialchars($row->$valcol) . '">' . htmlspecialchars($row->$displaycol) . '</option>';
            }
        }
        return $ret;	
    }
             
                
//------------------------------------------
// BUILD SELECT OPTIONS
//------------------------------------------
    function selectWhatsNewSpan($whatsnewaction="", $divid="", $wait="", $selval="0"){
        $span = array("0" => "0, [SELECT]","1" => "2W,2 Weeks","2" => "1W,1 Week","3" => "5D,5 Days","4" => "2D,2 Days ","5" => "1D,1 Day");
        $ci = &get_instance();
        $ret = "";
        $ret .= '<select size="1" name="whatsnewspan" id="whatsnewspan" onchange="searchScheduleWhatsNew('."'".$whatsnewaction."','". $divid."','". $wait."',''".')">'; 
        foreach ($span as $spnitem){
            $spanitems = explode(",", $spnitem);
            $ret .= ($spnitem == $selval) ? '<option value="'. $spanitems[0] . '" selected>' . $spanitems[1] . '</option>' : '<option value="'.$spanitems[0]. '">' . $spanitems[1] . '</option>';
        }                                  
        $ret .= '</select>';  
        return $ret;	
    }
    
//------------------------------------------
// BUILD SELECT OPTIONS
//------------------------------------------
    function selectWhatsNew($dmode, $selval=''){
        $span = array("0" => "0, [SELECT]","1" => "2W,2 Weeks","2" => "1W,1 Week","3" => "5D,5 Days","4" => "2D,2 Days ","5" => "1D,1 Day");
        $ci = &get_instance();
        $ret = '';
        $ret .= '<div class="select-style" >';
        $ret .= '<select class="form-select mb-3" size="1" name="whatsnewspan'.(($dmode=='P')?'':'-panels').'" id="whatsnewspan'.(($dmode=='P')?'':'-panels').'">'; 
        foreach ($span as $spnitem){
            $spanitems = explode(",", $spnitem);
            $ret .= ($spnitem == $selval) ? '<option value="'. $spanitems[0] . '" selected>' . $spanitems[1] . '</option>' : '<option value="'.$spanitems[0]. '">' . $spanitems[1] . '</option>';
        }                                  
        $ret .= '</select>';
        $ret .= '</div>';
        return $ret;	
    }    
//---------------------------------------------------
//
//---------------------------------------------------		
    public function generalGameList($conid, $bycompany=FALSE){
        $ci=&get_instance();
        $ret ='';
        $ret .= '<table id="games-list-main" class="table table-striped">';
        $ret .= '<tr>';
        $ret .= '<td colspan="5" class="schedule2">';
        $lastGameType = '';
        $lastGame = '';
        $lastGameSource = '';
        $genGameList1 = $this->getRegGameGenList($conid, $bycompany);
        $genGameList2 = $this->getPCGameGenList($genGameList1, $conid, $bycompany);
        if(($genGameList2[0] == -1) AND ($genGameList2[1] == -1)){
                $ret .= '<h1>No Games on the schedule at this time</h1>';
        }
        else{
            $lastGameType = "";
            foreach($genGameList2 as $gameitem){
                if($gameitem !=-1){
                    $strGameInfo = explode("~", $gameitem);
                    if(count($strGameInfo)>0){
                        $GameType = $strGameInfo[0];
                        $GameName = $strGameInfo[1];
                        $GameSource = $strGameInfo[2];
                        $GameComp = $strGameInfo[3];
                        $GameCompWeb = $strGameInfo[4];
                        $Gameid = $strGameInfo[5];
                        if($lastGameType != $GameType){
                            $ret .= '<thead class="table-warning">';
                            $ret .= '<th class="">';
                            if ($bycompany == FALSE){
                                $ret .= $GameType . '</th>' . '</thead>';
                            }
                                else{
                                   $ret .= $GameType . '</th>' . '</thead>';
                                }
                                $ret .= ' <tr><td>' . $this->buildGeneralGameLink($GameSource, $GameName, $Gameid, $conid) . '</td></tr>';
                            }
                            else
                            { 
                                if($lastGame != $GameName){
                                    $ret .= '<tr><td>' . $this->buildGeneralGameLink($GameSource, $GameName, $Gameid, $conid) . '</td></tr>';
                                } 
                            }
                        $lastGame = $GameName;
                        $lastGameType = $GameType;
                        $lastGameSource = $GameSource;
                    }
                }
            }
        }
        $ret .= '</td></tr></table>';
        return $ret;
    }  
//---------------------------------------------------
//  Regular General Game List
//---------------------------------------------------
    public function getRegGameGenList($conid, $byco){
        $ci=&get_instance();
        $i = 0;
        $reglist = array();
        $qry_gengamelist1 = 'SELECT ogre_gameschedule.gs_game_type, ogre_gameschedule.gs_game_name, ogre_gameschedule.gs_gn_id, ogre_manufacturers.gman_name, ogre_manufacturers.gman_web, ogre_games.gn_gman_id ';
        $qry_gengamelist1 .= ' FROM (ogre_gameschedule LEFT JOIN ogre_games ON ogre_gameschedule.gs_gn_id = ogre_games.gn_game_id) LEFT JOIN ogre_manufacturers ON ogre_games.gn_gman_id = ogre_manufacturers.gman_id ';
        $qry_gengamelist1 .= ' WHERE ((ogre_gameschedule.gs_cancelled=0 AND ogre_gameschedule.gs_displaymode="P") AND ((ogre_gameschedule.gs_game_list)<>1) AND ((ogre_gameschedule.gs_convention_id)=' . $conid . ')) ';
        $qry_gengamelist1 .= ' ORDER BY ogre_gameschedule.gs_game_type, ogre_gameschedule.gs_game_name;';			
        $query = $ci->db->query($qry_gengamelist1);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                if ($byco==FALSE){
                    $reglist[$i] = $row->gs_game_type . "~" . $row->gs_game_name . "~" . $row->gs_game_name . "~" . $row->gman_name . "~" . $row->gman_web  . "~" . $row->gs_gn_id . "~" . "R";
                }
                else{
                    $reglist[$i] = (($row->gn_gman_id==0) || (trim($row->gn_gman_id)=='')) ? "None/Unknown" . "~" . $row->gs_game_name . "~" . $row->gs_game_name . "~" . $row->gs_game_type . "~" . ""  . "~" . $row->gs_gn_id . "~" . "R" : $row->gman_name . "~" . $row->gs_game_name . "~" . $row->gs_game_name . "~" . $row->gs_game_type . "~" . $row->gman_web  . "~" . $row->gs_gn_id . "~" . "R";
                }	
                $i++;
            }
        } 
        else{
            $reglist[0] = -1;
        }
        return $reglist; 
    }	
//---------------------------------------------------
//  Players Choice General Game List
//---------------------------------------------------
    public function getPCGameGenList($reg, $conid, $byco){
        $ci=&get_instance();            
        $qry = 'SELECT DISTINCT ogre_playerschoicelist.pc_game_name, ogre_playerschoicelist.pc_gn_id, ogre_playerschoicelist.pc_game_type, ogre_gameschedule.gs_game_name, ogre_manufacturers.gman_name, ogre_manufacturers.gman_web, ogre_games.gn_gman_id ';
        $qry.= ' FROM ((ogre_gameschedule INNER JOIN ogre_playerschoicelist ON ogre_gameschedule.gs_id = ogre_playerschoicelist.pc_gs_id) LEFT JOIN ogre_games ON ogre_playerschoicelist.pc_gn_id = ogre_games.gn_game_id) LEFT JOIN ogre_manufacturers ON ogre_games.gn_gman_id = ogre_manufacturers.gman_id ';
        $qry .= ' WHERE (((ogre_gameschedule.gs_convention_id)=' . $conid . '))';
        $qry .= ' ORDER BY ogre_playerschoicelist.pc_game_name;';
        $query = $ci->db->query($qry);
        $i = count($reg);
        $i++;
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                if ($byco == FALSE){
                        $reg[$i] =  $row->pc_game_type . "~" . $row->pc_game_name . "~" .  $row->gs_game_name . "~" . $row->gman_name . "~" . $row->gman_web . "~" .  $row->pc_gn_id;
                }
                else{
                    $reg[$i] = (($row->gn_gman_id==0) || (trim($row->gn_gman_id)=='')) ? "None/Unknown" . "~" . $row->pc_game_name . "~" .  $row->gs_game_name . "~" . $row->pc_game_type . "~" . $row->gman_web . "~" .  $row->pc_gn_id : $row->gman_name . "~" . $row->pc_game_name . "~" .  $row->gs_game_name . "~" . $row->pc_game_type . "~" . $row->gman_web . "~" .  $row->pc_gn_id;  
                }
                $i++;
            }
        } 
        else{
            if ($reg[0] == -1){
                $reg[1] = -1;
            }
        }		
        sort($reg);
        return $reg;		
    }	
//---------------------------------------------------
//
//  BUILD GENERAL GAME LINK
//
//---------------------------------------------------
    public function buildGeneralGameLink($gs, $gn, $gid, $conid){
        $gl = $this->getPlayersChoiceScheduleID($gn, $conid);
        $action = site_url('ogrex/browseScheduleX/search_gamelist/FALSE'.'/'.$gid,'https');
        $divid="schedule-view";
        $wait = 'wait';
        $ret = '<a href="#" onclick="return searchByGamelist('."'".$action."','".$divid."','".$wait."'".');">';
        $ret .= $gn;
        $ret .= '</a>';      
        return $ret;
    }		

//---------------------------------------------------
//
//  GET PLAYER'S CHOICE SCHEDULE ID
//
//---------------------------------------------------
    public function getPlayersChoiceScheduleID($gn,  $conid){
        $ci=&get_instance();
        $qry = "SELECT DISTINCT ogre_playerschoicelist.pc_gs_id, ogre_playerschoicelist.pc_game_name ";
        $qry .= " FROM ogre_gameschedule INNER JOIN ogre_playerschoicelist ";
        $qry .= " ON ogre_gameschedule.gs_id = ogre_playerschoicelist.pc_gs_id ";
        $qry .= " WHERE ogre_gameschedule.gs_convention_id = " . $conid;
        $qry .= " AND ogre_playerschoicelist.pc_game_name = '" . $gn . "'";
        $qry .= " ORDER BY ogre_playerschoicelist.pc_game_name;";
        $query = $ci->db->query($qry);
        
        $gl = "";
        $lastid = 0;
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                if ($lastid <> $row->pc_gs_id){
                        $gl .= $row->pc_gs_id . "~";
                }
                $lastid = $row->pc_gs_id;
            }

        }
        if (trim($gl) != ""){
                $gl = substr($gl,0,strlen($gl)-1);  // TAKE OFF LAST COMMA
        }
        return $gl;
    }

    //---------------------------------------------------
    //
    // 
    //
    //---------------------------------------------------		
    public function getGameListFromGameID($gid, $conid){
        $ci=&get_instance();
        $qry = '(SELECT ogre_gameschedule.gs_id ';
        $qry .= ' FROM ogre_gameschedule ';
        $qry .= ' WHERE ogre_gameschedule.gs_convention_id = ' . $conid . ' AND ';
        $qry .= ' ogre_gameschedule.gs_gn_id = ' . $gid . ')';
        $qry .= ' UNION (SELECT ogre_gameschedule.gs_id ';
        $qry .= ' FROM ogre_gameschedule INNER JOIN ogre_playerschoicelist ';
        $qry .= ' ON ogre_gameschedule.gs_id = ogre_playerschoicelist.pc_gs_id ';
        $qry .= ' WHERE ogre_playerschoicelist.pc_gn_id = ' . $gid . ' AND ';
        $qry .= ' ogre_gameschedule.gs_convention_id =  ' . $conid . ');';	
        $i = 0;
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                        $glist[$i] = $row->gs_id;
                        $i++;
                }
        }
        return $glist;
    }
//---------------------------------------------------
//
// 
//
//---------------------------------------------------		
    public function generatePost(){
        $p["gamename"] = "";        // g
        $p["gametype"] = "0";       // t
        $p["gameslot"] = "0";       // s
        $p["gm_name"] = "0";        // p
        $p["affiliation"] = "0";    // a    
        $p["preregonly"] ="0";
        $p["special"] = "0";
        $p["keyword"] = "";         // k 
        $p["descriptor"] = "0";     // d
        return $p;
    }
    
//---------------------------------------------------
//
// 
//
//---------------------------------------------------	    
    public function genSharePostData($id){
        $pst = $this->generatePost();  
        $pd = explode("-",$id);
        switch($pd[0]){
            case "g":
                $pst["gamename"] = $pd[1];
                break;
            case "t":
                $pst["gametype"] = $pd[1];
                break;
            case "s":
                $pst["gameslot"] = $pd[1];
                break;
            case "p":
                $pst["gm_name"] = $pd[1];
                break;
            case "a":
                $pst["affiliation"] = $pd[1];
                break; 
            case "k":
                $pst["keyword"] = $pd[1];
                break;      
            case "d":
                $pst["descriptor"] = $pd[1];
                break;              
        }
        return $pst;
    }
//---------------------------------------------------
//
//---------------------------------------------------		
    public function isGSPostData($p){
        $ret = array("is" => FALSE, "skey" => "", "svalue" => "");
        if(is_array($p)){
            foreach ($p as $key => $value){
                if ($value != '0' && $value != "") {
                    $ret["is"] = TRUE;
                    $ret["skey"] = $key;
                    $ret["svalue"] = $value;
                }
            }
        }
        return $ret;
    }    
//---------------------------------------------------
//
//---------------------------------------------------		
    public function getGMNames($id, $type=1){
        $ci=&get_instance();
        $conid = $ci->session->ogre_conid;
        $logged_in = $ci->session->ogre_logged_in;
        $act = $ci->session->get('ogre_user_activated_' . $conid);
        $qry= 'SELECT ogre_prereg_player.pp_player_name, ';
        $qry.= ' ogre_users.user_last_name, ';
        $qry.= ' ogre_users.user_first_name, ';
        $qry.= ' ogre_users.user_full_name, ';
        $qry.= ' ogre_prereg_player.pp_gs_id ';
        $qry.= ' FROM ogre_prereg_player ';
        $qry.= ' INNER JOIN ogre_users ';
        $qry.= ' ON ogre_prereg_player.pp_player_id = ogre_users.user_index_id ';
        $qry.= ' WHERE pp_gs_id = ' . $id;
        $qry.= ' AND ' . ((intval($type) == 0) ? ' pp_gm_judge_flag <= ' . $type : ' ABS(pp_gm_judge_flag) = ' . $type);
        $qry.= ' AND pp_delete_flag = 0';
        $query = $ci->db->query($qry);
        $gm_names = '';
        if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                    $gm_names .= ($logged_in == TRUE && $act == 1) ? $row->user_full_name. ', ' : $row->user_first_name.' '.substr(trim($row->user_last_name), 0, 1).'.'.', '; 
                }
        }                        
        return substr(trim($gm_names), 0, strlen(trim($gm_names))-1);
    }		
		

//------------------------------------------
//
//------------------------------------------
    public function preregForm($gameid, $conid, $edit=FALSE){
        $ci=&get_instance();
        $ci->event->event_init($gameid);
        $curr_userid = $ci->session->ogre_user_ID;
        if ($curr_userid != 0){
                $ci->person->init($conid, '', $curr_userid);
        }
        if ($edit == TRUE){
            $ret = $ci->event->buildPreregPage($edit);
        }
        else{
            if ($ci->person->access_rating <= GAMEMASTER){
                $full = $ci->event->is_full();
                $isOPlay = (intval($ci->event->mmrpgFlag)===1?TRUE:FALSE);
                $curruser = $ci->person->user_id_num;
                $alreadyreg = $ci->event->isAlreadyRegisteredInSlot($curruser);
                if($full === FALSE ){
                    if ( $alreadyreg === FALSE){
                        $ret = $ci->event->buildPreregPage($edit);
                    }
                    else{
// ALREADY IN A GAME IN THE SLOT                                    
                        $misc = $ci->ogre_lib->getMiscContent('%ALREADY_IN_A_GAME_IN_THE_SLOT%', $conid);
                        $buttons = $this->registerPlayerFooter(FALSE, $gameid);
                        $ret = $misc["content"].$buttons;
                    }
                }                           
                else{
                    if ($alreadyreg === FALSE){
                        if ($isOPlay === TRUE){
//Alternate
                            $misc = $ci->ogre_lib->getMiscContent('%GAME_IS_FULL_OP1%', $conid);
                            $ret = $misc["content"];
                            $ret .= $ci->event->buildPreregPage($edit);
                        }
                        else{                                   
// Game is Full
                            $misc = $ci->ogre_lib->getMiscContent('%GAME_IS_FULL1%', $conid);
                            $ret = $misc["content"];
                        }
                    }
                    else{
// ALREADY IN A GAME IN THE SLOT                                    
                        $misc = $ci->ogre_lib->getMiscContent('%ALREADY_IN_A_GAME_IN_THE_SLOT%', $conid);
                        $buttons = $this->registerPlayerFooter(FALSE, $gameid);                                   
                        $ret = $misc["content"].$buttons;
                    }                                
                }
            }
            else   //ADMIN USER
            {
                $ret = $ci->event->buildPreregPage($edit);
            }
        }
        return $ret;
}
                
//------------------------------------------
//
//------------------------------------------
    public function preRegFormX($gameid, $conid, $edit=FALSE){
        $ci=&get_instance();                  
        $ci->event->event_init($gameid);
        $orgid = $ci->session->ogre_orgid;
        $curr_userid = $ci->session->ogre_user_ID;                  
        if ($curr_userid != 0){
                $ci->person->init($conid, '', $curr_userid);
        }
        if ($edit == TRUE){
            $ret = $ci->event->buildPreregPageX($gameid, $edit);
        }
        else{      

            if ($ci->person->access_rating <= GAMEMASTER){
                $full = $ci->event->is_full();
                $isOPlay = (intval($ci->event->mmrpgFlag)==1?TRUE:FALSE);
                $curruser = $ci->person->user_id_num;
                $alreadyreg = $ci->event->isAlreadyRegisteredInSlot($curruser);
                if($full === FALSE ){
                    if ($alreadyreg === FALSE){
                        $ret = $ci->event->buildPreregPageX($gameid, $edit);
                    }
                    else{
                        // ALREADY IN A GAME IN THE SLOT                                    
                        $misc = $ci->ogre_lib->getMiscContent('%ALREADY_IN_A_GAME_IN_THE_SLOT%', $conid);
                        $misc["content"] = '<div class="prereg_response2">'.$misc["content"].'</div>';
                        $buttons = $this->registerPlayerFooter(FALSE, $gameid);
                        $misc["content"]=$misc["content"].$buttons;
                        $ret = $misc["content"];
                    }
                }                           
                else{
                    if ($alreadyreg === FALSE){                                
                        if ($isOPlay === TRUE){
                            //Alternate
                            $misc = $ci->ogre_lib->getMiscContent('%GAME_IS_FULL_OP1%', $conid);
                            $ret = '<div class="prereg_response2">' . $misc["content"] . '</div>';
                            $ret .= $ci->event->buildPreregPageX($gameid, $edit);
                        }
                        else{                                   
                            // Game is Full
                            $misc = $ci->ogre_lib->getMiscContent('%GAME_IS_FULL1%', $conid);
                            $misc["content"] = '<div class="prereg_response2">'.$misc["content"].'</div>';
                            $buttons = $this->registerPlayerFooter(FALSE,  $gameid);                                        
                            $ret = $misc["content"].$buttons;
                        }
                    }
                    else{
                        // ALREADY IN A GAME IN THE SLOT                                    
                        $misc = $ci->ogre_lib->getMiscContent('%ALREADY_IN_A_GAME_IN_THE_SLOT%', $conid);                                   
                        $misc["content"] = '<div class="prereg_response2">'.$misc["content"].'</div>';                                 
                        $buttons = $this->registerPlayerFooter(FALSE,  $gameid);
                        $ret = $misc["content"].$buttons;
                    }                                
                }
            }
            else   //ADMIN USER
            {
                $ret = $ci->event->buildPreregPageX($gameid, $edit);
            }
        }

        return $ret;
    }
                
//------------------------------------------
//
//------------------------------------------
    public function registerform($gameid)
    {
        $ci=&get_instance();
        $ci->event->event_init($gameid);
        $ret = $ci->event->build_reg_page($gameid);
        return $ret;
    }  
//------------------------------------------
//
//------------------------------------------
    public function registerFormX($gameid){
        $ci=&get_instance();
        $ci->event->event_init($gameid);
        $ret = $ci->event->buildRegPageX($gameid);
        return $ret;
    }                  
    //------------------------------------------
    //
    //
    //
    //------------------------------------------
    public function preregAction($admin=FALSE, $p=NULL, $gameid=0){                 
        $ci = &get_instance();
        $conid = $ci->session->ogre_conid;
        if ($gameid==0){
            $gameid = $p['gid'];
        }
        else{
            $p['gid'] = $gameid;
        }
        $ci->event->event_init($gameid);
        $ginfo = $ci->event->basicinfo_array();                    
        $p2 = array_merge($p, $ginfo);
        $userid= (isset($p['userID'])) ? $p['userID'] :0;                                     
        if ($admin === FALSE){                                                                                                                                 
            $curr_userid= ($userid == 0) ?  $ci->session->ogre_user_ID :  $curr_userid = $userid;                               
            if ($curr_userid != 0){
                $ci->person->init($conid, '', $curr_userid);
                if(!isset($p['pname'])){
                    $p['pname'] = $ci->person->fullname;
                    $p['pemail'] = $ci->person->email;                                  
                }
            }
            $ci->convention->init($conid);                                                   
//   NEW REGISTRATION                        
            if ($p["preregid"] == '-9999'){                                
                $ret = $ci->event->registerPlayer($p, $curr_userid);    
                $msparentid=$ret['pp_player_prereg_id'];
                if($ret['result']===TRUE){
                    if ($ci->event->rpga_number_of_slots > 1){ 
                        $pms1=$this->insertMultiSlotPrereg($msparentid);
                        $childid = $ci->event->findOPMultiRoundChild();
                        $i=2;
                        foreach($childid as $child){
                            $ci->event->event_init($child);
                            $c = $ci->event->registerPlayer($p, $curr_userid);
                            $c2=$this->updateMultiSlotPrereg($msparentid, $c['pp_player_prereg_id'], $i);   
                            $i++;
                        }
                        $ci->event->event_init($gameid);
                    }
                    $ret = $this->registerPlayerResponse($ret, $p2, FALSE);
                }
            }
//   EDIT REGISTRATION                        
            else{                               
                if (!isset($p["remove"])){
                    $ret = $ci->event->registerPlayerUpdate($p2, $conid);
                    $ret = $this->registerPlayerResponse($ret, $p2, TRUE);
                    $ret["contactGM"] = (trim($p2["pnotes"]) != "") ? TRUE : FALSE;
                    if($ret['result']===TRUE){                                    
                        if ($ci->event->rpga_number_of_slots > 1){
                            $childid = $ci->event->findOPMultiRoundChild();
                            foreach($childid as $child2){                                                 
                                $ci->event->event_init($child2);
                                $p["preregid"]=$ci->person->getRegistrationInfo($child2,  'pp_player_prereg_id');
                                $c = $ci->event->registerPlayerUpdate($p, $conid); 
                            }    
                            $ci->event->event_init($gameid);
                        }
                    }
                }
                else {
//                          REMOVE 
                    $rem[0] = $ci->event->id;
                    $ret['result'] = $ci->person->removeFromGame($rem);
                    if ($ret['result'] === TRUE){
                        $ret['resp'] = $ci->event->buildRegistrationFormHeader();
                        $ret['resp'] .= '<table id="regform1">';
                        $ret['resp'] .= '<tr>';
                        $ret['resp'] .= '<td>';                                    
                        $ret['resp'] .= '<p>You have been Successfully Removed.</p>';
                        $ret['resp'] .= '</td>';
                        $ret['resp'] .= '</tr>';
                        $ret['resp'] .= '</table>';
                        $closeid = $ci->event->generate_opgridid($ci->event->id);
                        $rowid =  $ci->event->slot_day.$ci->event->row_enum;
                        $ret['resp'] .= $this->registerPlayerFooter($admin,  $gameid);
                    }

                }
            }
            $ci->person->resetPlayerSchedule();
        }
        else{
//                  ADMIN ADD PLAYER                        
            $ci->person->init('', $userid, $conid);
            $ret = $ci->event->registerPlayer($p, $userid);
            $msparentid=$ret['pp_player_prereg_id'];
            if(!isset($p['pname'])){
                $p['pname'] = $ci->person->fullname;
                $p['pemail'] = $ci->person->email;                                  
            }                        
            $ret = $this->registerPlayerResponse($ret, $p2);                        
            if($ret['result']===TRUE){                                 
                if ($ci->event->rpga_number_of_slots > 1){
                    $pms1=$this->insertMultiSlotPrereg($msparentid);
                    $i=2;
                    $childid = $ci->event->findOPMultiRoundChild();
                    foreach($childid as $child2){                                         
                        $ci->event->event_init($child2);                                   
                        $c = $ci->event->registerPlayer($p, $userid);
                        $c2=$this->updateMultiSlotPrereg($msparentid, $c['pp_player_prereg_id'], $i);
                        $i++;
                    }
                    $ci->event->event_init($gameid);
                }
            }
        }
        return $ret;
            }
//---------------------------------------------------
//
//---------------------------------------------------            
    public function registerPlayerResponse($ret, $p, $edit=FALSE){              
        if($ret['result']==TRUE){            
            if($edit===FALSE){
                $ret['resp'] .= '<div class="prereg_response">';
                $ret['resp'] .= '<p>Pre-Registration Confirmed</p>';
                $ret['resp'] .= '</div>';
    //                      EMAIL CONFIRMATION                        
    //                      -----------------------------  
                $ret['message'] = $p["pname"] . " ( " . $p["pemail"] . " ) " . "<br /><br />Registration Confirmation<br /><br />";
                $ret['message'] .= 'GAME: '. $p['game_name'] . ".<br /><br />";                             
                $ret['message'] .= ($p['game_title']!='')? 'TITLE: ' .$p['game_title'] .'<br /><br />' : "";
                $ret['message'] .= 'DAY: ' .$p['slot_day'] .'<br /><br />';  
                $ret['message'] .= 'TIME: ' .$p['slot_time'] .'<br /><br />';                        
                $ret['message'] .= (trim($p["pnotes"]) != "") ? "Notes to the GM: " . $p["pnotes"] : "";
                $ret['subject'] = $p['convention_name'] . " OGRe Game Registration Confirmation";                       
            }
            else{
                if(trim($p["pnotes"])!=""){
                    $ret['message'] = $p["pname"] . " ( " . $p["pemail"] . " ) " . "<br /><br />Player to GM Message<br /><br />";
                    $ret['message'] .= 'GAME: '. $p['game_name'] . ".<br /><br />";                             
                    $ret['message'] .= ($p['game_title']!='')? 'TITLE: ' .$p['game_title'] .'<br /><br />' : "";
                    $ret['message'] .= 'DAY: ' .$p['slot_day'] .'<br /><br />';  
                    $ret['message'] .= 'TIME: ' .$p['slot_time'] .'<br /><br />';                        
                    $ret['message'] .= "Notes to the GM: " . $p["pnotes"];
                    $ret['subject'] = $p['convention_name'] . " OGRe Game Registration: GM Contact";                                
                }
                $ret['resp'] .= '<div class="prereg_response">';
                $ret['resp'] .= '<p>Pre-Registration Updated</p>';
                $ret['resp'] .= '</div>';
            }
        }
        else
        {
            $ret['resp'] .= '<div class="prereg_response">';
            $ret['resp'] .= '<p>Error In Registraton! Contact Gaming Coorinator</p>';
            $ret['resp'] .= (isset($ret['msg'])) ? '<p>'.$ret['msg'].'</p>' : "";
            $ret['resp'] .= '</div>';
        }   
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------               
    public function registerPlayerFooter($admin, $gid){
        $ci = &get_instance();          
        $ret = $ci->event->registerPlayerFooter($admin, $gid);
        return $ret;
    }        
//---------------------------------------------------
//
//---------------------------------------------------            
    public function registerPlayerOnsite($p, $gameid, $gm=0){
        $ci=&get_instance();
        $ret2=FALSE;
        $ci->event->event_init($gameid);
        $conid = $ci->session->ogre_conid;
        if($p['ogreidnum'] != ''){
            $ci->person->init($conid, '', intval($p['ogreidnum']));
            $userid=$ci->person->user_id_num;  
            $p['pnamefirst'] = $ci->person->firstname;
            $p['pnamelast'] = $ci->person->lastname;
            $p['pemail'] = $ci->person->email;
        }
        else{
            $ci->person->init($conid, $p['pemail']);
            $userid = $ci->person->user_id_num;                
        }
        $p['userID']=$userid;
        $p["playgm"]='0';
        $p["activity2"]= (($gm==0) ? 'Player': 'Judge');
        $p['judgeAPL'] = '';
        $p["pnotes"] ='';
        $p["pname"]=$p['pnamefirst'] . ' ' . $p['pnamelast'];
        $p["combatrole"]='';
        $p["charlevel"]='';
        $p["playerAPL"]='';
        $alternate = (($p["alternate"]==1)? TRUE : FALSE);
        if(intval($userid) == 0){  
            $userid = $this->makeQuickUserProfile($conid, $p);
        }
        $ret = (($userid!=0) ? $ci->event->registerPlayer($p, $userid,FALSE,$alternate) : $ci->event->registerPlayer($p,0,TRUE,$alternate));
        $msparentid=$ret['pp_player_prereg_id'];
        if($ret['result']===TRUE){                                 
            if ($ci->event->rpga_number_of_slots > 1){
                $pms1=$this->insertMultiSlotPrereg($msparentid);
                $i=2;
                $childid = $ci->event->findOPMultiRoundChild();
                foreach($childid as $child2){                                         
                    $ci->event->event_init($child2);
                    $c = (($userid!=0) ? $ci->event->registerPlayer($p, $userid,FALSE,$alternate) : $ci->event->registerPlayer($p,0,TRUE,$alternate));
                    $c2 = $this->updateMultiSlotPrereg($msparentid, $c['pp_player_prereg_id'], $i); 
                    $i++;
                }
            }
        }
        if ($ret['result']==TRUE){
            $ret2='<p>Player is registered</p>';
            $ret2.=$ci->event->onsiteGamePlayerAdmin($gameid);
        }
        return $ret2;
    }
//---------------------------------------------------
//
//---------------------------------------------------      
    public function makeQuickUserActiveProfile($conid, $p){
        $ci = &get_instance();
        if(trim($p['pemail']) != ''){
            $p["userloginid"] = $p['pemail']; 
            $p["user_email"] = $p['pemail']; 
            $p["userfirstname"] = addslashes($p['pnamefirst']);
            $p["userlastname"] = addslashes($p['pnamelast']);
            $p['userpassword1'] = $ci->admin_lib->genRandomString(8);
            $p['userpassword2'] = $p['userpassword1'];
            $p["RPGANumber"] = ''; 
            $ret = $ci->person->saveProfileInfo($p);
            $ci->person->init($conid, $p['pemail']);
            $ci->person->activate();
        }
        return $ci->person->user_id_num;
    }
    
//------------------------------------------
//
//------------------------------------------             
    public function insertMultiSlotPrereg($parent){
        $ci=&get_instance();
        if($parent!=0){
           $qry = 'INSERT INTO ogre_prereg_multislot(';
           $qry .= 'pms_slot1_id ';
           $qry .= ') ';
           $qry .= ' VALUES (';
           $qry .= $parent . ') ';
        }     
       $ci->db->query($qry);
       $ret=($ci->db->affectedRows() > 0)?TRUE:FALSE;
       return $ret;
    }
         
//------------------------------------------
//
//------------------------------------------             
    public function updateMultiSlotPrereg($parent, $child, $i){
        $ci=&get_instance();
        if($parent !=0 && $i <= 18){
           $qry = 'UPDATE ogre_prereg_multislot SET ';
           $qry .= 'pms_slot'.$i.'_id=';
           $qry .= $child;
           $qry .= ' WHERE pms_slot1_id=';
           $qry .= $parent;
        }
       $ci->db->query($qry);
       $ret=($ci->db->affectedRows() > 0)?TRUE:FALSE;
       return $ret;
    }
     
//------------------------------------------
//
//------------------------------------------            
    private function getGMNameSelect($conid, $selval='0'){
       $ci=&get_instance();
       $logged_in = $ci->session->ogre_logged_in;
       $act = $ci->session->get('ogre_user_activated_' . $conid);            
       $qry = 'SELECT DISTINCT ogre_prereg_player.pp_player_id, ';
       $qry .= ' ogre_users.user_full_name, ogre_users.user_first_name, ';
       $qry .= ' ogre_users.user_last_name, ogre_users.user_access_rating2 ';
       $qry .= ' FROM (ogre_gameschedule INNER JOIN ogre_prereg_player ON ogre_gameschedule.gs_id = ogre_prereg_player.pp_gs_id)  ';
       $qry .= ' INNER JOIN ogre_users ON ogre_prereg_player.pp_player_id = ogre_users.user_index_id';
       $qry .= ' WHERE ABS(ogre_prereg_player.pp_gm_judge_flag) = 1  ';
       $qry .= ' AND ogre_gameschedule.gs_convention_id = ' . $conid;
       $qry .= ' OR ogre_users.user_access_rating2 >= ' . CONADMIN;
       $qry .= ' ORDER BY ogre_users.user_last_name, ogre_users.user_first_name;';                          
       $ret = "";
       $query = $ci->db->query($qry);
       if ($query->getNumRows() > 0){
           foreach ($query->getResult() as $row){
               $pname1 = ($logged_in == TRUE && $act == 1) ? $row->user_last_name.', '.$row->user_first_name : substr(trim($row->user_last_name), 0, 1).', ' .$row->user_first_name;
               $ret .= ($row->pp_player_id == $selval) ? '<option value="'. $row->pp_player_id . '" selected>' . htmlspecialchars($pname1) . '</option>' : '<option value="'. $row->pp_player_id . '">' . htmlspecialchars($pname1) . '</option>';
           }
       }
       return $ret;	
    }
         
//------------------------------------------
//
//------------------------------------------            
    public function buildTickethtml($pid=0){
       $ci=&get_instance();
       $conid = $ci->session->ogre_conid;
       $ret ='';
       if ($pid != 0){                
           $ret = $ci->person->getTickets($pid, $conid);
       }             
       return $ret;
    }  
//------------------------------------------
//
//------------------------------------------            
    private function onsitePlayerTickets($accessrating){
       $ret=''; 
       $ci = &get_instance();          
       if($accessrating >= REGVOL){                                                                
           $ret .= '<div id="player-ticket-form">';
           $ret .= '<form method="POST" id="play-tick-form" name="play-tick-form" action="">'; 
           $ret .= '<label for="player-ticket-email">Player Email</label>';
           $paction = site_url('ogrex/checkUserEmail','https');
           $ret .= '<input class="form-control form-control-sm" type="text" name="player-ticket-email" id="player-ticket-email"  onfocus="clearother(1);" onblur="playTicketPlayerLookup('."'','".$paction."'".')"   /> ';               
           $ret .= ' <span id="play-tick-player2"></span>';
           $ret .= '<label for="player-ticket-ogreid">Player OGRe ID</label>';
           $eaction = site_url('ogrex/getRegisterByNumPlayerInfo','https');
           $ret .= '<input class="form-control form-control-sm" type="text" name="player-ticket-ogreid" id="player-ticket-ogreid" onfocus="clearother(0);" onblur="playTicketPlayerLookup('."'".$eaction."',''".')" />';
           $ret .= '<div class="d-grid gap-2 mt-2" id="print-player-tickets-buttons">';
           $raction = site_url('ogre_pdf/pdfTickets','https');
           $ret .= '<input type="button" class="btn btn-primary btn-sm" type="button" id="player-tickets-button" name="player-tickets-button" onclick="pdfPlayerTickets(' . "'" . $raction . "'" . ');" value="  Ticket PDF  " />';
           $raction = site_url('ogre_pdf/pdfMyscedule','https');
           $ret .= '<input type="button" class="btn btn-primary btn-sm" type="button" id="player-tickets-button" name="player-tickets-button" onclick="pdfPlayerTickets(' . "'" . $raction . "'" . ');" value="  Schedule PDF  " />';
           $raction = site_url('ogre_pdf/pdfPlayerList','https');
           $ret .= '<input type="button" class="btn btn-primary btn-sm" type="button" id="playertickets_button" name="playerlist_button" onclick="pdfPlayerTickets(' . "'" . $raction . "'" . ');" value="  Player List PDF (GMs Only) " />';
           $ret .= '</div>';
           $ret .= '</form>';
           $ret .= '<div id="results" class="text-success"></div>';
           $ret .= '</div>';

       } 
       return $ret;           
    }         
//------------------------------------------
//
//------------------------------------------            
    public function onsiteRegisterByNumbers($accessrating){
       $ret=''; 
       $ci = &get_instance();    
       $conid = $ci->session->ogre_conid;                                     
       $now_date = new Time();
       $end_date = $ci->ogre_lib->getConGamingInfoKey($conid,'con_gaming_reg_close_date');
       $close_date = new Time($end_date);
       if($now_date->format("U") > $close_date->format("U")){                                 
           if($accessrating >= REGVOL){                                                                
                   $ret .= '<div id="register-by-numbers-form" style="display:block;">';
                   $ret .= '<form method="POST" id="reg-by-num-form" name="reg-by-num-form" action="">'; 
                   $ret .= '<label for="register-by-numbers-eventid">Event ID</label>';                        
                   $eaction = site_url('ogrex/getRegisteByNumEventInfo','https');
                   $ret .= '<input class="form-control form-control-sm" type="text" name="register-by-numbers-eventid" id="register-by-numbers-eventid" onblur="regByNumGameLookup('."'".$eaction."'".')" />';                                              

                   $ret .= 'Player OGRe ID';
                   $paction = site_url('ogrex/getRegisterByNumPlayerInfo','https');
                   $ret .= '<input type="text"  class="form-control form-control-sm" name="registerbynumbers_ogreid" id="registerbynumbers_ogreid"  onblur="regByNumPlayerLookup('."'".$paction."'".')" />';  
                   $ret .= '<div id="register-by-numbers-game">';
                   $ret .= '&nbsp;';                    
                   $ret .= '</div>';                                                                    
                   $ret .= '<div id="register-by-numbers-player">';
                   $ret .= '&nbsp;';  
                   $ret .= '</div>';
                   $ret .= '<div id="register-by-numbers-buttons"><div class="d-grid gap-2">';
                   $raction = site_url('ogrex/regActionRegByNum','https');
                   $ret .= '<input type="button" class="btn btn-primary" id="registerbynumbers_button" name="registerbynumbers_button" onclick="addPlayerRegByNum(' . "'" . $raction . "'" . ');" value="  Register  " />';
                   $ret .= '</div>'; 
                   $ret .= '</form>';
                   $ret .= '</div>'; 
                   $ret .= '<div id="results" class="results"></div>';
                   $ret .= '</div>';
           } 
       }
       else{
           $ret .= '<div id="register-by-numbers-form" style="display:block;">';
           $ret .= '<p>On Site Registration not open yet.</p>';
           $ret .= '</div>';
       } 
       return $ret;           
    }    
//------------------------
//
//------------------------
    public function getOptionsTabMenu($id, $conid, $p, $dmode="P"){
        $ci=&get_instance();           
        $orgid = $ci->session->ogre_orgid;          
        $qry = 'SELECT * FROM ogre_menus WHERE mnu_loc="5TAB" AND mnu_display = 1 AND mnu_sub_id =' . $id . ' ORDER BY mnu_code';
        $ret = '';
        $pid = $ci->session->ogre_user_ID;
        $logged_in = $ci->session->ogre_logged_in;
        $grtotal = (trim($pid) !=='') ? $ci->propose_lib->numberOfProposal($pid) : 0;
        $pncount = $this->gameSchedulexCount('N');
        $query = $ci->db->query($qry);
        $ret .= '<div id="horizontalTab-schedule">';           
        $ret .= '<ul>';
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $mnucode = substr($row->mnu_code, 3, strlen($row->mnu_code)-1);               
                switch($mnucode){
                    case 'OGRE.OPTIONS.MYPROPOSALS':
                        if($grtotal >0){
                            if($ci->session->get('ogre_user_accesslevel_' . $orgid) >= $row->mnu_securitylevel){                    
                                $tabcode = substr($row->mnu_code, -1, 1);
                                $ret .= '<li>';
                                $ret .= '<a title="'.$row->mnu_notes.'" href="#schedule-tab-'. $row->mnu_id .'" >';
                                $ret .= $row->mnu_text;
                                $ret .= '</a>';
                                $ret .= '</li>';
                            }                             
                        }
                    break;
                    case 'OGRE.OPTIONS.DOWNLOAD':
                        if($ci->session->get('ogre_user_accesslevel_' . $orgid) >= $row->mnu_securitylevel){                    
                            $tabcode = substr($row->mnu_code, -1, 1);
                            $ret .= '<li>';
                            $ret .= '<a title="'.$row->mnu_notes.'" href="#schedule-tab-'. $row->mnu_id .'" >';
                            $ret .= $row->mnu_text;
                            $ret .= '</a>';
                            $ret .= '</li>';
                        }
                    break;                    
                    case 'OGRE.OPTIONS.PANEL.SCHEDULE.N':
                        if($pncount > 0){
                            if($ci->session->get('ogre_user_accesslevel_' . $orgid) >= $row->mnu_securitylevel){                    
                                $tabcode = substr($row->mnu_code, -1, 1);
                                $ret .= '<li>';
                                $ret .= '<a title="'.$row->mnu_notes.'" href="#schedule-tab-'. $row->mnu_id .'" >';
                                $ret .= $row->mnu_text;
                                $ret .= '</a>';
                                $ret .= '</li>';
                            }                             
                        }
                    break;                            

                    default:
                        if($ci->session->get('ogre_user_accesslevel_' . $orgid) >= $row->mnu_securitylevel){                    
                            $tabcode = substr($row->mnu_code, -1, 1);
                            $ret .= '<li>';
                            $ret .= '<a title="'.$row->mnu_notes.'" href="#schedule-tab-'. $row->mnu_id .'" >';
                            $ret .= $row->mnu_text;
                            $ret .= '</a>';
                            $ret .= '</li>';
                        }
                    break;
                }     
            }
        }
        $ret .= '</ul>';
        
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                if($ci->session->get('ogre_user_accesslevel_' . $orgid) >= $row->mnu_securitylevel){                    
                    $ret .= '<div id="schedule-tab-'. $row->mnu_id .'">';
                    $mnucode = substr($row->mnu_code, 3, strlen($row->mnu_code)-1);
                        switch($mnucode){
                            case 'OGRE.OPTIONS.SCHEDULE.P':
                                $ret .= $this->gameScheduleXBody($conid, $p, 'P');
                                break;
                            case 'OGRE.OPTIONS.PANEL.SCHEDULE.N':
                                if($pncount > 0){
                                    $p = ["gameslot" => 0, "keyword" => '',"gamename" => 0,"affiliation" => 0, "gametype" => 0, "descriptor" => 0];                                      
                                    $whatsnew = FALSE; 
                                    $ret .= $this->gameScheduleXBody($conid, $p, 'N');    
                                }
                                break;
                            case 'OGRE.OPTIONS.GAMELIST':
                                $ret .= '<table width="100%">';
                                $ret .= '<tr>' . '<td>';
                                $ret .= '<h1>Game List</h1>';
                                $ret .= '</td>';
                                $ret .= '<td id="sortbuttons">';
                                $ret .= '<form method="POST">';
                                $action = site_url('ogrex/getGameList','https');
                                $locdiv = 'schedule-view_gamelist';
                                $ret .= '<label for="game-list" style="margin: 0 5px 0 5px;">Show by:  </label>';      
                                $ret .= '<div class="btn-group" id="game-list" role="group" aria-label="Basic radio toggle button group">';
                                $ret .='<input type="radio" class="btn-check"  autocomplete="off" name="sortBy" id="sortGameType" onclick="gameListResort('."'".$action."','". $locdiv. "','" .'gametype' . "'".');">';
                                $ret .='<label class="btn btn-outline-primary" for="sortGameType" onclick="">Game Type</label>';
                                $ret .= '<input type="radio" class="btn-check" autocomplete="off" name="sortBy" id="sortCompany" onclick="gameListResort('."'".$action."','". $locdiv. "','" .'company' . "'".');">';
                                $ret .= '<label onclick="" for="sortCompany" class="btn btn-outline-primary">Publisher</label>';
                                $ret .='</div>';    
                              
                                $ret .= '</div>';
                                $ret .= '</div>';
                                $ret .= '</form>';
                                $ret .= '</td>' . '</tr>';
                                $ret .= '</table>';
                                $image_properties = array('src' =>'images/ajax-loader.gif','alt'=>'ajax-loader.gif'); 
                                $ret .= '<div id="wait2" style="display: none">' . img($image_properties) . '</div>';                                    
                                $ret .= '<div id="schedule-view_gamelist" style="display:block;padding-top:5px;">'; 
                                $ret .= '</div>';   
                                break;
                            case 'OGRE.OPTIONS.MYPROPOSALS':
                                if($grtotal >0){
                                    $ret .= '<div id="schedule-view_myschedule" style="display:block;padding-top:5px;">'; 
                                    $ret .= '<div id="myproposalview">';
                                    $ret .= $ci->person->displayPlayerRequests();
                                    $ret .= '</div>';
                                    $ret .= '</div>';   
                                }
                                break;
                            case 'OGRE.OPTIONS.REGISTERBYNUMBERS':                                    
                                $ret .= '<h1>Register by the numbers</h1>';
                                $ret .= '<p>You must have both the Event ID and the OGRe ID of the participant.</p>';
                                $ret .= '<div id="schedule-view_onsite" style="display:block;padding-top:5px;">'; 
                                $curr_userid = $ci->session->ogre_user_ID;
                                if ($curr_userid != 0){
                                    $ci->person->init($conid, '', $curr_userid);
                                    $accessrating = $ci->person->access_rating;
                                }else{
                                    $accessrating = 10;
                                }                                    
                                $ret .= $this->onsiteRegisterByNumbers($accessrating);
                                $ret .= '</div>';
//                                $ret .= '<h2>Onsite Confirm</h2>';
//                                $ret .= '<div id="onsiteconfirmform" style="padding-top:25px;">';
//                                $ret .= $this->onsite_confirm($conid);
//                                $ret .= '</div>';
//                                $ret .= '<h2>Onsite Confirm Delete</h2>';
//                                $ret .= '<div id="onsiteconfirmform" style="padding-top:25px;">';
//                                $ret .= $this->onsite_confirm($conid,'del');
//                                $ret .= '</div>';                                    
                                break; 
                                
                            case 'OGRE.OPTIONS.PDFS':
                                $curr_userid = $ci->session->ogre_user_ID;
                                if ($curr_userid != 0){
                                    $ci->person->init($conid, '', $curr_userid);
                                    $accessrating = $ci->person->access_rating;
                                }                                   
                                $ret .= '<h3>PDFs</h3>';
                                $ret .= '<p><strong>Name of Attendee:</strong> <span id="play-tick-player1"> <em>Enter Email or OGRe ID Number below.</em></span></p>';
                                $ret .= '<div id="player-ticket-onsite" style="display:block;padding-top:5px;">'; 
                                if ($curr_userid != 0){
                                    $ci->person->init($conid, '', $curr_userid);
                                    $accessrating = $ci->person->access_rating;
                                }                                    
                                $ret .= $this->onsitePlayerTickets($accessrating);
                                
                                
                                $ret .= '</div>';                                 
                                break;
                            case 'OGRE.OPTIONS.ORGPLAY': 
                                $aff = '0';
                                $late = 0;
                                $print = FALSE;
                                $ret .= $ci->RPGA_lib->gen_row_enum(0, $conid);   
                                $ret .=  $ci->RPGA_lib->rpga_schedule_title($aff, $late, $print, TRUE);
                                $mc = $ci->ogre_lib->getMiscContent(7);
                                $ret .= '<table><tr><td>' . $mc["content"] . '</td></tr></table>';                                   
                                break; 
                            case 'OGRE.OPTIONS.DOWNLOAD': 
                                $aff = '0';
                                $late = 0;
                                $print = FALSE;
                                if ($logged_in===TRUE){
                                    $useridnum = $ci->session->ogre_user_ID;
                                    $ret .= $this->getSchedulePDFLinks($useridnum);
                                }                                 
                                break;                             
                            
                            default:
                                $ret .= $row->mnu_id;
                                break;
                        }
                        $ret .= '</div>';
                    }
                }
            }            
            $ret .= '</div>';
            return $ret;
        }
//------------------------
//
//
//
//------------------------          
        public function refesh_prereglnk($gid){
            $ci=&get_instance();
            $ci->event->event_init($gid);
            $orgid = $ci->session->ogre_orgid;
            $conid = $ci->session->ogre_conid; 
            $accessrating = 0 ;
            $verified=0;
            $logged=$ci->session->ogre_logged_in;
            if($logged != FALSE){
                $accessrating = $ci->session->get('ogre_user_accesslevel_' . $orgid);
                $verified= $ci->session->get('ogre_user_activated_' . $conid);                         
            }            
            $mode = 'all';
 	    $ret = (intval($ci->event->rpga_game_round) > 1) ? '-' : $this->getPreregLinkReg(intval($ci->event->prereg_players_allowed), $ci->event->id, $ci->event->mmrpgFlag, $accessrating, $verified);
             return $ret;
        }
//------------------------
//
//
//
//------------------------        
        public function refesh_open_seats($gid){
            $ci=&get_instance();
            $ci->event->event_init($gid);
            $ret='';
            $numPlayers = $ci->event->getPreregNum($ci->event->id);		
            $numTotlPlayers = $ci->event->getPlayerNum($ci->event->id, $ci->event->prereg_players_allowed);            
            if (is_numeric($numPlayers) && is_numeric($numTotlPlayers)){                              			
                if (intval($numTotlPlayers) == 0){
                        $ret .= '-';
                }
                else{
                    if ($numPlayers==0){
                        $ret .= $numTotlPlayers;
                    }
                    else{
                        $plist = $ci->event->getPlayerList(0);
                        if(intval($numPlayers) > $numTotlPlayers){
                            $of = intval($numPlayers) - intval($numTotlPlayers);
                            $numPlayersDisplay = '0' . " (+".$of.")";
                        }
                        else{
                            $numPlayersDisplay = intval($numTotlPlayers) - intval($numPlayers);
                        }
                        $ret .= $numPlayersDisplay;
                    }
                }
            } 
            return $ret;
        }
//------------------------
//
//------------------------  
    public function myschedule($print=FALSE){                
        $ci=&get_instance();
        $conid = $ci->session->ogre_conid;
        $gpopen = $ci->convention->isGamePreregOpen($conid);
        $ret = $ci->person_lib->getMySchedulex($print, $gpopen);
        return $ret;
     }   
 
//---------------------------------------------------
//
//
//
//---------------------------------------------------                 
    public function onsite_confirm($cid=0, $confordel="conf"){
        $ci = &get_instance(); 
        $conid = ($cid===0)? $ci->session->ogre_conid : $cid;
        if($confordel==="conf"){
            $sql = 'SELECT ogre_gameschedule.gs_game_name, ';
            $sql .= ' ogre_gameschedule.gs_game_title, ';
            $sql .= ' ogre_gameschedule.gs_slot_day, ';
            $sql .= ' ogre_gameschedule.gs_slot_time, ';
            $sql .= ' ogre_prereg_player.pp_player_name, ';
            $sql .= ' ogre_prereg_player.pp_player_prereg_id, ';
            $sql .= ' ogre_prereg_player.pp_gm_judge_flag, ';
            $sql .= ' ogre_gameschedule.gs_table_number ';
            $sql .= ' FROM ogre_gameschedule INNER JOIN ogre_prereg_player ';
            $sql .= ' ON ogre_gameschedule.gs_id = ogre_prereg_player.pp_gs_id ';
            $sql .= ' WHERE ogre_gameschedule.gs_convention_id = ' . $conid;
            $sql .= ' AND ogre_prereg_player.pp_player_confirmed = -1';
            $sql .= ' AND ogre_prereg_player.pp_delete_flag = 0';
            $sql .= ' ORDER BY ogre_gameschedule.gs_slot_code';
            $chkaction = site_url('ogrex/onisteConfirm/','https');
            $divid = "onsiteconfirm";
            $rowid = "confreg";
        }
        else{
            $sql = 'SELECT ogre_gameschedule.gs_game_name, ';
            $sql .= ' ogre_gameschedule.gs_game_title, ';
            $sql .= ' ogre_gameschedule.gs_slot_day, ';
            $sql .= ' ogre_gameschedule.gs_slot_time, ';
            $sql .= ' ogre_prereg_player.pp_player_name, ';
            $sql .= ' ogre_prereg_player.pp_player_prereg_id, ';
            $sql .= ' ogre_prereg_player.pp_gm_judge_flag, ';
            $sql .= ' ogre_gameschedule.gs_table_number ';
            $sql .= ' FROM ogre_gameschedule INNER JOIN ogre_prereg_player ';
            $sql .= ' ON ogre_gameschedule.gs_id = ogre_prereg_player.pp_gs_id ';
            $sql .= ' WHERE ogre_gameschedule.gs_convention_id = ' . $conid;
            $sql .= ' AND ogre_prereg_player.pp_player_confirmed <> -1';
            $sql .= ' AND ogre_prereg_player.pp_delete_flag = -1';
            $sql .= ' ORDER BY ogre_gameschedule.gs_slot_code';
            $chkaction = site_url('ogrex/onsite_delete/','https');  
            $divid = "onsitedelete";
            $rowid = "confdel";
        }
        $ret = '<table id="'.$divid.'" class="onsiteconfirm">';
        $ret .= '<tr>';
        $ret .= '<th>';
        $ret .= 'Game Time/Location';
        $ret .= '</th>';
        $ret .= '<th>';
        $ret .= 'Game Name';
        $ret .= '</th>';
        $ret .= '<th>';
        $ret .= 'Player Name';
        $ret .= '</th>';
        $ret .= '<th>';
        $ret .= 'Confirm';
        $ret .= '</th>';                
        $ret .= '</tr>';        
        $query = $ci->db->query($sql);
        if ($query->getNumRows() > 0){ 
            foreach ($query->getResult() as $row){     
                $ret .= '<tr>';
                $ret .= '<td>';
                $ret .= $row->gs_slot_day . ': ' . $row->gs_slot_time . ' at ' . $row->gs_table_number;
                $ret .= '</td>';
                $ret .= '<td>';
                $ret .= $row->gs_game_name;
                $ret .= (trim($row->gs_game_title)!='' ?  ': ' . $row->gs_game_title : '');
                $ret .= '</td>';
                $ret .= '<td>';
                $ret .= $row->pp_player_name . ((intval($row->pp_gm_judge_flag) == 0) ? ' (PL)': ((intval($row->pp_gm_judge_flag) == 1) ? ' (GM)': '(PGM)'));
                $ret .= '</td>';
                $ret .= '<td>';
                $ret .= '<input type="checkbox" id="'.$rowid.$row->pp_player_prereg_id.'" name="'.$rowid.$row->pp_player_prereg_id.'"  onclick="confirm_reg('.$row->pp_player_prereg_id.",'".$chkaction."','".$divid."'".');" />';
                $ret .= '</td>';                
                $ret .= '</tr>';
            }   
        $ret .= '<tr>';
        $ret .= '<td colspan="4">';
        $ret .= ' TOTAL: ' . $query->getNumRows();
        $ret .= '</td>';                
        $ret .= '</tr>';        
            
        }
        $ret .= '</table>';
        return $ret;
    }          
 
    //---------------------------------------------------
    //
    //
    //
    //---------------------------------------------------                 
    public function confirmPreregPlayer($id=0){
             $ci=&get_instance();
             $ret = TRUE;
             if($id!=0){
                $qry = "UPDATE ogre_prereg_player SET ";
                $qry .= " pp_player_confirmed = 1 ";
                $qry .= " WHERE pp_player_prereg_id = " . $id . ";";
                $ci->db->query($qry);
                $ret=($ci->db->affectedRows() > 0)?TRUE:FALSE;                
             }
            return $ret;        
    }   
    
//---------------------------------------------------
//
//
//
//---------------------------------------------------                 
    public function confirmDeletePlayer($id=0){
             $ci=&get_instance();
             $ret = TRUE;
             if($id != 0){
                $qry = "UPDATE ogre_prereg_player SET ";
                $qry .= " pp_delete_flag = 1, ";
                $qry .= " pp_datemodified = NOW() ";
                $qry .= " WHERE pp_player_prereg_id = " . $id . ";";
                $ci->db->query($qry);
                $ret=($ci->db->affectedRows() > 0)?TRUE:FALSE;                
             }
            return $ret;        
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------     
    public function shareScheduleLink($type, $id){
        $ci = &get_instance();
        $orgid = $ci->session->ogre_orgid;
        $conid = $ci->session->ogre_conid;
        $ci->organization->init($orgid);
        $ci->convention->init($conid);
        $controller = $ci->organization->ogrecontroller;
        $share = site_url($controller . '/share/' . $type . '/'. $id,'https');
        $image_properties = array('src' =>'images/fbshare.png','alt'=>'FBShare', 'height'=>'25');
        $ret = '<p>Share My GM Schedule: ';
        $ret .= '<span class="fb-share-button" data-href="' . $share. '" data-layout="button" data-size="small" data-mobile-iframe="true">';
        $ret .= '<a class="fb-xfbml-parse-ignore" target="_blank" ';
        $ret .= ' href="https://www.facebook.com/sharer/sharer.php?u='. urlencode($share)  .'&amp;src=sdkpreparse';
        $ret .= '&picture='. base_url() .'images/ogrelogo1.jpg';
        $ret .= '&title=' . urlencode($ci->convention->name . ' ' . $ci->ogre_lib->ogreTitle());
        $ret .= '&caption=' . urlencode($ci->convention->name . ' ' .$ci->ogre_lib->ogreTitle() . ' Schedule Share') ;
        $ret .= '&description='. urlencode('Sharing my GM schedule for ' . $ci->convention->name);
        $ret .= '"';
        $ret .= '>'.img($image_properties).'</a></span>';
        $ret .= '</p>';   
        return $ret;
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------     
    public function getBreakDownList($conid,$dmode){
        $ci = &get_instance();
        $sql = 'SELECT ';
        $sql .= ' ogre_games_descriptor.gd_id,  ';
        $sql .= ' ogre_games_descriptor.gd_descriptor,  ';
        $sql .= ' ogre_games_descriptor.gd_descriptor_type ';
        $sql .= ' FROM ogre_games_descriptor ';
        $sql .= ' WHERE gd_descriptor_type = 1 ';
        if ($dmode=="P"){
            $sql .= ' AND (ogre_games_descriptor.gd_id <> 22';
            $sql .= ' AND ogre_games_descriptor.gd_id <> 23';
            $sql .= ' AND ogre_games_descriptor.gd_id <> 14';
            $sql .= ' AND ogre_games_descriptor.gd_id <> 125)';
        }
        else
        {
            $sql .= ' AND (ogre_games_descriptor.gd_id = 14';
            $sql .= ' OR ogre_games_descriptor.gd_id = 125)';            
        }
        $ret = '<h4 class="card-title mt-3">Schedule Breakdown by Game Type</h4>';
        $ret .= '<ul class="list-group">';
        $query = $ci->db->query($sql);
        if ($query->getNumRows() > 0){ 
            foreach ($query->getResult() as $row){          
                $ret .= '<li class="list-group-item d-flex justify-content-between align-items-center">';
                $ret .= $row->gd_descriptor;
                $ret .= '<h6><span class="badge rounded-pill bg-primary">';
                $ret .= $this->getBreakDownList_count($conid, $row->gd_id, $dmode);
                $ret .= '</span></h6>';
                $ret .= '</li>';
            }
        }

        $ret .= '</ul>';
        return $ret;
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------     
    public function getBreakDownList_count($conid, $dscid, $dmode){
        $ret = '0';                    
        $sql =''; 
        $ci = &get_instance();
        $sql .= 'SELECT COUNT(ogre_gameschedule.gs_gn_id) AS CountOfgs_gn_id';
        $sql .= ' FROM ogre_gameschedule, ogre_games_descriptor_xref ';
        $sql .= ' WHERE ogre_gameschedule.gs_gn_id = ogre_games_descriptor_xref.gdx_gn_id ';
        $sql .= ' AND ogre_gameschedule.gs_convention_id= '.$conid.' ';
        $sql .= ' AND ogre_games_descriptor_xref.gdx_gd_id=' . $dscid;
        $sql .=' AND ogre_gameschedule.gs_cancelled=0 AND ogre_gameschedule.gs_displaymode = "'.$dmode.'" ';
        $query = $ci->db->query($sql);
        if ($query->getNumRows() > 0){ 
            foreach ($query->getResult() as $row){          
                $ret = $row->CountOfgs_gn_id;
            }
        }
        return $ret;
    }
//---------------------------------------------------
//
//
//
//---------------------------------------------------     
    public function getTotalSeatsAvailable($conid, $dscid=0){
        $ci = &get_instance();
        $ret = '0';                    
        $sql ='';
        $sql .= 'SELECT SUM(ogre_gameschedule.gs_max_number_of_players) AS TOTALPLAYERS';
        $sql .= ' FROM ogre_gameschedule, ogre_games_descriptor_xref,ogre_games_descriptor ';
        $sql .= ' WHERE ogre_gameschedule.gs_gn_id = ogre_games_descriptor_xref.gdx_gn_id ';
        $sql .= ' AND ogre_games_descriptor.gd_id = ogre_games_descriptor_xref.gdx_gd_id ';
        $sql .= ' AND ogre_gameschedule.gs_convention_id= '.$conid.' ';
        $sql .= (($dscid != 0) ? ' AND ogre_games_descriptor_xref.gdx_gd_id=' . $dscid : ' AND ogre_games_descriptor.gd_descriptor_type=1');
        $sql .=' AND ogre_gameschedule.gs_cancelled=0 AND ogre_gameschedule.gs_displaymode = "P" ';
        $query = $ci->db->query($sql);
        if ($query->getNumRows() > 0){ 
            foreach ($query->getResult() as $row){          
                $ret = $row->TOTALPLAYERS;
            }
        }
        return ($ret == NULL ? '0' : $ret);
    }    
//---------------------------------------------------
//
//
//
//---------------------------------------------------     
    public function getTotalSeatsTaken($conid, $dscid=0){
        $ret = '0';                    
        $sql =''; 
        $ci = &get_instance();
        $sql .= 'SELECT pp_player_prereg_id';
        $sql .= ' FROM ogre_prereg_player, ogre_gameschedule, ogre_games_descriptor_xref, ogre_games_descriptor ';
        $sql .= ' WHERE ogre_gameschedule.gs_gn_id = ogre_games_descriptor_xref.gdx_gn_id ';
        $sql .= ' AND ogre_games_descriptor.gd_id = ogre_games_descriptor_xref.gdx_gd_id ';
        $sql .= ' AND ogre_gameschedule.gs_id = ogre_prereg_player.pp_gs_id ';
        $sql .= ' AND ogre_gameschedule.gs_convention_id= '.$conid.' ';
        if ($dscid != 0){
            $sql .= ' AND ogre_games_descriptor_xref.gdx_gd_id=' . $dscid;
        }else{
           $sql .= ' AND ogre_games_descriptor.gd_descriptor_type = 1'; 
        }
        $sql .=' AND ogre_prereg_player.pp_delete_flag=0 AND ABS(ogre_prereg_player.pp_gm_judge_flag) <> 1 ';
        $sql .=' AND ogre_gameschedule.gs_cancelled=0 AND ogre_gameschedule.gs_displaymode = "P" ';
        $query = $ci->db->query($sql);
        return $query->getNumRows();
    }        
//---------------------------------------------------
//
//---------------------------------------------------     
    public function getSeatTotals($conid=0){  
        $ci = &get_instance();
        $ret = '';  
        $conid = (($conid ==0) ? $ci->session->ogre_conid : $conid);
        $seats = $ci->schedule_lib->getTotalSeatsAvailable($conid );
        $taken = $ci->schedule_lib->getTotalSeatsTaken($conid);
        $ret .= '<h4 class="card-title mt-3">Totals</h4>';
        $ret .= '<ul class="list-group">';
        $ret .= '<li class="list-group-item list-group-item-light justify-content-between d-flex">';
        $ret .= 'TOTAL GAMES:';
        $ret .= '<h6><span class="badge bg-primary rounded-pill">';
        $ret .= $ci->schedule_lib->gameSchedulexCount('P');
        $ret .= '</span></h6>';
        $ret .= '</li>';
        $ret .= '<li class="list-group-item list-group-item-dark justify-content-between d-flex">';
        $ret .= 'NEW GAMES IN THE PAST 2 WEEKS:';
        $ret .= '<h6><span class="badge bg-primary rounded-pill">';
        $ret .= $this->gameSchedulexCount('P', TRUE);
        $ret .= '</span></h6>';
        $ret .= '</li>';          
        $ret .= '<li class="list-group-item list-group-item-light justify-content-between d-flex">';
        $ret .= 'TOTAL SEATS AVAILABLE:';
        $ret .= '<h6><span class="badge bg-primary rounded-pill">';
        $ret .= $seats;
        $ret .= '</span></h6>';
        $ret .= '</li>';
        $ret .= '<li class="list-group-item list-group-item-dark justify-content-between d-flex">';
        $ret .= 'TOTAL SEATS TAKEN:';
        $ret .= '<h6><span class="badge bg-primary rounded-pill">';
        $ret .= $taken;
        $ret .= '</span></h6>';
        $ret .= '</li>';
        $ret .= '<li class="list-group-item d-flex justify-content-between align-items-center">';
        $ret .= 'CAPACITY PERCENTAGE:';
        $ret .= '<h6><span class="badge bg-primary">';
        $perc = (intval($seats) > 0) ? (($taken/$seats)) : 0;
        $ret .= number_format(floatval($perc) * 100, 2) . "%";
        $ret .= '</span></h6>';
        $ret .= '</li>';        
        $ret .= '</ul>';
        return $ret;
    }
//------------------------------------------------   
//
//------------------------------------------------           
    public function bggLookupForm($id=0, $type='boardgame'){  
        $ci = &get_instance();
        $ret = ''; 
        $ret .= '<div id="results" class="results"></div>';
        $ret .= $ci->ogre_lib->getMiscContent('%%MyBGLSTEP2%%',0,TRUE);
        $ret .= '<div class="row">';
        $ret .= '<div class="col-6 mb-4">';
        $ret .= '<div class="card border-info h-100">';
        $ret .= '<h4 class="card-header">Add Games to My Library</h4>';
        $ret .= '<div class="card-body">';
        switch ($type){
            case 'both':        
                $ret .= '<h6 id="addgl1">Search BGGeek/RPGGeek</h6>';
                $ret .= '<h6 id="addgl2" style="display:none">Manual Entry</h6>';
                break;
            case 'boardgame':
                $ret .= '<h6 id="addgl1">Search BGGeek</h6>';
                $ret .= '<h6 id="addgl2" style="display:none">Manual Entry</h6>';
                break;            
            case 'rpgitem':
                $ret .= '<h6 id="addgl1"">Search RPGGeek</h6>';
                $ret .= '<h6 id="addgl2" style="display:none">Manual Entry</h6>';
                break;           
        }                   
        $ret .= '<div id="bggsearchform">';
        switch ($type){
            case 'both':
                $ret .= '<div class="input-group m-2">';
                $ret .= '<label for="bggsearchtype" class="form-label">Search Type:</label>';
                $ret .= '<select class="form-control" name="bggsearchtype" id="bggsearchtype" size="1" >';
                $ret .= '<option value="boardgame">Tabletop/Board/Card Game</option>';
                $ret .= '<option value="rpgitem"> RPG </option>';              
                $ret .= '</select>';
                $ret .= '</div>';
                break;
            case 'boardgame':
                $ret .= '<select class="form-control invisible" name="bggsearchtype" id="bggsearchtype" size="1" style="display:none;">';
                $ret .= '<option value="boardgame">Tabletop/Board/Card Game</option>';            
                $ret .= '</select>';
                break;            
            case 'rpgitem':
                $ret .= '<select class="form-control invisible" name="bggsearchtype" id="bggsearchtype" size="1" style="display:none;">';
                $ret .= '<option value="rpgitem"> RPG </option>';              
                $ret .= '</select>';
                break;           
        }
        $ret .= '<div class="input-group m-2">';
        $ret .= '<label for="bggsearch" class="form-label">Search for:</label>';
        $ret .= '<input class="form-control mx-1" placeholder="Name of the game"  name="bggsearch" id="bggsearch" type="text" />';
        $ret .= '<span class="input-group-btn">';
        $ret .= '<input name="bgglookup" id="bgglookup" type="button" class="btn btn-primary btn-sm mx-1" value=" Go " onclick="bgglookup_search();" />';
        $ret .= '</span>';
        $ret .= '</div>';
        $ret .= '<label for="bggresults">Search Results Appear here:</label>';
        $ret .= '<select name="bggresults" id="bggresults" size="5" class="form-control" style="overflow-y: scroll;">';
        $ret .= '</select>';
        $image_properties = array('src' =>'images/ajax-loader.gif'); 
        $ret .= '<div id="bgg-wait" style="display: none">' . img($image_properties) . '</div>';
        $ret .= '</div>'; // bggsearchform
        $ret .= '<input type="hidden" name="entrymode" id="entrymode" value="0" />';
        $ret .= '<div id="bglmanual" style="display:none">';
        $ret .= '<input class="form-control mx-1" name="bglname" id="bglname" type="text" placeholder="Game Name" />';
        $ret .= '<div class="row my-2">';        
        $ret .= '<div class="col-3">';
        $ret .= '<label for="minplay"># of players:</label>';
        $ret .= '</div>';
        $ret .= '<div class="col-3">';       
        $ret .= '<input type="text" id="minplay" name="minplay" type="text" placeholder="Min" value="3" class="form-control"/> ';
        $ret .= '</div>';
        $ret .= '<div class="col-3 text-center">';
        $ret .= ' to ';
        $ret .= '</div>';
        $ret .= '<div class="col-3">';
        $ret .= '<input type="text" id="maxplay" name="maxplay" value="6" placeholder="Max" class="form-control" />'; 
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '<div class="row my-2">';        
        $ret .= '<div class="col-12">';   
        $ret .= '<select class="form-control" name="bgltype" id="bgltype" size="1" >';        
        $ret .=  $ci->proposal->gameTypeSelect('Board/Tabletop Game');
        $ret .= '</select>'; 
        $ret .= '</div>';
        $ret .= '</div>';        
        $ret .= '<div class="row my-2">';        
        $ret .= '<div class="col-12">';        
        $ret .= '<textarea class="form-control" name="gamenotes" id="gamenotes" placeholder="Description (copy and paste text or html)"></textarea>';
        $ret .= '</div>';
        $ret .= '</div>';        
        $ret .= '</div>'; // bglmanual
        $ret .= '</div>';  //Card-body
        $ret .= '<div class="card-footer">';
        $ret .= '<button type="button" class="btn btn-primary" id="butAddtoMyListManual" style="display:none" onclick="addFromManual();">Add to My List</button>';
        $ret .= '<button type="button" class="btn btn-secondary" id="butToggleTobggSearch" style="display:none" onclick="showBggSearch();">BGG Search </button>';
        $ret .= '<button type="button" class="btn btn-primary" id="butAddtoMyList" onclick="addFromBGG();">Add to My List</button>';
        $ret .= '<button type="button" class="btn btn-secondary" id="butToggleToManual" onclick="showBglManual();" disabled="disabled">Manual Entry</button>';  //
        $ret .= '</div>';  //card-footer
        $ret .= '</div>'; // card
        $ret .= '</div>'; // col-
        $ret .= '<div class="col-6 mb-4">';
        $ret .= '<div class="card border-info h-100">';
        $ret .= '<h4 class="card-header">My Game Library</h4>';
        $ret .= '<div class="card-body">';
        $ret .= '<label for="mybglist"  >Your List Will Appear here:</label>';
        $ret .= '<select name="mybglist" id="mybglist" size="12" multiple="" class="form-control">';
        $ret .= '</select>';
        $ret .= '</div>';
        $ret .= '<div class="card-footer">';
        $ret .= '<button type="button" class="btn btn-primary" onclick="remFromMyBGL();">Remove from My List</button>';
        $ret .= '</div>';
        $ret .= '</div>';    
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '<script>';
        $ret .= '$("#bggsearch").keypress(function (e){var key = e.which; if(key == 13) { $("input[name = bgglookup]").click(); return false; }});';  
        $ret .= '</script>';
        return $ret;
    }  
//------------------------------------------------   
//
//------------------------------------------------     
    public function gameLibraryWizard($pid){
        $ci = &get_instance();
        $intr = $ci->ogre_lib->getMiscContent('%%PBGL-INSTRUCTIONS%%', 0, TRUE);
        $ret  = $intr;
        $action = site_url('ogrex/bgLibraryIn','https');
        $ret .= '<div id="bgl-result-box" class="alert alert-dismissible alert-success" style="display:none">';
        $ret .= '<button type="button" class="close" data-dismiss="alert">&times;</button>';
        $ret .= '<div id="bgl-results"></div></div>';
        $ret .= '<form id="board-game-library" method="POST" action="'.$action.'" onchange="pglChanged();">';
        $ret .= '<input type="hidden" id="changed" name="changed" value="0" />';
        $ret .= '<input type="hidden" id="wizardrefresh" name="wizardrefresh" value="" />';
        $ret .= '<div class="accordion" id="board-game-library">';
        $ret .= '<div class="accordion-item">';
        $ret .= '<h5 class="accordion-header" id="headingOne">';
        $ret .= '<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#bg-lib-name" aria-expanded="true" aria-controls="bg-lib-name">';
        $ret .= '1 - Name';
        $ret .= '</button>';
        $ret .= '</h5>';
        $ret .= '<div id="bg-lib-name" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#board-game-library">';
        $ret .= '<div class="accordion-body">';
        $ret .= $this->gameLibraryName();
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '<div class="accordion-item">';
        $ret .= '<h5 class="accordion-header" id="headingTwo">';
        $ret .= '<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#board-game-lib-list" aria-expanded="false" aria-controls="board-game-lib-list">';
        $ret .= '2 - Library';
        $ret .= '</button>';
        $ret .= '</h5>';
        $ret .= '<div id="board-game-lib-list" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#board-game-library">';
        $ret .= '<div class="accordion-body">';
        $ret .= $this->bggLookupForm($pid);
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '<div class="accordion-item">';
        $ret .= '<h5 class="accordion-header" id="headingThree">';
        $ret .= '<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#board-game-lib-schedule" aria-expanded="false" aria-controls="board-game-lib-schedule">';
        $ret .= '3 - Availability';
        $ret .= '</button>';
        $ret .= '</h5>';
        $ret .= '<div id="board-game-lib-schedule" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#board-game-library">';
        $ret .= '<div class="accordion-body">';
        $ret .= $this->gameLibraryWhen();
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</form>';        
        return $ret;
    }  
//------------------------------------------------   
//
//------------------------------------------------      
    public function gameLibraryWhen(){
        $ci = &get_instance();
        $conid = $ci->session->ogre_conid;
        $ret = '<div class="row">';
        $ret .= '<div class="col-6 mb-4">';
        $ret .= '<div class="card border-info h-100">';
        $ret .= '<h4 class="card-header">When will you be available?</h4>';
        $ret .= '<div class="card-body">';
        $ret .= $ci->ogre_lib->getMiscContent('%%BGLTIMEINSTR%%',0,TRUE);
        $ret .= $ci->convention->dateSelectBoot($conid, 'bgl_date', 'Board Game Library Date of Con');
        $ret .= $ci->convention->timeSelectBootGroup('Start: ','bglhour-from','bglmin-from','bglampm-from');
        $ret .= $ci->convention_lib->slotLengthSelectBoot("bgl_length","Length in Hours:");
        $ret .= '</div>';
        $ret .= '<div class="card-footer">';
        $ret .= '<button type="button" class="btn btn-primary" onclick="addAvail();">Add to my Availability</button>';
        $ret .= '</div>';        
        $ret .= '</div>'; 
        $ret .= '</div>'; 
        $ret .= '<div class="col-6 mb-4">';
        $ret .= '<div class="card border-info h-100">';
        $ret .= '<h4 class="card-header">My Availability</h4>';
        $ret .= '<div class="card-body">';
        $ret .= '<select name="mybgavlist" id="mybgavlist" size="12" multiple="" class="form-control">';
        $ret .= '</select>';
        $ret .= '</div>';
        $ret .= '<div class="card-footer">';
        $ret .= '<button type="button" class="btn btn-primary" onclick="remMyAvail();">Remove from my Availability</button>';
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>'; 
        $ret .= '</div>';  
        return $ret;
    }
//------------------------------------------------   
//
//------------------------------------------------      
    public function gameLibraryName(){
        $ci = &get_instance();
        $conid = $ci->session->ogre_conid;
        $pid = $ci->session->ogre_user_ID;
        $ci->person->init($conid, '', $pid);
        $ret = '<div class="row">';
        $ret .= '<div class="col-12 mb-4">';
        $ret .= '<div class="card border-info h-100">';
        $ret .= '<h4 class="card-header">Give your Library a Name</h4>';
        $ret .= '<div class="card-body">';
        $ret .= $ci->ogre_lib->getMiscContent('%%MyBGLSTEP1%%',0,TRUE);
        $ret .= '<div class="form-group">';
        $ret .= '<label class="form-label" for="gmname">';      
        $ret .=  'Name*: ';
        $ret .= '</label>';
        $ret .=  ' <input type="text" id="gmname" name="gmname" class="form-control required" value="' . $ci->person->fullname . '" />';
        $ret .= '<label class="form-label" for="gmname">';        
        $ret .=  'E-Mail Address*: ';
        $ret .= '</label>';
        $ret .=  '<input type="text" id="gmemail" name="gmemail" value="' . $ci->person->email . '" class="form-control required" />';  
        $ret .= '<label class="form-label" for="glname">';      
        $ret .=  'Library Name*: ';
        $ret .= '</label>';
        $ret .=  ' <input type="text" id="glname" name="glname" class="form-control required" placeholder="Name your Awesome Bunch of Games"  />';        
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '<div class="card-footer">';
        $ret .= '<input type="hidden" id="gmid" name="gmid" value="' . $ci->person->user_id_num . '" />';
        $ret .= '</div>';        
        $ret .= '</div>'; 
        $ret .= '</div>'; 
        $ret .= '</div>';
        return $ret;
    }
//---------------------------------------------------
//
//--------------------------------------------------- 
    public function gamelibrary_email($p){
        $ci = &get_instance();
        $conid = $ci->session->ogre_conid; 
        $ci->convention->init($conid);
        $msg = '<p><strong>OGRe Personal Game Library Pending Approval</strong></p>';
        $msg .= '<p>The following person has registered a game library to be approved: </p>';
        $msg .= '<p>Name: ' . urldecode($p["gmname"]) . '</p>';
        $msg .= '<p>Email: ' . urldecode($p["gmemail"]) . '</p>';
        $msg .= '<p>Game Library: ' . urldecode($p["glname"]) . '</p>';
        $resp['from_eaddress']= $ci->convention->gamingcoordinatoremail;
        $resp['to_eaddress1'] = $ci->convention->gamingcoordinatoremail; 
        $resp['cc_eaddress1'] = urldecode($p["gmemail"]);
        $resp['subject'] = 'OGRe Personal Game Library Pending Approval';
        $resp['body'] =  $msg;        
        $ret = $ci->ogre_lib->emailMessageArray($resp);
        return $ret;
    }    
//---------------------------------------------------
//
//
//
//---------------------------------------------------    
    public function gsItemsNeedsAttention(){
        $ci = &get_instance();
        $conid = $ci->session->ogre_conid; 
        $ret = array();
        $ret["proposals"] = 0;
        $ret["libraries"] = 0;
        $ret["attention"] = FALSE;
        //PROPOSALS
        $sql = 'SELECT * FROM ogre_gamerequest where gr_con_id = '.$conid;
        $sql .= ' AND gr_delete = 0 AND gr_schedule_id = 0';
        $query = $ci->db->query($sql);
        $ret["proposals"] = $query->getNumRows();
        // PERSONAL GAME LIBRARIES
        $sql='SELECT * FROM ogre_gameschedule WHERE gs_convention_id = '.$conid;
        $sql.=' AND gs_gn_id = '. PERSONAL_LIBRARY_ID.' AND gs_displaymode = "R" ';
        $query = $ci->db->query($sql);
        $ret["libraries"] = $query->getNumRows();
        $ret["attention"] = (intval($ret["proposals"])+ intval($ret["libraries"])) > 0 ? TRUE : FALSE;
        return $ret;        
    }
//--------------------------------------------------- 
//
//
//
//---------------------------------------------------    
    public function timeBlockString($id,$slotcode){
        $day = '';
        $start = '';
        $len = '';
        $ret = '';
        $ret2 = '';
        $half = '';
        $code = substr($slotcode, 0, 7);
        $day =  substr($code, 0, 1);
        $start =  substr($code, 1, 2);
        $len = substr($code, 4, 2);
        $len2 = intval($len)*2;
        $half = substr($code, 6, 1);
        $min = substr($code, 3, 1);

        if ((intval($min) == 3)){            
            $ret .= $day.$start.$min.",";
            $ret2 = $id.",";
            $start = str_pad(intval($start)+1, 2,"0",STR_PAD_LEFT);
            $len2--;
        }
        for($i=0;$i<=(intval($len2))-1;$i++){
            $ret .= $day;
            $ret .= str_pad(intval($start) + round($i/2,0,PHP_ROUND_HALF_DOWN),2,"0",STR_PAD_LEFT);
            $ret .= (($i%2 == 0) ? "0" : "3");
            $ret .= ",";
            $ret2 = $id.",";
        }
        
        if ((intval($half) == 5)){
            $ret .= $day;
            $ret .= str_pad(intval($start) + round($i/2,0,PHP_ROUND_HALF_DOWN),2,"0",STR_PAD_LEFT);
            $ret .= (($i%2 == 0) ? "0" : "3");
            $ret .= "," ;          
            $ret2 = $id.",";
        }
        
        return $ret."~".$ret2;
    }    
//--------------------------------------------------- 
//
//
//
//---------------------------------------------------    
    public function conflict_check($cschedule, $id){
        $ci = &get_instance();
        $ret = '0';
        $key = 0;
        $ci->event->event_init($id);
        $curr = explode("~",$cschedule);
        $curtimes = explode(",",$curr[0]);
        $curids = explode(",",$curr[1]);
        
        $eschedule = $this->timeBlockString($ci->event->id, $ci->event->slot_code);
        //if(array_search($esched, $haystack))
        $evnt = explode("~",$eschedule);
        $evnttimes = explode(",",$evnt[0]);
        $evntids = explode(",",$evnt[1]);   
        
        for($i=0;$i<=len($evntids)-2;$i++){
           if(!array_search($evnttimes[$i],$curtimes)){
               $key = array_search($evnttimes[$i],$curtimes);
               $ret = $curids[$key];
           }
        }
        return $ret;
    }
    
} /* END LIB */	 
