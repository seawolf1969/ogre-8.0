<?php   
namespace App\Libraries;
use CodeIgniter\I18n\Time;
 class Admin_lib
 {

//***********************************
//
//***********************************
        public function slotsIn($p){
            $ci=&get_instance();
            $conid = $p["conid"];
            $ci->convention->init($conid);
            $bValid = TRUE;
            $err='';
            $ret = '';
            $ret .= '<strong><h4>';
            $ret .= $ci->convention->name;
            $ret .= ' Slots';
            $ret .= '</h4></strong> ';
            if(isset($p["remove"]) && isset($p["slotid"])){
                $ret .= $ci->convention->removeSlot($p["slotid"]);
            }
            else{ 
                if(trim($p["slot_number"]) == '' && !isset($p["slotid"])){
                    $bValid = FALSE;
                    $err = '<p>INVALID DATA! Slot Number can not be blank.</p>';
                }
                if($p["slot_length"] == 0){
                    $bValid = FALSE;
                    $err = '<p>INVALID DATA! Slot Length can not be zero.</p>';
                }
                if(isset($p["slot_RPGA"]) && $p["slot_rpga_number"] == '0'){
                    $bValid = FALSE;
                    $err = '<p>INVALID DATA! If this is a Organized Play Slot, it must have a ordinal number</p>';
                }
                else{
                    if($p["slot_rpga_number"] != '0' && !isset($p["slotid"])){
                        $late = (isset($p["slot_latenight"])) ? '1' : '0';
                        
                        if($ci->convention->opSlotExists($p["slot_rpga_number"], $late, $p["slot_length"])){
                            $bValid = FALSE;
                            $err = '<p>INVALID DATA! This Organized Play Slot Number exists.</p>';
                        }
                    }
                }

                if(!isset($p["slotid"])){
                    if($ci->convention->slotNumberExists($p["slot_number"])){
                        $bValid = FALSE;
                        $err = '<p>INVALID DATA! This Slot Number exists.</p>';
                    }
                }
                if($bValid != FALSE){
                    $rpgaslot = (isset($p["slot_RPGA"])) ? '1' : '0';
                    $p["slot_RPGA"] = $rpgaslot;
                    $p["slot_latenight"] = $late;
                    if(!isset($p["slotid"])){
                        $ret .= $ci->convention->new_slot_data($p);
                    }
                    else{
                        $ret .= $ci->convention->new_slot_data($p, $p["slotid"]);
                    }
                }
                else{
                    $ret .= $err;
                }
            }
            $ret .= '<hr />';
            $ret .= $ci->convention->viewSlotList(TRUE, $conid);

            return $ret;
        }        
        //***********************************
        //
        //
        //
        //***********************************   
        public function slotRemX($id){
            $ci=&get_instance();
            $ret = $ci->convention->removeSlot($id);
            return $ret;            
        }
//***********************************
//
//***********************************
        public function slotsInX($p){
            $ret=TRUE;
            $ci=&get_instance();
            if($p["slotid"]=='0'){
                $ret = $ci->convention->new_slot_data($p);
            }
            else{
                $ret = $ci->convention->new_slot_data($p, $p["slotid"]);
            }
            return $ret;
        }      
//***********************************
//
//***********************************        
        public function slotHeader($conid=0){
            $ret='';
            $ci=&get_instance();
            if($conid==0){
                $conid = $ci->session->ogre_conid;
            }            
            $ci->convention->init($conid); 
            $action = site_url('ogrex/getAddSlot','https');
            $saveaction = site_url('ogrex/slotsInX/','https');
            $listrefresh = site_url('ogrex/slotsListx','https');  
            $importaction = site_url('ogrex/slotsImport','https');  
            $importsaveaction = site_url('ogrex/slotsImportIn','https');   
            $instraction = site_url('ogrex/getSlotInstructions','https');
            $orgid = $ci->convention->orgid;    
            $ret .= '<p><a href="#" onclick="return get_slotforminstructions('."'".$instraction."'".');">Click here for Game Slot Admin instructions</a></p>';
            $ret .= '<div id="results" class="results"></div>';              
            $onchange=' onchange="load_slots_by_con(' ."'".site_url('ogrex/slotsListx','https')."',".'this.options[this.selectedIndex].value, this.options[this.selectedIndex].text);"';
            $ret .= $ci->convention_lib->conventionSelect($orgid, $conid, 'slotconfilter', $onchange);  //
            $ret .= '<div class="d-grid gap-2"><input type="button" value="Add Slot" class="btn btn-secondary m-1" id="addslot" name="addslot" onclick="addeditslot(0,'."'".$action.'/0'."','".$saveaction.'/0'."','".$listrefresh."','".$importaction."','".$importsaveaction."'".');" /></div>';
            $ret .= '<p id="slotcontitle"><strong>' . $ci->convention->name . ' Slots</strong></p>'; 
            return $ret;
        }
        
//***********************************
//
//***********************************        
        public function slotImport($to_conid){
            $ret='';
            $action = site_url("ogrex/slotImportList/",'https');
            $divid = 'slotimportllist';
            $ci=&get_instance();
            $ci->convention->init($to_conid);          
            $orgid = $ci->convention->orgid;      
            $onchange=' onchange="getSlotImportList('."'".$action."','".$divid."'".')"';
            $ret .= '<table id="slotimportheader" class="slotimportheader">';
            $ret .= '<tr>';
            $ret .= '<td>';
            $ret .= '<p><strong>Select event to import from:</strong><br />';          
            $ret .= '</p>';
            $ret .= '</td>';
            $ret .= '<td id="slot_toconname"><p>';
            $ret .= '</p></td>';
            $ret .= '</td>';
            $ret .= '</tr>';
            $ret .= '</table>';
            
            $ret .= $ci->convention_lib->conventionSelect($orgid, $to_conid, 'importslotcontitle', $onchange);
            $ret .= '<div id="slotimportllist"></div>';
            return $ret;
        }
//***********************************
//
//***********************************        
        public function transferLastYearSlots($from_conid, $to_conid){
            $ret=FALSE;
            $ci=&get_instance();
            $ci->convention->init($to_conid);
            $dow = $ci->convention->dayOfWeekArray();
            $qry = 'SELECT * ';
            $qry .= ' FROM ogre_gameslots ';
            $qry .= ' WHERE slot_conid = ' . $from_conid;

            $query = $ci->db->query($qry);
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){ 
                        $starttime = new Time($row->slot_start_time);
                        $p = array( "slotid" => 0,
                            "slot_code" => $row->slot_code,
                            "slot_number" => $row->slot_number, 
                            "slot_length" => $row->slot_length,
                            "slot_rpga_number" => $row->slot_rpga_number,
                            "slot_latenight" => $row->slot_latenight,
                            "slot_RPGA" => $row->slot_RPGA,
                            "slot_date" => $dow[$row->slot_day],
                            "slotstarttime" => $row->slot_start_time,
                            "slot_start_time_hour" => $starttime->format('h'),
                            "slot_start_time_min" => $starttime->format('i'),
                            "slot_start_time_AMPM" => $starttime->format('A'),                              
                            "conid" => $to_conid);
                        $ret .=  $ci->convention->save_new_slot($p, $to_conid);
                }
            }
            return $ret;           
        }
//***********************************
//
//***********************************        
        public function locationImport($to_conid){
            $ret='';
            $action = site_url("ogrex/locationImportList/",'https');
            $divid = 'locationimportllist';
            $ci=&get_instance();
            $ci->convention->init($to_conid);          
            $orgid = $ci->convention->orgid;      
            $onchange=' onchange="getLocationImportList('."'".$action."','".$divid."'".')"';
            $ret .= '<table id="locationimportheader" class="locationimportheader">';
            $ret .= '<tr>';
            $ret .= '<td>';
            $ret .= '<p><strong>Select event to import from:</strong><br />';          
            $ret .= '</p>';
            $ret .= '</td>';
            $ret .= '<td id="loctoconname"><p>';
            $ret .= '</p></td>';
            $ret .= '</td>';
            $ret .= '</tr>';
            $ret .= '</table>';
            $ret .= $ci->convention_lib->conventionSelect($orgid, $to_conid, "importlocconfilter", $onchange);
            return $ret;
        }          
//***********************************
//
//***********************************        
    public function locationHeader($conid){
        $ret='';
        $refreshaction = site_url("ogre/location/x",'https');
        $ci=&get_instance();
        $ci->convention->init($conid);          
        $orgid = $ci->convention->orgid;            
        $onchange=' onchange="load_location_by_con(' ."'".$refreshaction."',".'this.options[this.selectedIndex].value, this.options[this.selectedIndex].text);"';
        $ret .= $ci->convention_lib->conventionSelect($orgid, $conid, 'locconfilter', $onchange);
        return $ret;
    }        
        
        //***********************************
        //
        //
        //
        //***********************************        
        public function slotTabForm($conid){
            $ret = '';
            $ci=&get_instance();
            $ret .= '<div id="tabs">';          
            $ret .= '<ul>';                   
            $ret .= '<li>';
            $ret .= '<a href="#slottab-1" >';
            $ret .= 'Slot Add';
            $ret .= '</a>';
            $ret .= '</li>';
            $ret .= '<li>';
            $ret .= '<a href="#slottab-2" >';
            $ret .= 'Slot AutoAdd';
            $ret .= '</a>';
            $ret .= '</li>';
            $ret .= '</ul>';

            $ret .= '<div id="slottab-1">';
            $ret .= $this->slotForm($conid);
            $ret .= '</div>';
            
            $ret .= '<div id="slottab-2">';
            $ret .= '<p>Feature Pending</p>';  
            $ret .= '</div>';
            
            $ret .= '</div>';      
            return $ret;        
        }
        
        
        //***********************************
        //
        //
        //
        //***********************************
        public function slotForm($conid, $slotid=0){   
            $ret='';
            $ci=&get_instance();
            $ci->convention->init($conid); 
            $ret .= '<div id="slotform">';
            $ret .= '<form id="slot" name="slot">';
            $ret .= '<input id="slotid" name="slotid" type="hidden" value="' . $slotid . '" />';
            $ret .= '<input id="conid" name="conid" type="hidden" value="' . $conid .'" />';
            $ret .= '<div id="slotaddform">';
            
            $ret .= '<div class="form-group">';
            $ret .= '<label class="form-label" for="slot_number">';
            $ret .= 'Slot Number/Identifier *';
            $ret .= '</label>';

            if ($slotid == 0){
                $ret .= '<input class="form-control" placeholder="Something that uniquely identifies the Slot" id="slot_number" name="slot_number" type="text"  />';
            }
            else{
                $ret .= '<input class="form-control" placeholder="Default input" id="slot_number1" name="slot_number1" type="text" value="' . $ci->convention->slot_info($slotid,"slot_number") . '" disabled="disabled"   />';
                $ret .= '<input id="slot_number" name="slot_number" type="hidden" value="' . $ci->convention->slot_info($slotid,"slot_number") . '" />';               
            }

            $ret .= '<label class="form-label" for="slot_date">';
            $ret .= 'Slot Date *';
            $ret .= '</label>';
            $ret .=  ($slotid == 0) ? $ci->convention->date_select('slot_date') : $ci->convention->date_select('slot_date', $ci->convention->slot_info($slotid, "slot_date"));
            

            $ret .= '<label class="form-label" for="slot_start_time_hour">';
            $ret .= 'Slot Start Time *';
            $ret .= '</label>';
    
            
            if ($slotid == 0){
                $ret .= '<div class="row">';
                $ret .= '<div class="col-md-4">';
                $ret .= $ci->convention->timeSelectHour('slot_start_time_hour');
                $ret .= '</div>';
                $ret .= '<div class="col-md-4">';
                $ret .= $ci->convention->timeSelectMin('slot_start_time_min');
                $ret .= '</div>';
                $ret .= '<div class="col-md-4">';
                $ret .= $ci->convention->timeSelectAMPM('slot_start_time_AMPM');
                $ret .= '</div>';
                $ret .= '</div>';
                }
            else{
                $ret .= '<div class="row">';
                $ret .= '<div class="col-md-4">';                
                $t = $ci->convention->slot_info($slotid,"slot_start_time");
                $ret .= $ci->convention->timeSelectHour('slot_start_time_hour', substr($t,0,2));
                $ret .= '</div>';
                $ret .= '<div class="col-md-4">';
                $ret .= $ci->convention->timeSelectMin('slot_start_time_min',substr($t,3,2));
                $ret .= '</div>';
                $ret .= '<div class="col-md-4">';
                $ampm = (intval(substr($t,0,2)) > 12) ? 'PM' : 'AM';
                $ret .= $ci->convention->timeSelectAMPM('slot_start_time_AMPM',$ampm);
                $ret .= '</div>';
                $ret .= '</div>';                
            }
            $ret .= '<label class="form-label" for="slot_length">';
            $ret .= 'Slot Length *';
            $ret .= '</label>';
            
            $ret .=  ($slotid == 0) ? $ci->convention_lib->slotLengthSelect("slot_length") :  $ci->convention_lib->slotLengthSelect("slot_length", $ci->convention->slot_info($slotid,"slot_length"));
            
            $ret .= '<div class="row">';
            $ret .= '<div class="col-xs-6 col-md-4">';
            $ret .= '<label class="form-label" for="slot_RPGA">';
            $ret .= 'Organized Play Slot?';
            $ret .= '</label>';

            if ($slotid == 0){
                $ret .= '<input  id="slot_RPGA" name="slot_RPGA" type="checkbox" />';  //class="custom-control-input"
            }
            else{
                if ($ci->convention->slot_info($slotid, "slot_RPGA") == 1){
                    $ret .= '<input  class="custom-control-input"  id="slot_RPGA" name="slot_RPGA" type="checkbox" checked="checked" />';
                }
                else{
                    $ret .= '<input class="custom-control-input"  id="slot_RPGA" name="slot_RPGA" type="checkbox" />';
                }
            }
            $ret .= '</div>';
            $ret .= '<div class="col-xs-6 col-md-4">';
            $ret .= '<label class="form-label" for="slot_rpga_number">';
            $ret .= 'Organized Play Ordinal Slot Number **';
            $ret .= '</label>';
            $ret .=  ($slotid == 0) ? $ci->convention->opSlotNumberSelect('slot_rpga_number') : $ci->convention->opSlotNumberSelect('slot_rpga_number', $ci->convention->slot_info($slotid, "slot_rpga_number"));            
            $ret .= '</div>';
            $ret .= '<div class="col-xs-6 col-md-4">';
            $ret .= '<label class="form-label" for="slot_latenight">';
            $ret .= 'Midnight Madness/Late night Slot? +';
            $ret .= '</label>';
            if ($slotid == 0){
                $ret .= '<input id="slot_latenight" name="slot_latenight" type="checkbox" />';
            }
            else{
                if ($ci->convention->slot_info($slotid,"slot_latenight") == 1){
                    $ret .= '<input id="slot_latenight" name="slot_latenight" type="checkbox" checked="checked" />';
                }
                else{
                    $ret .= '<input id="slot_latenight" name="slot_latenight" type="checkbox" />';
                }
            }           
            $ret .= '</div>';            
            $ret .= '</div>';
            $ret .= '</div>';
            $ret .= '</div>'; 
            $ret .= '</div>';  
            $ret .= '</div>'; 
            $ret .= '<div id="results" class="results"></div>';
            return $ret;
        }

//***********************************
//
//***********************************
    public function timeProcess($p){
        if($p["game_start_time_AMPM"] == 'AM'){
            if (intval($p["game_start_time_hour"]) != 12){
                $hr = intval($p["game_start_time_hour"]);
            }
            else{
                $hr = intval($p["game_start_time_hour"]) - 12;
                $latenight = 1;
            }
            if (intval($p["game_start_time_hour"]) >= 1 && intval($p["game_start_time_hour"]) < 9){
                $latenight = 1;
            }
        }
        else
        {
            if (intval($p["game_start_time_hour"]) != 12){
                $hr = intval($p["game_start_time_hour"]) + 12;
            }
            else{
                $hr = intval($p["game_start_time_hour"]);
            }
        }
        $start =  str_pad($hr,2,'0',STR_PAD_LEFT) . substr($p["game_start_time_min"],0,1);
        return $start;
    }

//***********************************
//
//***********************************
        public function gameTypeSelect($dbc, $gdt=1, $selval=0){
            $ci=&get_instance();
            if ($gdt==1){
                $qry ='SELECT * FROM ogre_games_descriptor, ogre_games_descriptor_type ';
                $qry .= 'WHERE ogre_games_descriptor_type.gdt_id = ogre_games_descriptor.gd_descriptor_type ';
                $qry .= 'AND ogre_games_descriptor.gd_descriptor_type = 1 ORDER BY gd_descriptor';
            }
            elseif($gdt==-1){
                $qry ='SELECT * FROM ogre_games_descriptor, ogre_games_descriptor_type ';
                $qry .= 'WHERE ogre_games_descriptor_type.gdt_id = ogre_games_descriptor.gd_descriptor_type ';
                $qry .= 'AND ogre_games_descriptor.gd_descriptor_type <> 1 ORDER BY gd_descriptor';
            }
            else{
                $qry ='SELECT * FROM ogre_games_descriptor, ogre_games_descriptor_type ';
                $qry .= 'WHERE ogre_games_descriptor_type.gdt_id = ogre_games_descriptor.gd_descriptor_type ';
                $qry .= 'AND ogre_games_descriptor.gd_descriptor_type = ' . $gdt . ' ORDER BY gd_descriptor';
            }
            $ret = '';
            $ret .= '<option value="0">-</option>';

            $query = $ci->db->query($qry);
            if ($query->getNumRows() > 0) {
                foreach ($query->getResult() as $row) {
                    if (intval($row->gd_id) == $selval) {
                        $ret .= '<option value="' . $row->gd_id . '" selected="selected">' . $row->gd_descriptor . '</option>';
                    } else {
                        $ret .= '<option value="' . $row->gd_id . '">' . $row->gd_descriptor . '</option>';
                    }

                }
            }
            
            return $ret;
        }




        //***********************************
        //
        //
        //
        //***********************************
        public function gameNameSelect($dbc, $gt, $selval=0){
            $qry ='SELECT * FROM ogre_games, ogre_games_descriptor_xref, ogre_games_descriptor, ogre_games_descriptor_type ';
            $qry .= 'WHERE ogre_games.gn_game_id = ogre_games_descriptor_xref.gdx_gn_id ';
            $qry .= 'AND ogre_games_descriptor_xref.gdx_gd_id = ogre_games_descriptor.gd_id ';
            $qry .= 'AND ogre_games_descriptor_type.gdt_id = ogre_games_descriptor.gd_descriptor_type ';
            $qry .= 'AND ogre_games_descriptor.gd_id = ' . $gt . ' ';
            $qry .= 'AND ogre_games_descriptor.gd_descriptor_type = 1 ';
            $qry .= 'ORDER BY gn_game_name';
            $ret = '';
            while ($row = mysql_fetch_array($rs)){
                if($row["gd_id"] == $selval){
                    $ret .= '<option value="'. $row["gn_game_id"] . '" selected="selected">' . $row["gn_game_name"] . '</option>';
                }
                else{
                    $ret .= '<option value="'. $row["gn_game_id"] . '">' . $row["gn_game_name"] . '</option>';
                }
            }
            return $ret;
        }

//***********************************
//
//***********************************
        public function timeOptionSelect($n, $time='0'){
            $ret = ' < <select class="form-select"name="' . $n . '" size="1">';
                for ($i = 1; $i <= 24; $i++){
                    if($i != 24){
                        $comp = str_pad($i,2,'0',STR_PAD_LEFT) . ':00:00';
                        $comp2 = str_pad($i,2,'0',STR_PAD_LEFT) . ':30:00';
                    }
                    else{
                        $comp = str_pad($i-24,2,'0',STR_PAD_LEFT) . ':00:00';
                        $comp2 = str_pad($i-24,2,'0',STR_PAD_LEFT) . ':30:00';
                }

                if($i > 12){
                    $h = str_pad(($i-12),2,'0',STR_PAD_LEFT);
                    if ($i != 24){
                        $t = ($h) . ':00:00 PM';
                        $t2 = ($h) . ':30:00 PM';
                        $h24 = str_pad($i,2,'0',STR_PAD_LEFT);
                    }
                    else{
                        $t = $h . ':00:00 AM';
                        $t2 = $h . ':30:00 AM';;
                        $h = '00';
                        $h24 = $h;
                    }

                }
                else{
                    $h = str_pad($i,2,'0',STR_PAD_LEFT);
                    $h24 = str_pad($i,2,'0',STR_PAD_LEFT);
                    if ($i != 12){
                        $t = $h . ':00:00 AM';
                        $t2 = $h . ':30:00 AM';
                    }
                    else{
                        $t = $h . ':00:00 PM';
                        $t2 = $h . ':30:00 PM';
                    }

                }
                if ($comp == $time){
                    $ret .= '<option value="' . $h24 . ':00:00'  . '" selected="selected">';
                    $ret .= $t;
                    $ret .= '</option>';
                    $ret .= '<option value="' . $h24 . ':30:00'  . '" >';
                    $ret .= $t2;
                    $ret .= '</option>';
                }
                elseif ($comp2 == $time)
                {
                    $ret .= '<option value="' . $h24 . ':00:00'  . '" >';
                    $ret .= $t;
                    $ret .= '</option>';
                    $ret .= '<option value="' . $h24 . ':30:00'  . '" selected="selected">';
                    $ret .= $t2;
                    $ret .= '</option>';
                }
                else
                {
                    $ret .= '<option value="' . $h24 . ':00:00'  . '">';
                    $ret .= $t;
                    $ret .= '</option>';
                    $ret .= '<option value="' . $h24 . ':30:00'  . '">';
                    $ret .= $t2;
                    $ret .= '</option>';
                }
            }
            $ret .= '</select>';

            return $ret;
        }
//***********************************
//
//***********************************
        public function userAdmin($conid=0, $evntid=0){
            $ci=&get_instance();
            $ret = '';
            if($evntid==0){
                $action = site_url('ogrex/userAdminSearch','https');
            }
            else {
                $action = site_url('ogrex/gmplayer_admin_search/'.$evntid,'https');
            }
            $ci->convention->init($conid);
                                                    
            $ret .= '<div id="user-search">';
            $ret .= '<div id="user-admin" name="user-admin">'; 
            $ret .= '<p><em>To Search: Type in the name, e-mail address, portion of email address or portion of user`s name to search for a user.  If this user does not exist, you will have to add it.</em></p>';
            $ret .= '<label for="criteria">Search For:</label>';
            $ret .= '<input class="form-control form-control-sm  m-1" type="text" id="criteria" name="criteria" size="30" onblur="searchUsers('."'".$action."'".')" />';
            $ret .= '<div class="d-grid gap-2">';
            $ret .= '<input class="btn btn-primary m-1" type="button" id="searchuser" name="searchuser" value="Search" onclick="searchUsers('."'".$action."'".')" />';
            $ret .= '<input class="btn btn-primary m-1" type="button" id="adduser" name="adduser" value="Add User" onclick="openUserDialog(-1,' . "'" . site_url('ogre/user/-1','https')  . "','" . site_url('ogre/userIn/save','https')  . "'" . ');" />';
            $ret .= '</div>';
            if($evntid==0){
                $ret .= '<input type="hidden" id="evntid" name="evntid" value="'. $evntid .'" />';
            }
            $ret .= '</div>';
            $ret .= '<div id="activate-results" class="results"></div>'; 
            $ret .= '</div>';
            $image_properties = array('src' =>'images/ajax-loader.gif'); 
            $ret .= '<div id="wait" style="display: none">' . img($image_properties) . '</div>';             
            $ret .= '<div class="table-responsive">';
            $ret .= '<div id="search-results">';                                 
            $ret .= '</div>';
            $ret .= '</div>';
           
            return $ret;
        }
        //***********************************
        //
        //
        //
        //***********************************       
        public function usersAdminSearchResults($p, $conid){
            $ci=&get_instance();
            $crit = '';
            $ret='';
            $refreshaction = site_url('ogrex/userAdminSearch','https');
            if (isset($p['criteria'])){
                $crit = $p['criteria'];
            }
            if (trim($crit) != ''){
                $qry = "SELECT * FROM ogre_users ";
                $qry .= "WHERE user_email LIKE '%" . $crit ."%'";
                $qry .= " OR ";
                $qry .= "user_full_name LIKE '%" . $crit ."%'";
                $query = $ci->db->query($qry);
                $ret .= '<table class="table table-striped">';
                $ret .= '<thead>';
                $ret .= '<th><strong>Name</td>';
                $ret .= '<th><strong>OGRE ID</td>';
                $ret .= '<th colspan="2"><strong>Activate As ...</strong></td>';
                $ret .= '</thead>';
                
                if ($query->getNumRows() > 0){
                    $i=0;
                    foreach ($query->getResult() as $row){
                        $ci->person->init($conid, '', $row->user_index_id);
                        $ret .= '<tr>';
                        $ret .= '<td>';
                        $ret .= '<a href="#" onclick="openUserDialog('.$row->user_index_id . ",'" . site_url('ogre/user/'.$row->user_index_id,'https')  . "','" . site_url('ogre/userIn/save','https')  . "'" .');">' . $row->user_full_name . " - " . $row->user_email . '</a>';
                        $ret .= '</td>';
                        $ret .= '<td>';
                        $ret .= str_pad($row->user_index_id,6,'0',STR_PAD_LEFT);
                        $ret .= '</td>';
                        if (intval($ci->person->user_verified) == 0){
                            $ret .= '<td align="center">';
                            $paction= site_url('ogre/userIn/autoactx/' . PLAYER . '/' . $row->user_index_id,'https');
                            $ret .= '<input class="btn btn-secondary" id="activatePlayer" name="activatePlayer" type="button" value=" Player " onclick="activateUser('."'". $paction ."','".$refreshaction."'".');" />';
                            $ret .= '</td>';
                            $ret .= '<td align="center">';                                                         
                            $gaction=site_url('ogre/userIn/autoactx/' . GAMEMASTER . '/' . $row->user_index_id,'https');
                            $ret .= '<input class="btn btn-secondary" id="activateGM" name="activateGM" type="button" value=" GM " onclick="activateUser('."'".$gaction."','".$refreshaction."'".');" />';                              
                            $ret .= '</td>';
                        }
                        else{
                            $ret .= $this->userAdminActivationButtons($row->user_index_id, $ci->person->ogre_level_rating, $ci->person->access_rating);
                        }
                        $ret .= '</tr>';
                        $i++;
                    }
                    $ret .= '</table>';
                }
                else{
                    $ret .= '<tr colspan="4">';
                    $ret .= '<td>';
                    $ret .= 'None Found';
                    $ret .= '</td>';        
                    $ret .= '</tr>';
                    $ret .= '</table>';
                }
            }           
            return $ret;
        }
//***********************************
//
//
//
//***********************************               
        private function userAdminActivationButtons($id, $level, $acc){
            $ret = '';
            $refreshaction = site_url('ogrex/userAdminSearch','https');
            switch(intval($level)){
                case -1:
                    $ret .= '<td align="center" colspan="2">';
                    $ret .= '<a href="#" onclick="openUserDialog('.$id . ",'" . site_url('ogre/user/'.$id,'https')  . "','" . site_url('ogre/userIn/save','https')  . "'" .');"> Admin </a>';
                    $ret .= '</td>';
                    break;
                case 0:
                    if ($acc >= REGVOL){
                            $ret .= '<td align="center" colspan="2">';
                            $ret .= '<a href="#" onclick="openUserDialog('.$id . ",'" . site_url('ogre/user/'.$id,'https')  . "','" . site_url('ogre/userIn/save','https')  . "'" .');"> Admin </a>';
                            $ret .= '</td>';                
                    }
                    else{
                        if ($acc == GAMEMASTER){
                            $ret .= '<td align="center" colspan="2">';
                            $gaction=site_url('ogre/userIn/deactx/0/' . $id,'https');    
                            $ret .= '<input class="btn btn-secondary" name="deactivategm" type="button" value=" Deactivate GM "  onclick="activateUser('."'".$gaction."','".$refreshaction."'" .');" />';
                            $ret .= '</td>';
                        }
                        else{
                            $ret .= '<td align="center" colspan="2">';
                            $paction= site_url('ogre/userIn/deactx/0/' . $id,'https');
                            $ret .= '<input class="btn btn-secondary" name="deactivategm" type="button" value=" Deactivate Player " onclick="activateUser('."'".$paction."','".$refreshaction."'" .');"  />';
                            $ret .= '</td>';
                        }
                    }                        
                    break;
                default:
                    $ret .= '<td align="center" colspan="2">';
                    $ret .= '<a href="#" onclick="openUserDialog('.$id . ",'" . site_url('ogre/user/'.$id,'https')  . "','" . site_url('ogre/userIn/save','https')  . "'" .');"> Admin </a>';
                    $ret .= '</td>';                    
                    break;
            }
            return $ret;
        }
        
//***********************************
//
//***********************************       
        public function gmPlayerAdminSearchResults($p, $conid, $gid){
            $ci=&get_instance();
            $ret='';
            $ci->event->event_init($gid);
            $raction=site_url('ogrex/removePlayer','https');
            $raction2 = site_url('ogrex/gmplayer_admin_search/'.$gid,'https');            
            $crit = (isset($p['criteria'])) ? $p['criteria'] : '';
            if (trim($crit) != ''){
                $qry = "SELECT * FROM ogre_users ";
                $qry .= "WHERE user_email LIKE '%" . $crit ."%'";
                $qry .= " OR ";
                $qry .= "user_full_name LIKE '%" . $crit ."%'";
                $query = $ci->db->query($qry);
                if ($query->getNumRows() > 0){
                    $ret .= '<table class="padded-table" width="100%" border="0" cellspacing="0" cellpadding="20" bgcolor="#FFFFFF">';
                    $ret .= '<tr>';
                    $ret .= '<td><strong>Name</td>';
                    $ret .= '<td colspan="2"><strong>Add As ...</strong></td>';
                    $ret .= '<td colspan="2"><strong>Auto<br />Activate</strong></td>';
                    $ret .= '</tr>';
                    $i=0;
                    $action2 = site_url('ogrex/gmplayer_admin_search/'.$gid,'https');
                    foreach ($query->getResult() as $row){
                        $ci->person->init($conid, '', $row->user_index_id);
                        $gmflag=$ci->event->isPlayerGM($ci->person->user_id_num);
                        $ret .= ($i%2==0)? '<tr>' :  '<tr bgcolor="#CDCDCD">';
                        $maillink=mailto($ci->person->email,$ci->person->fullname.' ('.$ci->person->email.')');
                        $ret .= '<td>'. $maillink . '</td>';
                        switch(intval($gmflag)){
                            case -999:
                                $ret .= '<td align="center">';
                                $ret .= '<form name="actplayer" method="POST" >'; 
                                $addplayer=  site_url('ogrex/adminInsertPlayer/0','https');
                                $parameters=$this->build_addplayer_reg_Post($ci->person->user_id_num, $ci->event->id, 'Player');
                                $ret .= '<input class="btn btn-secondary" name="activatePlayer" type="button" value=" Add as Player " onclick="addplayer_reg('."'".$addplayer."','". $parameters ."','".$action2."'," .$ci->person->user_id_num.');" />';                                                      
                                $ret .= '</form>';                                    
                                $ret .= '</td>';
                                $ret .= '<td align="center">';
                                $addplayer=  site_url('ogrex/adminInsertPlayer/0','https');
                                $parameters=$this->build_addplayer_reg_Post($ci->person->user_id_num, $ci->event->id, 'Judge');

                                $ret .= '<form name="actgm" method="POST" >';                       
                                $ret .= '<input class="btn btn-secondary" name="activategm" type="button" value=" Add as GM " onclick="addplayer_reg('."'".$addplayer."','". $parameters ."','".$action2."'," .$ci->person->user_id_num.');"  />';                                
                                $ret .= '</form>';
                                $ret .= '</td>';
                                $ret .= '<td>';
                                $ret .= '<input type="checkbox" id="autoactivate'.$ci->person->user_id_num.'" name="autoactivate'.$ci->person->user_id_num.'" checked="checked">';
                                $ret .= '</td>';
                                break;
                            case 0:
                                if ($ci->person->access_rating >= ADMIN){
                                    $ret .= '<td align="center" colspan="3">Admin</td>';
                                }
                                else{
                                    $ret .= '<td align="center" colspan="2">';
                                    $ret .= '<form name="deactpl" method="POST" >'; 
                                    $ret .= '<input class="btn btn-secondary" name="deactivategm" type="button" value=" Remove Player "  onclick="removePlayer(' . $ci->person->user_id_num . ", " . $gid . ", " . "'" . $raction . "'," . $ci->event->mmrpgFlag.",'".$raction2."'" . ')"/>';
                                    $ret .= '</form>';
                                    $ret .= '</td>';
                                    $ret .= '<td>';
                                    $ret .= '</td>'; 
                                }
                                break;
                           case 1:      
                           case -1:                        
                                if ($ci->person->access_rating >= ADMIN){
                                    $ret .= '<td align="center" colspan="3">Admin</td>';
                                }
                                else{
                                    $ret .= '<td align="center" colspan="2">';
                                    $ret .= '<form name="deactgm" method="POST">'; 
                                    $ret .= '<input class="btn btn-secondary" name="deactivategm" type="button" value=" Remove GM " onclick="removeJudge(' . $ci->person->user_id_num . ", " . $gid . ", " . "'" . $raction . "'," . $ci->event->mmrpgFlag.",'".$raction2."'" . ')" />';
                                    $ret .= '</form>';
                                    $ret .= '</td>';
                                    $ret .= '<td>';
                                    $ret .= '</td>';   
                                }
                            break;
                        }
                        
                        $ret .= '</tr>';
                        $i++;
                    }
                    $ret .= '</table>';
                }
            }
            return $ret;
        }
//***********************************
//
//***********************************   
        private function build_addplayer_reg_Post($pid,$gid,$role)
        {
            //$p['gid']
            //$p['userID']
            //$p["preregid"]  
            //$p["pname"]
            //$p["pemail"]
            //$p["playgm"]
            //$p["activity2"] Player or Judge
            //$p["pnotes"]
            //
            //$p["charlevel"]
            //$p["playerAPL"]
            //$p["combatrole"]
            //
            //$p["judgeAPL"]            
            $ci=&get_instance();
            $conid = $ci->session->ogre_conid;
            if ($pid != 0)
            {
                $ci->person->init($conid, '', $pid);
            }      
            $ret='gid='.$gid.'&userID='.$pid;
            $ret .= '&preregid=-9999';
            $ret .= '&pname='.$ci->person->fullname;
            $ret .= '&pemail='.$ci->person->email;            
            $ret .= '&playgm=0';
            $ret .= '&activity2='.$role;
            $ret .= '&pnotes=';
            $ret .= '&charlevel=0';
            $ret .= '&playerAPL=0';
            $ret .= '&judgeAPL=0';
            $ret .= '&combatrole=0';
            return $ret;
        }
//***********************************
//
//
//
//***********************************
    public function user_admin_form($pid=0){
            $ci=&get_instance();
            $orgid = $ci->session->ogre_orgid;
            $conid = $ci->session->ogre_conid;
            $curr_user_access = $ci->session->get('ogre_user_accesslevel_' . $orgid );           
            if ($pid != 0){
                $ci->person->init($conid, '', $pid);
            }
            $ret = '';
            $ret .= '<form name="attendee" id="attendee">';
            $ret .= '<label for="user_first_name" class="form-label">First Name:</label>';
            $ret .= ($pid != 0 ) ? '<input type="text" class="form-control" id="user_first_name" name="user_first_name" value="' . $ci->person->firstname . '" />' : '<input type="Text" id="user_first_name" name="user_first_name" />&nbsp;&nbsp;';
            $ret .= '<label for="user_last_name" class="form-label">Last Name:</label>';
            $ret .= ($pid != 0 ) ? '<input type="text" class="form-control" id="user_last_name" name="user_last_name" value="' . $ci->person->lastname . '" />' : '<input type="Text" id="user_last_name" name="user_last_name" />';
            $ret .= '<label for="user_email" class="form-label">E-mail:</label>';
            $emaction = site_url('ogrex/checkEmailAddress','https');
            $ret .=  ( $pid != 0 ) ? '<input type="text" class="form-control" id="user_email" name="user_email" value="' . $ci->person->email . '"  onblur="check_userinfo(this,'."'".$emaction."','emailvalid'," . $ci->person->user_id_num . ",'user_email'". ');" />' : '<input type="text" class="form-control" id="user_email" name="user_email" onblur="check_userinfo(this,'."'".$emaction."','emailvalid', 0". ",'user_email'".');" />';
            $ret .= '<span id="emailvalid"></span>';
            $ret .= '<label for="user_login" class="form-label">User Log In ID:</label> ';
            $idaction = site_url('ogrex/check_userid','https');
            $ret .=  ( $pid != 0 ) ? '<input type="text" class="form-control" id="user_login" name="user_login" value="' . $ci->person->user_login_id . '" onblur="check_userinfo(this,'."'".$idaction."','idvalid',". $ci->person->user_id_num .",'user_login'". ');"/>' : '<input type="text" class="form-control" id="user_login" name="user_login" onblur="check_userinfo(this,'."'".$idaction."','idvalid', 0".",'user_login'".');" />';
            $ret .= '<span id="idvalid"></span>';
            $ret .= '<label for="accrate" class="form-label">Access Level:</label>';
            $ar = intval($ci->person->access_rating);
            $arval = $ci->person->getUserAccessLevelRating($conid, $pid);            
            $ret .= $this->accessLevelSelect($curr_user_access,$conid,$pid,$arval);
            $ret .= '<input type="hidden" name="accrate" id="accrate" value="'. $ar.'" />';
            $ret .= '<label for="pnotes" class="form-label">Notes:</label>';
            $ret .= '<textarea class="form-control" id="pnotes" name="pnotes"></textarea>';
            if ($pid != 0)
            {
                $ret .=  '<input type="hidden" name="userIndex" value="' . $ci->person->user_id_num . '" />';
                $ret .=  '<input type="hidden" name="Entered_On" value="'. time() . '">';
                $ret .=  '<input type="hidden" name="conid" value="' . $conid . '" />';
            }
            else
            {
                $ret .=  '<input type="hidden" name="userIndex" value="0" />';
                $ret .=  '<input type="hidden" name="Entered_On" value="'. time() . '">';
                $ret .=  '<input type="hidden" name="conid" value="' . $conid . '" />';
            }
            $ret .=  '</form>';
            $ret .= '<div id="results" class="results"></div>';
            return $ret;
        }
//***********************************
//
//***********************************       
    private function accessLevelSelect($cuseracc,$conid,$pid,$arval=0){
        $ci = &get_instance();
        $qry = 'SELECT DISTINCT os_seclevel FROM ogre_security ';
        $qry .= ((abs($arval) > 0) ? '' : ' WHERE os_seclevel = "con" ');
        $qry .= ' ORDER BY os_accesslevel;';
        $ret = '';
        $i = 0;
        $query = $ci->db->query($qry);
        if ($pid != 0){
            $ret .=  '<select class="form-select" aria-label="Select Access Level" size="1" name="accessrating" id="accessrating" onchange="verifycheck(this.options[this.selectedIndex].value);">';
            $ret .=  '<option value="0" '. ($arval == 0 ? ' selected="selected" ' : '') .'> Not Activated User </option>';                
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                    if(trim($row->os_seclevel) == 'con'){
                        $ret .= '<optgroup label="CON LEVEL">';
                    } else {
                        $ret .= '</optgroup><optgroup label="ORGANIZATION LEVEL">';
                    }
                    $ret .= $this->accessLevelSelectOpt($row->os_seclevel, $arval);
                    $ret .= '</optgroup>';
                }
            }    
            $ret .=  '</select>';
        }
        else{
            $ret .= ' < <select class="form-select"size="1" name="accessrating"><option value="1"> Player </option><option value="2"> GameMaster </option></select>';
        }            
        return $ret;
    }
//***********************************
//
//***********************************       
    private function accessLevelSelectOpt($seclvl, $arval){
        $ci = &get_instance();
        $orgid = $ci->session->ogre_orgid;
        $curr_user_access = $ci->session->get('ogre_user_accesslevel_' . $orgid );             
        $qry = 'SELECT * FROM ogre_security WHERE os_seclevel="'.$seclvl.'" ';
        $qry .= ' AND os_accesslevel <= ' . abs($curr_user_access); 
        $qry .= ' ORDER BY os_accesslevel;';

        $ret = '';
        $query = $ci->db->query($qry);
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $ret .=  '<option value="' .((($seclvl == 'con')? -1 : 1) * intval($row->os_accesslevel)) .'" '. ($arval == (($seclvl == 'con')? -1 : 1) * intval($row->os_accesslevel) ? ' selected="selected" ' : '') .'> '. $row->os_levelname. '</option>';
            }
        }
        return $ret;
    }
//***********************************
//
//***********************************
    public function conventionSelect($cid=0, $orgid=0){
        $ci = &get_instance();
        $qry = 'SELECT * FROM ogre_convention ';
        if ($orgid != 0){
            $qry .= ' WHERE con_org_id = ' . $orgid;
        }
        $qry .= ' ORDER BY con_start_date DESC;';
        $query = $ci->db->query($qry);
        $ret = ' < <select class="form-select" name="conid" size="1">';
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                if ($cid == $row->con_id){
                    $ret .= '<option value = "' . $row->con_id  . '" selected="selected">' . $row->con_name  . '</option>';
                }
                else{
                    $ret .= '<option value = "' . $row->con_id  . '">' . $row->con_name  . '</option>';
                }
            }
        }
        $ret .= '</select>';
        return $ret;
    }      

//---------------------------------------------------
//
//---------------------------------------------------
    public function timeSelect($n, $time='0'){
            $ret = '<select class="form-select" id="' . $n . '" name="' . $n . '" size="1">';
            for ($i = 1; $i <= 24; $i++){
                if($i > 12){
                    $t = ($i-12) . ':00:00 PM';
                }
                else{
                    $t = $i . ':00:00 AM';
                }
                if (str_pad($i,2,'0',STR_PAD_LEFT) . ':00:00' == $time){
                    $ret .= '<option value="' . str_pad($i,2,'0',STR_PAD_LEFT) . ':00:00'  . '" selected="selected">';
                    $ret .= $t;
                    $ret .= '</option>';
                }
                else{
                    $ret .= '<option value="' . str_pad($i,2,'0',STR_PAD_LEFT) . ':00:00'  . '">';
                    $ret .= $t;
                    $ret .= '</option>';
                }
            }
            $ret .= '</select>';

            return $ret;
        }
//---------------------------------------------------
//
//---------------------------------------------------
    public function datePartSelect($type, $name, $val=0){
        switch ($type){
            case 'd':
                $ret = ' <select class="form-select" name="' . $name . '">';
                for ($i=1;$i <= 31; $i++){
                    if($i != $val){
                        $ret .= '<option value="' . $i . '">' . str_pad($i,2,'0', STR_PAD_LEFT) . '</option>';
                    }
                    else{
                        $ret .= '<option value="' . $i . '" selected="selected">' . str_pad($i,2,'0', STR_PAD_LEFT) . '</option>';
                    }
                }
                $ret .= '</select>  ';
                break;
            case 'm':
                $ret = ' <select class="form-select" name="' . $name . '">';
                for ($i=1;$i <= 12; $i++){
                    if($i != $val){
                        $ret .= '<option value="' . $i . '">' . str_pad($i,2,'0', STR_PAD_LEFT) . '</option>';
                    }
                    else{
                        $ret .= '<option value="' . $i . '" selected="selected">' . str_pad($i,2,'0', STR_PAD_LEFT) . '</option>';
                    }
                }
                $ret .= '</select>';
                break;
            case 'y':
                $ret = ' <select class="form-select" name="' . $name . '">';
                for ($i=2007;$i <= YEARMAX; $i++){
                    if($i != $val){
                        $ret .= '<option value="' . $i . '">' . $i . '</option>';
                    }
                    else{
                        $ret .= '<option value="' . $i . '" selected="selected">' . $i . '</option>';
                    }
                }
                $ret .= '</select>';
                break;
            }
        return $ret;
    }

//***********************************

//***********************************
        public function conventionIn($p){
            $ci=&get_instance();
            $ci->convention->init($p['cid']);
            $ret = $ci->convention->saveConventions($p, $p['cid']);
            return $ret;
        }
//***********************************
//
//***********************************
        public function scenarioAdminMain($aff='0'){
            $ci = &get_instance();
            $ret='';
            $ret .= '<h2 id="op-scen-admin-title">OP Scenarios</h2>';
            $image_properties = array('src' =>'images/ajax-loader.gif','alt'=>'ajax-loader.gif');
            $ret .= '<div id="op-admin-wait2">' . img($image_properties) . '</div>';             
            $ret .= '<div id="scenario-admin-main">';
            $ret .= '<div id="add-results" class="results"></div>';
            $ret .= '<div id="scenario-admin-main-form">';
            $ret .= $ci->scenario->scenarioAdminForm();
            $ret .= '</div>';
            $ret .= '<div id="scenario-admin-main-list">';
            $ret .= $ci->scenario->scenarioListAdmin($aff); 
            $ret .= '</div>';
            $ret .= '</div>';
            return $ret;
        }

//------------------------
//
//------------------------
    public function buildScenarioAPLSDropdowns($low=0, $high=0){
        $ret = ' < <select class="form-select"name="scenarioMinApl">';
        $ret .= ($low == 0) ? '<option value="0" selected="selected"> - </option>' : '<option value="0"> - </option>';
        for ($i=1;$i<=20;$i++)
        {
            $ret .=  ($i == $low) ? '<option value="' . $i . '" selected="selected"> ' . $i . '</option>' : '<option value="' . $i . '"> ' . $i . '</option>';
        }
        $ret .= '</select>';
        $ret .= 'to';
        $ret .= ' < <select class="form-select"name="scenarioMaxApl">';
        $ret .= ($high == 0) ? '<option value="0" selected="selected"> - </option>' : '<option value="0"> - </option>';
        for ($i=1;$i<=20;$i++){
            if ($i == $high){
                $ret .= '<option value="' . $i . '" selected="selected"> ' . $i . '</option>';
            }
            else{
                $ret .= '<option value="' . $i . '"> ' . $i . '</option>';
            }
        }
        $ret .= '</select>';
        return $ret;
    }
        //---------------------------------------------------
        //
        //---------------------------------------------------
         public function game_admin_buttons(){
                $ret='';
                $ret .= '<h2 align="center">Game Event Admin</h2>';
                $ret .= '<div align="center"><table border="0" class="padded-table5px" cellspacing="0" cellpadding="0" align="center" bordercolor="#FFFFFF">';
                $ret .= '<tr>';
                $ret .= '<td align="center">';
                $ret .= '<input class="gevent" name="Regular" type="button" value="  Add A Regular Event  " onclick="self.location=' .  "'"  .  site_url('ogre/games/reg','https') . "'" . '" />';
                $ret .= '</td>';
                $ret .= '</tr>';
                $ret .= '<tr>';
                $ret .= '<td align="center">';
                $ret .= '<input  class="gevent" name="RPGA" type="button" value="  Add a Organized Play Event  " onclick="self.location=' .  "'"  .  site_url('ogre/games/rpga','https') . "'" . '" />';
                $ret .= '</td>';
                $ret .= '</tr>';
                $ret .= '</table></div>';
                return $ret;
         }
        //------------------------
        //
        //------------------------
        function getFirstSlotCode($conid){
            $ci=get_instance();
            $sc='';
            $qry = "SELECT DISTINCT ogre_gameslots.slot_code ";
            
            $qry .= " FROM ogre_gameslots ";
            $qry .= " WHERE ogre_gameslots.slot_conid = " . $conid;
            $qry .= " ORDER BY ogre_gameslots.slot_code LIMIT 1;";

            $query = $ci->db->query($qry);

            if($query->getNumRows() != 0){
                foreach ($query->getResult() as $row){
                    $sc = $row->slot_code;
                }
            }
            return $sc;
        }
        //---------------------------------------------------
        //
        //---------------------------------------------------
        public function convert_slot_code($sc){
            $sc = substr($sc,-2,2);
            $sn = (substr($sc,1,1) == "0") ? substr($sc,0,1) : substr($sc,0,1) . " MM";
            return $sn;
        }

        //------------------------
        //
        //
        //
        //------------------------
        public function getGameSlotSelect($slotcode='', $sl = 4){
            $ci=get_instance();          
            $conid = $ci->session->ogre_conid;
            $qry = 'SELECT * FROM ogre_gameslots ';
            $qry .= ' WHERE slot_conid = ' . $conid;
            $qry .= ' AND slot_RPGA = 1 ';
            $qry .= ' AND slot_length = ' . $sl;
            $qry .= ' ORDER BY slot_code;';
            $ret = '';
            $query = $ci->db->query($qry);
            if($query->getNumRows() != 0){
                foreach ($query->getResult() as $row){
                    $SNum =  ($row->slot_latenight != '0') ? $row->slot_number . 'MM' : $row->slot_number;
                    $ret .=  ($slotcode == $row->slot_code) ? '<option value="' . $row->slot_code . '" selected="selected">' . $SNum . '</option>' : '<option value="' . $row->slot_code . '">' . $SNum  . '</option>';
                }
            }
            $ret .= '<option value="DEL">DEL</option>';
            return $ret;
        }
 
//------------------------
//
//------------------------       
//        public function xml_setupindb($dbc, $sessionip, $con=NULL, $newconid=0){
//            if($newconid == 0){
//                $myxml = simplexml_load_file(base_url() . "xml/ogre_ini.xml");
//                foreach($myxml as $convention){
//                    $orgid = $convention->orgid;
//                    $conid = $convention->conventionid;
//                    $maint = $convention->maintenance;
//                    $msa_conid = $convention->msa_conid;
//                }
//            }
//            else{
//                $ci->convention->init($newconid);
//                
//                $orgid = $con->orgid;
//                $conid = $con->conid;
//                $maint = 0;
//                $msa_conid = $con->msa_conid;    
//                
//            }
//            $data = array(
//                            'xc_ip' => $sessionip,        
//                            'xc_orgid' => $orgid,
//                            'xc_conid'  => $conid,     
//                            'xc_msaconid'  => $msa_conid,   
//                            'xc_maintenance' => $maint                                 
//                        );       
//            
//            $userip = $sessionip;
//                        
//            $where = array('xc_ip' => $sessionip);
//            
//            $dbc->delete('ogre_xmlconfig', $where);
//            
//            $dbc->insert('ogre_xmlconfig', $data);
//            
//            return TRUE;
//            
//        }
 
        //------------------------
        //
        //
        //
        //------------------------       
        public function xml_savesetup($dbc, $sessionip, $dbutil)
        {
            
            $qry = 'SELECT xc_id, xc_orgid, xc_conid, xc_msaconid, xc_maintenance FROM ogre_xmlconfig WHERE xc_ip = "' . $sessionip . '"';
            
            $query = $dbc->query($qry);
            
            
            $config = array (
                              'root'    => 'conventions',
                              'element' => 'convention', 
                              'newline' => "\n", 
                              'tab'    => "\t",
                            );

            
            
            $xmlfile = $dbutil->xml_from_result($query,$config);
            $xmlfile = str_replace('xc_id', 'id', $xmlfile);
            $xmlfile = str_replace('xc_orgid', 'orgid', $xmlfile);
            $xmlfile = str_replace('xc_conid', 'conventionid', $xmlfile);
            $xmlfile = str_replace('xc_msaconid', 'msa_conid', $xmlfile);
            $xmlfile = str_replace('xc_maintenance', 'maintenance', $xmlfile);
            $xmlfile = '<?xml version="1.0" encoding="iso-8859-1"?>' . "\n" . $xmlfile;
           
            $ret = read_file('xml/ogre_ini.xml');
                       
            $ret = write_file('xml/ogre_ini.xml', $xmlfile, 'w+');
            if ($ret == TRUE)
            {
                $retn = '<h2>File Saved</h2>';
            }
            else
            {
                $retn = '<h2>File Not Saved</h2>';                
            }
            return $retn;
            
        }
 
        //------------------------
        //
        //
        //------------------------       
        public function ogre_setupform($dbc, $session){            
            $ret ='';
            $ret .='<form action="'.  site_url('ogre/setup_in/','https') . '" method="post" name="setupin">';
            $orgid = $session->ogre_orgid;
            $cid = $session->ogre_conid;
            $ret .= '<p>Select the Convention to set up Ogre For: </p><p>'. $this->conventionSelect($cid, $orgid) . '</p>';            
            $ret .='<p><input class="btn btn-secondary" name="setupin" type="submit" value="Save" /></p>';
            $ret .='</form>';
            
            return $ret;
        }
       //---------------------------------------------------
	//
	//
	//
	//---------------------------------------------------
          public function emailform($subject = "", $body = ""){
              
                $ret = '<h4 align="center">E-mail Form</h4>';
                $ret .= '<form action="' . site_url('ogre/emailaction','https') . '" method="post" name="contact" id="contact">';           

                $ret .= '<table width="90%" border="0" cellspacing="5" cellpadding="5">';
                $ret .= '<tr><td>';
                $ret .= 'GMs or Players or All';
                $ret .= '</td>';
                $ret .= '<td>';
                $ret .= ' < <select class="form-select"name="emtype" size="1">';
                $ret .= '<option value="GM">GMs</option>';
                $ret .= '<option value="Player">Players</option>';
                $ret .= '<option value="All">All</option>';
                $ret .= '</select>';
                $ret .= '</td>';
                $ret .= '</tr>';
                $ret .= '<tr>';
                $ret .= '<td>';
                $ret .= 'Subject';
                $ret .= '</td>';
                $ret .= '<td>';
                if (trim($subject) != "")
                {
                    $ret .= '<input type="text" class="form-control" size="35" maxlength="256" name="subject" value="' . $subject . '" />';  		   
                }
                else                
                {
                    $ret .= '<input type="text" class="form-control" size="35" maxlength="256" name="subject" />';  		   
                }
                $ret .= '</td>';
                $ret .= '</tr>';
                $ret .= '<tr>';
                $ret .= '<td colspan="2" align="center">';
                $ret .= '<p align="center"><strong>Enter your comments in the space provided below:</strong><br/>';

                if (trim($body) != "")
                {
                    $ret .= '<textarea name="comments" rows="20" cols="30">' . $body .  '</textarea>';
                }
                else
                {
                    $ret .= '<textarea name="comments" rows="20" cols="30"></textarea>';   
                }
                $ret .= '</td>';
                $ret .= '</tr>';
                $ret .= '<tr>';
                $ret .= '</table>';
                $ret .= '<p align="center"><input class="btn btn-secondary" type="submit" value="Send" /> ';
                $ret .= '</p>';
                $ret .= '</form>';
                
                return $ret;
          }



        //---------------------------------------------------
	//
	//
	//
	//---------------------------------------------------
        public function getemailaddresses($dbc, $conid, $etype="All"){
            $ret ='';
            switch (strtolower($etype)){
                case "all":
                    $qry='SELECT DISTINCT ogre_prereg_player.pp_player_email, ogre_prereg_player.pp_player_id ';
                    $qry.=' FROM ogre_prereg_player INNER JOIN ogre_gameschedule ON ogre_prereg_player.pp_gs_id = ogre_gameschedule.gs_id ';
                    $qry.=' WHERE (((ogre_gameschedule.gs_convention_id)=' . $conid . ')) ';
                    $qry.=' ORDER BY ogre_prereg_player.pp_player_id ';
                    break;
                case "player":
                    $qry='SELECT DISTINCT ogre_prereg_player.pp_player_email, ogre_prereg_player.pp_player_id ';
                    $qry.=' FROM ogre_prereg_player INNER JOIN ogre_gameschedule ON ogre_prereg_player.pp_gs_id = ogre_gameschedule.gs_id ';
                    $qry.=' WHERE (((ogre_gameschedule.gs_convention_id)= ' . $conid . ') AND ((ogre_prereg_player.pp_gm_judge_flag) <= 0)) ';
                    $qry.=' ORDER BY ogre_prereg_player.pp_player_id';
                    break;
                case "gm":
                    $qry='SELECT DISTINCT ogre_prereg_player.pp_player_email, ogre_prereg_player.pp_player_id ';
                    $qry.=' FROM ogre_prereg_player INNER JOIN ogre_gameschedule ON ogre_prereg_player.pp_gs_id = ogre_gameschedule.gs_id ';
                    $qry.=' WHERE (((ogre_gameschedule.gs_convention_id)= ' . $conid . ') AND (ABS(ogre_prereg_player.pp_gm_judge_flag) = 1)) ';
                    $qry.=' ORDER BY ogre_prereg_player.pp_player_id';
                    break;                
            }

            $query = $dbc->query($qry);
            
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){   
                    $ret .= $row->pp_player_email . ';';
                }                
            } 
            
            return $ret;
        }
//---------------------------------------------------
//
//
//
//---------------------------------------------------
        public function genRandomString($length=10){
            $characters = '0123456789abcdefghijklmnopqrstuvwxyz-';
            $charactersLength = strlen($characters);
            $randomString = '';
            for ($i = 0; $i < $length; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
            }
            return $randomString;
        }
        //***********************************
        //
        //
        //
        //***********************************
        public function generate_activatecode($p){
            $ci=&get_instance();
            $orgid = $ci->session->ogre_orgid;
            $conid = $ci->session->ogre_conid;
            $txn_id = $this->genRandomString(17);
            $qry = 'insert into ogre_paypal_cart_info(';
            $qry .= 'ppci_orgid, ';
            $qry .= 'ppci_conid, ';            
            $qry .= 'ppci_buyer_email, ';
            $qry .= 'itemnumber,';
            $qry .= 'txnid) ';
            $qry .= " values (";
            $qry .= $orgid . ", ";
            $qry .= $conid . ", '";
            $qry .= $p['email'] . "', '";                            
            $qry .= $p['ppitem'] . "', '";
            $qry .= strtoupper($txn_id)  . "')";   

            $ci->db->query($qry);

            if ($ci->db->affectedRows() > 0)
            {
                    $ret['result'] = TRUE;
                    $ret['code'] = $txn_id;
                    $ret['email'] = $p['email'];
            }
            else
            {
                    $ret['result'] = FALSE;
            }   
            
            return $ret;
                
        }
        //***********************************
        //
        //***********************************        
        public function generateActivationCodeForm(){
            $ci=&get_instance();
            $ret='';
            $ret.='<h3>Add Activation Code</h3>';
            $x=33;
            $inst=$ci->ogre_lib->getMiscContent($x);
            $ret.= $inst['content'];
            $ret.='<form method="POST" action="' . site_url('ogrex/actCodeIn','https') . '">';
            $ret.='<label for="fname">First Name</label>';
            $ret.='<td><input class="form-control form-control-sm" type="text" name="fname" size="20"></td>';
            $ret.='<label for="lname">Last Name</label>';
            $ret.='<td><input class="form-control form-control-sm" type="text" name="lname" size="20"></td>';
            $ret.='<label for="email">Email Address</label>';
            $ret.='<td><input class="form-control form-control-sm" type="text" name="email" size="20"></td>';
            $ret.='<label for="ppitem">Registation Type</label>';
            $ret.='<td>' . $this->paypalItemSelect() . '</td>';
            $ret.='<div class="d-grid gap-2"><input class="btn btn-secondary m-1" type="button" value="Submit" name="B1" onclick=""></div>';
            $ret.='</form>     ';
            return $ret;
        }
//***********************************
//
//***********************************
        public function paypalItemSelect(){
            $ci=&get_instance();
            $conid = $ci->session->ogre_conid;
            $orgid = $ci->session->ogre_orgid;
            $qry = 'SELECT * FROM ogre_paypalitem ';
            $qry .= ' WHERE ppi_orgid = ' . $orgid;
            $qry .= ' AND ppi_conid = ' . $conid;
            $qry .= ' ORDER BY ppi_name;';
            $query = $ci->db->query($qry);
            $ret = '< <select class="form-select" name="ppitem" size="1">';
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                        $ret .= '<option value = "' . $row->ppi_itemcode  . '">' . $row->ppi_name  . '</option>';
                }
            }
            $ret .= '</select>';
            return $ret;
        }        
//---------------------------------------------------
//
//---------------------------------------------------
    public function getSlotsX($conid, $sid){
        $ci=get_instance();
        $conid = $ci->session->ogre_conid;              
        $i=0;
        $ret='';
        $ci->scenario->init($sid, $conid);
        $sl=$ci->scenario->slot_length;
        $qry = 'SELECT slot_number, slot_rpga_number, slot_code, slot_length ';
        $qry .= ' FROM ogre_gameslots ';
        $qry .= ' WHERE slot_conid = ' . $conid;
        $qry .= ' AND slot_length = "' . $sl . '"';
        $qry .= ' ORDER BY slot_code;';       
        $slots = $ci->db->query($qry);
        if ($slots->getNumRows() > 0){
            foreach ($slots->getResult() as $slot)
            {                                          
                $ret.=$slot->slot_code . ',' . $slot->slot_rpga_number .  ',' . $slot->slot_length .  ',' . $slot->slot_number . ':';                            
            }
        }
        return $ret;
    }        
//---------------------------------------------------
//
//---------------------------------------------------
          public function getGamesX($gtype){
            $ret='';
            $ci=&get_instance();
            $qry = 'SELECT ogre_games.*, ogre_games_descriptor_xref.*, ogre_games_descriptor.*, ogre_games_descriptor_type.*';
            $qry .= ' FROM (ogre_games INNER JOIN ogre_games_descriptor_xref ON ogre_games.gn_game_id = ogre_games_descriptor_xref.gdx_gn_id)';
            $qry .= ' INNER JOIN (ogre_games_descriptor INNER JOIN ogre_games_descriptor_type ON ogre_games_descriptor.gd_descriptor_type = ogre_games_descriptor_type.gdt_id) ';
            $qry .= ' ON ogre_games_descriptor_xref.gdx_gd_id = ogre_games_descriptor.gd_id ';
            $qry .= ' WHERE ogre_games_descriptor.gd_descriptor_type = 1 AND ogre_games_descriptor.gd_id = ' . $gtype;
            $qry .= ' ORDER BY ogre_games.gn_game_name, ogre_games_descriptor.gd_descriptor;';
            $query = $ci->db->query($qry);
            if ($query->getNumRows() > 0){
                foreach ($query->getResult() as $row){
                    $ci->game->init($row->gn_game_id);
                    $ret .= $ci->game->gameid . ',' . $ci->game->game_name . ' (' . $ci->game->game_type . ')' . ':';
                 }
            }
            return $ret;
                
          }     
//---------------------------------------------------
//
//---------------------------------------------------
      public function ipnForm($ipnaction){           
            $ret = '<h4 align="center">PayPal IPN Test Form</h4>';

            $ret .= '<form action="" method="post" name="ipntest" id="ipntest">';           
            $ret .= '<label for="ipn-data">IPN Data String</label>';
            $ret .= '<textarea class="form-control m-1" placeholder="Leave a IPN Data here" id="ipn-data" name="ipn-data"></textarea>';   
            $ret .= '<div class="d-grid gap-2"><input class="btn btn-secondary m-1" type="button" value="  Send  " onclick="submitIPNData(' ."'". site_url($ipnaction,'https') ."'".');"/></div>';
            $ret .= '</form>';
            $ret .= '<div id="ipnresults" name="ipnresults" class="results"></div>';
            return $ret;
      }   
//---------------------------------------------------
//
//---------------------------------------------------
    public function opAdminTabs($aff='0'){
        $ret = '';
        $ci=&get_instance();
        $conid = $ci->session->ogre_conid;
        $ret .= '<div id="game-admin-filter"><label for="affiliation"> Organized Play Filter (Which OP do you wish to see?)</label>'.  $ci->event->getEventAffiliationFilter($aff, $conid) . '</div>';
        $ret .= '<div id="opahorizontalTab">';           
        $ret .= '<ul>';                   
        $ret .= '<li>';
        $ret .= '<a href="#opatab-1">';
        $ret .= 'Scenarios';
        $ret .= '</a>';
        $ret .= '</li>';
        $ret .= '<li>';
        $ret .= '<a href="#opatab-2">';
        $ret .= 'Scheduler';
        $ret .= '</a>';
        $ret .= '</li>';
        $ret .= '</ul>';
        $ret .= '<div id="opatab-1">';
        $ret .= '<div id="scenario-admin1">';
        $ret .= $this->scenarioAdminMain($aff);
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '<div id="opatab-2">';
        $ret .= '<div id="game-admin-header">';        
        $ret .=  $ci->event->gameAdminOP();
        $ret .= '</div>';
        $ret .= '<div id="game-admin-list">';
        $ret .= $ci->event->gameAdminOPSCurrentSchedule(0);        
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>'; 
        return $ret;
    }         
//---------------------------------------------------
//
//---------------------------------------------------
    public function eventAdminTabs(){
        $ret = '';
        $ci=&get_instance();
        $conid = $ci->session->ogre_conid;
        $ret .= '<div id="evhorizontalTab">';           
        $ret .= '<ul>';                   
        $ret .= '<li>';
        $ret .= '<a href="#tab-1" >';
        $ret .= 'Conventions';
        $ret .= '</a>';
        $ret .= '</li>';
        $ret .= '<li>';
        $ret .= '<a href="#tab-2" >';
        $ret .= 'Locations';
        $ret .= '</a>';
        $ret .= '</li>';
        $ret .= '<li>';
        $ret .= '<a href="#tab-3" >';
        $ret .= 'Slots';
        $ret .= '</a>';
        $ret .= '</li>';
        $ret .= '<li>';
        $ret .= '<a href="#tab-4" >';
        $ret .= 'Game DB';
        $ret .= '</a>';
        $ret .= '</li>';        
        $ret .= '</ul>';
        $ret .= '<div id="tab-1">';
        $ret .= '<h2>Conventions</h2>'; 
        $ret .= $ci->convention->conventionListHeader() . $ci->convention->conventionList();
        $ret .= '</div>';
        $ret .= '<div id="tab-2">';    
        $ret .= '<h2>Locations</h2>';
        $ret .= $this->locationHeader($conid);
        $ret .= '<div id="loclist">';
        $ret .= $ci->convention_lib->viewLocationList($conid, TRUE);
        $ret .= '</div>';       
        $ret .= '</div>';
        $ret .= '<div id="tab-3">';
        $ret .= '<h2>Slots</h2>';
        $ret .= $this->slotHeader($conid);
        $ret .= '<div id="slotlist">';                         
        $ret .= $ci->convention->viewSlotList(TRUE,$conid);
        $ret .= '</div>'; 
        $ret .= '</div>';        
        $ret .= '<div id="tab-4">';
        $ret .= $ci->game->getGameViewHeader(0);
        $ret .= '<div id="gamelist">';
        $ret .= $ci->game->getGameViewList(0, 'Yes');
        $ret .= '</div>'; 
        $ret .= '</div>';        
        $ret .= '</div>'; 
        return $ret;
        
    }        
//---------------------------------------------------
//
//---------------------------------------------------
    public function gamingAdminTabs(){
        $ret = '';
        $ci=&get_instance();
        $ret .= '<div id="gahorizontalTab">';           
        $ret .= '<ul>';
        $ret .= '<li>';
        $ret .= '<a href="#tab-1">';
        $ret .= 'Scheduled Games';
        $ret .= '</a>';
        $ret .= '</li>';
        $ret .= '<li>';
        $ret .= '<a href="#tab-2">';
        $ret .= 'Proposals';
        $ret .= '</a>';
        $ret .= '</li>';
        $ret .= '</ul>';
        $ret .= '<div id="tab-1">';
        $ret .= $ci->event->preregisterEdit(0);
        $ret .= '</div>';
        $ret .= '<div id="tab-2">';
        $ret .= '<div id="game-proposal-list">' . $ci->proposal->proposalList() . '</div>';
        $ret .= '<div id="pgl-proposal-list">' . $ci->proposal->personalGameLibraryList() . '</div>';
        $ret .= '</div>';
        $ret .= '</div>'; 
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------
    public function userAdminTabs(){
        $ret = '';
        $ci = &get_instance();
        $conid = $ci->session->ogre_conid;
        $ret .= '<div id="horizontalTab-admin-users">';           
        $ret .= '<ul>';                   
        $ret .= '<li>';
        $ret .= '<a href="#admin-users-tab-1">';
        $ret .= 'Users';
        $ret .= '</a>';
        $ret .= '</li>';
        $ret .= '<li>';
        $ret .= '<a href="#admin-users-tab-2">';
        $ret .= 'Send Code';
        $ret .= '</a>';
        $ret .= '</li>';
        $ret .= '<li>';
        $ret .= '<a href="#admin-users-tab-3">';
        $ret .= 'IPN Data';
        $ret .= '</a>';
        $ret .= '</li>';
        $ret .= '<li>';
        $ret .= '<a href="#admin-users-tab-4">';
        $ret .= 'Generate Act. Code';
        $ret .= '</a>';       
        $ret .= '</li>';
        $ret .= '</ul>';
        $ret .= '<div id="admin-users-tab-1">';
        $ret .= $this->userAdmin($conid);
        $ret .= '</div>';
        $ret .= '<div id="admin-users-tab-2">';    
        $ret .= $ci->ogre_lib->transactionID();
        $ret .= '<div id="act-code-results" style="width:100%;text-align: center; padding-top:15px; padding-bottom:5px;">';
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '<div id="admin-users-tab-3">';
        $action='ogre_paypal/index/TRUE';
        $ret .= $this->ipnForm($action);
        $ret .= '</div>';        
        $ret .= '<div id="admin-users-tab-4">';
        $ret .= $this->generateActivationCodeForm();
        $ret .= '</div>';        
        $ret .= '</div>'; 
        return $ret;
    }        
}

?>
