<?php
namespace App\Libraries;
use CodeIgniter\I18n\Time;

class Propose_lib{
//---------------------------------------------------
//
//---------------------------------------------------   
    public function eventProposal(){               
        $ci=&get_instance();
        $orgid = $ci->session->ogre_orgid;
        $conid = $ci->session->ogre_conid;
        $pid = $ci->session->ogre_user_ID;                
        $ci->convention->init($conid);
        $ci->proposal->prop_init(0, $conid);           
        $ci->person->init($conid, '', $pid);                              
        $conname = $ci->convention->name;                
        $key = '%PROPHEADER%';
        $needle = '%AGREEMENTLINK%';
        $txt = $ci->ogre_lib->getMiscContent($key);
        $link1 = '<a href="#" onclick="return get_gmpolicy('."'".site_url('ogrex/gmPolicyX','https')."'".')">Game Master Guidelines</a>.';
        $eventname = $conname;
        $eventdates = $ci->convention->getConDates();
        $ret = '';
        $ret1 = '';
        $image_properties = array('src' =>'images/help.png','width' => '25','style' => 'margin: 5px 0px 0px 5px;'); 
        
        $ret .= '<h2>Game Proposal Form</h2>';
        $ret .= str_replace($needle, $link1, $txt['content']);
        if($ci->session->ogre_logged_in == TRUE){
            $verified= $ci->session->get('ogre_user_activated_' . $conid);
            if (intval($verified) == 0){
                $txt1 = $ci->ogre_lib->getMiscContent('%%NOT-ACTIVE-PROPOSE%%',$conid,TRUE);
                $ret .= $ci->ogre_lib->bootAlert('alert-info','00','Proposing while Inactive', $txt1);
            }
        }
        $ret .= '<div id="results" class="results"></div>';
        $ret .= '<form id="proposal" name="proposal" action="' . site_url('ogrex/proposeActionx','https') . '">';       
        $ret .= '<div class="proposal" id="proposal_div">';

        $ret .= '<input type="hidden" id="eventname" name="eventname" value="'. $eventname . '" />';
        $ret .= '<input type="hidden" id="eventdates" name="eventdates" value="'. $eventdates . '" />';
        $ret .= '<input type="hidden" id="conid" name="conid" value="'. $conid . '" />';           
        $ret .= '<input type="hidden" id="gm_gender" name="gm_gender" value="" />';
        $ret .= '<input type="hidden" id="gm_city" name="gm_city" value="" />';
        $ret .= '<input type="hidden" id="gm_state" name="gm_state" value="" />';
        
        $ret1 .= '<div class="alert alert-info">';
        $ret1 .= '<div class="row my-1">';
        $ret1 .= '<div id="proposaltable_event_center" class="col">';
        $ret1 .=  '<label for="conlist">What event are you proposing for?</label>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';        
        $ret1 .= '<div class="row my-1">';        
        $ret1 .= '<div id="proposaltable_event_center" class="col">';       
        $ret1 .=  $this->getProposalConList($conid, $orgid);     
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div id="proposaltable_event_center" class="col my-1">';        
        $ret1 .= '<strong>Currently proposing for:</strong>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= '<div class="alert alert-secondary my-1">';        
        $ret1 .= '<div id="proposal_currentcon" class="col">'; 
        $ret1 .= '<span class="text-success font-weight-bold"> ' . $eventname .  ' - ';
        $ret1 .= ' ' . $eventdates .' </span>'; 
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';
      
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="proposalnumbertype" >Proposal Type</label>';
        $ret1 .= '<div class="input-group input-group-md">';        
        $ret1 .= $this->proposalNumberType();
        $action = 'proposal_help('."'".'proposalnumbertype'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';        
        $ret1 .= '</div>';
        $ret1 .= '</div>';     
        $ret1 .= '</div>'; 
        $ret1 .= $this->getHelpAlert('proposalnumbertype');
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="propnum" class="label label-default mx-3">Proposal Number:</label>';
        $ret1 .= '<div class="input-group mb-3">';
        $ret1 .= '<input  type="number" class="form-control " id="propnum" name="propnum" value="1"  placeholder="Proposal Number Start" >';
        $ret1 .= '<span class="input-group-text"> of </span>';
        $ret1 .= '<input type="number" class="form-control" id="propof" name="propof" value="1">';
        $action = 'proposal_help('."'".'propnum'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';         
        $ret1 .= '</div>';  
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('propnum');                   
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="gamesessions">Total Number of Game Sessions for this proposal:</label>';
        $ret1 .= '<div class="input-group input-group-md">'; 
        $ret1 .= $this->proposalSessionNumber();
        $action = 'proposal_help('."'".'gamesessions'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';         
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= '</div>'; 
        $ret1 .= $this->getHelpAlert('gamesessions');        
        
        $ret .= $ci->ogre_lib->bootCard('m-3',$ret1,'proposal_basic','Basic Information','');

        $ret1 = '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $txt =  $ci->ogre_lib->getMiscContent('%PROPOSALWHOINSTRUCTIONS%');    
        $ret1 .= $txt['content'];
        $ret1 .= '</div></div>';        

        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col" id="prop_label1">';      
        $ret1 .=  '<label for="gmname">Name*: </label>';  
        $ret1 .= '<div class="input-group input-group-md">';
        if($ci->session->ogre_logged_in == TRUE){
             $ret1 .=  ' <input class="form-control  required" type="text" id="gmname" name="gmname" value="' . $ci->person->fullname . '" />';
        }
        else{
            $ret1 .=  '<input class="form-control  required" type="text" name="gmname" id="gmname"  />';
        }
        $action = 'proposal_help('."'".'gmname'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= '</div>'; 
        $ret1 .= $this->getHelpAlert('gmname');
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col" id="prop_label1">';      
        $ret1 .=  '<label for="gmemail">E-Mail Address*: </label>';  
        $ret1 .= '<div class="input-group input-group-md">';        
        if($ci->session->get("ogre_logged_in") == TRUE){
            $ret1 .=  '<input type="email" id="gmemail" name="gmemail" value="' . $ci->person->email . '" class="form-control  required" placeholder="Email" />';
        }
        else{
            $ret1 .=  '<input type="email" id="gmemail" name="gmemail" class="form-control   required"" placeholder="Email" />';
        }
        $action = 'proposal_help('."'".'gmemail'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';        
        $ret1 .= '</div>'; 
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('gmemail');        
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col" id="prop_label1">';          
        $ret1 .= '<label for="gm_age" >Age: </label>';
        $ret1 .= '<div class="input-group input-group-md">';
        $ret1 .= '<input class="form-control " type="text" id="gm_age" name="gm_age" placeholder="Your Age" />';
        $action = 'proposal_help('."'".'gm_age'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';        
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('gm_age');
        
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col" id="gm_dphone1">';
        $ret1 .= '<label for="gm_phone" >Contact Phone: </label>';      
        $ret1 .= '<div class="input-group input-group-md">';
        $ret1 .= '<input class="form-control" type="tel" id="gm_dphone" name="gm_dphone" placeholder="Your Contact Phone" />';
        $action = 'proposal_help('."'".'gm_dphone'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';        
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('gm_dphone');
        
        
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col" id="firsttime1">';    
        $ret1 .= '<label for="firsttime" >First time running for us?:</label>';
        $ret1 .= '<div class="input-group input-group-md">';
        $ret1 .= '<select class="form-control " size="1" name="firsttime" id="firsttime" class="required" onchange="firsttime_gm(this.options[this.selectedIndex].value)">';
        $ret1 .= '<option value="Yes"> Yes </option>';
        $ret1 .= '<option value="No" selected="selected">  No </option>';
        $ret1 .= '</select>';
        $action = 'proposal_help('."'".'firsttime'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';        
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';        
        $ret1 .= $this->getHelpAlert('firsttime');
        
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';       
        $ret1 .= '<label for="gm_xp">GMing Experience (Years): </label>'; 
        $ret1 .= '<div class="input-group input-group-md">';
        $ret1 .= '<input class="form-control " type="number" id="gm_xp" name="gm_xp" />';
        $action = 'proposal_help('."'".'gm_xp'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';         
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= '</div>'; 
        $ret1 .= $this->getHelpAlert('gm_xp');
        
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';                  
        $ret1 .= '<label for="gm_runcongame">Con Game GMing Experience?: </label>'; 
        $ret1 .= '<div class="input-group input-group-md">';
        $ret1 .= '<select class="form-control " id="gm_runcongame" name="gm_runcongame" >';
        $ret1 .= '<option value="Yes"> Yes </option>';
        $ret1 .= '<option value="No">  No </option>';
        $ret1 .= '</select>';
        $action = 'proposal_help('."'".'gm_runcongame'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';         
        $ret1 .= '</div>';
        $ret1 .= '</div>';               
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('gm_runcongame');
        
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="playormarshal">Your Role for Game Event</label>';
        $ret1 .= '<div class="input-group input-group-md">';
        $ret1 .= $ci->proposal->proposalSelect('playormarshal', '%PLAYORMARSHAL%');   
        $action = 'proposal_help('."'".'playormarshal'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';          
        $ret1 .= '</div>';
        $ret1 .=' </div>';
        $ret1 .= '</div>';    
        $ret1 .= $this->getHelpAlert('playormarshal');
        
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="gmnum">Number of total GMs, including yourself:</label>';
        $ret1 .= '<div class="input-group input-group-md">';
        $ret1 .= '<input type="number" class="form-control " id="gmnum" name="gmnum" value="1" />';
        $action = 'proposal_help('."'".'gmnum'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';         
        $ret1 .=' </div>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('gmnum');
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="otherGMs" >Additional GM names/email addresses:</label>';
        $ret1 .= '<textarea id="otherGMs" name="otherGMs"></textarea>';
        $ret1 .=' </div>';
        $ret1 .= '</div>';
        $ret .= $ci->ogre_lib->bootCard('m-3',$ret1,'proposalWho','Who: Host or GM Information','');
       
        $laction = site_url('ogrex/getBGGSearch');
        
        $ret1 = '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="gametype">Game Type*</label>';
        $ret1 .= '<div class="input-group input-group-md">';
        $ret1 .= '<select size="1" name="gametype" id="gametype" class="form-control required" onchange="gametype_check(this.options[this.selectedIndex].value)">';
        $ret1 .=  $ci->proposal->gameTypeSelect();
        $ret1 .= '</select>';
        $action = 'proposal_help('."'".'gametype'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';          
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('gametype');
        
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="gamesystem">Game Name/Game System/Setting*</label>';
        $ret1 .= '<div class="input-group input-group-md">';
        $ret1 .= '<input type="text" class="form-control required" placeholder="Game Name/System" id="gamesystem" name="gamesystem" aria-label="Game Name/System" aria-describedby="bggSearch">';
        $ret1 .= '<button class="btn btn-primary btn-md m-2" type="button" id="bggSearch" onclick="displayBGGSearch('."'".$laction."'".')">Search</button>';
        $action = 'proposal_help('."'".'gamesystem'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';           
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';    
        $ret1 .= $this->getHelpAlert('gamesystem');
        
        $ret1 .= '<div class="row m-2" id="advtitle">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="gametitle">Adventure/Scenario Title <sup>(if applicable)</sup></label>';
        $ret1 .= '<div class="input-group input-group-md">';
        $ret1 .= '<input class="form-control" type="text" id="gametitle" name="gametitle" placeholder="Title if Applicable"/>';
        $action = 'proposal_help('."'".'gametitle'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';        
        $ret1 .= '</div>';
        $ret1 .= '</div>';   
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('gametitle');
        
        $ret1 .= '<div class="row m-2" id="advtitle">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="eventtype">Type of Event:</label>';
        $ret1 .= '<div class="input-group input-group-md">';
        $ret1 .= '<select size="1" name="eventtype" id="eventtype" class="form-control required">';
        $ret1 .=  $ci->proposal->eventTypeSelect(GENERAL_PLAY);
        $ret1 .= '</select>';
        $action = 'proposal_help('."'".'eventtype'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';         
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('eventtype');
        
        $ret1 .= '<div class="row m-2" id="advtitle">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="gamenotes">Description of proposed game (This will be posted publically):</label> ';           
        $ret1 .= '<textarea name="gamenotes" id="gamenotes"></textarea>';
        $ret1 .= '</div>';
        $ret1 .= '</div>'; 
        
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $ret1.= '<label for="minplay" class="label label-default mx-3">Number of players:</label>';
        $ret1 .= '<div class="input-group mb-3">';        
        $ret1 .= '<span class="input-group-text" id="" >Min:</span>';
        $ret1 .= '<input class="form-control" type="number" id="minplay" name="minplay" value="3" class="required"/>';
        $ret1 .= '<span class="input-group-text" id="">Max</span>';
        $ret1 .= '<input class="form-control" type="number" id="maxplay" name="maxplay" value="6" class="required" />';
        $action = 'proposal_help('."'".'maxplay'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';         
        $ret1 .= '</div>';  
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('maxplay');
        
        $ret .= $ci->ogre_lib->bootCard('m-3',$ret1,'proposalWhat','What: What are you going to run?','');                   

        $ret1 = '<div class="row m-2">';
        $ret1 .= '<div class="col-6">';
        $ret1 .= '<label for="gametime">Total Amount of time per session (in hours):</label>';
        $ret1 .= '<div class="input-group mb-3">'; 
        $ret1 .= '<input type="number" class="form-control required" id="gametime" name="gametime" value="4" /> ';
        $action = 'proposal_help('."'".'gametime'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';          
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= '<div class="col-6">';
        $ret1 .= '<label for="gametime-bgg">Minimum Time to Play (BGG/RPGG, in Minutes):</label>';
        $ret1 .= '<input type="number" class="form-control required" id="gametime-bgg" name="gametime-bgg" value="" disabled="disabled" /> ';
        $ret1 .= '</div>';        
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('gametime');
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="anytime">Desired approximate time(s) for this proposed event(s):</label>';
        $ret1 .= '<div class="input-group mb-3">'; 
        $ret1 .= $ci->proposal->proposalSelectSchedPref('anytime', '%PROPOSAL_SCHEDULE_OPTIONS%');
        $action = 'proposal_help('."'".'anytime'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';        
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('anytime');
        $ret1 .= '<div class="row m-2" id="prop_schedulepreferences_special" style="display:none">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="specialschedule">If the above is <strong>Specific Schedule</strong> Selected, please explain your specific schedule needs:</label>';
        $ret1 .= '<textarea name="specialschedule" id="specialschedule"></textarea>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        
        $ret .= $ci->ogre_lib->bootCard('m-3',$ret1,'proposalWhen','When: What are your scheduling preferences','');
        
        $ret1 = '<div class="row m-2">';
        $ret1 .= '<div class="col">'; 
        $ret1 .= '<label>Handling Online Preregistration & Onsite Registration:</label>';
        $ret1 .= '<div class="input-group mb-3">'; 
        $ret1 .= $this->registrationHandling($orgid, 0);
        $action = 'proposal_help('."'".'reghandling'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';        
        $ret1 .=' </div>';
        $ret1 .= '</div>'; 
        $ret1 .=' </div>';
        $ret1 .= $this->registrationHandling($orgid, 1);
        $ret1 .= $this->getHelpAlert('reghandling'); 
        
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="playbring">Player responsibilities - All Materials ...</label>';   
        $ret1 .= '<div class="input-group mb-3">'; 
        $ret1 .= $ci->proposal->proposalSelect('playbring', '%PLAYER_MATERIALS%');
        $action = 'proposal_help('."'".'playbring'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';         
        $ret1 .= '</div>';         
        $ret1 .=' </div>';
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('playbring');


        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label fo="knowledge">Player Knowledge: </label>';  
        $ret1 .= '<div class="input-group mb-3">'; 
        $ret1 .= $ci->proposal->proposalSelect('knowledge', '%GAME_KNOWLEDGE%');  
        $action = 'proposal_help('."'".'knowledge'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';          
        $ret1 .=' </div>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('knowledge');
                           
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="attitude">Attitude rating for this game: </label>';
        $ret1 .= '<div class="input-group mb-3">';        
        $ret1 .= $ci->proposal->proposalSelect('attitude', '%GAME_ATTITUDE%'); 
        $action = 'proposal_help('."'".'attitude'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';          
        $ret1 .=' </div>';        
        $ret1 .=' </div>';
        $ret1 .= '</div>';  
        $ret1 .= $this->getHelpAlert('attitude');
        
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="agerate">Age rating for this game: </label>';
        $ret1 .= '<div class="input-group mb-3">';  
        $ret1 .= $ci->proposal->proposalSelect('agerate', '%AGE_RATING%');
        $action = 'proposal_help('."'".'agerate'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';        
        $ret1 .=' </div>';
        $ret1 .= '</div>';               
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('agerate');
        
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">'; 
        $ret1 .= '<label for="rprating">Roleplaying Rating<sup>(RPGs/LARPs Only)</sup></label>';
        $ret1 .= '<div class="input-group mb-3">';
        $ret1 .= '<input class="form-control" type="number" id="rprating" name="rprating" value="0" max="10" min="0" />'; 
        $action = 'proposal_help('."'".'rprating'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';        
        $ret1 .=' </div>';
        $ret1 .= '</div>'; 
        $ret1 .= '</div>'; 
        $ret1 .= $this->getHelpAlert('rprating');
        
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="psrating">Puzzle Solving Rating<sup>(if applicable)</sup></label>';
        $ret1 .= '<div class="input-group mb-3">';
        $ret1 .= '<input class="form-control" type="number" id="psrating" name="psrating" value="0" max="10" min="0"  />'; 
        $action = 'proposal_help('."'".'psrating'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';         
        $ret1 .=' </div>';
        $ret1 .= '</div>'; 
        $ret1 .= '</div>'; 
        $ret1 .= $this->getHelpAlert('psrating');
        
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="actrating">Action Rating<sup>(if applicable)</sup></label> ';
        $ret1 .= '<div class="input-group mb-3">';
        $ret1 .= '<input class="form-control" type="number" id="actrating" name="actrating" value="0" max="10" min="0"  />'; 
        $action = 'proposal_help('."'".'actrating'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';          
        $ret1 .=' </div>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';        
        $ret1 .= $this->getHelpAlert('actrating');
        
        $ret1 .= '<div class="row m-2">';
        $ret1 .= '<div class="col">';        
        $ret1 .= '<label for="cmplxrating">Complexity<sup>(if applicable)</sup></label>';
        $ret1 .= '<div class="input-group mb-3">';
        $ret1 .= '<input class="form-control" type="number" id="cmplxrating" name="cmplxrating" value="0" max="10" min="0" />';
        $action = 'proposal_help('."'".'cmplxrating'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';         
        $ret1 .= '<input type="hidden" name="campaign" value="No" />';
        $ret1 .=' </div>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('cmplxrating');
        
        $ret .= $ci->ogre_lib->bootCard('m-3',$ret1,'proposal_more','More Details (Optional)',''); 
                
        $ret1 = '<div class="row my-2">';
        $ret1 .= '<div class="col">'; 
        $ret1 .= '<label for="tspace">How much table space will you need for this game?</label>';
        $ret1 .= '<div class="input-group mb-3">';
        $ret1 .= $ci->proposal->proposalSelect('tspace', '%GAME_TABLESPACE%');
        $action = 'proposal_help('."'".'tspace'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';         
        $ret1 .=' </div>';
        $ret1 .= '</div>';
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('tspace');
 
        $ret1 .= '<div class="row my-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<label for="tablesize">Specific Space, if applicable (Use this only if you need to Specify size)</label>';  
        $ret1 .= '<div class="input-group mb-3">';
        $ret1 .= '<input class="form-control " type="text" id="tablesize" name="tablesize" placeholder="0ft X 0ft" />';
        $action = 'proposal_help('."'".'tablesize'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';        
        $ret1 .=' </div>';
        $ret1 .= '</div>'; 
        $ret1 .= '</div>';
        $ret1 .= $this->getHelpAlert('tablesize');
        
        $ret1 .= '<div class="row my-2">';
        $ret1 .= '<div class="col">';
        $ret1 .= '<labelfor="space">How much area space will you need for this game?</label>';
        $ret1 .= '<div class="input-group mb-3">';
        $ret1 .= $ci->proposal->proposalSelect('space', '%GAME_PLAYSPACE%');
        $action = 'proposal_help('."'".'space'."'".');';
        $ret1 .= '<span id="proposal-help m-3">' . str_replace('img src', 'img onclick="'.$action. '" src',img($image_properties)) . '</span>';         
        $ret1 .=' </div>';
        $ret1 .= '</div>'; 
        $ret1 .= '</div>'; 
        $ret1 .= $this->getHelpAlert('space');
        
        $ret1 .= '<div class="row my-2">';
        $ret1 .= '<div class="col">';
        $txt2 = $ci->ogre_lib->getMiscContent('%ADDITIONALPROPINFO%');
        $ret1 .= $txt2['content'];        
        $ret1 .= '<label for="comments">Final Comments</label>';             
        $ret1 .= '<textarea id="comments" name="comments" rows="8" cols="75"></textarea>';
        $ret1 .=' </div>';
        $ret1 .= '</div>';       
        
        $ret .= $ci->ogre_lib->bootCard('m-3',$ret1,'proposalWhere','Where & Final Comments','');
                
        $ret1 = '<div class="row my-2">';
        $ret1 .= '<div class="col">';            
        $ret1 .= '<div class="alert alert-danger"><p>I have read and agree with the ';
        $ret1 .= '<a href="#" onclick="return get_gmpolicy('."'".site_url('ogrex/gmPolicyX','https')."'".')">Game Master Guidelines</a>. ';
        $ret1 .= '<div class="form-check form-check-inline">';
        $ret1 .= '<div class="form-check"><input class="form-check-input" type="radio" name="agree" id="agree" value="Yes"><label class="form-check-label" for="gridRadios1">Yes</label></div>';
        $ret1 .= '<div class="form-check"><input class="form-check-input" type="radio" name="agree" id="disagree" value="No" checked><label class="form-check-label" for="gridRadios2">No</label></div>';
        $ret1 .= '</div>';
        $ret1 .= '</fieldset>';
        $ret1 .= '<input type="hidden" name="gm_id" value="' . $ci->person->user_id_num . '">';           
        $ret1 .=' </div>';
        $ret1 .= '</div>'; 
        
        $ret .= $ci->ogre_lib->bootCard('m-3',$ret1,'proposal_agree','GM Agreement','');
        
        $ret .=  '</div>'; 
        
        $ret .= '<div class="row my-2">';
        $ret .= '<div class="col">';         
        $ret .= '<button class="btn btn-primary float-end" type="button" onClick="submitProposal();">Submit Proposal</button>';     
        $ret .= '</div>';
        $ret .= '</div>';         
        $ret .=  '</form>';
        

        return $ret;
    }    
            
//---------------------------------------------------
//
//---------------------------------------------------   
    public function proposalNumberType(){
        $ci=&get_instance();
        $ret = $ci->proposal->proposalSelect('proposalnumbertype', '%PROPOSAL.NUMBER.TYPE%');
        $ret = str_replace('<select ', '<select onchange="show_proposaloption(this.options[this.selectedIndex].value);" ', $ret);
        return $ret;
    }
            
//---------------------------------------------------
//
//---------------------------------------------------             
    public function proposalSessionNumber(){
        $ci = &get_instance();
        $ret = '<select class="form-control" id="gamesessions" name="gamesessions"  onchange="show_proposalsessioninfo(this.options[this.selectedIndex].value);">';
        $ret .= '<option value="1" selected="selected">1</option>';
        $ret .= '<option value="2">2</option>';
        $ret .= '<option value="3">3</option>';
        $ret .= '<option value="4">4</option>';
        $ret .= '<option value="5">5</option>';
        $ret .= '<option value="6">6</option>';
        $ret .= '<option value="7">7</option>';
        $ret .= '<option value="8">8</option>';
        $ret .= '<option value="9">9</option>';
        $ret .= '<option value="10">10</option>';
        $ret .= '<option value="-10">10+</option>';
        $ret .= '<option value="-99">As many as possible</option>';
        $ret .= '</select>';           
        return $ret;               
    }

//---------------------------------------------------
//
//---------------------------------------------------    
    public function proposeAction($conid=0, $p=NULL){
        $ci=&get_instance();
        $conid = ($conid = 0) ? $ci->session->get('ogre_conid') : $conid; 
        $ci->convention->init($conid);
        $ci->proposal->prop_init(0, $conid);
        $msg = (trim($p["agree"]) == 'No') ? ' You must Agree with the Game Master Guidelines. ' : '';
        $msg .= (trim($p["gmname"]) == "") ? ' Your name is required. ' : '';
        $msg .= (trim($p["gmemail"]) == "") ? ' Your email address is required. ' : '';
        $inputErr = (trim($msg) != '') ? TRUE : FALSE;
        if ($inputErr != TRUE){
            $ins = $ci->proposal->insertGameRequest($p);
            $ret = ($ins === TRUE) ? $ci->proposal->emailGameRequest($p, $ci->convention->gamingcoordinatoremail, $ins) : ' Error Posting Proposal.  Please contact Gaming Coordinator. ';
        }
        if (!is_array($ret)){
            $ret .= '<p>' . $ret .  '</p>';
            if (trim($msg) != "") {
                $ret .= '<p>' . $msg .  '</p>';
            }                    
        }

        return $ret;
    }
            
//---------------------------------------------------
//
//---------------------------------------------------
    public function getProposalConList($cid=0, $orgid=0){
        $ci=&get_instance();
        date_default_timezone_set("America/New_York");
        $qry = 'SELECT * FROM ogre_convention ';
        $qry .= ' WHERE (con_start_date >= NOW()) OR (con_id='. $cid .') ';
        if ($orgid != 0){
            $qry .= ' AND con_org_id = ' . $orgid;
        }
        $qry .= ' ORDER BY con_start_date;';                       
        $query = $ci->db->query($qry);                      
        $ret = '<select class="form-control my-2" title="Which Con are you Proposing for" name="conlist" id="conlist" size="1" onchange="changeCurrCon(this.options[this.selectedIndex].value);">';
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $sdate = new Time($row->con_start_date);
                $edate = new Time($row->con_end_date);  
                if (intval($edate->Format('m')) == intval($sdate->Format('m'))){
                    if($row->con_eventtype!='day'){
                        $condates = $sdate->Format('F') . ' ' . $sdate->Format('d') . ' - ' . $edate->Format('d') . ', ' . $sdate->Format('Y');
                    }
                    else{
                        $condates = $sdate->Format('F') . " " . $sdate->Format('d') . ', ' . $sdate->Format('Y');
                    }
                }
                else{

                    $condates = $sdate->Format('F') . ' ' . $sdate->Format('d') . ' - ' . $edate->Format('F') . ' ' . $edate->Format('d') . ', ' . $edate->Format('Y');
                }

                if ($cid == $row->con_id){
                    $ret .= '<option value = "' . $row->con_id .'~'.$row->con_name.'~'.$condates. '" selected="selected">' . $row->con_name  . ' (Current)</option>';
                }
                else
                {
                    $ret .= '<option value = "' . $row->con_id .'~'.$row->con_name.'~'.$condates.  '">' . $row->con_name  . '</option>';
                }
            }
        }
        $ret .= '</select>';
        return $ret;
    }       
//---------------------------------------------------
//
//---------------------------------------------------
    public function numberOfProposal($pid=0, $conid=0){
        $ci=&get_instance();
        date_default_timezone_set("America/New_York");    
        $cconid = $ci->session->ogre_conid;
        $orgid = $ci->session->ogre_orgid;        
        $qry = 'SELECT * FROM ogre_convention ';
        if($conid==0){
            $qry .= ' WHERE (con_start_date >= NOW()) OR (con_id='. $cconid .') ';
        }
        else{
            $qry .= ' WHERE (con_id='. $conid .') '; 
        }
        if ($orgid != 0){
            $qry .= ' AND con_org_id = ' . $orgid;
        }        
        $grtotal = 0;      
        $qry .= ' ORDER BY con_start_date;';  
        $query = $ci->db->query($qry);                      
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                $sql = 'SELECT gr_id FROM ogre_gamerequest';
                $sql .= ' WHERE gr_con_id = ' . $row->con_id;
                $sql .= ' AND gr_gm_id = ' . $pid; 
                $sql .= ' AND gr_delete = 0';                  
                $qrygr = $ci->db->query($sql);
                $grtotal = $grtotal + $qrygr->getNumRows();
            }
        }
        return $grtotal;
    }      
//---------------------------------------------------
//
//---------------------------------------------------
    public function registrationHandling($orgid, $ctype){
        $ci=&get_instance();
        $ret = '';
        $conid = $ci->session->ogre_conid;
        $clist1 = $ci->ogre_lib->getMiscContent('%PROPOSAL.PREREG.REG.HANDLING.LIST%',$conid);
        $clist2 = explode(',', $clist1['content']);
        if($ctype==0){
        $ret .= '<select class="form-control" title="Prereg/Reg Handling" name="reghandling" id="reghandling" size="1" onchange="changeRegHandling(this.options[this.selectedIndex].value);">';
        foreach ($clist2 as $cid){
            $regh = $ci->ogre_lib->getMiscContent(intval($cid));
            $ret .= '<option value="'.$cid.'"'.(($cid == DEFAULT_GAME_REG_HANDLING) ? 'selected="selected" ' : '').'>'.$regh['title'].'</option>';
        }
        $ret .= '</select>';                  
        }else{
            foreach ($clist2 as $cid){
               $regh = $ci->ogre_lib->getMiscContent(intval($cid));
               $ret .= '<div class="reghandtext" id="rh'.$cid.'" '.(($cid == DEFAULT_GAME_REG_HANDLING) ? '' : 'style="display:none"').'>';
               $ret .='<div class="alert alert-secondary m-3">';
               $ret .= $regh['content'];
               $ret .= '</div></div>';
           }           
        }
        return $ret;
    }
//---------------------------------------------------
//
//---------------------------------------------------         
    public function bggSearch($gtype = 3){  
        $ci = &get_instance();
        $ret = ''; 
        $ret .= '<div id="results" class="results"></div>';
        $ret .= '<div class="row">';
        $ret .= '<div class="col mb-4">';
        $ret .= '<div class="card border-info h-100">';
        $ret .= '<div class="card-body">';
        switch ($gtype){
            case 3:
            case 4:
            case 5:
            case 12:    
                $ret .= '<h6 id="addgl1">Search BGGeek</h6>';
                $type = 'boardgame';
                break;            
            case 11:
            case 18:    
                $ret .= '<h6 id="addgl1"">Search RPGGeek</h6>';
                $type = 'rpg';
                break;           
        }                   
        $ret .= '<div id="bggsearchform">';
        switch ($type){
            case 'boardgame':
                $ret .= '<select class="form-control" name="bggsearchtype" id="bggsearchtype" size="1">';
                $ret .= '<option value="boardgame">Tabletop/Board/Card Game</option>';            
                $ret .= '</select>';
                break;            
            case 'rpg':
                $ret .= '<select class="form-control" name="bggsearchtype" id="bggsearchtype" size="1">';
                $ret .= '<option value="rpg"> RPG </option>';              
                $ret .= '</select>';
                break;           
        }
        
        $ret .= '<div class="input-group m-2">';
        $ret .= '<label for="bggsearch" class="form-label">Search for:</label>';
        $ret .= '<input class="form-control mx-1" placeholder="Keyword"  name="bggsearch" id="bggsearch" type="text" />';
        $ret .= '<span class="input-group-btn">';
        $ret .= '<input name="bgglookup" id="bgglookup" type="button" class="btn btn-primary btn-sm mx-1" value=" Go " onclick="bgglookup_search('."'".$type."'".');" />';
         
        $ret .= '</span>';
        $ret .= '</div>';
        
        $ret .= '<select name="bggresults" id="bggresults" size="5" class="form-control" style="overflow-y: scroll;">';
        $ret .= '<option value="0">[Search Results Appear here]</options>';
        $ret .= '</select>';
        $image_properties = array('src' =>'images/ajax-loader.gif'); 
        $ret .= '<div id="bgg-wait" style="display: none">' . img($image_properties) . '</div>';
        $ret .= '</div>'; // bggsearchform
        $ret .= '<input type="hidden" name="entrymode" id="entrymode" value="0" />';
        $ret .= '<div id="bglmanual" style="display:none">';
        $ret .= '<input class="form-control mx-1" name="bglname" id="bglname" type="text" placeholder="Game Name" />';
  
        $ret .= '<div class="row my-2">';        
        $ret .= '<div class="col-3">';
        $ret .= '<label for="minplay"># of players:</label>';
        $ret .= '</div>';
        $ret .= '<div class="col-3">';       
        $ret .= '<input type="text" id="minplay" name="minplay" type="text" placeholder="Min" value="3" class="form-control"/> ';
        $ret .= '</div>';
        $ret .= '<div class="col-3 text-center">';
        $ret .= ' to ';
        $ret .= '</div>';
        $ret .= '<div class="col-3">';
        $ret .= '<input type="text" id="maxplay" name="maxplay" value="6" placeholder="Max" class="form-control" />'; 
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '<div class="row my-2">';        
        $ret .= '<div class="col-12">';   
        $ret .= '<select class="form-control" name="bgltype" id="bgltype" size="1" >';        
        $ret .=  $ci->proposal->gameTypeSelect('Board/Tabletop Game');
        $ret .= '</select>'; 
        $ret .= '</div>';
        $ret .= '</div>';        
        $ret .= '<div class="row my-2">';        
        $ret .= '<div class="col-12">';        
        $ret .= '<textarea class="form-control" name="gamenotes" id="gamenotes" placeholder="Description (copy and paste text or html)"></textarea>';
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>'; // bglmanual
        $ret .= '</div>';  //Card-body
        $ret .= '</div>';  //card-footer
        $ret .= '</div>'; // card

        $ret .= '</div>'; // col-
        $ret .= '</div>'; // row-
        $ret .= '<div class="row m-2">';
        $ret .= '<div class="col">';
        $ret .= '<label for="gamesystem-bgg">Game Name/Game System/Setting*</label>';
        $ret .= '<input type="text" id="gamesystem-bgg" name="gamesystem-bgg" disabled="disabled" class="form-control  required" placeholder="Game Name" />';
        $ret .= '</div>';
        $ret .= '</div>';  
        
        $ret .= '<div class="row m-2">';
        $ret .= '<div class="col-6">';
        $ret .= '<label for="minplay-bgg">Minimum Players*</label>';
        $ret .= '<input type="text" id="minplay-bgg" name="minplay-bgg" disabled="disabled" class="form-control  required" placeholder="Min Players"/>';
        $ret .= '</div>';
        $ret .= '<div class="col-6">';
        $ret .= '<label for="maxplay-bgg">Maximum Players*</label>';
        $ret .= '<input type="text" id="maxplay-bgg" name="maxplay-bgg" disabled="disabled" class="form-control  required" placeholder="Max Players"/>';
        $ret .= '</div>';
        $ret .= '</div>';
        
        $ret .= '<div class="row m-2">';
        $ret .= '<div class="col">';
        $ret .= '<label for="minplay-bgg">Minimum Play Time</label>';
        $ret .= '<input type="text" id="minplaytime-bgg" name="minplaytime-bgg" disabled="disabled" class="form-control  required" placeholder="Min Play Time"/>';
        $ret .= '</div>';
        $ret .= '</div>';           
        
        $ret .= '<div class="row m-2">';
        $ret .= '<div class="col">';
        $ret .= '<div for="gamesystem">Game Description</div>';
        $ret .= '<div id="bgg-game-desc"></div>';
        $ret .= '</div>';
        $ret .= '</div>';    
        
        $ret .= '<script>$("#bggresults").change(function(){selectBGG();});</script>';    
        return $ret;
    }      
//---------------------------------------------------
//
//---------------------------------------------------    
    private function getHelpAlert($fldn){
        $ret ='';
        $ci = &get_instance();
        $ret .= '<div id="'.$fldn.'-help" class="row m-2" style="display:none;">';
        $ret .= '<div class="col">';       
        $ret .= '<div class="alert alert-warning alert-dismissible" role="alert">';
        $help = $ci->ogre_lib->getMiscContent('%%'.$fldn.'%%');
        $ret .= $help['content'];;
        
        $ret .= '</div>';
        $ret .= '</div>';
        $ret .= '</div>';          
        return $ret;
    }
}?>
