<?php
namespace App\Libraries;
use CodeIgniter\I18n\Time;
 class Convention_lib
 {
		//***********************************
		//
		//
		//
		//***********************************
		public function conventionList($edit=''){
                    $ci=&get_instance();                    
                    $qry = 'SELECT * FROM ogre_convention ORDER BY con_start_date DESC;';
                    $query = $ci->db->query($qry);
                    $ret = '';
                    if ($query->getNumRows() > 0){
                        foreach ($query->getResult() as $row){
                            $ret .= '<br /><br />';
                            $ret .= '<table cellpadding="5" cellspacing="0" border="1" width="100%">';
                            $ret .= '<tr>';
                            $ret .= '<td colspan="2">';
                            $ret .= '<h2>' . $row->con_name . '</h2>' ;
                            $ret .= '</td>';
                            $ret .= '</tr>';

                            $ret .= '<tr>';
                            $ret .= '<td width="30%">';
                            $ret .= 'Con ID';
                            $ret .= '</td>';
                            $ret .= '<td>';
                            $ret .= $row->con_msa_id;
                            $ret .= '</td>';
                            $ret .= '</tr>';

                            $ret .= '<tr>';
                            $ret .= '<td width="30%">';
                            $ret .= 'Name';
                            $ret .= '</td>';
                            $ret .= '<td>';
                            $ret .= $row->con_name;
                            $ret .= '</td>';
                            $ret .= '</tr>';

                            $ret .= '<tr>';
                            $ret .= '<td width="30%">';
                            $ret .= 'Year';
                            $ret .= '</td>';
                            $ret .= '<td>';
                            $ret .= $row->con_year;
                            $ret .= '</td>';
                            $ret .= '</tr>';

                            $ret .= '<tr>';
                            $ret .= '<td width="30%">';
                            $ret .= 'Start Date/Time';
                            $ret .= '</td>';
                            $ret .= '<td>';
                            $ret .= $row->con_start_date . ' ' . $row->con_start_time  ;
                            $ret .= '</td>';
                            $ret .= '</tr>';

                            $ret .= '<tr>';
                            $ret .= '<td width="30%">';
                            $ret .= 'End Date Time';
                            $ret .= '</td>';
                            $ret .= '<td>';
                            $ret .= $row->con_end_date . ' ' . $row->con_end_time ;
                            $ret .= '</td>';
                            $ret .= '</tr>';

                            $ret .= '<tr>';
                            $ret .= '<td width="30%">';
                            $ret .= 'Location';
                            $ret .= '</td>';
                            $ret .= '<td>';
                            $ret .= $row->con_location;
                            $ret .= '</td>';
                            $ret .= '</tr>';

                            $ret .= '<tr>';
                            $ret .= '<td width="30%">';
                            $ret .= 'Location Address';
                            $ret .= '</td>';
                            $ret .= '<td>';
                            $ret .= '<br />' . $row->con_loc_address;
                            $ret .= '<br />' . $row->con_loc_city . ', ' . $row->con_loc_state . ' ' . $row->con_loc_zip;
                            $ret .= '<br />' . $row->con_loc_phone;
                            $ret .= '<br />' . $row->con_loc_website;
                            $ret .= '</td>';
                            $ret .= '</tr>';


                            $ret .= '<tr>';
                            $ret .= '<td width="30%">';
                            $ret .= 'Web Site';
                            $ret .= '</td>';
                            $ret .= '<td>';
                            $ret .= $row->con_website;
                            $ret .= '</td>';
                            $ret .= '</tr>';

                            $ret .= '<tr>';
                            $ret .= '<td colspan="2" align="right">';
                            $ret .= '<input class="btn btn-secondary" type="button" value="  Edit  " onclick="self.location=' . "'" . $edit . '&ca=1&conid=' . $row->con_id . "'" . '" />';
                            $ret .= '</td>';
                            $ret .= '</tr>';

                            $ret .= '</table>';
                        }
                    }
                    return $ret;
		}
//***********************************
//
//***********************************
		public function get_conlist($cid=0, $orgid=0){
                    $ci=&get_instance();                  
                    $qry = 'SELECT * FROM ogre_convention ';
                    if ($orgid != 0){
                        $qry .= ' WHERE con_org_id = ' . $orgid;
                    }
                    $qry .= ' ORDER BY con_start_date DESC;';                      
                    $query = $ci->db->query($qry);
                    $ret = '<select name="conlist" size="1">';
                    if ($query->getNumRows() > 0){
                        foreach ($query->getResult() as $row){
                            if ($cid == $row->con_id){
                                $ret .= '<option value = "' . $row->con_id  . '" selected="selected">' . $row->con_name  . '</option>';
                            }
                            else
                            {
                                $ret .= '<option value = "' . $row->con_id  . '">' . $row->con_name  . '</option>';
                            }
                        }
                    }
                    $ret .= '</select>';
                    return $ret;
		}
//***********************************
//
//***********************************
		public function getlastcon(){
                    $ci=&get_instance();
                    $qry = 'SELECT ogre_convention.con_id ';
                    $qry .= ' FROM ogre_convention ';
                    $qry .= ' ORDER BY ogre_convention.con_id DESC LIMIT 1;';
                    $query = $ci->db>query($qry);
                    if ($query->getNumRows() > 0){
                        foreach ($query->getResult() as $row){
                            $ret = $row->con_id;
                        }

                    }
                    return $ret;
		}
//***********************************
//
//***********************************
		public function get_loclist($locid=0){
                    $ci=&get_instance();
                    $conid = $ci->session->ogre_conid;
                    $qry = 'SELECT * ';
                    $qry .= ' FROM ogre_location ';
                    $qry .= ' WHERE loc_con_id = ' . $conid . ';';
                    $qry .= ' AND loc_deleteflag = 0 ';
                    
                    $query = $ci->db->query($qry);
                    $ret = '<select name="loclist_select" id="loclist_select" size="1">';
                    if ($locid == 0){
                        $ret .= '<option value = "0" selected="selected">- SELECT AN LOCATION - </option>';
                    }
                    if ($query->getNumRows() > 0){
                        foreach ($query->getResult() as $row){
                            if ($locid == $row->loc_locationid){
                                $ret .= '<option value = "' . $row->loc_locationid  . '" selected="selected">' . $row->loc_location_name . ' - ' . $row->loc_con_location_name . '</option>';
                            }
                            else{
                                $ret .= '<option value = "' . $row->loc_locationid  . '">' . $row->loc_location_name . ' - ' . $row->loc_con_location_name  . '</option>';
                            }
                        }
                    }
                    $ret .= '</select>';
                    return $ret;
		}
//***********************************
//
//***********************************
		public function viewLocationList($conid=0, $edit=FALSE){
                    $ci=&get_instance();
                    $conid = (($conid == 0)? $ci->session->ogre_conid : $conid);
                    $ci->convention->init($conid);
                    $cntlr = (($ci->organization->ogrecontroller==NULL) ? '' : $ci->organization->ogrecontroller); 
                    $action = base_url() . '/'. $cntlr ."/location";
                    $saveaction = site_url("ogrex/locationIn",'https');
                    $remaction = site_url("ogrex/delLocation",'https');
                    $refreshaction = site_url($cntlr ."/location/x",'https');
                    $tablesaction = site_url("ogrex/tables",'https');
                    $tablessaveaction = site_url("ogrex/tablesIn",'https');
                    $addmoretables = site_url('ogrex/addTables','https');
                    $tablesrefresh = site_url('ogrex/tablesList','https');
                    $importaction = site_url('ogrex/locationsImport','https');
                    $importsaveaction = site_url('ogrex/locationsImportIn','https');
                    if($conid==0){
                        $conid = $ci->session->ogre_conid;                    
                    }
                    $ci->convention->init($conid);
                    $qry = 'SELECT * ';
                    $qry .= ' FROM ogre_location ';
                    $qry .= ' WHERE loc_con_id = ' . $conid;
                    $qry .= ' AND loc_deleteflag = 0 ';
                    $qry .= ' ORDER BY loc_seqnum';
                    $query = $ci->db->query($qry);
                    $ret = '';
                    if ($edit==TRUE){
                          $ret .= '<div class="d-grid gap-2"><input class="btn btn-secondary m-1" name="add" type="button" value="Add New Location" onclick="return addeditLocation(0,'."'".$action.'/0/'.$conid."','".$saveaction."','','".$refreshaction."','".$importaction."','".$importsaveaction."'".');" /></div>';                                                                         // id, action, saveaction, listrefresh, importaction, importsaveaction
                     }                          
                    $ret .= '<div id="locresults" class="results"></div>';
                    $ret .= '<p id="loccontitle"><strong>'.$ci->convention->name.' Locations</strong></p>';
                    $ret .= '<div class="table-responsive">'; 
                    $ret .= '<table id="locationlist_table" class="table table-striped">';
                    $ret .= '<tr>';
                    $ret .= '<th>';
                    $ret .= 'Loc. #';
                    $ret .= '</th>';
                    $ret .= '<th>';
                    $ret .= 'Hotel Name';
                    $ret .= '</th>';
                    $ret .= '<th>';
                    $ret .= 'Con Name';
                    $ret .= '</th>';
                    $ret .= '<th>';
                    $ret .= 'Table Prefix';
                    $ret .= '</th>';
                    $ret .= '<th>';
                    $ret .= '# of Tables';
                    $ret .= '</th>'; 
                    if ($edit==TRUE){
                        $ret .= '<th>';
                        $ret .= 'Tables Edit';
                        $ret .= '</th>';
                        $ret .= '<th>';
                        $ret .= 'Delete';
                        $ret .= '</th>';   
                    }
                    $ret .= '</tr>';
                    if ($query->getNumRows() > 0){
                        foreach ($query->getResult() as $row){
                            $ret .= '<tr>';
                            
                            $ret .= '<td>';
                            $ret .= $row->loc_seqnum;
                            $ret .= '</td>';
                            
                            $ret .= '<td>';
                            $editlink1='<a href="#" id="editloc' . $row->loc_locationid . '" name="editloc' . $row->loc_locationid . '" title="Click Location Name ot Edit" onclick="return addeditLocation('.$row->loc_locationid.','."'".$action."/".$row->loc_locationid.'/'.$conid."','".$saveaction."','".$remaction."','".$refreshaction."','".$importaction."','".$importsaveaction."'".');">'.$row->loc_location_name.'</a>';
                            $ret .= (($edit==TRUE) ? $editlink1 :$row->loc_location_name);                       
                            $ret .= '</td>';
                            
                            $ret .= '<td>';
                            $editlink2='<a href="#" id="editloc' . $row->loc_locationid . '" name="editloc' . $row->loc_locationid . '" title="Click Location Name ot Edit" onclick="return addeditLocation('.$row->loc_locationid.','."'".$action."/".$row->loc_locationid.'/'.$conid."','".$saveaction."','".$remaction."','".$refreshaction."','".$importaction."','".$importsaveaction."'".');">'.$row->loc_con_location_name.'</a>';
                            $ret .= (($edit==TRUE) ? $editlink2 :$row->loc_con_location_name);  
                            $ret .= '</td>';
                            
                            $ret .= '<td>';
                            $ret .= $row->loc_table_prefix;
                            $ret .= '</td>';
                            
                            $ret .= '<td>';
                            $ret .= $row->loc_last_table_number;
                            $ret .= '</td>';     
                            if ($edit==TRUE){
                                $ret .= '<td class="locationlist_table_tblbutton">';
                                $ret .= '<input class="btn btn-secondary" name="edittbl' . $row->loc_locationid . '" type="button" value="Tables" onclick="addeditLocationTables('.$row->loc_locationid.",'". $tablesaction.'/'.$row->loc_locationid ."','".$tablessaveaction."','".$addmoretables."','".$tablesrefresh."','".$refreshaction."'".');" />';
                                $ret .= '</td>';

                                $ret .= '<td>';
                                $ret .= '<input type="checkbox" id="remove'. $row->loc_locationid . '" name="remove'. $row->loc_locationid . '" value="Delete" title="Click this to delete location." onclick="remLocation(' . $row->loc_locationid . ',' . "'".  $remaction . "','". $refreshaction ."'". ')" />';
                                $ret .= '</td>'; 
                            }
                            $ret .= '</tr>';
                        }
                    }
                    $ret .= '</table>';
                    $ret .= '</div>';
                 if ($edit==TRUE){
                          $ret .= '<table id="locationlist_table_addbottom" class="locationlist_table">';  
                          $ret .= '<tr>';
                          $ret .= '<td class="locationlist_table_addbutton">';
                          $ret .= '<input class="btn btn-secondary" name="add" type="button" value="Add New Location" onclick="return addeditLocation(0,'."'".$action.'/0/'.$conid."','".$saveaction."','','".$refreshaction."','".$importaction."','".$importsaveaction."'".');" />';                                                                         // id, action, saveaction, listrefresh, importaction, importsaveaction
                          $ret .= '</td>';
                          $ret .= '</tr>';
                          $ret .= '</table>';
                     }                        
                    return $ret;
		}
//***********************************
//
//***********************************
    public function getTableTypeList($ttid=0,$locid=0){
        $ci=&get_instance();
        $qry = 'SELECT * FROM ogre_table_type;';
        $query = $ci->db->query($qry);
        $ret = '<select name="table_type" size="1">';
        if ($locid == 0){
            $ret .= '<option value = "0" selected="selected">- SELECT TABLE TYPE - </option>';
        }
        if ($query->getNumRows() > 0){
            foreach ($query->getResult() as $row){
                if ($ttid == $row->tt_id){
                    $ret .= '<option value = "' . $row->tt_id  . '" selected="selected">' . $row->tt_type  . '</option>';
                }
                else{
                    $ret .= '<option value = "' . $row->tt_id  . '">' . $row->tt_type . '</option>';
                }
            }
        }
        $ret .= '</select>';
        return $ret;
    }
//***********************************
//
//***********************************
    public function slotLengthSelect($n, $l=0){
        $ret = '<select class="form-select" id="' . $n . '" name="' . $n . '" size="1">';
        if ($l==0){
            $ret .= '<option value="0" selected="selected">';
            $ret .= 'In Hours';
            $ret .= '</option>';
        }
        for ($i = 1; $i <= 36; $i++){
            if ($i/2 == $l){
                $ret .= '<option value="' . $i/2 . '" selected="selected">  ';
                $ret .= $this->process_hour_option($i);
                $ret .= '  </option>';
            }
            else
            {
                $ret .= '<option value="' . $i/2 . '">  ';
                $ret .= $this->process_hour_option($i);
                $ret .= '  </option>';
            }
        }
        $ret .= '</select>';
        return $ret;
    }
    //***********************************
    //
    //
    //
    //***********************************
    public function slotLengthSelectBoot($n, $lbl, $l=0){
        $ret = ''; 
        $ret .= '<div class="form-group my-1">';
        $ret .= '<div class="input-group my-1">';       
        $ret .= '<label class="form-label" for="slot_length">';      
        $ret .= $lbl;
        $ret .= '</label>';
        $ret .= '<select class="form-select" id="' . $n . '" name="' . $n . '" size="1">';
        if ($l==0){
            $ret .= '<option value="0" hidden="hidden" selected="selected">';
            $ret .= 'In Hours';
            $ret .= '</option>';
        }
        for ($i = 1; $i <= 36; $i++){
            if ($i/2 == $l){
                $ret .= '<option value="' . $i/2 . '" selected="selected">  ';
                $ret .= $this->process_hour_option($i);
                $ret .= '  </option>';
            }
            else
            {
                $ret .= '<option value="' . $i/2 . '">  ';
                $ret .= $this->process_hour_option($i);
                $ret .= '  </option>';
            }
        }
        $ret .= '</select>';
        $ret .= '</div>';
        $ret .= '</div>';          
        return $ret;
    }    
   
    
    //---------------------------------------------------
    //
    //  
    //
    //---------------------------------------------------      
    private function process_hour_option($i){
        $ret = '';
        if ($i == 1){
            $ret .= $i/2;
        }
        else{
            if (fmod($i,2) == 0){
                $ret .= $i/2 . ".0";
            }
            else{
                $ret .= $i/2;
            }
        }  
        return $ret;
    }            
            //---------------------------------------------------
            //
            //  
            //
            //---------------------------------------------------                  
            public function conventionSelect($orgid=0, $conid=0, $n="", $onchange=''){
                $ci=&get_instance();
                $ret='';              
                $qry = 'SELECT con_id, con_name, con_year FROM ogre_convention ';
                $qry .= ' WHERE con_start_date>=NOW() ';
                $qry .= ' AND con_org_id='.$orgid;
                $qry .= ' ORDER BY con_start_date;';
                $n = (($n==="")?"confilter":$n);
                $ret .= '<div id="convention-filer-select">';
                $ret .= '<label for="'.$n.'">Filter by Convention</label>';
                $ret .= '<select class="form-control" name="'.$n.'" id="'.$n.'" size="1" '. $onchange .'>';
                $ret .= '<option value = "0">ALL</option>';    
                $query = $ci->db->query($qry);
                $ret .= '<optgroup label="Active">';
                if ($query->getNumRows() > 0){
                    foreach ($query->getResult() as $row){     
                        if ($conid == $row->con_id){
                          $ret .= '<option value = "' . $row->con_id  . '" selected="selected">' . $row->con_name .' '. '</option>';
                        }
                        else {
                          $ret .= '<option value = "' . $row->con_id  . '">' . $row->con_name .' '. '</option>';
                        }                  
                    }   
                }
                $ret .= '</optgroup>';
                $qry = 'SELECT con_id, con_name, con_year FROM ogre_convention WHERE con_start_date<NOW() AND con_org_id='.$orgid .' ORDER BY con_start_date DESC;';
                $query = $ci->db->query($qry);
                $ret .= '<optgroup label="Past">';
                if ($query->getNumRows() > 0){
                    foreach ($query->getResult() as $row){     
                        if ($conid == $row->con_id){
                          $ret .= '<option value = "' . $row->con_id  . '" selected="selected">' . $row->con_name .' '. '</option>';
                        }
                        else {
                          $ret .= '<option value = "' . $row->con_id  . '">' . $row->con_name .' '. '</option>';
                        }                  
                    }   
                }
                $ret .= '</optgroup>';                
                $ret .= '</select>';
                $ret .= '</div>';                
                return $ret;
            }                
}?>
